#!/usr/bin/env bash
set -Eeuo pipefail
PASS="${SKVM_ROOT_PASSWORD:-admin123}"
HN="${SKVM_HOSTNAME:-skvm-vps}"
hostname "$HN" 2>/dev/null || true
printf 'root:%s\n' "$PASS" | chpasswd
mkdir -p /run/sshd
cat >/etc/ssh/sshd_config.d/99-skvm.conf <<CFG
PermitRootLogin yes
PasswordAuthentication yes
KbdInteractiveAuthentication no
UsePAM yes
PrintMotd no
CFG
/usr/sbin/sshd
exec tail -f /dev/null
