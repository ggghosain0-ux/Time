#!/usr/bin/env node
'use strict';
/**
 * Create or update a panel user from the CLI.
 *
 *   node scripts/createuser.js --user admin --pass secret123 --role owner
 *   node scripts/createuser.js --user bob --pass hunter222        # regular user
 *   node scripts/createuser.js --list
 *   node scripts/createuser.js --user bob --pass newpass --reset-password
 */
const db = require('../src/db');
const auth = require('../src/auth');
const { uid } = require('../src/utils');

function arg(name, fallback = null) {
  const i = process.argv.indexOf(`--${name}`);
  if (i !== -1 && process.argv[i + 1] && !process.argv[i + 1].startsWith('--')) return process.argv[i + 1];
  return process.argv.includes(`--${name}`) ? true : fallback;
}

(async function main() {
  db.load();
  const users = db.get('users');

  if (arg('list')) {
    if (!users.length) return console.log('No users yet - create one with --user <name> --pass <password>');
    console.log('ID                     USERNAME        ROLE    CREATED');
    for (const u of users) console.log(`${u.id.padEnd(22)} ${u.username.padEnd(15)} ${u.role.padEnd(7)} ${(u.createdAt || '').slice(0, 10)}`);
    return;
  }

  const username = arg('user') || arg('username');
  const password = arg('pass') || arg('password');
  const role = arg('role') || 'user';
  const email = arg('email') || '';
  if (!username || !password) {
    console.error('Usage: node scripts/createuser.js --user <name> --pass <password> [--role owner|admin|user] [--email a@b.c] [--list]');
    process.exit(1);
  }
  if (!auth.ROLES[role]) return console.error(`Invalid role "${role}" (owner|admin|user)`);

  const existing = users.find((u) => u.username.toLowerCase() === String(username).toLowerCase());
  const hashed = await auth.hashPassword(password);

  if (existing) {
    db.update('users', existing.id, { password: hashed, role, passwordVersion: (existing.passwordVersion || 0) + 1, suspended: false });
    console.log(`Updated user "${username}" (role: ${role}, password reset)`);
  } else {
    db.insert('users', {
      id: uid('usr'), username, email, password: hashed, role, passwordVersion: 0,
      createdAt: new Date().toISOString(), suspended: false, createdBy: 'cli',
    });
    console.log(`Created user "${username}" with role "${role}"`);
  }
  await db.flush();
})();
