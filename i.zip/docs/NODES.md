# Nodes, the local node installer and server runtimes

This document explains how Zenith Panel runs Minecraft servers, how the **Local Node** is created
automatically during installation, how to switch a node between the *process* runtime and the *Docker
container* runtime, and what to do when something is wrong.

> **Nothing here is simulated.** Every capability is probed (`docker version`, `java -version`, `df`,
> `/proc`, an HTTP round-trip to the agent), every failure prints the command output that caused it,
> and a node is only marked **online** after its health checks pass.

---

## 1. Concepts

| Term | Meaning |
|---|---|
| **Panel** | this Node.js process (`node server.js`) - HTTP API, WebSocket console, UI |
| **Node** | a machine that can host servers. The panel host itself is one (`local`, always named **Local Node**) |
| **Runtime / backend** | how a server is executed on a node: `process` (java child process) or `docker` (one container per server) |
| **Allocation** | a TCP+UDP port from the node's port range assigned to a server |
| **Agent** | the tiny HTTP service (`scripts/node-agent.js`, systemd unit `zenith-node`) that lets the panel drive a *different* machine |

Two ways to run a server on a node:

```
process runtime                      docker runtime
─────────────────                    ──────────────────────────────
panel ──spawn──► java -jar …         panel ──docker start -a -i──► container
  • child process of the panel         • eclipse-temurin:<java>-jre
  • cwd = servers/<id>                 • -v servers/<id>:/data
  • console = stdout/stdin             • -p <port>:<port>/{tcp,udp}
  • stats from /proc                   • --memory <Xmx+384>m, --cpus
  • needs a JRE on the host            • JVM lives inside the image
```

Both give the same panel experience: live console, player list, one-click player actions, files, backups.

---

## 2. What `install.sh` does for the node

```
bash install.sh                 # panel + Local Node (java processes)
bash install.sh --node docker   # panel + Local Node running servers in containers
bash install.sh --node remote   # panel + this host attached through the agent API
bash install.sh --node none     # panel only
```

Order of operations (all idempotent):

1. **Detect** — cores (`getconf`), RAM (`/proc/meminfo`), disk (`df -Pm`), public IP (ipify/ifconfig.me/icanhazip),
   local IP (`ip route get 1.1.1.1`), Java version, Docker availability. All of it is printed and stored on the node.
2. **Docker** (only when needed) — Docker's GPG key + apt repository for your distro, `docker-ce`,
   `containerd.io`, `docker-buildx-plugin`, `docker-compose-plugin`, service enable/start, `usermod -aG docker`
   for the installing user, then a **real** `docker run --rm eclipse-temurin:<java>-jre java -version` smoke test.
3. **Wings** (`--wings auto` = only with Docker) — downloads the real Pterodactyl wings binary, writes
   `/etc/pterodactyl/config.yml` with a **generated** UUID/token, installs and starts the `wings` systemd unit,
   then verifies it answers on its API port.
4. **Panel boot** — creates the owner account, writes `.env` (`PORT`, `JWT_SECRET`, `NODE_RUNTIME`, `SFTP_PORT`, …)
   and starts the panel.
5. **Registration** — `OWNER_SECRET` (32 random bytes, stored in `.env`, mode 600) is sent as `x-owner-secret` to
   `POST /api/nodes/auto-register` with the detected facts. The panel creates or refreshes **Local Node** and returns a
   node token **once**; the installer stores it root-only in `/etc/zenith/node.env`.
6. **Reporter** — `/usr/local/bin/zenith-node-report` + a systemd timer (or a cron entry) refreshes the node every
   60 s: detected resources, backend, status.
7. **Health check** — `POST /api/nodes/:id/health-check` (local nodes are checked by the panel itself):
   panel process, CPU, memory, disk, java, docker (REQUIRED when the node uses containers) and whether the first
   allocation is bindable. The node's `status` becomes `online` **only** if every check passes.
8. **Proof** — with the docker backend a throwaway container really starts before the installer finishes.

Everything is appended to `${TMPDIR:-/tmp}/zenith-install-<timestamp>.log`; uninstall keeps
`data/ servers/ backups/` unless you pass `--purge`.

### Flags

| Flag | Effect |
|---|---|
| `--node local\|docker\|remote\|none` | node mode (default `local`) |
| `--node-runtime process\|docker` | explicit backend override |
| `--docker auto\|yes\|no` | install/repair Docker and the compose plugin |
| `--wings auto\|yes\|no` | install the real wings daemon + local node config |
| `--node-port`, `--wings-port`, `--sftp-port` | ports for agent / wings / SFTP |
| `--repair` | re-detect, fix Docker/wings/agent, re-register, re-run health checks |
| `--node-only` | only the node part (panel untouched) |
| `--update` | git pull + npm install + restart + refresh the node registration |
| `--uninstall [--purge]` | stop and remove services; `--purge` also removes credentials, wings and containers |

---

## 3. Admins: managing a node from the panel

**Nodes page**

* Status badge is real: `online`, `offline` or `not checked` (never a default green).
* **check** runs the health check and shows a table of every measured check with its detail string; the same modal
  offers **Repair node** (re-detect, drop an impossible backend choice, re-run the checks, refresh the registration).
* **gear** opens node settings: name/description, FQDN/port/scheme (remote nodes), **server runtime** (processes or
  containers), **container image**, port range, CPU/memory/disk limits and maintenance mode.
  * Choosing containers while the engine is unreachable is **refused with Docker's own error**.
  * Shrinking the port range is refused while servers still sit outside it (the error lists their ports).
* **Docker** opens the engine card: version, API version, storage driver, host CPU/RAM, images (with *Pull an image*),
  and every container the panel owns with its state and published ports.

**Admin → Settings**

* *New servers run as* — panel-wide default runtime, plus the default container image.
* *SFTP* — enable/disable and change the port; the state line shows the live listener and the exact error when it is down.
  *Restart SFTP* rebinds it without restarting the panel.

**API**

| Method | Path | Purpose |
|---|---|---|
| `GET` | `/api/system/docker` | engine probe, counts, images, panel containers, exact error |
| `POST` | `/api/system/docker/verify` | re-probe and list containers |
| `GET` | `/api/system/docker/images` | images on the host |
| `POST` | `/api/system/docker/pull` | `{ "image": "eclipse-temurin:21-jre" }` - real `docker pull` |
| `GET` | `/api/system/sftp` | SFTP listener state, open sessions |
| `POST` | `/api/system/sftp/{start,stop,restart}` | control the listener |
| `GET` | `/api/nodes/detect` | measured host facts (`?deep=false` for cached probes) |
| `POST` | `/api/nodes/auto-register` | register/refresh a node (`x-owner-secret` or admin JWT) |
| `PATCH` | `/api/nodes/:id` | identity, runtime, image, allocations, limits, maintenance |
| `POST` | `/api/nodes/:id/health-check` | run the checks (200 healthy / 409 with the failures) |
| `POST` | `/api/nodes/:id/repair` | re-detect + re-check, returns the actions taken |
| `GET` | `/api/nodes/:id/containers` | what Docker is really running for this panel |

---

## 4. Choosing a runtime per server

`backendFor(server)` resolves in this order: `server.backend` → `node.backend` → `NODE_RUNTIME` → `process`.
The create wizard can set it per server (`"backend": "docker"`); the node default is what the node's settings say.

Docker specifics (`src/services/runtime.js`, `src/services/docker.js`):

| Step | What happens |
|---|---|
| image | `eclipse-temurin:<server.javaVersion>-jre`, overridable per server/node; pulled with 3 retries, streamed into the console |
| create | `docker create --name zenith-<server id> -i -w /data -v <servers>/<id>:/data --memory <Xmx+384>m --memory-swap <same> [-p <port>:<port>/tcp -p <port>:<port>/udp] [-e …] <image> java <jvm args> -jar <jar> nogui` |
| start | `docker start -a -i` → stdout **and** stdin are attached, so `say`, `op`, `stop`, … work exactly like the process runtime |
| stats | `docker stats --no-stream` (CPU%, memory against the cgroup limit, PIDs, net/block IO) |
| stop | the JVM's own stop command on stdin, then `docker stop -t 15`, then `docker kill` as a last resort |
| crash | container exit code is logged; `AUTO_RESTART_ON_CRASH=true` restarts it after 5 s |
| panel restart | running containers are adopted on boot (`runtime.reconcileContainers()`), so nothing is started twice or forgotten |

Remote nodes get the same feature from the agent: `POST /api/node/servers/:id/provision` accepts
`{"containerRuntime":"docker","dockerImage":"…"}`, the agent creates the container and `start` attaches with
`docker start -a -i`. `GET /api/node/status` reports `containerRuntime: { available, engine, error }` so the panel
shows the truth for that box too.

---

## 5. Troubleshooting

| Symptom | What it means | Fix |
|---|---|---|
| Nodes page: *Docker is not available* with `spawnSync docker ENOENT` | the `docker` binary is not on the panel's `PATH` | install Docker (`bash install.sh --repair --node docker`) or keep using the process runtime |
| `Cannot connect to the Docker daemon at unix:///var/run/docker.sock` | the CLI exists, `dockerd` is not running | `systemctl start docker` (check `journalctl -u docker -n 40`) |
| `permission denied … /var/run/docker.sock` | the panel user is not in the `docker` group | `usermod -aG docker <user>`, then restart the panel |
| start fails with `docker pull … failed after 3 attempts` | registry/egress problem | the console shows the last lines from Docker; check DNS/proxy or pre-pull the image |
| server marked **crashed** right after start with a docker error | the container could not be created/started | read the console line the panel wrote; fix, then start again |
| node stays **offline** after install | at least one health check failed | Nodes → **check** shows the failing check and its error; **Repair node** afterwards |
| `port 2022 is already in use` (SFTP) | something else owns the port (sshd, wings SFTP on 2022) | Admin → Settings → change the SFTP port, or stop the other service |
| `the ssh2 package is not installed` | optional dependency missing after a manual update | `npm install ssh2` in the panel directory, then restart |
| `wings did not start` | the daemon crashed on boot | `journalctl -u wings -n 60` (its config is `/etc/pterodactyl/config.yml`) |

Every one of these strings is the *actual* error the panel received - the UI never replaces a failure with a
success message.

---

## 6. Uninstall / cleanup

```bash
bash install.sh --uninstall              # stop panel services; keeps data/, servers/, backups/
bash install.sh --uninstall --purge      # also: node credentials, /opt/zenith-node, wings, containers
docker ps -a --filter name=zenith-       # inspect what Docker kept
docker rm -f $(docker ps -aq --filter name=zenith-)   # manual container cleanup
```

`/etc/zenith/node.env` holds the node credentials (mode 600, root only) and `/etc/pterodactyl/config.yml` the wings
configuration. Both are only removed by `--purge`.
