#!/bin/sh
set -eu
mkdir -p /run/sshd
echo "root:${ROOT_PASSWORD:-root123}" | chpasswd
sed -ri 's/^#?PermitRootLogin .*/PermitRootLogin yes/' /etc/ssh/sshd_config
sed -ri 's/^#?PasswordAuthentication .*/PasswordAuthentication yes/' /etc/ssh/sshd_config
/usr/sbin/sshd
exec tail -f /dev/null
