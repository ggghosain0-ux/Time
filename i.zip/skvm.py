import os
import re
import secrets
import shlex
import threading
import time
from datetime import datetime, timezone
from functools import wraps
from pathlib import Path

from flask import Flask, render_template, render_template_string, request, redirect, url_for, flash, abort, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash

try:
    import docker
except Exception:
    docker = None

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "skvm.db"
app = Flask(__name__, template_folder=str(BASE_DIR / "templates"))
app.config.update(
    SECRET_KEY=os.environ.get("SKVM_SECRET_KEY") or secrets.token_hex(32),
    SQLALCHEMY_DATABASE_URI=f"sqlite:///{DB_PATH}",
    SQLALCHEMY_TRACK_MODIFICATIONS=False,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("SKVM_COOKIE_SECURE", "0") == "1",
    MAX_CONTENT_LENGTH=1 * 1024 * 1024,
)
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"
login_manager.login_message = "Please sign in to continue."

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default="user")
    created_at = db.Column(db.DateTime, nullable=False, default=lambda: datetime.now(timezone.utc))
    vps = db.relationship("VPS", backref="owner", lazy=True, cascade="all, delete-orphan")
    def set_password(self, password): self.password_hash = generate_password_hash(password)
    def check_password(self, password): return check_password_hash(self.password_hash, password)

class VPS(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False, index=True)
    node = db.Column(db.String(100), nullable=False, default="Local-Node-1")
    ram = db.Column(db.Integer, nullable=False)       # MB
    disk = db.Column(db.Integer, nullable=False)      # requested GB
    cpu = db.Column(db.Integer, nullable=False)
    os = db.Column(db.String(50), nullable=False)
    container_id = db.Column(db.String(128), nullable=True, index=True)
    tmate_token = db.Column(db.Text, nullable=True)
    status = db.Column(db.String(30), nullable=False, default="Provisioning")
    error_message = db.Column(db.Text, nullable=True)
    progress = db.Column(db.Integer, nullable=False, default=0)
    progress_message = db.Column(db.String(255), nullable=True)
    provision_attempt = db.Column(db.Integer, nullable=False, default=0)
    disk_enforced = db.Column(db.Boolean, nullable=False, default=False)
    disk_status = db.Column(db.String(500), nullable=True)
    created_at = db.Column(db.DateTime, nullable=False, default=lambda: datetime.now(timezone.utc))

class Settings(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    panel_name = db.Column(db.String(120), nullable=False, default="SKVM Panel")
    logo_url = db.Column(db.String(1000))
    banner_url = db.Column(db.String(1000))
    background_url = db.Column(db.String(1000))

def now(): return datetime.now(timezone.utc)

@app.template_filter("dt")
def format_dt(value):
    if not value: return "—"
    if value.tzinfo is None: value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc).strftime("%d %b %Y, %H:%M UTC")

def get_docker():
    if docker is None: return None
    try:
        client = docker.from_env(timeout=10)
        client.ping()
        return client
    except Exception:
        return None

def csrf():
    token = session.get("_csrf")
    if not token:
        token = secrets.token_urlsafe(32)
        session["_csrf"] = token
    return token
app.jinja_env.globals["csrf_token"] = csrf

@app.before_request
def csrf_guard():
    if request.method in {"POST", "PUT", "PATCH", "DELETE"}:
        sent = request.form.get("_csrf") or request.headers.get("X-CSRF-Token")
        expected = session.get("_csrf")
        if not expected or not sent or not secrets.compare_digest(str(sent), str(expected)):
            abort(400, description="Invalid CSRF token.")

@app.context_processor
def inject_globals():
    return {"site": Settings.query.first() or Settings(panel_name="SKVM Panel"), "now": now()}

@login_manager.user_loader
def load_user(user_id):
    try: return db.session.get(User, int(user_id))
    except Exception: return None

def admin_required(fn):
    @wraps(fn)
    @login_required
    def wrapper(*args, **kwargs):
        if current_user.role != "admin": abort(403)
        return fn(*args, **kwargs)
    return wrapper

def migrate_schema():
    db.create_all()
    inspector = db.inspect(db.engine)
    if "vps" not in inspector.get_table_names(): return
    columns = {c["name"] for c in inspector.get_columns("vps")}
    additions = {
        "progress": "INTEGER NOT NULL DEFAULT 0",
        "progress_message": "VARCHAR(255)",
        "provision_attempt": "INTEGER NOT NULL DEFAULT 0",
        "disk_enforced": "BOOLEAN NOT NULL DEFAULT 0",
        "disk_status": "VARCHAR(500)",
        "error_message": "TEXT",
    }
    with db.engine.begin() as conn:
        for name, ddl in additions.items():
            if name not in columns:
                conn.exec_driver_sql(f"ALTER TABLE vps ADD COLUMN {name} {ddl}")

def seed():
    db.create_all()
    if not Settings.query.first(): db.session.add(Settings(panel_name="SKVM Panel"))
    username = os.environ.get("SKVM_ADMIN_USERNAME", "admin").strip() or "admin"
    password = os.environ.get("SKVM_ADMIN_PASSWORD", "admin123")
    admin = User.query.filter_by(username=username).first()
    if not admin:
        admin = User(username=username, role="admin"); admin.set_password(password); db.session.add(admin)
    elif admin.role != "admin":
        admin.role = "admin"
    db.session.commit()

def parse_ram(value):
    m = re.fullmatch(r"\s*(\d+)\s*(GB|MB)?\s*", value or "", re.I)
    if not m: raise ValueError("RAM must be like 1GB or 1024MB.")
    n = int(m.group(1)); mb = n if (m.group(2) or "GB").upper() == "MB" else n * 1024
    if not 128 <= mb <= 131072: raise ValueError("RAM must be between 128MB and 128GB.")
    return mb

def parse_disk(value):
    m = re.fullmatch(r"\s*(\d+)\s*(GB)?\s*", value or "", re.I)
    if not m: raise ValueError("Disk must be like 10GB.")
    gb = int(m.group(1))
    if not 1 <= gb <= 2048: raise ValueError("Disk must be between 1GB and 2048GB.")
    return gb

def parse_cpu(value):
    m = re.fullmatch(r"\s*(\d+)\s*(Core|Cores|CPU)?\s*", value or "", re.I)
    if not m: raise ValueError("CPU must be like 1 Core.")
    cpu = int(m.group(1))
    if not 1 <= cpu <= 64: raise ValueError("CPU must be between 1 and 64 cores.")
    return cpu

def image_for(os_name): return {"Ubuntu 22.04":"ubuntu:22.04", "Ubuntu 20.04":"ubuntu:20.04"}.get(os_name)

def exec_container(container, script, timeout=300):
    script = str(script).replace("\x00", "")
    # The outer shell is only used to apply a timeout; the actual script is
    # quoted with shlex.quote so tmate's #{...} format is never mangled.
    wrapped = f"timeout --preserve-status {int(timeout)}s bash -lc {shlex.quote(script)}"
    result = container.exec_run(["bash", "-lc", wrapped], stdout=True, stderr=True)
    output = result.output
    if isinstance(output, tuple): output = b"".join(x or b"" for x in output)
    text = (output or b"").decode("utf-8", errors="replace")
    if result.exit_code != 0:
        raise RuntimeError(text[-6000:] or f"Container command exited with {result.exit_code}")
    return text

def extract_tmate_ssh(text):
    # Accept normal tmate output such as: ssh <token>@nyc1.tmate.io
    patterns = [
        r"(?m)^\s*(ssh\s+(?:-p\s+\d+\s+)?[A-Za-z0-9._:-]+@[A-Za-z0-9._:-]+)\s*$",
        r"(ssh\s+(?:-p\s+\d+\s+)?[A-Za-z0-9._:-]+@[A-Za-z0-9._:-]+)",
    ]
    for pattern in patterns:
        match = re.search(pattern, text or "")
        if match: return match.group(1).strip()
    return None

def update_progress(vps, percent, message, status=None):
    vps.progress = max(0, min(100, int(percent))); vps.progress_message = message
    if status: vps.status = status
    db.session.commit()

def create_container(client, image, vps):
    """Create a resource-limited container without probing storage quotas.

    Generic Docker cannot promise a hard per-container disk quota. In
    particular, Docker-in-Docker/btrfs hosts can reject storage_opt=size with
    EPERM. SKVM therefore never sends storage_opt by default and never turns
    that host capability issue into a provisioning failure. The requested
    disk value remains metadata until the operator configures a host-specific
    quota driver.
    """
    labels = {
        "com.skvm.managed": "true",
        "com.skvm.vps_id": str(vps.id),
        "com.skvm.user_id": str(vps.user_id),
        "com.skvm.disk_requested": f"{vps.disk}G",
    }
    common = dict(
        image=image, command=["bash", "-lc", "sleep infinity"], detach=True,
        mem_limit=vps.ram * 1024 * 1024, nano_cpus=vps.cpu * 1_000_000_000,
        restart_policy={"Name":"unless-stopped"}, labels=labels,
        name=f"skvm-{vps.id}-{secrets.token_hex(4)}",
    )
    mode = os.environ.get("SKVM_DISK_MODE", "compat").lower()
    if mode == "strict":
        raise RuntimeError("SKVM_DISK_MODE=strict requires a Docker host with verified hard quota support. This node must be configured before strict disk enforcement can be enabled.")
    if mode not in {"compat", "auto"}:
        raise RuntimeError("Invalid SKVM_DISK_MODE. Use compat or auto.")
    c = client.containers.run(**common)
    return c, False, f"Requested disk: {vps.disk} GB · hard Docker quota not configured on this node"

PROVISIONING = set()
PROVISION_LOCK = threading.Lock()

def provision(vps_id):
    with PROVISION_LOCK:
        if vps_id in PROVISIONING: return
        PROVISIONING.add(vps_id)
    try:
        _provision(vps_id)
    finally:
        with PROVISION_LOCK: PROVISIONING.discard(vps_id)

def _provision(vps_id):
    with app.app_context():
        vps = db.session.get(VPS, vps_id)
        if not vps: return
        max_attempts = 3
        last_error = None
        for attempt in range(1, max_attempts + 1):
            container = None
            try:
                vps.provision_attempt = attempt; vps.error_message = None; vps.tmate_token = None
                vps.disk_enforced = False; vps.disk_status = None; db.session.commit()
                client = get_docker()
                if not client: raise RuntimeError("Docker Engine is unavailable. Start Docker and grant the SKVM process access to the Docker socket.")
                update_progress(vps, 5, f"Attempt {attempt}/{max_attempts}: connected to Docker", "Provisioning")
                image = image_for(vps.os)
                if not image: raise RuntimeError(f"Unsupported OS: {vps.os}")
                try: client.images.get(image)
                except Exception:
                    update_progress(vps, 14, f"Pulling {image} from Docker Hub…")
                    client.images.pull(image)
                update_progress(vps, 27, "Creating isolated container…")
                container, enforced, disk_message = create_container(client, image, vps)
                vps.container_id = container.id; vps.disk_enforced = enforced; vps.disk_status = disk_message; db.session.commit()
                update_progress(vps, 38, "Installing tmate inside the container…")
                install_script = r"""set -eu
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y --no-install-recommends ca-certificates tmate
command -v tmate >/dev/null 2>&1
tmate -V
"""
                exec_container(container, install_script, 360)
                update_progress(vps, 60, "Starting tmate session…")
                start_script = r"""set -eu
SOCK=/tmp/skvm-tmate.sock
rm -f "$SOCK"
tmate -S "$SOCK" new-session -d -s skvm
sleep 2
tmate -S "$SOCK" has-session -t skvm
"""
                exec_container(container, start_script, 60)
                update_progress(vps, 68, "Waiting for tmate SSH registration…")
                ssh = None; last_output = ""
                timeout_seconds = max(30, min(600, int(os.environ.get("SKVM_TUNNEL_TIMEOUT", "180"))))
                deadline = time.monotonic() + timeout_seconds
                # IMPORTANT: do not use `wait-for-server` or `wait tmate-ready`.
                # Some distro tmate builds do not expose those subcommands.
                # Polling `display` is compatible with those builds and avoids
                # the exact error seen in the old provisioning flow.
                while time.monotonic() < deadline:
                    try:
                        last_output = exec_container(container, r"""SOCK=/tmp/skvm-tmate.sock
tmate -S "$SOCK" display -p '#{tmate_ssh}' 2>&1 || true
""", 15)
                    except Exception as exc:
                        last_output = str(exc)
                    ssh = extract_tmate_ssh(last_output)
                    if ssh: break
                    elapsed = timeout_seconds - max(0, int(deadline - time.monotonic()))
                    pct = 68 + min(22, int((elapsed / timeout_seconds) * 22))
                    update_progress(vps, pct, "Waiting for tmate relay registration…")
                    time.sleep(3)
                if not ssh:
                    raise RuntimeError("tmate SSH session was not registered before the timeout. Check outbound internet/DNS from the Docker container. Last tmate output: " + (last_output[-2000:] or "<empty>"))
                update_progress(vps, 94, "Verifying container…")
                container.reload()
                if container.status != "running": raise RuntimeError(f"Container stopped unexpectedly (status={container.status}).")
                vps.tmate_token = ssh; vps.status = "Active"; vps.progress = 100; vps.progress_message = "VPS is ready."; vps.error_message = None; db.session.commit(); return
            except Exception as exc:
                last_error = str(exc)
                vps.error_message = last_error[-8000:]
                vps.status = "Failed" if attempt == max_attempts else "Retrying"
                vps.progress_message = f"Attempt {attempt}/{max_attempts} failed." + (" Retrying automatically…" if attempt < max_attempts else "")
                db.session.commit()
                if container:
                    try: container.remove(force=True)
                    except Exception: pass
                vps.container_id = None; vps.tmate_token = None; db.session.commit()
                if attempt < max_attempts: time.sleep(3 * attempt)
        vps.status = "Failed"; vps.progress_message = "Provisioning failed. Review the error below."; vps.error_message = last_error or "Unknown provisioning error."; db.session.commit()

def owned_vps(vps_id):
    vps = db.session.get(VPS, vps_id)
    if not vps: abort(404)
    if vps.user_id != current_user.id and current_user.role != "admin": abort(403)
    return vps

@app.route("/")
def starter(): return redirect(url_for("dashboard")) if current_user.is_authenticated else render_template("starter.html")

@app.route("/login", methods=["GET","POST"])
def login():
    if current_user.is_authenticated: return redirect(url_for("dashboard"))
    if request.method == "POST":
        user = User.query.filter_by(username=request.form.get("username", "").strip()).first()
        if user and user.check_password(request.form.get("password", "")):
            login_user(user, remember=True); return redirect(url_for("dashboard"))
        flash("Invalid username or password.", "error")
    return render_template("login.html")

@app.route("/register", methods=["GET","POST"])
def register():
    if current_user.is_authenticated: return redirect(url_for("dashboard"))
    if request.method == "POST":
        username=request.form.get("username","").strip(); password=request.form.get("password","")
        if not re.fullmatch(r"[A-Za-z0-9_.-]{3,32}", username): flash("Username must be 3–32 characters.", "error")
        elif len(password)<8: flash("Password must be at least 8 characters.", "error")
        elif User.query.filter_by(username=username).first(): flash("Username already exists.", "error")
        else:
            u=User(username=username, role="user"); u.set_password(password); db.session.add(u); db.session.commit(); flash("Account created. Please sign in.","success"); return redirect(url_for("login"))
    return render_template("register.html")

@app.post("/logout")
@login_required
def logout(): logout_user(); return redirect(url_for("starter"))

@app.route("/dashboard")
@login_required
def dashboard():
    vps=VPS.query.filter_by(user_id=current_user.id).order_by(VPS.created_at.desc()).all()
    return render_template("dashboard.html", vps_list=vps, active=sum(v.status=="Active" for v in vps), total_ram=sum(v.ram for v in vps))

@app.route("/myvps")
@login_required
def myvps(): return render_template("myvps.html", vps_list=VPS.query.filter_by(user_id=current_user.id).order_by(VPS.created_at.desc()).all())

@app.route("/vps/<int:vps_id>")
@login_required
def vps_details(vps_id): return render_template("vps_details.html", vps=owned_vps(vps_id))

@app.post("/vps/<int:vps_id>/action/<action>")
@login_required
def vps_action(vps_id, action):
    vps=owned_vps(vps_id); client=get_docker(); container=None
    if client and vps.container_id:
        try: container=client.containers.get(vps.container_id)
        except Exception: container=None
    if not container: flash("Docker container is unavailable.","error"); return redirect(url_for("vps_details",vps_id=vps.id))
    try:
        if action=="start": container.start(); vps.status="Active"
        elif action=="stop": container.stop(timeout=10); vps.status="Stopped"
        elif action=="restart": container.restart(timeout=10); vps.status="Active"
        else: abort(400)
        db.session.commit(); flash(f"Container {action} successful.","success")
    except Exception as exc: flash(str(exc),"error")
    return redirect(url_for("vps_details",vps_id=vps.id))

@app.route("/profile", methods=["GET","POST"])
@login_required
def profile():
    if request.method=="POST":
        if not current_user.check_password(request.form.get("current_password","")): flash("Current password is incorrect.","error")
        elif len(request.form.get("new_password",""))<8: flash("New password must be at least 8 characters.","error")
        else: current_user.set_password(request.form["new_password"]); db.session.commit(); flash("Password updated.","success")
    return render_template("profile.html")

@app.route("/admin")
@admin_required
def admin_dashboard():
    client=get_docker(); running=total=0; docker_ok=bool(client); driver="Unavailable"
    if client:
        try:
            info=client.info(); driver=info.get("Driver","Unknown")
            cs=client.containers.list(all=True,filters={"label":"com.skvm.managed=true"}); total=len(cs); running=sum(c.status=="running" for c in cs)
        except Exception: docker_ok=False
    return render_template("admin_dashboard.html",docker_ok=docker_ok,running=running,total_containers=total,users_count=User.query.count(),vps_count=VPS.query.count(),recent_vps=VPS.query.order_by(VPS.created_at.desc()).limit(10).all(),driver=driver)

@app.route("/admin/create-vps",methods=["GET","POST"])
@app.route("/create-vps",methods=["GET","POST"])
@admin_required
def create_vps():
    users=User.query.order_by(User.username.asc()).all()
    if request.method=="POST":
        try:
            owner=db.session.get(User,int(request.form["user_id"]));
            if not owner: raise ValueError("Selected user does not exist.")
            name=request.form.get("name","").strip()
            if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9 _.-]{1,99}",name): raise ValueError("VPS name must be 2–100 characters.")
            v=VPS(name=name,user_id=owner.id,node="Local-Node-1",ram=parse_ram(request.form.get("ram")),disk=parse_disk(request.form.get("disk")),cpu=parse_cpu(request.form.get("cpu")),os=request.form.get("os",""),status="Provisioning")
            if not image_for(v.os): raise ValueError("Unsupported OS.")
            db.session.add(v); db.session.commit(); threading.Thread(target=provision,args=(v.id,),daemon=True).start(); return redirect(url_for("vps_details",vps_id=v.id))
        except Exception as exc: db.session.rollback(); flash(str(exc),"error")
    return render_template("create_vps.html",users=users)

@app.route("/admin/users")
@app.route("/user-management")
@admin_required
def user_management(): return render_template("user_management.html",users=User.query.order_by(User.created_at.desc()).all())

@app.post("/admin/users/<int:user_id>/role")
@admin_required
def change_role(user_id):
    u=db.session.get(User,user_id)
    if not u: abort(404)
    if u.id==current_user.id: flash("You cannot change your own role here.","error")
    else: u.role="user" if u.role=="admin" else "admin"; db.session.commit(); flash("Role updated.","success")
    return redirect(url_for("user_management"))

@app.post("/admin/users/<int:user_id>/delete")
@admin_required
def delete_user(user_id):
    u=db.session.get(User,user_id)
    if not u: abort(404)
    if u.id==current_user.id or u.role=="admin": flash("This account cannot be deleted here.","error")
    else:
        client=get_docker()
        for v in list(u.vps):
            if client and v.container_id:
                try: client.containers.get(v.container_id).remove(force=True)
                except Exception: pass
        db.session.delete(u); db.session.commit(); flash("User deleted.","success")
    return redirect(url_for("user_management"))

@app.route("/admin/settings",methods=["GET","POST"])
@app.route("/settings",methods=["GET","POST"])
@admin_required
def settings():
    s=Settings.query.first()
    if request.method=="POST":
        s.panel_name=request.form.get("panel_name","").strip()[:120] or "SKVM Panel"; s.logo_url=request.form.get("logo_url","").strip()[:1000] or None; s.banner_url=request.form.get("banner_url","").strip()[:1000] or None; s.background_url=request.form.get("background_url","").strip()[:1000] or None; db.session.commit(); flash("Settings saved.","success")
    return render_template("settings.html")

@app.post("/vps/<int:vps_id>/retry")
@login_required
def retry_provision(vps_id):
    vps=owned_vps(vps_id)
    if vps.status!="Failed": flash("This VPS is not currently eligible for retry.","error"); return redirect(url_for("vps_details",vps_id=vps.id))
    vps.status="Provisioning"; vps.progress=0; vps.progress_message="Retry queued…"; vps.error_message=None; db.session.commit(); threading.Thread(target=provision,args=(vps.id,),daemon=True).start(); return redirect(url_for("vps_details",vps_id=vps.id))

@app.get("/api/vps/<int:vps_id>/status")
@login_required
def vps_status_api(vps_id):
    v=owned_vps(vps_id)
    return jsonify(status=v.status,ssh=v.tmate_token,error=v.error_message,progress=v.progress,message=v.progress_message,attempt=v.provision_attempt,disk_enforced=v.disk_enforced,disk_status=v.disk_status)

ERROR_HTML=r"""<!doctype html><html lang="en" class="dark"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Error · {{site.panel_name}}</title><script src="https://cdn.tailwindcss.com"></script><style>body{background:#05070d;color:#e7eaf0}</style></head><body class="min-h-screen grid place-items-center p-5"><div class="max-w-lg text-center"><div class="text-7xl font-black text-indigo-300">{{code}}</div><h1 class="text-2xl font-bold mt-4">{{message}}</h1><a href="{{url_for('starter')}}" class="inline-block mt-6 px-5 py-2.5 rounded-xl bg-indigo-500 font-semibold">Go home</a></div></body></html>"""
@app.errorhandler(400)
def e400(e): return render_template_string(ERROR_HTML,code=400,message=getattr(e,'description','Bad request.')),400
@app.errorhandler(403)
def e403(_): return render_template_string(ERROR_HTML,code=403,message='Access denied.'),403
@app.errorhandler(404)
def e404(_): return render_template_string(ERROR_HTML,code=404,message='Page not found.'),404

with app.app_context(): migrate_schema(); seed()

if __name__=="__main__": app.run(host="0.0.0.0",port=int(os.environ.get("SKVM_PORT","5555")),debug=False,threaded=True)
