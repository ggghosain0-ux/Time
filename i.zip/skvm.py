#!/usr/bin/env python3
import os, sqlite3, subprocess, signal, time, uuid, threading, shutil, random, logging, secrets, re
from pathlib import Path
from functools import wraps
from datetime import datetime
from contextlib import contextmanager

from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify, abort
from werkzeug.security import generate_password_hash, check_password_hash

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
VM_DIR = DATA_DIR / "vms"
DB_PATH = DATA_DIR / "skvm.db"
DATA_DIR.mkdir(exist_ok=True)
VM_DIR.mkdir(exist_ok=True)

app = Flask(__name__)
app.secret_key = os.environ.get("SKVM_SECRET_KEY") or secrets.token_hex(32)
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("SKVM_COOKIE_SECURE","0") == "1",
    PERMANENT_SESSION_LIFETIME=86400,
)
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("skvm")

DEFAULT_PASSWORD = os.environ.get("SKVM_ADMIN_PASSWORD", "admin123")
PUBLIC_IP = os.environ.get("SKVM_PUBLIC_IP", "").strip() or "127.0.0.1"
PORT_MIN, PORT_MAX = 10000, 60000

OS_TEMPLATES = {
    "ubuntu-22.04": {"name":"Ubuntu 22.04", "url":"https://cloud-images.ubuntu.com/jammy/current/jammy-server-cloudimg-amd64.img"},
    "ubuntu-24.04": {"name":"Ubuntu 24.04", "url":"https://cloud-images.ubuntu.com/noble/current/noble-server-cloudimg-amd64.img"},
    "debian-12": {"name":"Debian 12", "url":"https://cloud.debian.org/images/cloud/bookworm/latest/debian-12-generic-amd64.qcow2"},
}

def conn():
    c=sqlite3.connect(DB_PATH, timeout=30, check_same_thread=False)
    c.row_factory=sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA busy_timeout=10000")
    return c

def db(sql, params=(), one=False, all=False):
    last=None
    for _ in range(5):
        try:
            c=conn(); cur=c.execute(sql, params)
            if all: out=cur.fetchall()
            elif one: out=cur.fetchone()
            else: out=None
            c.commit(); c.close(); return out
        except sqlite3.OperationalError as e:
            last=e; time.sleep(.2)
    raise last

def init_db():
    c=conn()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS users(
      id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
      email TEXT UNIQUE NOT NULL, password TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'user', is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, last_login TEXT
    );
    CREATE TABLE IF NOT EXISTS vps(
      id INTEGER PRIMARY KEY AUTOINCREMENT, vps_id TEXT UNIQUE NOT NULL,
      user_id INTEGER NOT NULL, name TEXT NOT NULL, os_template TEXT NOT NULL,
      ram_mb INTEGER NOT NULL, cpu_cores INTEGER NOT NULL, disk_gb INTEGER NOT NULL,
      ssh_port INTEGER UNIQUE NOT NULL, ssh_user TEXT NOT NULL DEFAULT 'root',
      ssh_password TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'creating',
      pid INTEGER, progress INTEGER NOT NULL DEFAULT 0, step TEXT,
      tmate_ssh TEXT, tmate_web TEXT, error TEXT,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT,
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS notifications(
      id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
      title TEXT NOT NULL, message TEXT NOT NULL, type TEXT DEFAULT 'info',
      is_read INTEGER DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS audit_log(
      id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, action TEXT NOT NULL,
      details TEXT, timestamp TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
    """)
    defaults={
      "site_name":"SKVM Panel","theme":"#6366f1","server_ip":PUBLIC_IP,
      "base_port":str(PORT_MIN)
    }
    for k,v in defaults.items(): c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)",(k,v))
    admin=c.execute("SELECT id FROM users WHERE username='admin'").fetchone()
    if not admin:
        c.execute("INSERT INTO users(username,email,password,role) VALUES(?,?,?,?)",
                  ("admin","admin@skvm.local",generate_password_hash(DEFAULT_PASSWORD),"admin"))
    c.commit(); c.close()

def setting(k, default=""):
    r=db("SELECT value FROM settings WHERE key=?",(k,),one=True)
    return r["value"] if r else default

@app.context_processor
def globals_():
    return {"site_name":setting("site_name","SKVM Panel"),"theme_color":setting("theme","#6366f1"),
            "server_ip":setting("server_ip",PUBLIC_IP)}

def audit(action, details=""):
    try: db("INSERT INTO audit_log(user_id,action,details) VALUES(?,?,?)",
           (session.get("user_id"),action,details))
    except Exception: pass

def notify(uid,title,msg,typ="info"):
    try: db("INSERT INTO notifications(user_id,title,message,type) VALUES(?,?,?,?)",(uid,title,msg,typ))
    except Exception: pass

def login_required(f):
    @wraps(f)
    def w(*a,**kw):
        if "user_id" not in session: return redirect(url_for("login", next=request.path))
        return f(*a,**kw)
    return w

def admin_required(f):
    @wraps(f)
    def w(*a,**kw):
        if "user_id" not in session: return redirect(url_for("login"))
        if session.get("role")!="admin": flash("Admin access required.","danger"); return redirect(url_for("dashboard"))
        return f(*a,**kw)
    return w

def get_vps(vps_id):
    return db("""SELECT v.*,u.username,u.email FROM vps v JOIN users u ON u.id=v.user_id
                 WHERE v.vps_id=?""",(vps_id,),one=True)

def owner_required(f):
    @wraps(f)
    def w(vps_id,*a,**kw):
        v=get_vps(vps_id)
        if not v: abort(404)
        if session.get("role")!="admin" and v["user_id"]!=session.get("user_id"):
            abort(403)
        return f(vps_id,*a,**kw)
    return w

def port_free(port, exclude=None):
    if not (1 <= port <= 65535): return False
    q="SELECT id FROM vps WHERE ssh_port=?"; p=[port]
    if exclude: q+=" AND vps_id!=?"; p.append(exclude)
    if db(q,p,one=True): return False
    # Avoid ports currently bound by host processes.
    r=subprocess.run(["ss","-ltnH"],capture_output=True,text=True)
    return not re.search(rf":{port}\s", r.stdout or "")

def allocate_port():
    for p in range(PORT_MIN,PORT_MAX):
        if port_free(p): return p
    raise RuntimeError("No free SSH ports available")

def vm_dir(vps_id): return VM_DIR/vps_id

class QEMU:
    def alive(self,v):
        pid=v["pid"]
        if pid:
            try: os.kill(int(pid),0); return True
            except OSError: pass
        # Recover pid if qemu process survived but DB lost pid.
        d=vm_dir(v["vps_id"]); pf=d/"qemu.pid"
        if pf.exists():
            try:
                p=int(pf.read_text()); os.kill(p,0); return True
            except: pass
        return False

    def image(self,v):
        d=vm_dir(v["vps_id"]); d.mkdir(parents=True,exist_ok=True)
        img=d/"disk.qcow2"
        if img.exists() and img.stat().st_size > 1024*1024: return img
        src=OS_TEMPLATES[v["os_template"]]["url"]; raw=d/"base.img"
        update(v,10,"Downloading OS image")
        r=subprocess.run(["curl","-fL","--retry","3","--connect-timeout","10","-o",str(raw),src],capture_output=True,text=True,timeout=600)
        if r.returncode: raise RuntimeError("OS image download failed: "+(r.stderr[-500:] or "network error"))
        update(v,45,"Preparing disk")
        r=subprocess.run(["qemu-img","convert","-f","qcow2","-O","qcow2",str(raw),str(img)],capture_output=True,text=True,timeout=300)
        if r.returncode: raise RuntimeError("qemu-img convert failed: "+r.stderr[-500:])
        raw.unlink(missing_ok=True)
        r=subprocess.run(["qemu-img","resize",str(img),f"{v['disk_gb']}G"],capture_output=True,text=True,timeout=60)
        if r.returncode: raise RuntimeError("Disk resize failed: "+r.stderr[-500:])
        return img

    def seed(self,v):
        d=vm_dir(v["vps_id"]); seed=d/"seed.iso"
        pw=v["ssh_password"]
        # cloud-init package is normally included in Ubuntu/Debian cloud images.
        user_data=f"""#cloud-config
hostname: skvm-{v['vps_id'][:8]}
manage_etc_hosts: true
ssh_pwauth: true
disable_root: false
chpasswd:
  expire: false
  list:
    - root:{pw}
users:
  - default
  - name: root
    lock_passwd: false
    shell: /bin/bash
    sudo: ALL=(ALL) NOPASSWD:ALL
runcmd:
  - [ bash, -lc, "echo 'root:{pw}' | chpasswd" ]
  - [ bash, -lc, "mkdir -p /etc/ssh/sshd_config.d && printf 'PermitRootLogin yes\\nPasswordAuthentication yes\\n' > /etc/ssh/sshd_config.d/99-skvm.conf" ]
  - [ bash, -lc, "systemctl restart ssh || systemctl restart sshd || true" ]
"""
        (d/"user-data").write_text(user_data)
        (d/"meta-data").write_text(f"instance-id: {v['vps_id']}\nlocal-hostname: skvm-{v['vps_id'][:8]}\n")
        update(v,70,"Creating cloud-init disk")
        r=subprocess.run(["cloud-localds",str(seed),str(d/"user-data"),str(d/"meta-data")],capture_output=True,text=True,timeout=60)
        if r.returncode: raise RuntimeError("cloud-localds failed: "+r.stderr[-500:])
        return seed

    def start(self,v):
        d=vm_dir(v["vps_id"]); img=d/"disk.qcow2"; seed=d/"seed.iso"; pf=d/"qemu.pid"
        if not img.exists() or not seed.exists(): raise RuntimeError("VM files are missing; recreate this VPS")
        self.stop(v, quiet=True)
        update(v,88,"Starting virtual machine")
        # KVM when available; otherwise TCG fallback so development environments do not fail immediately.
        accel = ["-accel","kvm:tcg"]
        cmd=["qemu-system-x86_64","-name",f"skvm-{v['vps_id'][:8]}","-machine","q35",
             *accel,"-m",str(v["ram_mb"]),"-smp",str(v["cpu_cores"]),
             "-drive",f"file={img},if=virtio,format=qcow2",
             "-drive",f"file={seed},if=virtio,format=raw",
             "-netdev",f"user,id=n0,hostfwd=tcp::{v['ssh_port']}-:22",
             "-device","virtio-net-pci,netdev=n0","-nographic","-daemonize",
             "-pidfile",str(pf)]
        r=subprocess.run(cmd,capture_output=True,text=True,timeout=60)
        if r.returncode: raise RuntimeError("QEMU failed: "+(r.stderr[-800:] or r.stdout[-800:] or "unknown error"))
        for _ in range(20):
            if pf.exists():
                try:
                    pid=int(pf.read_text()); os.kill(pid,0)
                    return pid
                except: pass
            time.sleep(.5)
        raise RuntimeError("QEMU started but no running PID was detected")

    def stop(self,v,quiet=False):
        pid=v["pid"]
        if pid:
            try:
                os.kill(int(pid),signal.SIGTERM)
                for _ in range(10):
                    try: os.kill(int(pid),0); time.sleep(.3)
                    except OSError: break
                try: os.kill(int(pid),signal.SIGKILL)
                except OSError: pass
            except OSError: pass
        # Kill only this VM's qemu by name; never broad pkill.
        subprocess.run(["pkill","-TERM","-f",f"skvm-{v['vps_id'][:8]}"],capture_output=True)
        (vm_dir(v["vps_id"])/"qemu.pid").unlink(missing_ok=True)

    def metrics(self,v):
        if not self.alive(v): return {"cpu":0,"ram_mb":0,"uptime":"offline"}
        try:
            p=__import__("psutil").Process(int(v["pid"]))
            return {"cpu":round(p.cpu_percent(interval=.15),1),
                    "ram_mb":round(p.memory_info().rss/1048576,1),
                    "uptime":str(datetime.now()-datetime.fromtimestamp(p.create_time())).split(".")[0]}
        except: return {"cpu":0,"ram_mb":0,"uptime":"unknown"}

qemu=QEMU()

def update(v,pct,step,status=None,error=None,pid=None):
    fields="progress=?,step=?,updated_at=CURRENT_TIMESTAMP"
    vals=[pct,step]
    if status is not None: fields+=",status=?"; vals.append(status)
    if error is not None: fields+=",error=?"; vals.append(error)
    if pid is not None: fields+=",pid=?"; vals.append(pid)
    vals.append(v["vps_id"])
    db(f"UPDATE vps SET {fields} WHERE vps_id=?",vals)

def provision(vps_id):
    v=get_vps(vps_id)
    if not v: return
    try:
        update(v,2,"Preparing")
        qemu.image(v)
        qemu.seed(v)
        pid=qemu.start(v)
        update(v,100,"Ready",status="running",error="",pid=pid)
        notify(v["user_id"],"VPS ready",f"{v['name']} is running on SSH port {v['ssh_port']}.","success")
        audit("vps.provision",f"{v['name']} ({vps_id}) ready")
    except Exception as e:
        log.exception("Provision failed for %s",vps_id)
        qemu.stop(v,quiet=True)
        update(v,100,"Failed",status="error",error=str(e),pid=None)
        notify(v["user_id"],"VPS provisioning failed",f"{v['name']}: {e}","danger")
        audit("vps.provision_failed",f"{v['name']}: {e}")

def status_of(v):
    return "running" if qemu.alive(v) else ("error" if v["status"]=="error" else "stopped")

@app.route("/")
def index(): return redirect(url_for("dashboard" if session.get("user_id") else "login"))

@app.route("/login",methods=["GET","POST"])
def login():
    if request.method=="POST":
        u=request.form.get("username","").strip(); p=request.form.get("password","")
        user=db("SELECT * FROM users WHERE username=? AND is_active=1",(u,),one=True)
        if user and check_password_hash(user["password"],p):
            session.clear(); session.update(user_id=user["id"],username=user["username"],role=user["role"]); session.permanent=True
            db("UPDATE users SET last_login=CURRENT_TIMESTAMP WHERE id=?",(user["id"],))
            audit("auth.login",u); return redirect(request.args.get("next") or url_for("admin_dashboard" if user["role"]=="admin" else "dashboard"))
        flash("Invalid username or password.","danger")
    return render_template("login.html")

@app.route("/logout",methods=["POST","GET"])
def logout(): session.clear(); return redirect(url_for("login"))

@app.route("/register",methods=["GET","POST"])
def register():
    if request.method=="POST":
        u=request.form.get("username","").strip(); e=request.form.get("email","").strip(); p=request.form.get("password","")
        if not re.fullmatch(r"[A-Za-z0-9_.-]{3,32}",u): flash("Username must be 3-32 characters.","danger")
        elif len(p)<8: flash("Password must be at least 8 characters.","danger")
        else:
            try:
                db("INSERT INTO users(username,email,password) VALUES(?,?,?)",(u,e,generate_password_hash(p)))
                flash("Account created. Please sign in.","success"); return redirect(url_for("login"))
            except sqlite3.IntegrityError: flash("Username or email already exists.","danger")
    return render_template("register.html")

@app.route("/dashboard")
@login_required
def dashboard():
    rows=db("SELECT * FROM vps WHERE user_id=? ORDER BY created_at DESC",(session["user_id"],),all=True)
    return render_template("dashboard.html",vps=rows)

@app.route("/vps/create",methods=["GET","POST"])
@admin_required
def create_vps():
    if request.method=="POST":
        try:
            name=request.form.get("name","").strip()
            ost=request.form.get("os_template","ubuntu-22.04")
            uid=int(request.form.get("user_id") or session["user_id"])
            ram=int(request.form.get("ram_mb",1024)); cpu=int(request.form.get("cpu_cores",1)); disk=int(request.form.get("disk_gb",10))
            requested=request.form.get("ssh_port","").strip()
            if not name or len(name)>64: raise ValueError("VPS name is required (max 64 characters)")
            if ost not in OS_TEMPLATES: raise ValueError("Unsupported OS template")
            if ram<512 or ram>262144: raise ValueError("RAM must be 512-262144 MB")
            if cpu<1 or cpu>64: raise ValueError("CPU must be 1-64 cores")
            if disk<5 or disk>2048: raise ValueError("Disk must be 5-2048 GB")
            port=int(requested) if requested else allocate_port()
            if not port_free(port): raise ValueError(f"SSH port {port} is already in use")
            vps_id=uuid.uuid4().hex
            pw=secrets.token_urlsafe(12)
            db("""INSERT INTO vps(vps_id,user_id,name,os_template,ram_mb,cpu_cores,disk_gb,ssh_port,ssh_password,status,progress,step)
                  VALUES(?,?,?,?,?,?,?,?,?,'creating',0,'Queued')""",
               (vps_id,uid,name,ost,ram,cpu,disk,port,pw))
            audit("vps.create",f"{name} ({vps_id})")
            threading.Thread(target=provision,args=(vps_id,),daemon=True).start()
            flash(f"{name} queued. Provisioning started.","success")
            return redirect(url_for("manage_vps",vps_id=vps_id))
        except (ValueError,TypeError) as e: flash(str(e),"danger")
    users=db("SELECT id,username FROM users WHERE is_active=1 ORDER BY username",all=True)
    return render_template("create_vps.html",os_templates=OS_TEMPLATES,users=users)

@app.route("/vps/<vps_id>")
@login_required
@owner_required
def manage_vps(vps_id):
    v=get_vps(vps_id); return render_template("manage_vps.html",vps=v,real_status=status_of(v),metrics=qemu.metrics(v))

@app.route("/vps/<vps_id>/status")
@login_required
@owner_required
def vps_status(vps_id):
    v=get_vps(vps_id)
    return jsonify({"success":True,"status":status_of(v),"progress":v["progress"],"step":v["step"],"error":v["error"]})

def control(vps_id, action):
    v=get_vps(vps_id)
    if not v: return jsonify(success=False,message="VPS not found"),404
    if v["status"]=="creating": return jsonify(success=False,message="VPS is still provisioning")
    try:
        if action=="start":
            if qemu.alive(v): return jsonify(success=True,message="VPS is already running")
            pid=qemu.start(v); update(v,100,"Running",status="running",error="",pid=pid); audit("vps.start",v["name"])
            return jsonify(success=True,message="VPS started")
        if action=="stop":
            qemu.stop(v); update(v,100,"Stopped",status="stopped",error="",pid=None); audit("vps.stop",v["name"])
            return jsonify(success=True,message="VPS stopped")
        if action=="restart":
            qemu.stop(v); time.sleep(1); pid=qemu.start(v); update(v,100,"Running",status="running",error="",pid=pid); audit("vps.restart",v["name"])
            return jsonify(success=True,message="VPS restarted")
        return jsonify(success=False,message="Unknown action"),400
    except Exception as e:
        log.exception("control")
        update(v,100,"Error",status="error",error=str(e),pid=None)
        return jsonify(success=False,message=str(e)),500

@app.post("/vps/<vps_id>/start")
@login_required
@owner_required
def start(vps_id): return control(vps_id,"start")
@app.post("/vps/<vps_id>/stop")
@login_required
@owner_required
def stop(vps_id): return control(vps_id,"stop")
@app.post("/vps/<vps_id>/restart")
@login_required
@owner_required
def restart(vps_id): return control(vps_id,"restart")

@app.post("/vps/<vps_id>/retry")
@admin_required
def retry(vps_id):
    v=get_vps(vps_id)
    if not v: return jsonify(success=False,message="Not found"),404
    if status_of(v)=="running": return jsonify(success=False,message="Already running")
    update(v,0,"Queued",status="creating",error="",pid=None)
    threading.Thread(target=provision,args=(vps_id,),daemon=True).start()
    return jsonify(success=True,message="Provisioning retry started")

@app.post("/vps/<vps_id>/delete")
@admin_required
def delete_vps(vps_id):
    v=get_vps(vps_id)
    if not v: return jsonify(success=False,message="Not found"),404
    qemu.stop(v,quiet=True); shutil.rmtree(vm_dir(vps_id),ignore_errors=True)
    db("DELETE FROM vps WHERE vps_id=?",(vps_id,)); audit("vps.delete",v["name"])
    return jsonify(success=True,message="VPS deleted")

@app.route("/vps/<vps_id>/terminal")
@login_required
@owner_required
def terminal(vps_id):
    v=get_vps(vps_id)
    return render_template("terminal.html",vps=v)

@app.post("/vps/<vps_id>/tmate")
@login_required
@owner_required
def tmate(vps_id):
    # tmate is optional: SSH remains available even when relay access is blocked.
    v=get_vps(vps_id)
    if status_of(v)!="running": return jsonify(success=False,message="Start the VPS first")
    try:
        cmd=["sshpass","-p",v["ssh_password"],"ssh","-o","StrictHostKeyChecking=no","-o","ConnectTimeout=5","-p",str(v["ssh_port"]),f"root@127.0.0.1",
             "command -v tmate >/dev/null || (apt-get update -qq && DEBIAN_FRONTEND=noninteractive apt-get install -y -qq tmate); "
             "tmate -S /tmp/skvm-tmate.sock new-session -d 2>/dev/null || true; "
             "tmate -S /tmp/skvm-tmate.sock wait tmate-ready 2>/dev/null || true; "
             "printf '%s\\n' \"$(tmate -S /tmp/skvm-tmate.sock display -p '#{tmate_ssh}' 2>/dev/null)\""]
        r=subprocess.run(cmd,capture_output=True,text=True,timeout=90)
        val=(r.stdout or "").strip().splitlines()
        ssh=next((x for x in val if x.startswith("ssh ")),None)
        if ssh:
            db("UPDATE vps SET tmate_ssh=?,error='' WHERE vps_id=?",(ssh,vps_id))
            return jsonify(success=True,tmate_ssh=ssh)
        return jsonify(success=False,message="tmate relay did not return a session. Use the direct SSH command below; this does not affect VPS availability.")
    except Exception as e: return jsonify(success=False,message=str(e))

@app.route("/profile",methods=["GET","POST"])
@login_required
def profile():
    if request.method=="POST":
        e=request.form.get("email","").strip(); pw=request.form.get("password","")
        if pw and len(pw)<8: flash("Password must be at least 8 characters.","danger")
        else:
            db("UPDATE users SET email=?"+(",password=?" if pw else "")+" WHERE id=?",
               (e,generate_password_hash(pw),session["user_id"]) if pw else (e,session["user_id"]))
            flash("Profile updated.","success")
    u=db("SELECT * FROM users WHERE id=?",(session["user_id"],),one=True)
    return render_template("profile.html",user=u)

@app.route("/notifications")
@login_required
def notifications():
    rows=db("SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 100",(session["user_id"],),all=True)
    return render_template("notifications.html",notifications=rows)

@app.post("/notifications/read/<int:nid>")
@login_required
def read_notification(nid):
    db("UPDATE notifications SET is_read=1 WHERE id=? AND user_id=?",(nid,session["user_id"]))
    return jsonify(success=True)

@app.route("/admin")
@admin_required
def admin_dashboard():
    import psutil
    allv=db("SELECT * FROM vps",all=True)
    running=sum(status_of(v)=="running" for v in allv)
    mem=psutil.virtual_memory(); disk=psutil.disk_usage("/")
    return render_template("admin/dashboard.html",total=len(allv),running=running,users=db("SELECT COUNT(*) c FROM users",one=True)["c"],
                           cpu=psutil.cpu_percent(),mem=mem,disk=disk)

@app.route("/admin/vps")
@admin_required
def admin_vps():
    rows=db("SELECT v.*,u.username FROM vps v JOIN users u ON u.id=v.user_id ORDER BY v.created_at DESC",all=True)
    return render_template("admin/vps.html",vps=rows)

@app.route("/admin/users")
@admin_required
def admin_users():
    rows=db("""SELECT u.*,COUNT(v.id) vm_count FROM users u LEFT JOIN vps v ON v.user_id=u.id
               GROUP BY u.id ORDER BY u.created_at DESC""",all=True)
    return render_template("admin/users.html",users=rows)

@app.route("/admin/users/create",methods=["GET","POST"])
@admin_required
def create_user():
    if request.method=="POST":
        try:
            db("INSERT INTO users(username,email,password,role) VALUES(?,?,?,?)",
               (request.form["username"].strip(),request.form["email"].strip(),generate_password_hash(request.form["password"]),request.form.get("role","user")))
            flash("User created.","success"); return redirect(url_for("admin_users"))
        except sqlite3.IntegrityError: flash("Username or email already exists.","danger")
    return render_template("admin/create_user.html")

@app.route("/admin/users/<int:uid>/edit",methods=["GET","POST"])
@admin_required
def edit_user(uid):
    u=db("SELECT * FROM users WHERE id=?",(uid,),one=True)
    if not u: abort(404)
    if request.method=="POST":
        pw=request.form.get("password","")
        if uid==session["user_id"] and request.form.get("role")!="admin": flash("You cannot remove your own admin role.","danger"); return redirect(request.url)
        sql="UPDATE users SET username=?,email=?,role=?,is_active=?"+(",password=?" if pw else "")+" WHERE id=?"
        params=(request.form["username"].strip(),request.form["email"].strip(),request.form.get("role","user"),1 if request.form.get("is_active") else 0,generate_password_hash(pw),uid) if pw else (request.form["username"].strip(),request.form["email"].strip(),request.form.get("role","user"),1 if request.form.get("is_active") else 0,uid)
        try: db(sql,params); flash("User updated.","success"); return redirect(url_for("admin_users"))
        except sqlite3.IntegrityError: flash("Username/email already exists.","danger")
    return render_template("admin/edit_user.html",user=u)

@app.post("/admin/users/<int:uid>/delete")
@admin_required
def delete_user(uid):
    if uid==session["user_id"]: return jsonify(success=False,message="You cannot delete yourself")
    u=db("SELECT * FROM users WHERE id=?",(uid,),one=True)
    if not u: return jsonify(success=False,message="Not found"),404
    vs=db("SELECT * FROM vps WHERE user_id=?",(uid,),all=True)
    for v in vs: qemu.stop(v,quiet=True); shutil.rmtree(vm_dir(v["vps_id"]),ignore_errors=True)
    db("DELETE FROM vps WHERE user_id=?",(uid,)); db("DELETE FROM notifications WHERE user_id=?",(uid,)); db("DELETE FROM users WHERE id=?",(uid,))
    audit("user.delete",u["username"]); return jsonify(success=True,message="User deleted")

@app.route("/admin/settings",methods=["GET","POST"])
@admin_required
def admin_settings():
    if request.method=="POST":
        for k in ("site_name","theme","server_ip"):
            db("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(k,request.form.get(k,"")))
        flash("Settings saved.","success")
    return render_template("admin/settings.html",settings={k:setting(k) for k in ("site_name","theme","server_ip")})

@app.route("/admin/audit")
@admin_required
def admin_audit():
    rows=db("SELECT a.*,u.username FROM audit_log a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.timestamp DESC LIMIT 200",all=True)
    return render_template("admin/audit.html",logs=rows)

@app.errorhandler(403)
def forbidden(e): return render_template("errors/404.html",code=403,message="Access denied"),403
@app.errorhandler(404)
def not_found(e): return render_template("errors/404.html",code=404,message="Page not found"),404
@app.errorhandler(500)
def server_error(e): return render_template("errors/500.html"),500

@app.template_filter("dt")
def dt(v): return str(v or "—")

if __name__=="__main__":
    init_db()
    app.run(host=os.environ.get("SKVM_HOST","0.0.0.0"),port=int(os.environ.get("SKVM_PORT","5555")),debug=False,threaded=True)
