/* Servers list + create-server wizard */
(async function () {
  const grid = document.getElementById('serverGrid');
  const searchInput = document.getElementById('searchInput');
  const statusFilter = document.getElementById('statusFilter');
  const sortSelect = document.getElementById('sortSelect');
  let catalogue = null;
  let versionCache = {};

  try { await bootstrap({ active: 'servers.html' }); } catch (_) { return; }

  Layout.title('Servers', 'all instances you can access');
  Layout.actions(`<button class="btn sm primary" id="createBtn">${ICONS.plus} Create server</button>`);
  document.getElementById('createBtn').onclick = openCreate;
  document.getElementById('refreshBtn').onclick = () => load();

  async function load() {
    const params = new URLSearchParams();
    if (searchInput.value) params.set('search', searchInput.value);
    if (statusFilter.value) params.set('status', statusFilter.value);
    if (sortSelect.value) params.set('sort', sortSelect.value);
    try {
      const data = await API.get(`/servers?${params}`);
      Layout.setServerCount(data.total);
      render(data);
    } catch (err) {
      grid.innerHTML = `<div class="banner-note red">${ICONS.warn}<div>${esc(err.message)}</div></div>`;
    }
  }

  function card(s) {
    const stats = s.stats || {};
    return `<div class="card hoverable server-card" data-id="${s.id}">
      <div class="head">
        <div class="server-icon">${esc((s.serverType || 'MC').slice(0, 2))}</div>
        <div class="grow">
          <div class="row between">
            <a class="title truncate" href="server.html?id=${s.id}">${esc(s.name)}</a>
            ${statusBadge(s.status)}
          </div>
          <div class="tiny dim mono truncate">${esc(s.serverType)} ${esc(s.version || '')} · ${esc(s.nodeName || 'local')} · :${s.port}</div>
        </div>
      </div>
      <div class="row" style="gap:14px;font-size:12.5px">
        <span class="dim">${s.players || 0}/${s.maxPlayers || 20} online</span>
        <span class="dim">${(stats.cpu || 0).toFixed ? (stats.cpu || 0).toFixed(1) : 0}% CPU</span>
        <span class="dim">${stats.memoryPretty || '0 B'} RAM</span>
      </div>
      <div class="bar ${(stats.memory || 0) > 85 ? 'red' : (stats.memory || 0) > 65 ? 'yellow' : 'blue'}"><i style="width:${Math.min(stats.memory || 0, 100)}%"></i></div>
      <div class="row between tiny dim">
        <span>${s.uptime ? `up ${fmt.duration(s.uptime)}` : 'offline'}${s.packages ? ` · ${s.packages} add-on${s.packages === 1 ? '' : 's'}` : ''}</span>
        <span>${s.ownerName ? esc(s.ownerName) : ''}</span>
      </div>
      <div class="power-row">
        ${s.perms.console ? (s.status === 'running'
          ? `<button class="btn sm" data-power="restart" data-id="${s.id}">${ICONS.restart} Restart</button>
             <button class="btn sm red" data-power="stop" data-id="${s.id}">${ICONS.stop} Stop</button>`
          : `<button class="btn sm green" data-power="start" data-id="${s.id}" ${s.status === 'installing' ? 'disabled' : ''}>${ICONS.play} Start</button>`)
        : ''}
        <a class="btn sm" href="server.html?id=${s.id}">${ICONS.terminal} Console</a>
      </div>
    </div>`;
  }

  function render(data) {
    if (!data.servers.length) {
      grid.innerHTML = `<div style="grid-column:1/-1">${UI.empty('No servers found', 'Create a server to get started - it installs the jar for you.')}</div>`;
      return;
    }
    grid.innerHTML = data.servers.map(card).join('');
  }

  document.addEventListener('click', async (e) => {
    const btn = e.target.closest('[data-power]');
    if (!btn) return;
    btn.disabled = true;
    try {
      await API.post(`/servers/${btn.dataset.id}/${btn.dataset.power}`);
      UI.toast(`${btn.dataset.power} requested`, 'success');
      setTimeout(load, 1500);
    } catch (err) { UI.toast(err.message, 'error'); btn.disabled = false; }
  });

  let debounce;
  [searchInput, statusFilter, sortSelect].forEach((el) => el.addEventListener('input', () => {
    clearTimeout(debounce); debounce = setTimeout(load, 250);
  }));

  /* ------------------------------ create wizard ------------------------------ */
  async function openCreate() {
    catalogue = catalogue || await API.get('/system/catalogue');
    const state = {
      step: 1,
      name: '',
      serverType: 'PAPER',
      version: '',
      versions: [],
      memory: catalogue.defaultMemory || 2048,
      port: '',
      subdomain: '',
      maxPlayers: 20,
      eulaAccepted: true,
      autoStart: false,
      install: true,
      nodeId: 'local',
      backend: '', // '' = follow the node's own runtime
    };

    let nodes = [{ id: 'local', name: 'Local node', local: true, status: 'online' }];
    try {
      const res = await API.get('/nodes');
      nodes = res.nodes || nodes;
      // only nodes the panel can actually reach are selectable
      state.nodeId = (nodes.find((n) => n.id === 'local') || nodes[0]).id;
    } catch (_) { /* admin-only view; everyone can still use the local node */ }

    const m = UI.modal({
      title: 'Create a Minecraft server',
      wide: true,
      body: `
        <div class="steps" id="wizSteps"><div class="s active"></div><div class="s"></div><div class="s"></div></div>
        <div id="wizBody"></div>`,
      footer: `<button class="btn" data-close>Cancel</button>
               <button class="btn" id="wizPrev" style="display:none">Back</button>
               <button class="btn primary" id="wizNext">Continue</button>`,
      onMount(root, { close }) {
        root.querySelector('#wizPrev').onclick = () => { state.step = Math.max(1, state.step - 1); paint(); };
        root.querySelector('#wizNext').onclick = async () => {
          if (state.step < 3) {
            if (state.step === 1 && !readStep1()) return;
            state.step += 1;
            if (state.step === 2) await loadVersions();
            paint();
          } else {
            submit(close);
          }
        };
        paint();
        void close;

        function readStep1() {
          const body = root.querySelector('#wizBody');
          state.name = body.querySelector('[name=name]').value.trim();
          state.memory = parseInt(body.querySelector('[name=memory]').value, 10) || 2048;
          state.port = body.querySelector('[name=port]').value.trim();
          const subEl = body.querySelector('[name=subdomain]');
          if (subEl) state.subdomain = subEl.value.trim();
          state.maxPlayers = parseInt(body.querySelector('[name=maxPlayers]').value, 10) || 20;
          state.eulaAccepted = body.querySelector('[name=eula]').checked;
          state.autoStart = body.querySelector('[name=autoStart]').checked;
          const nodeEl = body.querySelector('[name=nodeId]');
          if (nodeEl) state.nodeId = nodeEl.value;
          const backendEl = body.querySelector('[name=backend]');
          if (backendEl) state.backend = backendEl.value;
          if (!state.name) { UI.toast('Give your server a name', 'error'); return false; }
          return true;
        }

        async function loadVersions() {
          if (versionCache[state.serverType]) { state.versions = versionCache[state.serverType]; return; }
          const body = root.querySelector('#wizBody');
          if (body) body.querySelector('#versionList').innerHTML = `<div class="tiny dim">Loading versions from the ${esc(state.serverType)} API...</div>`;
          try {
            const data = await API.get(`/system/versions/${state.serverType}`);
            state.versions = data.versions || [];
            versionCache[state.serverType] = state.versions;
            state.version = data.latest || (state.versions[0] && state.versions[0].id) || '';
          } catch (err) {
            state.versions = [];
            state.version = 'latest';
            UI.toast(`Could not load versions (${err.message}) - you can still install later`, 'warn');
          }
        }

        function paint() {
          const steps = root.querySelectorAll('#wizSteps .s');
          steps.forEach((s, i) => { s.className = `s ${i + 1 < state.step ? 'done' : i + 1 === state.step ? 'active' : ''}`; });
          root.querySelector('#wizPrev').style.display = state.step > 1 ? '' : 'none';
          root.querySelector('#wizNext').textContent = state.step === 3 ? 'Create & install' : 'Continue';
          const body = root.querySelector('#wizBody');

          if (state.step === 1) {
            body.innerHTML = `
              <div class="col" style="gap:14px">
                <label class="field">Server name
                  <input name="name" placeholder="Survival SMP" value="${esc(state.name)}" maxlength="60">
                </label>
                <div class="field-row">
                  <label class="field">Memory (MB)
                    <input type="number" name="memory" value="${state.memory}" min="256" step="256">
                    <span class="hint">Heap size for the JVM (-Xmx). 2 GB is fine for 10-20 players.</span>
                  </label>
                  <label class="field">Port <span class="dim tiny">(blank = auto)</span>
                    <input type="number" name="port" value="${state.port}" placeholder="25565" min="1024" max="65535">
                  </label>
                  <label class="field">Max players
                    <input type="number" name="maxPlayers" value="${state.maxPlayers}" min="1" max="1000">
                  </label>
                </div>
                <label class="field">Subdomain <span class="dim tiny">(optional)</span>
                  <input name="subdomain" value="${esc(state.subdomain)}" placeholder="survival" maxlength="40">
                  <span class="hint">Creates a hostname like <span class="mono">survival.your-domain.com</span> once an admin configures the base domain.</span>
                </label>
                ${nodes.length > 1 ? `
                <label class="field">Node
                  <select name="nodeId">
                    ${nodes.map((n) => `<option value="${esc(n.id)}" ${n.id === state.nodeId ? 'selected' : ''}>${esc(n.name)} · ${esc(n.status || 'unknown')}${n.local ? ' (this host)' : ` · ${esc(n.fqdn || '')}`}</option>`).join('')}
                  </select>
                  <span class="hint">Remote nodes need Java + a reachable agent port; the panel installs the jar there for you.</span>
                </label>` : ''}
                <label class="field">Runtime
                  <select name="backend">
                    <option value="" ${state.backend ? '' : 'selected'}>Follow the node (<span id="nodeRuntime">${esc((nodes.find((n) => n.id === state.nodeId) || {}).backend || 'process')}</span>)</option>
                    <option value="docker" ${state.backend === 'docker' ? 'selected' : ''}>Docker container - isolated, memory and CPU limited</option>
                    <option value="process" ${state.backend === 'process' ? 'selected' : ''}>Java process on the node host</option>
                  </select>
                  <span class="hint">Docker is validated against the node when the server is created: if the daemon cannot be reached, creation fails with the engine's own error instead of pretending a container will run.</span>
                </label>
                <label class="checkbox"><input type="checkbox" name="eula" ${state.eulaAccepted ? 'checked' : ''}>
                  <span>I accept the <b>Minecraft EULA</b> (<a href="https://aka.ms/MinecraftEULA" target="_blank" style="text-decoration:underline">minecraft.net/eula</a>) - required before the server can start</span></label>
                <label class="checkbox"><input type="checkbox" name="autoStart" ${state.autoStart ? 'checked' : ''}>
                  <span>Start this server automatically when the panel boots</span></label>
              </div>`;
          }

          if (state.step === 2) {
            body.innerHTML = `
              <div class="col" style="gap:14px">
                <div>
                  <div class="label tiny dim" style="margin-bottom:8px">Server software</div>
                  <div class="pick-grid">
                    ${catalogue.types.map((t) => `
                      <div class="pick ${t.id === state.serverType ? 'active' : ''}" data-type="${t.id}">
                        <b>${t.name}</b><span>${t.description}</span>
                        <div class="chips" style="margin-top:7px">
                          ${t.plugins ? '<span class="chip">plugins</span>' : ''}${t.mods ? '<span class="chip">mods</span>' : ''}${t.kind === 'proxy' ? '<span class="chip">proxy</span>' : ''}
                        </div>
                      </div>`).join('')}
                  </div>
                </div>
                <div>
                  <div class="row between" style="margin-bottom:8px">
                    <div class="label tiny dim">Version</div>
                    <input type="search" id="versionSearch" placeholder="filter versions..." style="max-width:200px" value="">
                  </div>
                  <div id="versionList" style="max-height:230px;overflow-y:auto;display:flex;flex-wrap:wrap;gap:7px">
                    ${state.versions.length ? state.versions.map((v) => `<div class="pick ${v.id === state.version ? 'active' : ''}" data-version="${esc(v.id)}" style="padding:7px 11px"><b style="font-family:var(--mono);font-size:12.5px">${esc(v.id)}</b></div>`).join('') : `<div class="tiny dim">Loading versions...</div>`}
                  </div>
                </div>
              </div>`;
            body.querySelectorAll('[data-type]').forEach((el) => el.onclick = async () => {
              state.serverType = el.dataset.type;
              await loadVersions();
              paint();
            });
            body.querySelectorAll('[data-version]').forEach((el) => el.onclick = () => {
              state.version = el.dataset.version;
              body.querySelectorAll('[data-version]').forEach((x) => x.classList.remove('active'));
              el.classList.add('active');
            });
            const vs = body.querySelector('#versionSearch');
            if (vs) vs.oninput = () => {
              const q = vs.value.toLowerCase();
              body.querySelectorAll('[data-version]').forEach((el) => {
                el.style.display = el.dataset.version.toLowerCase().includes(q) ? '' : 'none';
              });
            };
          }

          if (state.step === 3) {
            body.innerHTML = `
              <div class="col" style="gap:12px">
                <div class="banner-note green">${ICONS.check}<div><b>Ready to create</b><div class="tiny">${esc(state.name)} · ${esc(state.serverType)} ${esc(state.version || 'latest')} · ${state.memory} MB RAM</div></div></div>
                <dl class="kv">
                  <dt>Type</dt><dd>${esc(state.serverType)} ${esc(state.version || '')}</dd>
                  <dt>Memory</dt><dd>${state.memory} MB</dd>
                  <dt>Node</dt><dd>${esc((nodes.find((n) => n.id === state.nodeId) || { name: 'Local node' }).name)}</dd>
                  <dt>Port</dt><dd>${state.port || 'auto-allocated from the node range'}</dd>
                  <dt>Subdomain</dt><dd>${state.subdomain ? esc(state.subdomain) : '<span class="dim">none</span>'}</dd>
                  <dt>Max players</dt><dd>${state.maxPlayers}</dd>
                  <dt>Runtime</dt><dd>${state.backend === 'docker' ? 'Docker container' : state.backend === 'process' ? 'Java process' : `node default (${esc((nodes.find((n) => n.id === state.nodeId) || {}).backend || 'process')})`}</dd>
                  <dt>Auto start</dt><dd>${state.autoStart ? 'yes' : 'no'}</dd>
                </dl>
                <label class="checkbox"><input type="checkbox" name="install" ${state.install ? 'checked' : ''}>
                  <span>Download and install the server jar now (recommended - progress shows in the console)</span></label>
                <div class="tiny dim">Java is installed automatically: ${state.serverType === 'PAPER' || state.serverType === 'VANILLA' ? 'the panel fetches a matching Temurin JRE if the host has none.' : 'the loader installer runs in the background.'}</div>
                ${state.nodeId !== 'local' ? `<div class="banner-note"><div><b>Remote node selected</b><div class="tiny">The jar is downloaded, Java provisioned and the process started on <b>${esc((nodes.find((n) => n.id === state.nodeId) || {}).name || 'that node')}</b>. Console, power, stats and backups are proxied through the agent; the file manager and Modrinth installs operate on the panel host's copy.</div></div></div>` : ''}
              </div>`;
            const cb = body.querySelector('[name=install]');
            if (cb) cb.onchange = () => { state.install = cb.checked; };
          }

          const nodeSelect = body.querySelector('[name=nodeId]');
          if (nodeSelect) nodeSelect.onchange = () => {
            state.nodeId = nodeSelect.value;
            const label = body.querySelector('#nodeRuntime');
            if (label) label.textContent = (nodes.find((n) => n.id === state.nodeId) || {}).backend || 'process';
          };
        }

        async function submit(close) {
          const btn = root.querySelector('#wizNext');
          btn.disabled = true;
          btn.innerHTML = `${UI.spinner(14)} Creating...`;
          try {
            const installEl = root.querySelector('#wizBody [name=install]');
            if (installEl) state.install = installEl.checked;
            const res = await API.post('/servers', {
              name: state.name,
              serverType: state.serverType,
              version: state.version || 'latest',
              memory: state.memory,
              port: state.port || undefined,
              maxPlayers: state.maxPlayers,
              eulaAccepted: state.eulaAccepted,
              autoStart: state.autoStart,
              install: state.install,
              nodeId: state.nodeId,
              backend: state.backend || undefined,
              subdomain: state.subdomain || undefined,
            });
            UI.toast(`Server "${res.server.name}" created`, 'success');
            if (res.subdomainError) UI.toast(`Subdomain not created: ${res.subdomainError}`, 'warn');
            close();
            location.href = `server.html?id=${res.server.id}`;
          } catch (err) {
            UI.toast(err.message, 'error');
            btn.disabled = false;
            btn.textContent = 'Create & install';
          }
        }
      },
    });
    void m;
  }

  await load();
  if (new URLSearchParams(location.search).get('create') === '1' || location.hash === '#create') {
    history.replaceState(null, '', location.pathname);
    openCreate();
  }
})();
