'use strict';
/**
 * Zenith Panel - entry point.
 *
 *   node server.js            # panel
 *   PORT=8080 node server.js  # custom port
 *
 * The panel is a single Node process:
 *   express HTTP API  +  websocket console  +  child-process supervisor
 *   (every Minecraft server is a child process of this panel, exactly like a
 *    "local node" in Pterodactyl).
 */
const express = require('express');

/*
 * Express 4 does not forward rejections from async route handlers, so a thrown
 * error (validation, quota, port conflict, ...) leaves the HTTP request hanging
 * forever instead of returning a JSON error. Patch the Router factory so every
 * handler's promise is routed into the normal error handler.
 * Must run before the route modules are required.
 */
(function patchAsyncRouteHandlers() {
  const METHODS = ['get', 'post', 'put', 'patch', 'delete', 'all'];
  const wrap = (fn) => {
    if (typeof fn !== 'function' || fn.length > 3) return fn; // 4 args = error middleware
    return function zenithAsyncHandler(req, res, next) {
      try {
        const out = fn(req, res, next);
        if (out && typeof out.then === 'function') out.catch(next);
        return out;
      } catch (err) {
        next(err);
        return undefined;
      }
    };
  };
  const originalRouter = express.Router;
  express.Router = function patchedRouter(options) {
    const router = originalRouter.call(express, options);
    for (const method of METHODS) {
      const original = router[method].bind(router);
      router[method] = (routePath, ...handlers) => original(routePath, ...handlers.map(wrap));
    }
    return router;
  };
})();

const http = require('http');
const path = require('path');
const fs = require('fs');
const os = require('os');

const cfg = require('./src/config');
const db = require('./src/db');
const logger = require('./src/logger');
const auth = require('./src/auth');
const runtime = require('./src/services/runtime');
const nodesSvc = require('./src/services/nodes');
const scheduler = require('./src/services/scheduler');
const metrics = require('./src/services/metrics');
const playersSvc = require('./src/services/players');
const discordSvc = require('./src/services/discord');
const playit = require('./src/services/playit');
const sftpSvc = require('./src/services/sftp');
const wsConsole = require('./src/ws/console');

/* ------------------------------ bootstrap ------------------------------ */
db.load();
nodesSvc.defaultNode();

async function ensureOwnerFromEnv() {
  const username = process.env.ZENITH_OWNER_USER || process.env.PANEL_OWNER_USER;
  const password = process.env.ZENITH_OWNER_PASS || process.env.PANEL_OWNER_PASS;
  if (!username || !password) return null;
  const users = db.get('users');
  const existing = users.find((u) => u.username.toLowerCase() === username.toLowerCase());
  if (existing) {
    db.update('users', existing.id, {
      password: await auth.hashPassword(password),
      role: 'owner',
      passwordVersion: (existing.passwordVersion || 0) + 1,
    });
    logger.info('panel', `owner "${username}" password refreshed from environment`);
    return existing.id;
  }
  users.forEach((u) => { if (u.role === 'owner') u.role = 'admin'; });
  const created = {
    id: `usr_${Date.now().toString(36)}owner`,
    username,
    email: process.env.ZENITH_OWNER_EMAIL || '',
    password: await auth.hashPassword(password),
    role: 'owner',
    passwordVersion: 0,
    createdAt: new Date().toISOString(),
    suspended: false,
    createdBy: 'installer',
  };
  db.insert('users', created);
  logger.ok('panel', `owner account "${username}" created`);
  return created.id;
}

async function reconcileServerStates() {
  // Local children die with the panel, so their stale statuses go offline.
  // Servers on remote nodes keep running there - adopt them instead.
  const remote = require('./src/services/remote');
  for (const server of db.get('servers') || []) {
    const stale = ['running', 'starting', 'stopping', 'installing'].includes(server.status);
    if (runtime.isRemote(server)) {
      if (stale) db.update('servers', server.id, { status: 'offline' });
      remote.reconcile(server).catch((err) => logger.warn('remote', `${server.name}: ${err.message}`));
      continue;
    }
    if (stale) {
      db.update('servers', server.id, { status: 'offline' });
      runtime.setStatus(server.id, 'offline');
    }
  }
}

async function autostartServers() {
  if (!cfg.autostart) return;
  const candidates = (db.get('servers') || []).filter((s) => s.autoStart && !s.suspended);
  for (const server of candidates) {
    try {
      logger.info('panel', `auto-starting ${server.name}...`);
      await runtime.start(server, { silent: true });
    } catch (err) {
      logger.warn('panel', `auto-start failed for ${server.name}: ${err.message}`);
    }
  }
  for (const server of db.get('servers') || []) {
    if (server.playit && server.playit.enabled && server.playit.autostart) {
      try { await playit.start(server); } catch (err) { logger.warn('playit', `autostart failed for ${server.name}: ${err.message}`); }
    }
  }
}

/* ------------------------------ express ------------------------------ */
const app = express();
app.disable('x-powered-by');
app.set('trust proxy', true);
app.use(express.json({ limit: Math.min(cfg.maxUploadSize, 2 * 1024 * 1024 * 1024) }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// tiny request log (quiet by default)
app.use((req, res, next) => {
  if (process.env.REQUEST_LOG === 'true') {
    const start = Date.now();
    res.on('finish', () => logger.debug('http', `${req.method} ${req.originalUrl} ${res.statusCode} ${Date.now() - start}ms`));
  }
  next();
});

// permissive CORS for the API (the panel UI is same-origin; API keys are used by bots)
app.use('/api', (req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-API-Key, X-Node-Token, X-Node-Secret');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PATCH,PUT,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

/* ---- routes ---- */
const authRoutes = require('./src/routes/auth');
const serverRoutes = require('./src/routes/servers');
const fileRoutes = require('./src/routes/files');
const backupRoutes = require('./src/routes/backups');
const modrinthRoutes = require('./src/routes/modrinth');
const playitRoutes = require('./src/routes/playit');
const playerRoutes = require('./src/routes/players');
const subdomainRoutes = require('./src/routes/subdomains');
const adminRoutes = require('./src/routes/admin');

app.use('/api/auth', authRoutes);
app.use('/api/servers', serverRoutes);
app.use('/api/servers/:id/files', fileRoutes);
app.use('/api/servers/:id/backups', backupRoutes);
app.use('/api/servers/:id/playit', playitRoutes);
app.use('/api/servers/:id/players', playerRoutes);
app.use('/api/servers/:id/subdomains', subdomainRoutes);
app.use('/api/modrinth', modrinthRoutes);
app.use('/api/system', adminRoutes.system);
app.use('/api/users', adminRoutes.users);
app.use('/api/nodes', adminRoutes.nodes);
app.use('/api/settings', adminRoutes.settings);
app.use('/api/keys', adminRoutes.apiKeys);

/** Panel version + health for scripts/monitoring. */
app.get('/api/version', (req, res) => res.json({ name: cfg.panelName, version: cfg.version, node: process.version, hostname: os.hostname() }));

/** Node bootstrap scripts (also served at /node.sh for `curl | bash`). */
app.get('/node.sh', (req, res) => res.type('text/plain').sendFile(path.join(__dirname, 'scripts', 'node.sh')));
app.get('/node-agent.js', (req, res) => res.type('text/plain').sendFile(path.join(__dirname, 'scripts', 'node-agent.js')));
app.get('/install.sh', (req, res) => res.type('text/plain').sendFile(path.join(__dirname, 'install.sh')));
app.get('/fake-docker.js', (req, res) => res.type('text/plain').sendFile(path.join(__dirname, 'scripts', 'fake-docker.js')));
app.get('/uninstall.sh', (req, res) => res.type('text/plain').sendFile(path.join(__dirname, 'uninstall.sh')));

/* ---- static frontend ---- */
const PUBLIC_DIR = path.join(__dirname, 'public');
app.use(express.static(PUBLIC_DIR, { extensions: ['html'], maxAge: process.env.NODE_ENV === 'production' ? '1h' : 0 }));

app.get('/api/*', (req, res) => res.status(404).json({ error: `Unknown API route ${req.method} ${req.originalUrl}` }));

app.get('*', (req, res, next) => {
  const candidate = path.join(PUBLIC_DIR, `${req.path.replace(/^\/|\/$/g, '').split('/')[0] || 'index'}.html`);
  if (req.path !== '/' && fs.existsSync(candidate)) return res.sendFile(candidate);
  if (req.path.startsWith('/assets/')) return next();
  res.sendFile(path.join(PUBLIC_DIR, 'index.html'));
});

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  logger.error('http', `${req.method} ${req.originalUrl} -> ${err.message}`);
  if (err.code === 'LIMIT_FILE_SIZE') return res.status(413).json({ error: `Upload too large (max ${(cfg.maxUploadSize / 1024 / 1024 / 1024).toFixed(1)} GB)` });
  res.status(err.status || 500).json({ error: err.message || 'Internal panel error' });
});

/* ------------------------------ start ------------------------------ */
const server = http.createServer(app);
wsConsole.attach(server);

/**
 * Mirror lifecycle events into the configured Discord notification channel.
 * Failures are swallowed inside `discord.notify()` so a dead webhook can never
 * break a server start/stop.
 */
function wireDiscordNotifications() {
  const last = new Map(); // serverId -> status, to only announce transitions
  runtime.events.on('event', (ev) => {
    if (!ev || ev.serverId === undefined) return;
    if (ev.type !== 'status' && ev.type !== 'started') return;
    const server = db.find('servers', (s) => s.id === ev.serverId);
    if (!server) return;
    const status = ev.type === 'started' ? 'running' : (ev.data && ev.data.status) || 'unknown';
    if (last.get(server.id) === status) return;
    const previous = last.get(server.id);
    last.set(server.id, status);
    if (!previous) return; // first observation (e.g. boot reconcile) stays quiet
    if (status === 'running') {
      discordSvc.notify('started', server, { line: 'The server finished booting and is accepting players.' }).catch(() => {});
    } else if (status === 'crashed') {
      discordSvc.notify('crashed', server, { line: `Process exited${ev.data && ev.data.lastError ? `: ${ev.data.lastError}` : ''}` }).catch(() => {});
    } else if (status === 'offline') {
      discordSvc.notify('stopped', server, { line: 'The server is now offline.' }).catch(() => {});
    }
  });
}

(async function main() {
  await ensureOwnerFromEnv();
  reconcileServerStates().catch((err) => logger.warn('panel', `state reconcile: ${err.message}`));
  metrics.start();
  playersSvc.attachParser();
  discordSvc.autostart();
  wireDiscordNotifications();
  // adopt containers that survived a panel restart (docker backend) - the log
  // line only appears when docker is actually present
  // SFTP: a real ssh2 server, started only when enabled in settings
  sftpSvc.start().then((st) => {
    if (st.running) logger.ok('sftp', `SFTP ready on port ${st.port}`);
    else if (st.reason === 'missing-dependency') logger.warn('sftp', st.error);
  }).catch((err) => logger.warn('sftp', `start failed: ${err.message}`));
  runtime.reconcileContainers()
    .then((r) => {
      if (r.supported && r.adopted.length) logger.ok('runtime', `adopted ${r.adopted.length} running container(s) after restart`);
    })
    .catch((err) => logger.warn('runtime', `container reconcile: ${err.message}`));
  scheduler.start();
  nodesSvc.refresh().catch(() => {});
  setInterval(() => nodesSvc.refresh().catch(() => {}), 60000).unref?.();

  server.listen(cfg.port, cfg.host, () => {
    const users = (db.get('users') || []).length;
    const servers = (db.get('servers') || []).length;
    logger.ok('panel', `${cfg.panelName} v${cfg.version} listening on http://${cfg.host}:${cfg.port}`);
    logger.info('panel', `${servers} server(s), ${users} user(s) | data: ${cfg.dataDir}`);
    if (users === 0) logger.warn('panel', 'No users yet - open the panel and create the first account (it becomes the owner)');
    if (cfg.generatedSecret) logger.warn('panel', 'JWT_SECRET was generated and written to .env');
    autostartServers().catch((err) => logger.error('panel', err.message));
  });
})();

/* ------------------------------ shutdown ------------------------------ */
let shuttingDown = false;
async function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  logger.warn('panel', `${signal} received - shutting down`);
  try { await runtime.shutdownAll(); } catch (_) {}
  try { await playit.stopAll(); } catch (_) {}
  try { await sftpSvc.stop(); } catch (_) {}
  try { await db.flush(); } catch (_) {}
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 6000).unref?.();
}
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('uncaughtException', (err) => {
  logger.error('panel', `uncaught exception: ${err.stack || err.message}`);
  try { fs.appendFileSync(path.join(cfg.dataDir, 'crash.log'), `${new Date().toISOString()} ${err.stack}\n`); } catch (_) {}
});
process.on('unhandledRejection', (reason) => logger.error('panel', `unhandled rejection: ${reason && reason.message ? reason.message : reason}`));

module.exports = app;
