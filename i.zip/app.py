import os, sqlite3, secrets, time, threading, subprocess, re
from flask import Flask, request, jsonify, render_template, session, redirect
import docker
from docker.errors import NotFound, APIError

APP_DIR=os.path.dirname(os.path.abspath(__file__))
DB=os.path.join(APP_DIR,"skvm.db")
SECRET=os.getenv("SKVM_SECRET_KEY") or secrets.token_hex(32)
ADMIN_USER=os.getenv("SKVM_ADMIN_USERNAME","admin")
ADMIN_PASS=os.getenv("SKVM_ADMIN_PASSWORD","admin123")
IMAGE=os.getenv("SKVM_TUNNEL_IMAGE","skvm/ubuntu22-tmate:latest")
SSH_BASE=int(os.getenv("SKVM_SSH_PORT_BASE","22000"))
TMATE_ENABLED=os.getenv("SKVM_ENABLE_TMATE","1")=="1"
TMATE_TIMEOUT=int(os.getenv("SKVM_TMATE_TIMEOUT","12"))

app=Flask(__name__)
app.secret_key=SECRET
client=docker.from_env()

def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def init_db():
    c=db()
    c.execute("""create table if not exists vps(
      id integer primary key autoincrement, name text not null,
      container_id text, ssh_port integer, tmate_ssh text, status text,
      created integer not null)""")
    c.commit(); c.close()
init_db()

def auth():
    return session.get("admin")==True

def next_port():
    c=db()
    used={r["ssh_port"] for r in c.execute("select ssh_port from vps where ssh_port is not null")}
    c.close()
    p=SSH_BASE
    while p in used: p+=1
    return p

def tmate_session(container_id):
    """Best-effort: never blocks provisioning for the full tmate relay lifetime."""
    if not TMATE_ENABLED: return None
    cmd=["docker","exec",container_id,"sh","-lc",
         "command -v tmate >/dev/null 2>&1 || (apt-get update -qq && DEBIAN_FRONTEND=noninteractive apt-get install -y -qq tmate); "
         "tmate -S /tmp/tmate.sock new-session -d 2>/dev/null; "
         "tmate -S /tmp/tmate.sock wait tmate-ready >/dev/null 2>&1; "
         "tmate -S /tmp/tmate.sock display -p '#{tmate_ssh}' 2>/dev/null"]
    try:
        p=subprocess.run(cmd,capture_output=True,text=True,timeout=TMATE_TIMEOUT)
        out=(p.stdout or "").strip()
        m=re.search(r"ssh\s+\S+@\S+",out)
        return m.group(0) if m else None
    except Exception:
        return None

def create_vps(name,ram="1g",cpu=1,disk="10g"):
    port=next_port()
    # Disk quota is intentionally not passed: overlay2 quotas are not portable.
    c=client.containers.run(
        IMAGE, detach=True, name="skvm-"+secrets.token_hex(5),
        mem_limit=ram, nano_cpus=int(cpu*1e9),
        ports={"22/tcp":port},
        environment={"TZ":"UTC"},
        restart_policy={"Name":"unless-stopped"},
        labels={"skvm":"v6"}
    )
    # Wait briefly for sshd; provisioning must not wait on tmate.
    deadline=time.time()+8
    while time.time()<deadline:
        try:
            rc,_=c.exec_run("sh -lc 'ss -lnt 2>/dev/null | grep -q \":22 \" || true'")
            break
        except Exception: time.sleep(.4)
    tssh=tmate_session(c.id)
    status="running" if c.status=="running" else c.status
    conn=db()
    conn.execute("insert into vps(name,container_id,ssh_port,tmate_ssh,status,created) values(?,?,?,?,?,?)",
                 (name,c.id,port,tssh,status,int(time.time())))
    conn.commit(); conn.close()
    return {"id":conn.execute if False else None}

@app.get("/")
def home():
    if not auth(): return redirect("/login")
    c=db(); rows=c.execute("select * from vps order by id desc").fetchall(); c.close()
    return render_template("index.html",vps=rows)

@app.route("/login",methods=["GET","POST"])
def login():
    if request.method=="POST":
        if request.form.get("username")==ADMIN_USER and request.form.get("password")==ADMIN_PASS:
            session["admin"]=True; return redirect("/")
        return render_template("login.html",error="Invalid username or password.")
    return render_template("login.html")

@app.get("/logout")
def logout():
    session.clear(); return redirect("/login")

@app.post("/api/vps")
def api_create():
    if not auth(): return jsonify(error="unauthorized"),401
    data=request.get_json(silent=True) or {}
    name=(data.get("name") or "VPS").strip()[:60]
    try:
        port=next_port()
        c=client.containers.run(
            IMAGE,detach=True,name="skvm-"+secrets.token_hex(5),
            mem_limit=str(data.get("ram") or "1g"),
            nano_cpus=int(float(data.get("cpu") or 1)*1e9),
            ports={"22/tcp":port},
            restart_policy={"Name":"unless-stopped"},
            labels={"skvm":"v6"}
        )
        tssh=tmate_session(c.id)
        status="running"
        con=db(); cur=con.execute(
          "insert into vps(name,container_id,ssh_port,tmate_ssh,status,created) values(?,?,?,?,?,?)",
          (name,c.id,port,tssh,status,int(time.time())))
        vid=cur.lastrowid; con.commit(); con.close()
        return jsonify(id=vid,name=name,ssh_port=port,tmate_ssh=tssh,
                       direct_ssh=f"ssh root@<HOST> -p {port}",
                       tmate_available=bool(tssh))
    except Exception as e:
        return jsonify(error=str(e)),500

@app.post("/api/vps/<int:vid>/<action>")
def api_action(vid,action):
    if not auth(): return jsonify(error="unauthorized"),401
    con=db(); r=con.execute("select * from vps where id=?",(vid,)).fetchone()
    if not r: return jsonify(error="not found"),404
    try:
        c=client.containers.get(r["container_id"])
        if action=="start": c.start()
        elif action=="stop": c.stop(timeout=10)
        elif action=="restart": c.restart(timeout=10)
        elif action=="delete":
            c.remove(force=True); con.execute("delete from vps where id=?",(vid,)); con.commit(); con.close()
            return jsonify(ok=True)
        else: return jsonify(error="bad action"),400
        con.execute("update vps set status=? where id=?", (c.status,vid)); con.commit(); con.close()
        return jsonify(ok=True,status=c.status)
    except Exception as e:
        con.close(); return jsonify(error=str(e)),500

@app.get("/api/vps/<int:vid>")
def api_info(vid):
    if not auth(): return jsonify(error="unauthorized"),401
    con=db(); r=con.execute("select * from vps where id=?",(vid,)).fetchone(); con.close()
    if not r:return jsonify(error="not found"),404
    return jsonify(dict(r))

if __name__=="__main__":
    app.run(host="0.0.0.0",port=int(os.getenv("PORT","5555")))
