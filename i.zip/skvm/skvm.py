import os
import re
import secrets
import shlex
import time
import threading
from datetime import datetime, timezone
from functools import wraps

from flask import Flask, render_template, request, redirect, url_for, flash, abort, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash

try:
    import docker
    from docker.errors import DockerException, APIError, NotFound
except Exception:
    docker = None
    DockerException = APIError = NotFound = Exception

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.path.join(BASE_DIR, "skvm.db")

app = Flask(__name__)
app.config.update(
    SECRET_KEY=os.environ.get("SKVM_SECRET_KEY") or secrets.token_hex(32),
    SQLALCHEMY_DATABASE_URI=f"sqlite:///{DB_PATH}",
    SQLALCHEMY_TRACK_MODIFICATIONS=False,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    MAX_CONTENT_LENGTH=2 * 1024 * 1024,
)
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default="user")
    created_at = db.Column(db.DateTime, nullable=False, default=lambda: datetime.now(timezone.utc))
    vps = db.relationship("VPS", backref="owner", lazy=True, cascade="all, delete-orphan")

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class VPS(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False, index=True)
    node = db.Column(db.String(100), nullable=False, default="Local-Node-1")
    ram = db.Column(db.Integer, nullable=False)          # MB
    disk = db.Column(db.Integer, nullable=False)         # GB, metadata/limit request
    cpu = db.Column(db.Integer, nullable=False, default=1)
    os = db.Column(db.String(50), nullable=False, default="Ubuntu 22.04")
    container_id = db.Column(db.String(128), nullable=True, index=True)
    tmate_token = db.Column(db.Text, nullable=True)
    status = db.Column(db.String(30), nullable=False, default="Provisioning")
    error_message = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, nullable=False, default=lambda: datetime.now(timezone.utc))

class Settings(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    panel_name = db.Column(db.String(120), nullable=False, default="SKVM Panel")
    logo_url = db.Column(db.String(1000), nullable=True)
    banner_url = db.Column(db.String(1000), nullable=True)
    background_url = db.Column(db.String(1000), nullable=True)

def utcnow():
    return datetime.now(timezone.utc)

def docker_client():
    if docker is None:
        return None
    try:
        client = docker.from_env()
        client.ping()
        return client
    except Exception:
        return None

def admin_required(view):
    @wraps(view)
    @login_required
    def wrapped(*args, **kwargs):
        if current_user.role != "admin":
            abort(403)
        return view(*args, **kwargs)
    return wrapped

def csrf_token():
    token = session.get("_csrf")
    if not token:
        token = secrets.token_urlsafe(32)
        session["_csrf"] = token
    return token

app.jinja_env.globals["csrf_token"] = csrf_token

@app.before_request
def protect_state_changes():
    if request.method in {"POST", "PUT", "PATCH", "DELETE"}:
        sent = request.form.get("_csrf") or request.headers.get("X-CSRF-Token")
        expected = session.get("_csrf")
        if not expected or not sent or not secrets.compare_digest(str(sent), str(expected)):
            abort(400, description="Invalid CSRF token.")

@app.context_processor
def globals_for_templates():
    settings = Settings.query.first()
    return {
        "site": settings or Settings(panel_name="SKVM Panel"),
        "now": utcnow(),
    }

@login_manager.user_loader
def load_user(user_id):
    try:
        return db.session.get(User, int(user_id))
    except Exception:
        return None

def seed():
    db.create_all()
    settings = Settings.query.first()
    if not settings:
        settings = Settings(panel_name="SKVM Panel")
        db.session.add(settings)
    admin = User.query.filter_by(username=os.environ.get("SKVM_ADMIN_USERNAME", "admin")).first()
    if not admin:
        admin = User(
            username=os.environ.get("SKVM_ADMIN_USERNAME", "admin"),
            role="admin",
        )
        admin.set_password(os.environ.get("SKVM_ADMIN_PASSWORD", "admin123"))
        db.session.add(admin)
    elif admin.role != "admin":
        admin.role = "admin"
    db.session.commit()

def parse_ram(value):
    m = re.fullmatch(r"\s*(\d+)\s*(GB|MB)?\s*", value or "", re.I)
    if not m:
        raise ValueError("RAM must be like 1GB or 1024MB.")
    n = int(m.group(1))
    unit = (m.group(2) or "GB").upper()
    mb = n if unit == "MB" else n * 1024
    if not 128 <= mb <= 131072:
        raise ValueError("RAM must be between 128MB and 128GB.")
    return mb

def parse_disk(value):
    m = re.fullmatch(r"\s*(\d+)\s*(GB)?\s*", value or "", re.I)
    if not m:
        raise ValueError("Disk must be like 10GB.")
    gb = int(m.group(1))
    if not 1 <= gb <= 2048:
        raise ValueError("Disk must be between 1GB and 2048GB.")
    return gb

def parse_cpu(value):
    m = re.fullmatch(r"\s*(\d+)\s*(Core|Cores|CPU)?\s*", value or "", re.I)
    if not m:
        raise ValueError("CPU must be like 1 Core.")
    cpu = int(m.group(1))
    if not 1 <= cpu <= 64:
        raise ValueError("CPU must be between 1 and 64 cores.")
    return cpu

def image_for_os(os_name):
    return "ubuntu:22.04" if os_name == "Ubuntu 22.04" else "ubuntu:20.04"

def run_exec(container, command, timeout=180):
    result = container.exec_run(["bash", "-lc", command], stdout=True, stderr=True, demux=True)
    out, err = result.output if hasattr(result, "output") else (b"", b"")
    out = out or b""
    err = err or b""
    if result.exit_code != 0:
        raise RuntimeError((err + out).decode(errors="replace")[-6000:])
    return out.decode(errors="replace")

def provision_vps(vps_id):
    with app.app_context():
        vps = db.session.get(VPS, vps_id)
        if not vps:
            return
        client = docker_client()
        if not client:
            vps.status = "Failed"
            vps.error_message = "Docker Engine is unavailable. Start Docker and retry."
            db.session.commit()
            return

        container = None
        try:
            vps.status = "Provisioning"
            vps.error_message = None
            db.session.commit()

            image = image_for_os(vps.os)
            client.images.pull(image)

            name = f"skvm-{vps.id}-{secrets.token_hex(4)}"
            mem = vps.ram * 1024 * 1024
            nano_cpus = vps.cpu * 1_000_000_000

            # The disk field is recorded as a requested capacity. A portable Docker
            # volume quota cannot be guaranteed across storage drivers, so we avoid
            # falsely claiming a hard quota.
            container = client.containers.run(
                image=image,
                name=name,
                command=["bash", "-lc", "sleep infinity"],
                detach=True,
                mem_limit=mem,
                nano_cpus=nano_cpus,
                restart_policy={"Name": "unless-stopped"},
                labels={
                    "com.skvm.managed": "true",
                    "com.skvm.vps_id": str(vps.id),
                    "com.skvm.user_id": str(vps.user_id),
                },
            )
            vps.container_id = container.id
            db.session.commit()

            # Ubuntu images do not contain tmate. Install it without relying on the
            # obsolete `wait-for-server` command. tmate's current readiness command
            # is `wait tmate-ready`, then `display -p '#{tmate_ssh}'`.
            install = """
set -e
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y --no-install-recommends ca-certificates curl gnupg openssh-client
if ! command -v tmate >/dev/null 2>&1; then
  curl -fsSL https://packagecloud.io/install/repositories/tmate-io/rpm/script.deb.sh | bash || true
fi
apt-get update -y
apt-get install -y --no-install-recommends tmate
rm -rf /var/lib/apt/lists/*
"""
            run_exec(container, install, timeout=300)

            start = """
set -e
rm -f /tmp/skvm-tmate.sock
tmate -S /tmp/skvm-tmate.sock new-session -d
tmate -S /tmp/skvm-tmate.sock wait tmate-ready
tmate -S /tmp/skvm-tmate.sock display -p '#{tmate_ssh}'
"""
            session_text = run_exec(container, start, timeout=120).strip()
            match = re.search(r"(?m)ssh\s+\S+@\S+", session_text)
            if not match:
                # Retry once after a short relay-registration delay.
                time.sleep(4)
                session_text = run_exec(
                    container,
                    "tmate -S /tmp/skvm-tmate.sock wait tmate-ready; "
                    "tmate -S /tmp/skvm-tmate.sock display -p '#{tmate_ssh}'",
                    timeout=90,
                ).strip()
                match = re.search(r"(?m)ssh\s+\S+@\S+", session_text)

            if not match:
                raise RuntimeError(
                    "tmate did not return an SSH session. Output: "
                    + session_text[-4000:]
                )

            vps.tmate_token = match.group(0)
            vps.status = "Active"
            vps.error_message = None
            db.session.commit()

        except Exception as exc:
            if container:
                try:
                    container.remove(force=True)
                except Exception:
                    pass
            vps.container_id = None
            vps.tmate_token = None
            vps.status = "Failed"
            vps.error_message = str(exc)[-6000:]
            db.session.commit()

def container_for(vps):
    client = docker_client()
    if not client or not vps.container_id:
        return None, client
    try:
        return client.containers.get(vps.container_id), client
    except Exception:
        return None, client

@app.route("/")
def starter():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))
    return render_template("starter.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            login_user(user, remember=True)
            return redirect(url_for("dashboard"))
        flash("Invalid username or password.", "error")
    return render_template("login.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if not re.fullmatch(r"[A-Za-z0-9_.-]{3,32}", username):
            flash("Username must be 3–32 characters and contain only letters, numbers, dot, underscore or hyphen.", "error")
        elif len(password) < 8:
            flash("Password must contain at least 8 characters.", "error")
        elif User.query.filter_by(username=username).first():
            flash("Username is already registered.", "error")
        else:
            user = User(username=username, role="user")
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            flash("Account created. You can now sign in.", "success")
            return redirect(url_for("login"))
    return render_template("register.html")

@app.post("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("starter"))

@app.route("/dashboard")
@login_required
def dashboard():
    vps_list = VPS.query.filter_by(user_id=current_user.id).order_by(VPS.created_at.desc()).all()
    active = sum(v.status == "Active" for v in vps_list)
    return render_template("dashboard.html", vps_list=vps_list, active=active)

@app.route("/myvps")
@login_required
def myvps():
    vps_list = VPS.query.filter_by(user_id=current_user.id).order_by(VPS.created_at.desc()).all()
    return render_template("myvps.html", vps_list=vps_list)

@app.route("/vps/<int:vps_id>")
@login_required
def vps_details(vps_id):
    vps = db.session.get(VPS, vps_id)
    if not vps:
        abort(404)
    if vps.user_id != current_user.id and current_user.role != "admin":
        abort(403)
    return render_template("vps_details.html", vps=vps)

@app.post("/vps/<int:vps_id>/action/<action>")
@login_required
def vps_action(vps_id, action):
    vps = db.session.get(VPS, vps_id)
    if not vps:
        abort(404)
    if vps.user_id != current_user.id and current_user.role != "admin":
        abort(403)
    container, client = container_for(vps)
    if not container:
        flash("Docker container is unavailable.", "error")
        return redirect(url_for("vps_details", vps_id=vps.id))
    try:
        if action == "start":
            container.start()
        elif action == "stop":
            container.stop(timeout=10)
        elif action == "restart":
            container.restart(timeout=10)
        else:
            abort(400)
        vps.status = "Active" if action != "stop" else "Stopped"
        db.session.commit()
        flash(f"Container {action}ed successfully.", "success")
    except Exception as exc:
        flash(str(exc), "error")
    return redirect(url_for("vps_details", vps_id=vps.id))

@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    if request.method == "POST":
        current = request.form.get("current_password", "")
        new = request.form.get("new_password", "")
        if not current_user.check_password(current):
            flash("Current password is incorrect.", "error")
        elif len(new) < 8:
            flash("New password must contain at least 8 characters.", "error")
        else:
            current_user.set_password(new)
            db.session.commit()
            flash("Password updated.", "success")
    return render_template("profile.html")

@app.route("/admin")
@admin_required
def admin_dashboard():
    client = docker_client()
    running = 0
    total_containers = 0
    docker_ok = bool(client)
    if client:
        try:
            containers = client.containers.list(all=True, filters={"label": "com.skvm.managed=true"})
            total_containers = len(containers)
            running = sum(c.status == "running" for c in containers)
        except Exception:
            docker_ok = False
    return render_template(
        "admin_dashboard.html",
        docker_ok=docker_ok,
        running=running,
        total_containers=total_containers,
        users_count=User.query.count(),
        vps_count=VPS.query.count(),
        recent_vps=VPS.query.order_by(VPS.created_at.desc()).limit(8).all(),
    )

@app.route("/admin/create-vps", methods=["GET", "POST"])
@admin_required
def create_vps():
    users = User.query.order_by(User.username.asc()).all()
    if request.method == "POST":
        try:
            owner_id = int(request.form.get("user_id", ""))
            owner = db.session.get(User, owner_id)
            if not owner:
                raise ValueError("Selected user does not exist.")
            name = request.form.get("name", "").strip()
            if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9 _.-]{1,99}", name):
                raise ValueError("VPS name must be 2–100 characters.")
            ram = parse_ram(request.form.get("ram"))
            disk = parse_disk(request.form.get("disk"))
            cpu = parse_cpu(request.form.get("cpu"))
            os_name = request.form.get("os")
            if os_name not in {"Ubuntu 22.04", "Ubuntu 20.04"}:
                raise ValueError("Unsupported OS.")
            vps = VPS(
                name=name,
                user_id=owner.id,
                node="Local-Node-1",
                ram=ram,
                disk=disk,
                cpu=cpu,
                os=os_name,
                status="Provisioning",
            )
            db.session.add(vps)
            db.session.commit()
            threading.Thread(target=provision_vps, args=(vps.id,), daemon=True).start()
            flash("Deployment started. Open the VPS details page to monitor it.", "success")
            return redirect(url_for("vps_details", vps_id=vps.id))
        except Exception as exc:
            db.session.rollback()
            flash(str(exc), "error")
    return render_template("create_vps.html", users=users)

@app.route("/admin/users")
@admin_required
def user_management():
    users = User.query.order_by(User.created_at.desc()).all()
    return render_template("user_management.html", users=users)

@app.post("/admin/users/<int:user_id>/role")
@admin_required
def change_role(user_id):
    user = db.session.get(User, user_id)
    if not user:
        abort(404)
    if user.id == current_user.id:
        flash("You cannot change your own admin role here.", "error")
    else:
        user.role = "admin" if user.role != "admin" else "user"
        db.session.commit()
        flash("User role updated.", "success")
    return redirect(url_for("user_management"))

@app.post("/admin/users/<int:user_id>/delete")
@admin_required
def delete_user(user_id):
    user = db.session.get(User, user_id)
    if not user:
        abort(404)
    if user.id == current_user.id:
        flash("You cannot delete your own account.", "error")
    elif user.role == "admin":
        flash("Admin accounts cannot be deleted from this page.", "error")
    else:
        for vps in list(user.vps):
            container, client = container_for(vps)
            if container:
                try:
                    container.remove(force=True)
                except Exception:
                    pass
        db.session.delete(user)
        db.session.commit()
        flash("User deleted.", "success")
    return redirect(url_for("user_management"))

@app.route("/admin/settings", methods=["GET", "POST"])
@admin_required
def settings():
    obj = Settings.query.first()
    if request.method == "POST":
        obj.panel_name = request.form.get("panel_name", "").strip()[:120] or "SKVM Panel"
        obj.logo_url = request.form.get("logo_url", "").strip()[:1000] or None
        obj.banner_url = request.form.get("banner_url", "").strip()[:1000] or None
        obj.background_url = request.form.get("background_url", "").strip()[:1000] or None
        db.session.commit()
        flash("Panel settings saved.", "success")
    return render_template("settings.html")

@app.get("/api/vps/<int:vps_id>/status")
@login_required
def api_vps_status(vps_id):
    vps = db.session.get(VPS, vps_id)
    if not vps:
        abort(404)
    if vps.user_id != current_user.id and current_user.role != "admin":
        abort(403)
    return jsonify({
        "status": vps.status,
        "tmate_token": vps.tmate_token,
        "error": vps.error_message,
    })

@app.errorhandler(403)
def forbidden(_):
    return render_template("starter.html", error_message="Access denied."), 403

@app.errorhandler(400)
def bad_request(e):
    return render_template("starter.html", error_message=getattr(e, "description", "Bad request.")), 400

@app.errorhandler(404)
def not_found(_):
    return render_template("starter.html", error_message="Page not found."), 404

with app.app_context():
    seed()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("SKVM_PORT", "5555")), debug=False)
