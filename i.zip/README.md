# SKVM Production Build

## Install
sudo bash install.sh

## Default admin
Username: admin
Password: admin123

## Panel
http://SERVER_IP:5555

## Diagnostics
sudo systemctl status skvm
sudo journalctl -u skvm -f
curl http://127.0.0.1:5555/health

## tmate
SKVM creates a persistent container, installs tmate, starts a session and polls:
tmate -S /tmp/skvm-tmate.sock display -p '#{tmate_ssh}'

It does NOT use the obsolete wait-for-server command.

## Disk
SKVM does not request Docker storage_opt/btrfs quotas. The requested disk value is metadata unless the Docker host has a supported quota mechanism. This prevents btrfs "operation not permitted" from breaking provisioning.

## Network
Default is Docker bridge. If your host specifically requires host networking for outbound relay connectivity, set:
SKVM_DOCKER_NETWORK=host
in .env and restart:
sudo systemctl restart skvm

Host networking has tradeoffs and should only be used when required.
