# SKVM v8.2

Professional Flask + Docker VPS control panel for a real Linux VPS and Docker-enabled development environments.

## Default administrator
Username: `admin`  
Password: `admin123`

Change it immediately after the first login.

## Real Ubuntu/Debian VPS
```bash
chmod +x install.sh
sudo ./install.sh
```

The installer installs Docker, creates a healthy Python environment, builds Ubuntu 22.04, Ubuntu 24.04 and Debian 12 guest images locally, initializes SQLite, and installs a Gunicorn systemd service.

Open `http://SERVER_IP:5555`.

If UFW is enabled:
```bash
sudo ufw allow 5555/tcp
sudo ufw allow 10000:20000/tcp
```

## CodeSandbox / development
```bash
chmod +x start.sh
./start.sh
```

`start.sh` does not use systemd. It repairs/recreates a broken `.venv` when pip is missing and can fall back to system Python when venv support is unavailable.

A real Docker daemon is required for actual VPS/container creation. If CodeSandbox does not expose Docker, the web panel can run but cannot create real Docker VPS containers.

## Features
- Restored and visible Settings page
- Admin dashboard and Docker health
- Admin-only VPS creation
- User management and VPS assignment
- Start / Stop / Restart
- Reprovision / Delete
- Browser terminal
- Direct SSH credentials and port
- Optional asynchronous tmate access
- tmate failures never block a healthy VPS
- Local guest images; no nonexistent `skvm/ubuntu22-tmate` image
- CSRF protection and hashed passwords
- Audit log and notifications
- Maintenance mode and registration control
- Mobile-friendly UI

## tmate
A tmate SSH/web session can only be registered when the guest can reach the tmate relay. The panel never waits for tmate during VPS provisioning. Direct SSH is available as soon as the container is healthy.

## Disk
`disk_gb` is stored and displayed, but Docker's default overlay storage does not guarantee a hard per-container disk quota. Hard quotas require a quota-capable storage driver/filesystem.
