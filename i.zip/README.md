# Zenith Panel

A **Pterodactyl-style Minecraft server hosting panel** with a pure **Node.js backend** — no PHP, no separate Wings daemon, no database server to install. One process supervises your Minecraft servers, streams their consoles in real time, installs plugins straight from **Modrinth**, gives every server a **subdomain**, manages **players in one click**, graphs host history, and can even be driven from **Discord**.

> UI/pages were inspired by the [JTG panel](https://github.com/JishnuTheGamer/Jtg) (dark, control-room look); the backend, runtime supervisor, installer and every line of code here are original and self-contained.
>
> **Everything in this repository is new code.** No files were copied from the reference repository.

```
   ┌───────────────────────────────────────────────────────────────┐
   │  Browser (vanilla JS UI, no build step)                       │
   │  dashboard · analytics · servers · console · players · backups  │
   └───────────────┬───────────────────────────────┬───────────────┘
                   │ REST /api/*                    │ WebSocket /ws
   ┌───────────────▼───────────────────────────────▼───────────────┐
   │  Zenith Panel  (single Node.js process)                        │
   │   express API · ws console · auth/RBAC · scheduler             │
   │   runtime supervisor ── spawns ──► java -jar server.jar        │
   │   modrinth · playit · backups · java manager · nodes           │
   └───────────────┬───────────────────────────────────────────────┘
                   │ child processes + filesystem
      servers/<id>/  world/ plugins/ server.properties  …  backups/
```

---

## Feature overview

### Real-time console
* WebSocket stream (`/ws`) with a rolling in-memory buffer (3000 lines default) — reconnect and you get a snapshot, not a blank screen.
* Automatic fallback to HTTP long-polling when a proxy blocks websockets, so the console works everywhere.
* Command input, coloured log classification (join/leave, WARN, ERROR, panel/installer lines), player tracking parsed from the log, "jump to end", clear buffer.
* Power actions: start, restart, graceful stop (sends `stop`/`end`, then SIGTERM, then SIGKILL after `STOP_TIMEOUT`), force kill.
* Live CPU %, memory (RSS of the JVM + children), uptime, disk usage, progress bars for installs/backups/Modrinth downloads.

### Server software
Install and switch between, all downloaded live from upstream APIs (new Minecraft versions appear without a panel update):

| Type | Source | Notes |
|---|---|---|
| Vanilla | Mojang version manifest | all releases |
| Paper / Velocity | `fill.papermc.io` v3 | stable build picked automatically |
| Purpur | `api.purpurmc.org` | latest build |
| Fabric / Quilt | fabricmc / quiltmc meta | loader + server launcher jar |
| Forge / NeoForge | maven | installer run for you (`--installServer`) |
| BungeeCord | `ci.md-5.net` | latest successful build |
| Spigot | BuildTools | optionally built from source |
| Custom | upload | bring your own jar |

Version **migration** (e.g. Paper 1.21.1 → 1.21.4) takes an automatic safety backup first, re-installs the jar and reports progress in the console.

### Modrinth integration (plugins & mods)
* Global search page + per-server **browse** tab pre-filtered by the server's loader and Minecraft version (Paper→`paper|spigot|bukkit`, Fabric→`fabric`, NeoForge→`neoforge`, …).
* One-click install into `/plugins` or `/mods`, with **recursive required-dependency resolution**.
* Installed list with version, size, source, enable/disable (renames to `.jar.disabled`), delete, and **update checking** against the newest compatible version (old jar kept as `.bak`).
* Project detail modal with changelog-free version picker (all compatible builds, release/beta/alpha badges).
* Icons are proxied through the panel, so the UI also works on networks that block external requests.

### playit.gg tunnels
Free public addresses without port forwarding, implemented against the playit **agent v1.x** (daemon + CLI):
1. Panel downloads `playit-agent` + `playit-cli` for the host architecture into `data/bin`.
2. `playit-cli claim generate` → `claim url` → a real `https://playit.gg/claim/<code>` link is shown in the UI **and** in the server console.
3. `claim exchange` runs in the background; the moment you approve the agent in your browser, the secret is stored and the daemon starts (`playit-agent --secret … --socket-path … --log-path …`).
4. Agent logs are tailed into the server console; tunnel addresses (`*.playit.gg:port`) are parsed and shown as the public address.
5. Per-server isolation (own secret, own socket, own log), optional autostart with the server, reset flow to re-claim, or paste an existing secret key.

### File manager
Browse, create folders, edit text/config files in a modal editor, upload (drag & drop, multi-file), download files **and folders** (zipped on the fly), rename, copy, delete, zip/unzip archives, recursive file search, live `server.properties` editor with the common gameplay keys. Every path is validated against traversal.

### Docker containers (container runtime)
* Switch a node to **Docker containers** (Nodes → node settings, or `install.sh --node docker`) and every server on
  it runs as its own container: `eclipse-temurin:<java>-jre`, the server directory bind-mounted at `/data`,
  the allocation published for **tcp + udp**, `--memory <Xmx + 384 MB>` and `--cpus` when the node has a core limit.
* The console is a real attach (`docker start -a -i`), so the live output, player list, one-click player actions and
  `docker stats` numbers (the kernel's, not estimates) all behave exactly like the process runtime.
* The panel refuses to pretend: if Docker is missing, saving the node fails with the exact error, a start writes
  `Docker is not available on this node: …` to the server console and the server is marked crashed instead of "running".
* `install.sh` installs Docker from Docker's own apt repository, pre-pulls the Temurin image, adds your user to the
  `docker` group and proves a container really starts before the node is marked healthy.

### Automatic node installation (installer)
* `install.sh` (no flags needed) detects the host - CPU cores, RAM, disk, IPs, Java, Docker - boots the panel,
  registers **Local Node** through the panel API with a **generated credential** (`OWNER_SECRET` protects that path),
  then runs a **real health check**; only if every check answers does the node go online.
* Node modes: `--node local` (java processes), `--node docker` (containers), `--node remote` (this host via the agent
  API), `--node none`. Optional extras: `--docker yes|no|auto`, `--wings auto|yes|no` (real Pterodactyl wings daemon).
* Idempotent: re-running updates the existing node and keeps its credentials. `--repair` re-detects the host, fixes the
  node and re-runs the health check; `--node-only` touches only the node; `--uninstall [--purge]` stops the panel and
  removes the agent, wings config, containers and credentials (your `data/`, `servers/` and `backups/` are never deleted).
* Everything is logged to a timestamped file (`/tmp/zenith-install-*.log` by default) and every failure prints the exact
  command output instead of a success message.

### SFTP
* A **real SSH/SFTP server** (ssh2) with its own generated RSA host key: log in as `<panel user>.<server id>` with your
  panel password (or an API key) and reach *that server's* files with FileZilla, WinSCP, Cyberduck, `sftp` or `rsync -e ssh`.
* Sessions are chrooted to the server directory - `..` and absolute paths are rejected, `level.dat`, worlds, plugins and
  configs are all reachable, and every request is answered (never a silently dropped session).
* Admin → Settings toggles it and sets the port; the state shown in the UI is the real listener state.

### Worlds
* Detects every world on disk (any folder with a `level.dat`), sizes it, counts region files and shows when it was last
  played. Activate (rewrites `level-name`), download as a real zip, duplicate, import a world zip (traversal-safe,
  `level.dat` required) and delete - the active world is protected, and nether/end folders travel with their overworld.

### server.properties editor
* A labelled form for the common settings (motd, port, players, difficulty, whitelist, view distance, ...) plus every
  other key, and a raw text view. Saves keep a `server.properties.bak`, refuse junk, and warn when a running server
  needs a restart.

### Remote nodes
* Add a node → run the generated one-liner on that machine (installs Node, Java, the agent and a systemd service called `zenith-node`).
* Pick the node when creating a server, or move an existing (stopped) server to it later.
* The agent API is token-authenticated (`x-node-token`), heartbeats every 30 s and reports cores, load, memory, disk and its running servers; the panel pings it every 60 s so the Nodes page shows live bars.
* Console, power, commands, stats, schedules, backups **and Modrinth plugin/mod installs** work on remote servers (the node downloads the jar itself); general file-manager access still targets the panel host's copy.

### Subdomains (join addresses)
* Admin sets a base domain + provider once (**Admin → Settings → Subdomains**) — used by every server.
* With a **Cloudflare API token** the panel creates and deletes the records itself: an `A` record for the node IP plus a `_minecraft._tcp` **SRV** record pointing at the port, so players join `survival.example.com` and never type a port.
* Without a token everything still works in **manual mode**: the panel prints the exact `A`/`SRV` pair to paste into any DNS provider.
* Create a subdomain from the create-server wizard or later in **Server → Network**; hostnames are uniqueness-checked panel-wide and removed cleanly (records included).

### Player manager (live list + one-click actions)
* Live online list with **real 3D skin heads** (fetched through the panel's image proxy, so it works behind firewalls and on mobile that block skin CDNs).
* One-click buttons for the things admins actually do: **full health**, **full hunger**, **op/deop**, plus a full action sheet — give items, gamemode, XP, flight, teleport to spawn, whitelist/unwhitelist, kick, ban/pardon, kill, clear inventory, play time.
* Works on a name you type too (for offline players), in bulk via the API, and identically on **remote nodes** (the command is forwarded to that node's agent).
* Every action is validated server-side (player names, item ids, counts, gamemode, reasons) before it reaches the console — no command injection, and all of them are written to the audit log.

### Analytics & allocations
* The panel samples the host every 5 s into a bounded in-memory ring buffer (1 hour) and draws **static SVG charts** — CPU, memory, players online, servers running — no chart library, no CDN, nothing to load.
* Dashboards show live sparklines; **Analytics** (`analytics.html`) shows the full window, peak/average summary, a server-status donut and the audit trail.
* **Allocations** (`allocations.html`) maps every port of every node: used, free, next free, and which server/owner holds it.

### Discord bot
* Configure a bot token + guild id in **Admin → Settings → Subdomains & Discord** and the panel connects its own gateway client — no `discord.js`, no extra dependency (`ws` is already there).
* Commands like `!servers`, `!status`, `!start/!stop/!restart`, `!cmd`, `!players`, `!op`, `!give`, `!heal`, `!allocations` and `!newserver` (the bot asks for a username, registers the account if needed, then creates the server).
* Identity is mapped to panel accounts (`!link <username> <password>`), so a Discord user only sees and controls what their panel account may access; server events (started/stopped/crashed) can be posted to a notification channel.
* Step-by-step setup, permissions and troubleshooting: [`docs/DISCORD.md`](docs/DISCORD.md).

### Backups
* Zip backups into `backups/<server-id>/` using the system `zip` (streaming, low memory) with an `adm-zip` fallback.
* Create (manual or scheduled), download, lock (never pruned), delete, prune, and **restore** — which stops the server, extracts over the files, rewrites `eula.txt` and restarts it.
* Progress for big worlds is streamed to the console.

### Scheduling
Per-server cron tasks (`minute hour day month weekday`): start, restart, stop, backup, or run a console command. Tick resolution 30 s, "run now" button, last-run result stored.

### Panel administration
* Roles: **owner > admin > user**, plus per-server **subusers** with granular permissions (`console, files, backups, plugins, network, settings, schedules, subusers`).
* User CRUD, suspend, password reset, audit log of every action (`/api/system/activity`).
* Panel settings: name, open registration, default memory, max servers per user, automatic JRE downloads, crash auto-restart.
* API keys (`X-API-Key`, shown once at creation) for automation, panel config export, health/metrics endpoints.
* Per-user server limits (quota per account, falling back to the panel-wide default in Settings).
* **Multi-machine hosting:** besides the built-in local node you can attach any number of remote nodes with one `curl | bash` command. The agent downloads the server jar, provisions its own JRE, and runs the process there - the panel keeps the console (mirrored in real time), power controls, live stats, schedules, backups (archived on the node, pulled to the panel) and server moves between nodes. Each node has a detail view with live telemetry, its server list and the agent command.

### Java runtimes
* Detects JVMs (PATH, `JAVA_HOME`, `/usr/lib/jvm`, panel-managed).
* Automatically downloads **Temurin JREs** (Adoptium API) into `data/java/jre-<major>` when a server needs one — so a fresh VPS can run a 1.21.4+ server with zero manual Java setup.
* Version mapping: 26.x → 25, 1.20.5+/1.21+ → 21, 1.18–1.20.4 → 17, older → 8. Pin a runtime per server if you prefer.

### Auto-installer (`install.sh`)
One script for **any** environment: Ubuntu/Debian/Mint, RHEL/Rocky/Alma/Fedora/CentOS, Arch/Manjaro, openSUSE, Alpine, with or without systemd.

---

## Screens

| Page | What is on it |
|---|---|
| `index.html` | sign in (opens the register form when registration is allowed) |
| `register.html` | stand-alone sign-up page (respects the panel's registration setting) |
| `dashboard.html` | live console, players, host resources, server cards |
| `analytics.html` | CPU/RAM/players history charts built from the metrics ring buffer |
| `servers.html` | server list + the create wizard (subdomain, node, software, memory) |
| `server.html` | **12 tabs**: console, players, files, properties, worlds, sftp, Modrinth, backups, network, schedules, people, settings |
| `nodes.html` | local + remote nodes, Docker engine card, health checks, node settings, allocations |
| `allocations.html` | every port across every node, what is free and what is used |
| `admin.html` | **7 tabs**: users, servers, settings (runtime/SFTP), integrations (DNS + Discord), allocations, java, activity |
| `account.html` | profile, password, API keys, your servers |
| `apikeys.html` | dedicated API key page with copy-ready curl examples |

## Quick start

### 1. One-command install (recommended)

```bash
# interactive
curl -fsSL https://raw.githubusercontent.com/your-org/zenith-panel/main/install.sh | sudo bash

# fully unattended (installs Node 20, Java, PM2/service, generates secrets, creates the owner)
sudo bash install.sh --yes --port 8080 --user admin --password 'SuperSecret123' --email me@example.com
```

What it does: detects the distro + package manager → installs base tools, Node.js 18+/20 and Java → clones/copies the panel → writes `.env` with generated `JWT_SECRET` + `NODE_SECRET` → `npm ci --omit=dev` → creates the owner account → installs a **systemd service** (or PM2 / Docker / nohup fallback) → optional **nginx + Let's Encrypt** reverse proxy with websocket upgrade → opens the firewall (panel port + 25565-25665) → health check → prints the panel URL and credentials.

Useful flags:

```bash
bash install.sh --help
  -p, --port <n>        panel port (default 8080)
  -u, --user <name>     owner username        -P, --password <pw>   owner password
  -e, --email <mail>    owner e-mail          -n, --name "<panel>"  panel name
  -d, --dir <path>      install directory     --url <url>           public panel URL
      --domain <fqdn>   configure nginx       --ssl                 also request a cert
  -y, --yes             unattended            --docker              run via docker compose
      --pm2             use PM2 instead of systemd
      --skip-java / --skip-node               --update / --uninstall [--purge]
```

### 2. Manual install

```bash
git clone <this repo> zenith-panel && cd zenith-panel
npm install
cp .env.example .env          # set JWT_SECRET at minimum
npm run createuser -- --user admin --pass 'SuperSecret123' --role owner
npm start                     # http://localhost:8080
```

### 3. Docker

```bash
JWT_SECRET=$(openssl rand -hex 32) ZENITH_OWNER_PASS=changeme123 docker compose up -d --build
```

### 4. Management CLI

```bash
./scripts/zenith status|start|stop|restart|logs|update
./scripts/zenith user add steve 'theirpassword' user
./scripts/zenith backup-db | doctor | version
```

### 5. Verify an install

`scripts/smoke.js` logs in and walks the whole API plus the websocket console handshake - useful
after an upgrade or when something "looks wrong":

```bash
node scripts/smoke.js --url http://localhost:8080 --user admin --pass 'yourpassword'
#  27 passed, 1 skipped  <- exit code 0 means every subsystem answered

# optional: render every page headlessly and fail on any JavaScript error
npm install --no-save jsdom
node scripts/uitest.js --url http://localhost:8080 --user admin --pass 'yourpassword'
#  All UI checks passed.
```

---

## Repository layout

```
server.js                  entry point: express + ws + bootstrap
install.sh / uninstall.sh  universal installer, remover
ecosystem.config.cjs       PM2 config        Dockerfile / docker-compose.yml
scripts/
  createuser.js            CLI user management
  zenith                   service management CLI
  node-agent.js            remote node agent (heartbeat + node API on another box)
  smoke.js / uitest.js     end-to-end API/websocket self-test, headless UI test (jsdom)
  node.sh                  one-liner node installer (curl | bash)
  fake-docker.js           test double for the docker CLI (tests only - never used at runtime)
src/
  config.js  db.js         env config, dependency-free JSON database
  auth.js    logger.js     JWT + bcrypt + RBAC + API keys, audit log
  routes/                  auth, servers, files, backups, modrinth, playit,
                           players, subdomains, admin
  services/
    runtime.js             process supervisor, log ring buffer, players, stats hook
    stats.js               /proc sampling (CPU%, RSS of process tree), host metrics
    versions.js            upstream catalogue + jar/installer downloader
    java.js                JVM detection + Temurin downloader
    modrinth.js            search, install, dependencies, updates, enable/disable
    playit.js              v1.x claim flow + daemon supervision
    backups.js             zip/unzip backup engine
    files.js               safe file manager
    docker.js              real docker CLI wrapper (probe, pull, create, attach, stats, logs)
    servers.js  nodes.js   server records, port allocation, nodes + auto-registration/health checks
    worlds.js              world detection, activation, zip export/import
    sftp.js                ssh2 SFTP server: auth via panel credentials, chroot per server
    players.js             player action table (op/heal/feed/give/…) + roster parsing
    metrics.js             5 s host ring buffer behind the Analytics graphs
    dns.js                 subdomains: Cloudflare records or manual instructions
    discord.js             gateway bot (no discord.js): commands, !link, !newserver
    scheduler.js           cron ticker + task execution
  ws/console.js            websocket fan-out, auth, stats push
public/                    zero-build frontend (HTML + CSS + ES5-ish JS)
  index.html  register.html  dashboard.html  analytics.html  servers.html  server.html
  nodes.html  allocations.html  admin.html  account.html  apikeys.html
  css/app.css  js/*.js
docs/                      API.md, ARCHITECTURE.md, NODES.md, DISCORD.md
data/  servers/  backups/   runtime state (git-ignored)
```

## Configuration (`.env`)

| Key | Default | Meaning |
|---|---|---|
| `PANEL_NAME` / `PANEL_URL` | Zenith Panel / `http://localhost:8080` | branding + URLs used in install commands |
| `PORT` / `HOST` | 8080 / 0.0.0.0 | panel bind address |
| `JWT_SECRET` | generated | token signing (auto-written if missing) |
| `OWNER_SECRET` | installer-generated | lets `install.sh` register the local node without a password; blank it to disable |
| `NODE_RUNTIME` | `process` | default runtime for new servers on this host: `process` or `docker` |
| `SFTP_ENABLED` / `SFTP_PORT` | `true` / `2022` | the real SFTP server (ssh2) and its port |
| `ALLOW_REGISTRATION` | true | open self-registration |
| `DATA_DIR` / `SERVER_DATA_DIR` / `BACKUP_DIR` | ./data ./servers ./backups | storage layout |
| `MAX_UPLOAD_SIZE` | 5 GB | file manager upload cap |
| `JAVA_BIN` / `JAVA_DIR` | java / ./data/java | JVM discovery + managed JRE location |
| `STOP_TIMEOUT` / `LOG_BUFFER_LINES` | 20 / 3000 | graceful stop window, console buffer |
| `AUTOSTART_SERVERS` | true | start `autoStart` servers when the panel boots |
| `MODRINTH_API` / `MODRINTH_USER_AGENT` | api.modrinth.com/v2 | Modrinth endpoint + contact UA |
| `PLAYIT_BIN_DIR` / `PLAYIT_GLOBAL_SECRET` | ./data/bin / empty | agent location, shared secret |
| `NODE_SECRET` | generated | shared secret for remote node registration |

## Security notes

* bcrypt password hashing, JWT sessions with a `passwordVersion` so password changes invalidate old tokens, login brute-force throttling per IP+user.
* Every server route passes through `serverScope(permission)` — ownership, subuser permissions and admin role are checked before the handler runs.
* File manager and Modrinth installer resolve paths with `safeJoin()`; `../../` escapes are rejected, and the panel's own `.playit` folder is off limits.
* Servers are spawned with `spawn(bin, args)` — never a shell — so a server name or console line cannot inject commands.
* Run the panel as a **dedicated non-root user**; child JVMs inherit that privilege. Containers: mount `data/ servers/ backups/` as volumes.
* Loot/abuse note: the panel is a remote-control surface for your machine. Put it behind HTTPS + a strong password (the installer offers nginx + certbot), or keep it on a private network/VPN.

## API cheat-sheet

Full reference: [`docs/API.md`](docs/API.md). Console socket: [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md).

```bash
TOKEN=$(curl -s -X POST localhost:8080/api/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"username":"admin","password":"..."}' | jq -r .token)

curl -s -H "Authorization: Bearer $TOKEN" localhost:8080/api/servers            # list
curl -s -X POST -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  -d '{"name":"SMP","serverType":"PAPER","version":"1.21.4","memory":4096,"eulaAccepted":true}' \
  localhost:8080/api/servers                                                    # create + install
curl -s -X POST -H "Authorization: Bearer $TOKEN" localhost:8080/api/servers/<id>/start
curl -s -X POST -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  -d '{"command":"say hi"}' localhost:8080/api/servers/<id>/command
curl -s -H "Authorization: Bearer $TOKEN" "localhost:8080/api/modrinth/search?q=essentials&projectType=plugin"

# players: list, one-click action, bulk
curl -s -H "Authorization: Bearer $TOKEN" localhost:8080/api/servers/<id>/players
curl -s -X POST -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  -d '{"action":"heal"}' localhost:8080/api/servers/<id>/players/Notch/action
curl -s -X POST -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  -d '{"action":"give","item":"diamond","count":8}' localhost:8080/api/servers/<id>/players/Notch/action

# subdomains, history, allocations, discord
curl -s -H "Authorization: Bearer $TOKEN" localhost:8080/api/servers/<id>/subdomains
curl -s -X POST -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  -d '{"sub":"survival"}' localhost:8080/api/servers/<id>/subdomains
curl -s -H "Authorization: Bearer $TOKEN" "localhost:8080/api/system/history?minutes=30"
curl -s -H "Authorization: Bearer $TOKEN" localhost:8080/api/system/allocations
curl -s -H "Authorization: Bearer $TOKEN" localhost:8080/api/system/discord
```

## FAQ / troubleshooting

**Do I need Docker?** No. Docker is optional (the panel's own Dockerfile/compose). Minecraft servers are plain child processes, which is why the panel also runs happily inside a container, on a Raspberry Pi, or on a 1 GB VPS.

**"Server jar not found"** — the software is still installing, or the install failed. Open the server console; installer output is streamed there. `Reinstall software` in the settings tab re-runs it.

**Console shows "live (polling)"** — the websocket was blocked by a proxy. Everything still works, just at ~1.5 s intervals. For nginx the installer already adds `Upgrade`/`Connection` headers.

**playit says "waiting for claim"** — open the claim link, sign in to playit.gg and approve the agent. The panel completes the exchange on its own and starts the daemon. Then create the Minecraft Java tunnel (local port = your server port) in the playit dashboard.

**Ports** — each server gets a port from the node's range (default 25565-25665). Open that range on your firewall; the installer does it for ufw/firewalld.

**Logs** — systemd: `journalctl -u zenith-panel -f`; PM2: `pm2 logs zenith-panel`; plain: `logs/panel.log`. Installer log: `/tmp/zenith-install-*.log`.

**"My remote node shows offline"** — the panel could not reach `http://<fqdn>:<agent-port>/api/node/status`.
Check that the agent service runs (`systemctl status zenith-node` on that box), that the port is open, and that
the FQDN/port in the node record are right (Nodes → details → *Ping agent*).

**"Remote server crashed right after start"** — usually the node ran out of RAM: the agent starts the JVM with
the memory you set in the panel, so give the box headroom (`free -m` on the node) or lower the server's memory.

**Remote backups** — the agent zips its copy and the panel pulls the archive into `backups/<id>/`, so listing,
download, pruning and restore work exactly like local ones. Restore streams the file back and the node extracts it.

**"My subdomain does not work"** — check the two records: an `A` record for the label → node public IP, and a
`_minecraft._tcp` `SRV` record → the same hostname with the port (priority 0, weight 5). In manual mode the panel
shows both; in Cloudflare mode press *Test connection* to confirm the token can see the zone.

**"The Discord bot does not answer"** — enable the **Message Content** intent in the Discord developer portal
(Bot → Privileged Gateway Intents), make sure the bot was invited to the guild with the `bot` scope, and check the
bot log in *Admin → Settings → Subdomains & Discord*.

**"Skin heads are blank"** — the browser could not reach the skin host; the panel proxies avatars through
`/api/system/proxy/image` for exactly this case. Blank heads still show the player's initial.

## Roadmap

* General file manager access to remote nodes (proxy uploads/downloads through the agent)
* Rename/patch operations on nodes so jars can be enabled/disabled remotely
* SFTP/WebDAV access per server (drag worlds in with your file manager)
* World upload/download wizard with `.mrpack`/modpack import
* Docker-per-server runtime (cgroups limits, like Wings) as an alternative to child processes
* Email alerts (Discord notifications already ship with the bot)
* Two-factor authentication and OAuth login

## License

MIT — see [LICENSE](LICENSE). Minecraft is a trademark of Mojang AB; this project is unofficial and not affiliated with Mojang, Pterodactyl, Modrinth or playit.gg.
