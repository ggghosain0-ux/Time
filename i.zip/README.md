# SKVM v6 — rebuilt VPS panel

This build is based on the old NVM/QEMU panel structure, but fixes the main reliability problems:
- Start/stop/restart/delete use POST endpoints and target only the selected VM.
- VM status is checked from the real QEMU process.
- QEMU uses KVM with TCG fallback instead of failing immediately where `/dev/kvm` is unavailable.
- Provisioning failures are recorded and shown instead of leaving a VPS stuck forever.
- Retry provisioning is available to admins.
- SSH passwords are generated per VPS instead of using one hard-coded password.
- tmate is optional and never blocks VPS creation; direct SSH remains available.
- User deletion no longer calls stop with a missing argument.
- Persistent Flask secret and systemd service are installed by install.sh.

## Install
```bash
chmod +x install.sh
./install.sh
```

Default admin:
- username: `admin`
- password: `admin123`

Change `SKVM_ADMIN_PASSWORD` in `.env` before first initialization if you want a different password.

## Production notes
Use a real Ubuntu/Debian host with QEMU/KVM support and enough CPU/RAM/disk. CodeSandbox-style containers may not provide `/dev/kvm`, stable inbound ports, or unrestricted networking, so they are not suitable as the actual VPS hypervisor.
