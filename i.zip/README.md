# SKVM v6

v6 fixes the two failures shown in v5:

1. `skvm/ubuntu22-tmate:latest` is built locally, so Docker does not try to pull a nonexistent private image.
2. Provisioning no longer waits for tmate relay registration. tmate is best-effort with a short timeout; the VPS is created immediately and a direct host-port SSH route is shown as fallback.

## Important
`t​​mate` cannot be made instant if the environment blocks outbound DNS/TCP or the tmate relay is unavailable. In CodeSandbox, direct SSH port forwarding may also be restricted. For a real VPS, run this on a host where Docker and outbound TCP/DNS work.

Default panel login: `admin / admin123`.
Change the password before production by setting `SKVM_ADMIN_PASSWORD` in `.env`.

## Run
```bash
chmod +x install.sh docker-entrypoint.sh
./install.sh
sudo -E .venv/bin/python app.py
```
Then open port 5555. For production, put the Flask app behind nginx/Caddy and use HTTPS.
