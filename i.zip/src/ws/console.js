'use strict';
/**
 * Real-time layer (WebSocket, `ws`).
 *
 * Client -> server:
 *   { type: 'subscribe', serverId }
 *   { type: 'unsubscribe', serverId }
 *   { type: 'command', serverId, command }
 *   { type: 'ping' }
 *
 * Server -> client:
 *   { type: 'hello', ... }            session info
 *   { type: 'log', serverId, data, seq }
 *   { type: 'status', serverId, data }
 *   { type: 'stats', serverId, data }
 *   { type: 'players', serverId, data }
 *   { type: 'install', serverId, data }
 *   { type: 'playit', serverId, data }
 *   { type: 'error', message }
 *
 * Auth: ?token=<jwt> or Authorization header, or the subprotocol
 * `zenith, <token>`. Falls back to HTTP polling (/api/servers/:id/logs)
 * when a browser cannot open a socket.
 */
const url = require('url');
const { WebSocketServer } = require('ws');

const auth = require('../auth');
const db = require('../db');
const logger = require('../logger');
const runtime = require('../services/runtime');
const playit = require('../services/playit');

const clients = new Set();
let statsTimer = null;

function attach(httpServer) {
  const wss = new WebSocketServer({ server: httpServer, path: '/ws', clientTracking: true });

  wss.on('connection', async (socket, req) => {
    const { query } = url.parse(req.url, true);
    let token = query.token;
    if (!token && req.headers['sec-websocket-protocol']) {
      const parts = String(req.headers['sec-websocket-protocol']).split(',').map((s) => s.trim());
      token = parts.find((p) => p && p !== 'zenith');
    }
    if (!token) { socket.close(4001, 'Authentication required'); return; }
    const user = await auth.resolveUser({ headers: { authorization: `Bearer ${token}` }, query: {}, ip: req.socket.remoteAddress });
    if (!user) { socket.close(4001, 'Invalid token'); return; }

    const client = { socket, user, serverIds: new Set(), alive: true };
    clients.add(client);

    socket.send(JSON.stringify({ type: 'hello', user: { id: user.id, username: user.username, role: user.role }, panel: require('../config').panelName }));
    logger.debug('ws', `${user.username} connected (${clients.size} clients)`);

    socket.on('message', async (raw) => {
      let msg;
      try { msg = JSON.parse(raw.toString()); } catch { return; }
      if (msg.type === 'ping') return socket.send(JSON.stringify({ type: 'pong', at: Date.now() }));
      if (msg.type === 'subscribe' || msg.type === 'unsubscribe') {
        const server = db.find('servers', (s) => s.id === msg.serverId);
        if (!server || !auth.canAccess(client.user, server)) {
          return socket.send(JSON.stringify({ type: 'error', message: 'No access to that server' }));
        }
        if (msg.type === 'subscribe') {
          client.serverIds.add(server.id);
          const snapshot = runtime.getLogs(server.id, msg.since || 0);
          const info = runtime.info(server.id);
          socket.send(JSON.stringify({ type: 'log', serverId: server.id, data: snapshot.lines.map((l) => l.line).join('\n'), seq: snapshot.seq, snapshot: true }));
          socket.send(JSON.stringify({ type: 'status', serverId: server.id, data: { status: info.status, uptime: info.uptime } }));
          socket.send(JSON.stringify({ type: 'players', serverId: server.id, data: info.players }));
          socket.send(JSON.stringify({ type: 'stats', serverId: server.id, data: info.stats }));
          socket.send(JSON.stringify({ type: 'playit', serverId: server.id, data: playit.status(server.id) }));
          if (info.installProgress) socket.send(JSON.stringify({ type: 'install', serverId: server.id, data: info.installProgress }));
        } else {
          client.serverIds.delete(server.id);
        }
        return;
      }
      if (msg.type === 'command') {
        const server = db.find('servers', (s) => s.id === msg.serverId);
        if (!server || !auth.can(client.user, server, 'console')) {
          return socket.send(JSON.stringify({ type: 'error', message: 'No console permission' }));
        }
        try {
          runtime.sendCommand(server.id, msg.command);
          db.log({ actor: client.user.username, action: 'server.command', serverId: server.id, serverName: server.name, detail: String(msg.command).slice(0, 120) });
        } catch (err) {
          socket.send(JSON.stringify({ type: 'error', message: err.message }));
        }
        return;
      }
      if (msg.type === 'power') {
        const server = db.find('servers', (s) => s.id === msg.serverId);
        if (!server || !auth.can(client.user, server, 'console')) {
          return socket.send(JSON.stringify({ type: 'error', message: 'No console permission' }));
        }
        try {
          if (msg.action === 'start') await runtime.start(server);
          else if (msg.action === 'stop') await runtime.stop(server.id);
          else if (msg.action === 'restart') await runtime.restart(server.id);
          else if (msg.action === 'kill') await runtime.kill(server.id);
          db.log({ actor: client.user.username, action: `server.${msg.action}`, serverId: server.id, serverName: server.name });
        } catch (err) {
          socket.send(JSON.stringify({ type: 'error', message: err.message }));
        }
      }
    });

    socket.on('pong', () => { client.alive = true; });
    socket.on('close', () => {
      clients.delete(client);
      logger.debug('ws', `${user.username} disconnected (${clients.size} clients)`);
    });
    socket.on('error', () => clients.delete(client));
  });

  /* fan out runtime events */
  runtime.events.on('event', ({ serverId, type, data }) => {
    const payload = JSON.stringify({ type, serverId, data, at: Date.now() });
    for (const client of clients) {
      if (!client.serverIds.has(serverId)) continue;
      if (client.socket.readyState !== 1) continue;
      try { client.socket.send(payload); } catch (_) {}
    }
  });

  /* periodic stats push for subscribed servers */
  statsTimer = setInterval(async () => {
    const ids = new Set();
    for (const client of clients) for (const id of client.serverIds) ids.add(id);
    for (const serverId of ids) {
      const stats = await runtime.sampleStats(serverId).catch(() => null);
      if (!stats) continue;
      const info = runtime.info(serverId);
      const payload = JSON.stringify({ type: 'stats', serverId, data: { ...stats, status: info.status, uptime: info.uptime, installProgress: info.installProgress }, at: Date.now() });
      for (const client of clients) {
        if (client.serverIds.has(serverId) && client.socket.readyState === 1) {
          try { client.socket.send(payload); } catch (_) {}
        }
      }
    }
  }, 2000);
  statsTimer.unref?.();

  /* heartbeat: drop dead sockets */
  const hb = setInterval(() => {
    for (const client of clients) {
      if (!client.alive) { try { client.socket.terminate(); } catch (_) {} clients.delete(client); continue; }
      client.alive = false;
      try { client.socket.ping(); } catch (_) {}
    }
  }, 30000);
  hb.unref?.();

  logger.info('ws', 'console socket listening on /ws');
  return wss;
}

function broadcast(serverId, type, data) {
  const payload = JSON.stringify({ type, serverId, data, at: Date.now() });
  for (const client of clients) {
    if (client.serverIds.has(serverId) && client.socket.readyState === 1) {
      try { client.socket.send(payload); } catch (_) {}
    }
  }
}
exports.broadcast = broadcast;

exports.attach = attach;
exports.clientCount = () => clients.size;
