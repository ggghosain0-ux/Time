'use strict';
/** Backup API - mounted at /api/servers/:id/backups */
const express = require('express');
const auth = require('../auth');
const backups = require('../services/backups');
const runtime = require('../services/runtime');

const router = express.Router({ mergeParams: true });
router.use(auth.authenticate, auth.serverScope('backups'));

router.get('/', async (req, res) => {
  res.json({ backups: await backups.list(req.server.id) });
});

router.post('/', async (req, res) => {
  try {
    const record = await backups.create(req.server, { note: req.body.note || '', automatic: false });
    res.status(201).json({ backup: record });
  } catch (err) { res.status(400).json({ error: err.message }); }
});

/** Create a backup and stream live progress over the console socket. */
router.post('/stream', async (req, res) => {
  runtime.state(req.server.id).logs.push('[backup] Starting backup...');
  res.json({ ok: true, message: 'Backup started - progress is shown in the console' });
  try {
    const record = await backups.create(req.server, {
      note: req.body.note || '',
      onProgress: (p) => runtime.setInstallProgress(req.server.id, { step: 'backup', ...p }),
    });
    runtime.state(req.server.id).logs.push(`[backup] Created ${record.filename} (${record.sizePretty})`);
    runtime.setInstallProgress(req.server.id, { step: 'done', percent: 100, note: 'Backup complete' });
  } catch (err) {
    runtime.state(req.server.id).logs.push(`[backup] FAILED: ${err.message}`);
    runtime.setInstallProgress(req.server.id, { step: 'error', percent: 100, note: err.message });
  }
  void req.params;
});

router.get('/:backupId/download', async (req, res) => {
  try { await backups.streamDownload(req.server, req.params.backupId, res); }
  catch (err) { res.status(404).json({ error: err.message }); }
});

router.post('/:backupId/restore', async (req, res) => {
  if (runtime.isOnline(req.server.id) && req.body.force !== true) {
    return res.status(409).json({ error: 'Stop the server first, or pass force:true to stop it automatically' });
  }
  try {
    const result = await backups.restore(req.server, req.params.backupId);
    res.json({ ok: true, ...result });
  } catch (err) { res.status(400).json({ error: err.message }); }
});

router.patch('/:backupId', async (req, res) => {
  try { res.json(await backups.lock(req.server, req.params.backupId, req.body.locked)); }
  catch (err) { res.status(400).json({ error: err.message }); }
});

router.delete('/:backupId', async (req, res) => {
  try { res.json(await backups.remove(req.server, req.params.backupId)); }
  catch (err) { res.status(400).json({ error: err.message }); }
});

router.post('/prune', async (req, res) => {
  try { res.json(await backups.prune(req.server, parseInt(req.body.keep || 10, 10))); }
  catch (err) { res.status(400).json({ error: err.message }); }
});

module.exports = router;
