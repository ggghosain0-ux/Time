'use strict';
/**
 * Core server API: list, create, power actions, console, stats, settings,
 * subusers, software (re)installation and version migration.
 */
const express = require('express');
const path = require('path');
const fsp = require('fs/promises');

const cfg = require('../config');
const db = require('../db');
const auth = require('../auth');
const logger = require('../logger');
const runtime = require('../services/runtime');
const versions = require('../services/versions');
const javaSvc = require('../services/java');
const serverSvc = require('../services/servers');
const nodesSvc = require('../services/nodes');
const dns = require('../services/dns');
const worlds = require('../services/worlds');
const sftpSvc = require('../services/sftp');
const { formatBytes, safeJoin, exists, uid } = require('../utils');

const router = express.Router();
const multer = require('multer');
// one shared instance: the jar upload, world imports and file uploads all reuse it
const upload = multer({ dest: path.join(cfg.dataDir, 'tmp'), limits: { fileSize: cfg.maxUploadSize } });
const worldUpload = upload;

/* ------------------------------ helpers ------------------------------ */
function withUsage(server, user) {
  const info = runtime.info(server.id);
  return {
    id: server.id,
    name: server.name,
    description: server.description,
    ownerId: server.ownerId,
    ownerName: server.ownerName,
    nodeId: server.nodeId,
    nodeName: server.nodeName,
    serverType: server.serverType,
    version: server.version,
    build: server.build,
    memory: server.memory,
    cpuLimit: server.cpuLimit,
    diskLimit: server.diskLimit,
    port: server.port,
    ip: server.ip,
    status: info.status,
    backend: info.backend || runtime.backendFor(server),
    container: info.container || null,
    containerId: info.containerId || null,
    dockerImage: server.dockerImage || null,
    requestedBackend: server.backend || null,
    suspended: !!server.suspended,
    players: info.players.length,
    maxPlayers: server.maxPlayers || info.maxPlayers,
    uptime: info.uptime,
    stats: info.stats,
    javaVersion: server.javaVersion,
    eulaAccepted: !!server.eulaAccepted,
    autoStart: !!server.autoStart,
    createdAt: server.createdAt,
    packages: (server.packages || []).length,
    backups: (server.backups || []).length,
    playit: { ...(server.playit || {}), tunnel: runtime.state(server.id).logs ? (server.playit && server.playit.tunnels ? server.playit.tunnels[0] : null) : null },
    perms: {
      console: auth.can(user, server, 'console'),
      files: auth.can(user, server, 'files'),
      backups: auth.can(user, server, 'backups'),
      plugins: auth.can(user, server, 'plugins'),
      network: auth.can(user, server, 'network'),
      settings: auth.can(user, server, 'settings'),
      schedules: auth.can(user, server, 'schedules'),
      subusers: auth.can(user, server, 'subusers'),
      admin: auth.isAdmin(user),
    },
    isOwner: server.ownerId === user.id,
  };
}

/** Reinstall / migrate the server software, streaming progress to the console. */
async function installSoftware(server, { version, serverType, resetJar = false }, actor) {
  const type = String(serverType || server.serverType).toUpperCase();
  const ver = version || server.version;
  runtime.setStatus(server.id, 'installing', { serverType: type, version: ver });
  const log = (msg) => runtime.state(server.id).logs.push(`[installer] ${msg}`);
  log(`Installing ${type} ${ver} ...`);

  // A server on a remote node is installed by that node's agent (jar + JRE there).
  if (runtime.isRemote(server)) {
    try {
      const result = await require('../services/remote').provision(server, { type, version: ver });
      runtime.setInstallProgress(server.id, { step: 'done', percent: 100, note: 'Installation complete' });
      db.log({ actor, action: 'server.install', serverId: server.id, serverName: server.name, detail: `${type} ${ver} on node` });
      return db.find('servers', (x) => x.id === server.id);
    } catch (err) {
      runtime.pushExternalLog(server.id, `[installer] FAILED: ${err.message}`);
      runtime.setStatus(server.id, 'offline', { lastError: err.message });
      logger.error('servers', `remote install failed for ${server.name}: ${err.message}`);
      throw err;
    }
  }

  const result = await versions.install(server, {
    type,
    version: ver,
    progress: (step, percent, note) => {
      runtime.setInstallProgress(server.id, { step, percent, note });
      if (note) log(note);
    },
  });

  const patch = {
    serverType: type,
    version: ver,
    build: result.build || null,
    javaVersion: versions.javaFor(ver),
    javaPath: result.javaPath || server.javaPath || '',
    status: 'offline',
    lastInstalledAt: new Date().toISOString(),
  };
  if (result.jar) patch.jarFile = result.jar;
  if (resetJar) patch.jarFile = result.jar || 'server.jar';
  if (type === 'CUSTOM') patch.version = 'custom';
  const updated = db.update('servers', server.id, patch);
  runtime.setInstallProgress(server.id, { step: 'done', percent: 100, note: 'Installation complete' });
  runtime.setStatus(server.id, 'offline');
  log('Installation complete.');
  db.log({ actor, action: 'server.install', serverId: server.id, serverName: server.name, detail: `${type} ${ver}` });
  return updated;
}
router.installSoftware = installSoftware;

/* ------------------------------ listing ------------------------------ */
router.get('/', auth.authenticate, async (req, res) => {
  const all = db.get('servers') || [];
  const mine = all.filter((s) => auth.canAccess(req.user, s));
  const { search, status, nodeId, ownerId, sort = 'name', withUsage: wantUsage } = req.query;
  let list = mine;
  if (search) list = list.filter((s) => s.name.toLowerCase().includes(String(search).toLowerCase()));
  if (status) list = list.filter((s) => runtime.info(s.id).status === status);
  if (nodeId) list = list.filter((s) => s.nodeId === nodeId);
  if (ownerId) list = list.filter((s) => s.ownerId === ownerId);
  let mapped = list.map((s) => withUsage(s, req.user));
  if (sort === 'status') mapped.sort((a, b) => a.status.localeCompare(b.status));
  else if (sort === 'created') mapped.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  else mapped.sort((a, b) => a.name.localeCompare(b.name));

  if (wantUsage === 'disk') {
    mapped = await Promise.all(mapped.map(async (m) => ({ ...m, ...(await serverSvc.usage(db.find('servers', (s) => s.id === m.id), { withDisk: true })) })));
  }
  res.json({
    servers: mapped,
    total: mapped.length,
    running: mapped.filter((s) => s.status === 'running').length,
    limits: { maxServersPerUser: db.settings().maxServersPerUser, isAdmin: auth.isAdmin(req.user) },
  });
});

/* ------------------------------ create ------------------------------ */
router.post('/', auth.authenticate, async (req, res) => {
  const { name, serverType, version, memory, port } = req.body || {};
  if (!name) return res.status(400).json({ error: 'A server name is required' });
  if (!serverType) return res.status(400).json({ error: 'Pick a server software' });
  let server = await serverSvc.create(req.body, req.user);

  // Optional subdomain at creation time (label only - the base domain and
  // provider come from Admin → Settings → Subdomains).
  let subdomainError = null;
  if (req.body.subdomain) {
    try {
      const label = dns.slugify(req.body.subdomain);
      const settings = dns.settings();
      if (!label) throw new Error('Invalid subdomain label');
      if (!settings.domain) throw new Error('No base domain configured by the admin yet');
      const result = await dns.createRecords({ sub: label, name: server.name, port: server.port, ip: req.body.ip });
      const record = {
        id: uid('sub'), sub: label, host: result.host, port: server.port,
        provider: result.provider, records: result.created.length ? result.created : result.records,
        createdAt: new Date().toISOString(), createdBy: req.user.username,
      };
      server = db.update('servers', server.id, { subdomains: [record] });
      db.log({ actor: req.user.username, action: 'subdomain.create', serverId: server.id, serverName: server.name, detail: record.host });
    } catch (err) {
      subdomainError = err.message;
      logger.warn('dns', `subdomain for ${server.name} not created: ${err.message}`);
    }
  }

  const installNow = req.body.install !== false;
  res.status(201).json({ server: withUsage(server, req.user), installQueued: installNow, subdomainError });

  if (installNow) {
    installSoftware(server, { version: version || server.version, serverType }, req.user.username)
      .catch((err) => {
        logger.error('servers', `install failed for ${server.name}: ${err.message}`);
        runtime.state(server.id).logs.push(`[installer] FAILED: ${err.message}`);
        runtime.setStatus(server.id, 'offline', { lastError: err.message });
      });
  }
});

/* ------------------------------ detail ------------------------------ */
router.get('/:id', auth.authenticate, auth.serverScope(), async (req, res) => {
  const s = req.server;
  const info = runtime.info(s.id);
  const playit = require('../services/playit');
  res.json({
    server: {
      ...withUsage(s, req.user),
      javaArgs: s.javaArgs,
      aikarFlags: s.aikarFlags !== false,
      onlineMode: s.onlineMode !== false,
      stopCommand: s.stopCommand,
      jarFile: s.jarFile,
      lastError: info.lastError,
      restartCount: info.restarts,
      installProgress: info.installProgress,
      javaPath: info.java,
      schedules: s.schedules || [],
      subusers: (s.subusers || []).map((su) => ({ ...su, username: (db.find('users', (u) => u.id === su.userId) || {}).username || 'deleted' })),
      portAllocations: s.portAllocations || [s.port],
      backupCount: (s.backups || []).length,
      packageCount: (s.packages || []).length,
    },
    playit: playit.status(s.id),
    node: nodesSvc.get(s.nodeId) || null,
    live: {
      status: info.status, players: info.players, stats: info.stats, uptime: info.uptime,
      backend: info.backend, container: info.container, containerId: info.containerId, pid: info.pid,
    },
  });
});

router.patch('/:id', auth.authenticate, auth.serverScope('settings'), async (req, res) => {
  const allowed = ['name', 'description', 'memory', 'cpuLimit', 'diskLimit', 'maxPlayers', 'onlineMode',
    'javaArgs', 'javaArgs', 'aikarFlags', 'eulaAccepted', 'autoStart', 'autoBackup', 'stopCommand', 'javaVersion', 'javaPath', 'ip', 'port'];
  const patch = {};
  for (const key of allowed) if (req.body[key] !== undefined) patch[key] = req.body[key];
  // runtime choice: 'docker' needs a DOCKER-capable node, and it is validated here
  if (req.body.backend !== undefined) {
    const backend = req.body.backend === 'docker' ? 'docker' : (req.body.backend === 'process' ? 'process' : '');
    if (backend === 'docker') {
      if (req.server.nodeId && req.server.nodeId !== 'local') {
        const remote = require('../services/remote');
        const probe = await remote.containerRuntime(req.server).catch((err) => ({ available: false, error: err.message }));
        if (!probe.available) return res.status(409).json({ error: `The node "${req.server.nodeName || req.server.nodeId}" reports Docker unavailable: ${probe.error}` });
      } else {
        const d = require('../services/docker').probe({ force: true });
        if (!d.available) return res.status(409).json({ error: `Docker is not available on this node: ${d.error}` });
      }
      if (runtime.isOnline(req.server.id)) return res.status(409).json({ error: 'Stop the server before changing its runtime' });
    }
    patch.backend = backend;
  }
  if (req.body.dockerImage !== undefined) {
    const image = String(req.body.dockerImage || '').trim();
    if (image && !/^[a-zA-Z0-9][\w.\-/:@]{0,120}$/.test(image)) return res.status(400).json({ error: 'That is not a valid container image reference' });
    patch.dockerImage = image;
  }
  if (patch.memory !== undefined) patch.memory = Math.max(256, parseInt(patch.memory, 10) || 2048);
  if (patch.port !== undefined) {
    const wanted = parseInt(patch.port, 10);
    const taken = (db.get('servers') || []).some((s) => s.id !== req.server.id && s.port === wanted);
    if (taken) return res.status(409).json({ error: `Port ${wanted} is already used by another server` });
    patch.port = wanted;
    patch.portAllocations = [...new Set([...(req.server.portAllocations || []), wanted])];
  }
  const updated = db.update('servers', req.server.id, patch);
  if (patch.eulaAccepted !== undefined || patch.port !== undefined) {
    runtime.writeEula(updated).catch(() => {});
  }
  if (req.server.status === 'running' && ['memory', 'javaArgs', 'aikarFlags'].some((k) => patch[k] !== undefined)) {
    runtime.state(req.server.id).logs.push('[panel] Changing memory/JVM flags requires a restart to take effect.');
  }
  db.log({ actor: req.user.username, action: 'server.update', serverId: req.server.id, serverName: updated.name, detail: Object.keys(patch).join(', ') });
  res.json({ server: withUsage(updated, req.user) });
});

router.delete('/:id', auth.authenticate, auth.serverScope('settings'), async (req, res) => {
  if (!auth.isAdmin(req.user) && req.server.ownerId !== req.user.id) {
    return res.status(403).json({ error: 'Only the owner of this server can delete it' });
  }
  await serverSvc.destroy(req.server, { removeFiles: req.query.files !== 'false', removeBackups: req.query.backups !== 'false' });
  res.json({ ok: true, deleted: req.server.id });
});

/* ------------------------------ suspend (admin) ------------------------------ */
router.post('/:id/suspend', auth.authenticate, auth.requireAdmin, async (req, res) => {
  const suspended = req.body.suspended !== false;
  const updated = db.update('servers', req.server.id, { suspended });
  if (suspended) {
    try { if (runtime.isOnline(req.server.id)) await runtime.stop(req.server.id, { force: true }); } catch (_) {}
    runtime.state(req.server.id).logs.push('[panel] Server suspended by an administrator');
  }
  db.log({ actor: req.user.username, action: suspended ? 'server.suspend' : 'server.unsuspend', serverId: req.server.id, serverName: req.server.name });
  res.json({ ok: true, suspended: updated.suspended });
});

/* ------------------------------ power ------------------------------ */
const power = (action) => async (req, res) => {
  const s = req.server;
  try {
    if (s.suspended && !auth.isAdmin(req.user)) return res.status(403).json({ error: 'Server is suspended' });
    let result;
    if (action === 'start') {
      if (runtime.isOnline(s.id)) return res.status(409).json({ error: 'Server is already running' });
      result = await runtime.start(s);
    } else if (action === 'stop') {
      result = await runtime.stop(s.id);
    } else if (action === 'restart') {
      result = await runtime.restart(s.id);
    } else if (action === 'kill') {
      result = { killed: await runtime.kill(s.id) };
    }
    db.log({ actor: req.user.username, action: `server.${action}`, serverId: s.id, serverName: s.name });
    res.json({ ok: true, result, status: runtime.info(s.id).status });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

router.post('/:id/start', auth.authenticate, auth.serverScope('console'), power('start'));
router.post('/:id/stop', auth.authenticate, auth.serverScope('console'), power('stop'));
router.post('/:id/restart', auth.authenticate, auth.serverScope('console'), power('restart'));
router.post('/:id/kill', auth.authenticate, auth.serverScope('console'), power('kill'));

/* ------------------------------ console ------------------------------ */
router.get('/:id/logs', auth.authenticate, auth.serverScope('console'), (req, res) => {
  const since = parseInt(req.query.since || '0', 10);
  const data = runtime.getLogs(req.server.id, since);
  res.json({
    lines: data.lines,
    seq: data.seq,
    status: data.status,
    players: runtime.info(req.server.id).players,
    stats: runtime.info(req.server.id).stats,
    installProgress: runtime.state(req.server.id).installProgress,
  });
});

router.post('/:id/logs/clear', auth.authenticate, auth.serverScope('console'), (req, res) => {
  runtime.clearLogs(req.server.id);
  res.json({ ok: true });
});

router.post('/:id/command', auth.authenticate, auth.serverScope('console'), (req, res) => {
  const { command } = req.body || {};
  if (!command) return res.status(400).json({ error: 'command is required' });
  try {
    runtime.sendCommand(req.server.id, command);
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.get('/:id/stats', auth.authenticate, auth.serverScope(), async (req, res) => {
  const stats = await runtime.sampleStats(req.server.id);
  const info = runtime.info(req.server.id); // info() keys on the server id
  // usage() knows that a remote server's disk counters live on its node
  const usage = await serverSvc.usage(req.server, { withDisk: true });
  res.json({ stats, status: info.status, uptime: info.uptime, players: info.players, disk: usage.disk || null, remote: info.remote });
});

/* ------------------------- software versions ------------------------- */
router.get('/:id/versions', auth.authenticate, auth.serverScope('settings'), async (req, res) => {
  try {
    const list = await versions.listVersions(req.server.serverType);
    res.json({ ...list, current: req.server.version, javaVersion: versions.javaFor(req.server.version), recommendedJava: versions.javaFor(list.latest) });
  } catch (err) {
    res.status(502).json({ error: `Could not reach the ${req.server.serverType} version API: ${err.message}` });
  }
});

router.post('/:id/reinstall', auth.authenticate, auth.serverScope('settings'), async (req, res) => {
  const { version = req.server.version, serverType = req.server.serverType, wipe = false } = req.body || {};
  if (runtime.isOnline(req.server.id)) return res.status(409).json({ error: 'Stop the server first' });
  if (wipe) {
    const dir = serverSvc.dir(req.server);
    await fsp.rm(path.join(dir, req.server.jarFile || 'server.jar'), { force: true });
  }
  res.json({ ok: true, message: `Installing ${serverType} ${version} in the background - watch the console` });
  installSoftware(req.server, { version, serverType, resetJar: true }, req.user.username)
    .catch((err) => {
      runtime.state(req.server.id).logs.push(`[installer] FAILED: ${err.message}`);
      runtime.setStatus(req.server.id, 'offline', { lastError: err.message });
    });
});

/** Migrate to another Minecraft version (keeps worlds; jars/libraries refreshed). */
router.post('/:id/migrate', auth.authenticate, auth.serverScope('settings'), async (req, res) => {
  const { version, serverType = req.server.serverType } = req.body || {};
  if (!version) return res.status(400).json({ error: 'Target version is required' });
  if (runtime.isOnline(req.server.id)) return res.status(409).json({ error: 'Stop the server first' });

  runtime.state(req.server.id).logs.push(`[migration] ${req.server.serverType} ${req.server.version} -> ${serverType} ${version}`);
  const backups = require('../services/backups');
  let backup = null;
  try {
    runtime.state(req.server.id).logs.push('[migration] Taking a safety backup first...');
    backup = await backups.create(req.server, { note: `Pre-migration ${req.server.version} -> ${version}`, automatic: true });
  } catch (err) {
    runtime.state(req.server.id).logs.push(`[migration] backup skipped: ${err.message}`);
  }
  res.json({ ok: true, backup: backup ? backup.filename : null, message: `Migrating to ${serverType} ${version} in the background` });
  installSoftware(req.server, { version, serverType, resetJar: true }, req.user.username)
    .catch((err) => {
      runtime.state(req.server.id).logs.push(`[migration] FAILED: ${err.message}`);
      runtime.setStatus(req.server.id, 'offline', { lastError: err.message });
    });
});

/* ------------------------------ upload jar ------------------------------ */
router.post('/:id/jar', auth.authenticate, auth.serverScope('settings'), upload.single('jar'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No jar uploaded' });
  if (!/\.jar$/i.test(req.file.originalname)) return res.status(400).json({ error: 'Only .jar files are accepted' });
  const dir = serverSvc.dir(req.server);
  const dest = safeJoin(dir, req.file.originalname);
  await fsp.rename(req.file.path, dest);
  const updated = db.update('servers', req.server.id, {
    jarFile: req.file.originalname,
    serverType: req.body.serverType ? String(req.body.serverType).toUpperCase() : req.server.serverType,
    version: req.body.version || req.server.version,
  });
  runtime.state(req.server.id).logs.push(`[panel] Custom jar installed: ${req.file.originalname}`);
  db.log({ actor: req.user.username, action: 'server.jar', serverId: req.server.id, serverName: req.server.name, detail: req.file.originalname });
  res.json({ ok: true, server: withUsage(updated, req.user) });
});

/* ------------------------------ subusers ------------------------------ */
router.post('/:id/subusers', auth.authenticate, auth.serverScope('subusers'), (req, res) => {
  const { username, permissions = [], email } = req.body || {};
  const user = db.find('users', (u) => u.username.toLowerCase() === String(username || '').toLowerCase()
    || (email && u.email && u.email.toLowerCase() === String(email).toLowerCase()));
  if (!user) return res.status(404).json({ error: 'No panel user with that username/e-mail' });
  if (user.id === req.server.ownerId) return res.status(400).json({ error: 'That user already owns this server' });
  const perms = (permissions.length ? permissions : ['console']).filter((p) => p === '*' || auth.SERVER_PERMS.includes(p));
  const existing = (req.server.subusers || []).filter((s) => s.userId !== user.id);
  const sub = { userId: user.id, username: user.username, permissions: perms, addedAt: new Date().toISOString(), addedBy: req.user.username };
  db.update('servers', req.server.id, { subusers: [...existing, sub] });
  db.log({ actor: req.user.username, action: 'subuser.add', serverId: req.server.id, serverName: req.server.name, detail: `${user.username}: ${perms.join(',')}` });
  res.status(201).json({ subuser: sub, available: auth.SERVER_PERMS });
});

router.patch('/:id/subusers/:userId', auth.authenticate, auth.serverScope('subusers'), (req, res) => {
  const { permissions = [] } = req.body || {};
  const perms = permissions.filter((p) => p === '*' || auth.SERVER_PERMS.includes(p));
  const subusers = (req.server.subusers || []).map((s) => (s.userId === req.params.userId ? { ...s, permissions: perms } : s));
  db.update('servers', req.server.id, { subusers });
  res.json({ subuser: subusers.find((s) => s.userId === req.params.userId) });
});

router.delete('/:id/subusers/:userId', auth.authenticate, auth.serverScope('subusers'), (req, res) => {
  db.update('servers', req.server.id, { subusers: (req.server.subusers || []).filter((s) => s.userId !== req.params.userId) });
  res.json({ ok: true });
});

/* ------------------------------ schedules ------------------------------ */
const scheduler = require('../services/scheduler');
router.get('/:id/schedules', auth.authenticate, auth.serverScope(), (req, res) => {
  res.json({ schedules: (req.server.schedules || []).map((s) => ({ ...s, description: scheduler.describe(s.cron) })), actions: scheduler.ACTIONS });
});
router.post('/:id/schedules', auth.authenticate, auth.serverScope('schedules'), (req, res) => {
  try {
    const task = scheduler.create(req.server, req.body || {});
    res.status(201).json({ task });
  } catch (err) { res.status(400).json({ error: err.message }); }
});
router.patch('/:id/schedules/:taskId', auth.authenticate, auth.serverScope('schedules'), (req, res) => {
  const task = scheduler.update(req.server, req.params.taskId, req.body || {});
  res.json({ task });
});
router.delete('/:id/schedules/:taskId', auth.authenticate, auth.serverScope('schedules'), (req, res) => {
  res.json(scheduler.remove(req.server, req.params.taskId));
});
router.post('/:id/schedules/:taskId/run', auth.authenticate, auth.serverScope('schedules'), async (req, res) => {
  try { res.json({ result: await scheduler.runNow(req.server.id, req.params.taskId) }); }
  catch (err) { res.status(400).json({ error: err.message }); }
});

/* ------------------------------ node move ------------------------------ */
/**
 * Re-assign a server to another node. Safe by default: the current software is
 * re-installed on the target node and the world files stay behind, which is why
 * we require the server to be stopped and ask for the caller to acknowledge the
 * data transfer with `{ "keepData": false }` (or true when the world is copied
 * manually with the file manager / backups).
 */
router.post('/:id/node', auth.authenticate, auth.requireAdmin, async (req, res) => {
  const target = db.find('nodes', (n) => n.id === (req.body || {}).nodeId);
  if (!target) return res.status(404).json({ error: 'Node not found' });
  const server = req.server;
  if (runtime.isOnline(server.id)) return res.status(409).json({ error: 'Stop the server before moving it' });
  if (server.nodeId === target.id) return res.status(400).json({ error: `Already on node "${target.name}"` });

  let port = null;
  if (target.id !== 'local') {
    const remoteSvc = require('../services/remote');
    try {
      port = await remoteSvc.freePort(target, target.portRange);
    } catch (err) {
      return res.status(409).json({ error: `Node "${target.name}" is unreachable: ${err.message}` });
    }
    if (!port) return res.status(409).json({ error: `No free port on node "${target.name}"` });
  } else {
    port = await serverSvc.allocatePort(0, target);
  }

  const updated = db.update('servers', server.id, {
    nodeId: target.id, nodeName: target.name, port, portAllocations: [port], status: 'offline',
  });
  runtime.pushExternalLog(server.id, `[panel] moved to node "${target.name}" on port ${port}`);
  if (target.id !== 'local') {
    installSoftware(updated, { version: server.version, serverType: server.serverType }, req.user.username)
      .catch((err) => runtime.pushExternalLog(server.id, `[installer] FAILED: ${err.message}`));
  }
  db.log({ actor: req.user.username, action: 'server.move', serverId: server.id, serverName: server.name, detail: `-> ${target.name}` });
  res.json({ ok: true, server: withUsage(updated, req.user), installing: target.id !== 'local' });
});

/* ------------------------------ activity ------------------------------ */
router.get('/:id/activity', auth.authenticate, auth.serverScope(), (req, res) => {
  res.json({ activity: (db.get('activity') || []).filter((a) => a.serverId === req.server.id).slice(0, 60) });
});

/* ------------------------------ raw properties ------------------------------ */
router.get('/:id/properties', auth.authenticate, auth.serverScope('settings'), async (req, res) => {
  const files = require('../services/files');
  try {
    const { content } = await files.read(req.server, 'server.properties');
    const parsed = {};
    for (const line of content.split('\n')) {
      if (!line || line.startsWith('#')) continue;
      const idx = line.indexOf('=');
      if (idx > 0) parsed[line.slice(0, idx)] = line.slice(idx + 1);
    }
    res.json({ properties: parsed, raw: content });
  } catch (err) {
    res.status(404).json({ error: 'server.properties not found yet - start the server once or install it' });
  }
});

/**
 * Update server.properties.
 *   { properties: { motd: 'hi', pvp: 'true' } }  -> merge individual keys
 *   { raw: 'motd=hi\npvp=true\n' }                -> write the whole file
 * Both keep a `server.properties.bak` copy so a bad save is always recoverable.
 */
router.put('/:id/properties', auth.authenticate, auth.serverScope('settings'), async (req, res) => {
  const files = require('../services/files');
  const body = req.body || {};
  try {
    const { content } = await files.read(req.server, 'server.properties');
    let out = content;
    let changed = [];

    if (typeof body.raw === 'string') {
      if (body.raw.length > 512 * 1024) return res.status(400).json({ error: 'The file is too large for the raw editor (512 KB limit) - use the Files tab' });
      if (body.raw.includes('\u0000')) return res.status(400).json({ error: 'The file contains null bytes - refusing to save' });
      const malformed = body.raw.split('\n').filter((l) => l.trim() && !l.trim().startsWith('#') && !l.includes('='));
      if (malformed.length > 3) return res.status(400).json({ error: `That does not look like a properties file (${malformed.length} lines without "=")` });
      changed = ['(raw file)'];
      out = body.raw.endsWith('\n') ? body.raw : `${body.raw}\n`;
    } else {
      const properties = body.properties || body;
      for (const [key, rawValue] of Object.entries(properties)) {
        if (!/^[a-zA-Z0-9._-]{1,64}$/.test(key)) return res.status(400).json({ error: `Invalid property name: ${key}` });
        const value = String(rawValue).replace(/[\r\n]/g, '');
        const re = new RegExp(`^${key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}=.*$`, 'm');
        if (re.test(out)) out = out.replace(re, `${key}=${value}`);
        else out += `${out.endsWith('\n') ? '' : '\n'}${key}=${value}\n`;
        changed.push(key);
      }
    }

    try { await files.write(req.server, 'server.properties.bak', content); } catch (_) { /* first save */ }
    await files.write(req.server, 'server.properties', out);
    const live = runtime.info(req.server.id);
    const running = ['running', 'starting'].includes(live.status);
    const needsRestart = running && changed.some((k) => ['server-port', 'level-name', 'online-mode', 'max-players', 'enable-rcon', 'enable-query', '(raw file)'].includes(k));
    db.log({ actor: req.user.username, action: 'server.properties', serverId: req.server.id, serverName: req.server.name, detail: `updated ${changed.length} setting(s)` });
    res.json({ ok: true, changed, restartRequired: needsRestart, backup: 'server.properties.bak' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

/* ------------------------------ java ------------------------------ */
router.get('/:id/java', auth.authenticate, auth.serverScope('settings'), async (req, res) => {
  res.json({
    required: versions.javaFor(req.server.version),
    pinned: req.server.javaPath || null,
    available: await javaSvc.list(),
  });
});

router.post('/:id/java/install', auth.authenticate, auth.serverScope('settings'), async (req, res) => {
  const major = parseInt(req.body.version || versions.javaFor(req.server.version), 10);
  res.json({ ok: true, message: `Installing Java ${major} in the background - watch the console` });
  javaSvc.ensure(major, (p) => runtime.setInstallProgress(req.server.id, { step: 'java', percent: p.percent, note: `Java ${major}: ${p.note || `${p.percent}%`}` }))
    .then((bin) => {
      runtime.state(req.server.id).logs.push(`[java] Java ${major} ready: ${bin}`);
      db.update('servers', req.server.id, { javaPath: bin, javaVersion: major });
      runtime.setInstallProgress(req.server.id, { step: 'done', percent: 100, note: `Java ${major} installed` });
    })
    .catch((err) => runtime.state(req.server.id).logs.push(`[java] install failed: ${err.message}`));
});

router.get('/:id/upload-url', auth.authenticate, auth.serverScope(), (req, res) => {
  res.json({ hint: 'POST multipart/form-data to the files API', maxBytes: cfg.maxUploadSize, maxPretty: formatBytes(cfg.maxUploadSize) });
});

/* ------------------------------- worlds ------------------------------- */

/** Every Minecraft world on disk, with the one that is currently active. */
router.get('/:id/worlds', auth.authenticate, auth.serverScope('files'), async (req, res) => {
  try {
    const data = await worlds.list(req.server);
    res.json({ ...data, permissions: { canManage: auth.can(req.user, req.server, 'settings') } });
  } catch (err) { res.status(400).json({ error: err.message, worlds: [] }); }
});

/** Make a world the one the server loads next time (rewrites level-name). */
router.post('/:id/worlds/:name/activate', auth.authenticate, auth.serverScope('settings'), async (req, res) => {
  try {
    const result = await worlds.activate(req.server, req.params.name);
    db.log({ actor: req.user.username, action: 'world.activate', serverId: req.server.id, serverName: req.server.name, detail: req.params.name });
    res.json({ ...result, restartRequired: runtime.info(req.server.id).status !== 'offline' });
  } catch (err) { res.status(400).json({ error: err.message }); }
});

/** Download a world as a zip (streamed straight from the real directory). */
router.get('/:id/worlds/:name/download', auth.authenticate, auth.serverScope('files'), async (req, res) => {
  try {
    await worlds.exportTo(req.server, req.params.name, res);
    db.log({ actor: req.user.username, action: 'world.download', serverId: req.server.id, serverName: req.server.name, detail: req.params.name });
  } catch (err) {
    if (!res.headersSent) res.status(err.message.includes('does not exist') ? 404 : 400).json({ error: err.message });
  }
});

/** Import a world from a zip upload (also accepts a .zip stored in the files tab). */
router.post('/:id/worlds/import', auth.authenticate, auth.serverScope('files'), worldUpload.single('file'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Attach a world .zip (field name "file")' });
  try {
    const result = await worlds.importZip(req.server, req.file.path, { name: req.body.name });
    db.log({ actor: req.user.username, action: 'world.import', serverId: req.server.id, serverName: req.server.name, detail: `${result.name} (${result.prettyBytes})` });
    res.status(201).json({ ...result, ...(await worlds.list(req.server)) });
  } catch (err) {
    res.status(400).json({ error: err.message });
  } finally {
    fsp.unlink(req.file.path).catch(() => {});
  }
});

/** Duplicate / delete a world. */
router.post('/:id/worlds/:name/duplicate', auth.authenticate, auth.serverScope('files'), async (req, res) => {
  try {
    const result = await worlds.duplicate(req.server, req.params.name);
    db.log({ actor: req.user.username, action: 'world.duplicate', serverId: req.server.id, serverName: req.server.name, detail: result.name });
    res.json(result);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

router.delete('/:id/worlds/:name', auth.authenticate, auth.serverScope('settings'), async (req, res) => {
  try {
    const result = await worlds.remove(req.server, req.params.name);
    db.log({ actor: req.user.username, action: 'world.delete', serverId: req.server.id, serverName: req.server.name, detail: `${result.name} (${formatBytes(result.bytes)})` });
    res.json(result);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

/* -------------------------------- SFTP -------------------------------- */

/** Connection details + the real status of the SFTP subsystem. */
router.get('/:id/sftp', auth.authenticate, auth.serverScope('files'), async (req, res) => {
  const node = nodesSvc.get(req.server.nodeId || 'local');
  const remote = req.server.nodeId && req.server.nodeId !== 'local';
  res.json({
    ...sftpSvc.connectionInfo(req.server, req.user),
    remoteNode: remote,
    nodeName: node ? node.name : null,
    note: remote
      ? 'This server runs on a remote node: files are moved to the node while a session is open, so large uploads take a little longer.'
      : 'Sessions are chrooted to the server directory - you can only ever reach this server\'s files.',
  });
});


module.exports = router;
module.exports.withUsage = withUsage;
