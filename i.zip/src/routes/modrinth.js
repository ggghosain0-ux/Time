'use strict';
/**
 * Modrinth API:
 *   /api/modrinth/search              - global search
 *   /api/modrinth/project/:id         - project details
 *   /api/modrinth/versions/:id        - versions (filter by loader/game version)
 *   /api/servers/:id/packages         - installed plugins/mods for a server
 */
const express = require('express');
const auth = require('../auth');
const modrinth = require('../services/modrinth');
const runtime = require('../services/runtime');
const db = require('../db');

const router = express.Router();

/* --------------------------- public/search --------------------------- */
router.get('/search', auth.authenticate, async (req, res) => {
  try {
    const { q = '', projectType, loader, gameVersion, limit = 20, offset = 0, sort = 'relevance' } = req.query;
    const data = await modrinth.search({
      query: q, projectType, loader, gameVersion,
      limit: Math.min(parseInt(limit, 10) || 20, 50),
      offset: parseInt(offset, 10) || 0,
      sort,
    });
    res.json(data);
  } catch (err) { res.status(502).json({ error: `Modrinth search failed: ${err.message}` }); }
});

router.get('/project/:id', auth.authenticate, async (req, res) => {
  try { res.json({ project: await modrinth.project(req.params.id) }); }
  catch (err) { res.status(502).json({ error: err.message }); }
});

router.get('/versions/:id', auth.authenticate, async (req, res) => {
  try {
    res.json({ versions: await modrinth.versions(req.params.id, { loader: req.query.loader, gameVersion: req.query.gameVersion }) });
  } catch (err) { res.status(502).json({ error: err.message }); }
});

/** Search pre-filtered for one server (loader + game version facets). */
router.get('/servers/:id/browse', auth.authenticate, auth.serverScope('plugins'), async (req, res) => {
  try {
    const projectType = modrinth.modrinthProjectType(req.server.serverType, req.query.type);
    const data = await modrinth.search({
      query: req.query.q || '',
      projectType,
      loader: req.query.loader || undefined,
      gameVersion: req.query.gameVersion || req.server.version,
      limit: Math.min(parseInt(req.query.limit || '20', 10), 50),
      offset: parseInt(req.query.offset || '0', 10),
      sort: req.query.sort || 'relevance',
    });
    res.json({ ...data, projectType, loaders: modrinth.loadersFor(req.server.serverType), gameVersion: req.server.version });
  } catch (err) { res.status(502).json({ error: `Modrinth unavailable: ${err.message}` }); }
});

/* --------------------------- installed packages --------------------------- */
router.get('/servers/:id/packages', auth.authenticate, auth.serverScope('plugins'), async (req, res) => {
  const installed = await modrinth.listInstalled(req.server, req.query.type);
  res.json({
    packages: installed,
    projectType: modrinth.modrinthProjectType(req.server.serverType, req.query.type),
    loaders: modrinth.loadersFor(req.server.serverType),
    gameVersion: req.server.version,
    serverType: req.server.serverType,
  });
});

router.post('/servers/:id/packages', auth.authenticate, auth.serverScope('plugins'), async (req, res) => {
  const { projectId, versionId, type, resolveDependencies = true } = req.body || {};
  if (!projectId) return res.status(400).json({ error: 'projectId is required' });
  const log = (msg) => runtime.state(req.server.id).logs.push(`[modrinth] ${msg}`);
  log(`Installing ${projectId}...`);
  res.json({ ok: true, message: 'Install started - progress is logged in the console' });
  try {
    const result = await modrinth.install(req.server, {
      projectId, versionId, projectType: type, resolveDependencies,
      onProgress: (note) => {
        log(note);
        runtime.setInstallProgress(req.server.id, { step: 'modrinth', percent: 60, note });
      },
    });
    result.installed.forEach((p) => log(`Installed ${p.title} ${p.version} -> ${p.dir}/${p.filename}`));
    log('Done. Restart the server to load new content.');
    runtime.setInstallProgress(req.server.id, { step: 'done', percent: 100, note: 'Plugin installed' });
    db.log({ actor: req.user.username, action: 'plugin.install', serverId: req.server.id, serverName: req.server.name, detail: result.installed.map((i) => i.title).join(', ') });
  } catch (err) {
    log(`FAILED: ${err.message}`);
    runtime.setInstallProgress(req.server.id, { step: 'error', percent: 100, note: err.message });
  }
});

router.get('/servers/:id/packages/updates', auth.authenticate, auth.serverScope('plugins'), async (req, res) => {
  try { res.json(await modrinth.checkUpdates(req.server)); }
  catch (err) { res.status(502).json({ error: err.message }); }
});

router.post('/servers/:id/packages/update', auth.authenticate, auth.serverScope('plugins'), async (req, res) => {
  const { id, versionId } = req.body || {};
  try {
    const result = await modrinth.update(req.server, { id, versionId });
    runtime.state(req.server.id).logs.push(`[modrinth] Updated ${result.filename}: ${result.from} -> ${result.to}`);
    res.json({ ok: true, ...result });
  } catch (err) { res.status(400).json({ error: err.message }); }
});

router.post('/servers/:id/packages/toggle', auth.authenticate, auth.serverScope('plugins'), async (req, res) => {
  try { res.json(await modrinth.toggle(req.server, req.body || {})); }
  catch (err) { res.status(400).json({ error: err.message }); }
});

router.delete('/servers/:id/packages/:packageId', auth.authenticate, auth.serverScope('plugins'), async (req, res) => {
  try {
    const result = await modrinth.remove(req.server, { id: req.params.packageId });
    db.log({ actor: req.user.username, action: 'plugin.remove', serverId: req.server.id, serverName: req.server.name, detail: result.removed });
    res.json({ ok: true, ...result });
  } catch (err) { res.status(400).json({ error: err.message }); }
});

module.exports = router;
