'use strict';
/**
 * Player endpoints.
 *   GET  /api/servers/:id/players              online players + action catalogue
 *   POST /api/servers/:id/players/refresh      ask the server for its roster
 *   POST /api/servers/:id/players/:name/action { action, ...args } one-click action
 *   POST /api/servers/:id/players/bulk         run an action on several players
 */
const express = require('express');
const db = require('../db');
const auth = require('../auth');
const runtime = require('../services/runtime');
const players = require('../services/players');

const router = express.Router({ mergeParams: true });

router.get('/', auth.authenticate, auth.serverScope('console'), (req, res) => {
  const list = players.online(req.server.id);
  res.json({
    players: list.map((p) => ({ ...p, op: false, onlineFor: p.joinedAt ? Date.now() - p.joinedAt : 0 })),
    count: list.length,
    max: runtime.state(req.server.id).maxPlayers || req.server.maxPlayers || 20,
    status: runtime.info(req.server.id).status,
    actions: players.actions(),
  });
});

router.post('/refresh', auth.authenticate, auth.serverScope('console'), (req, res) => {
  const sent = players.refresh(req.server);
  res.json({ ok: true, requested: sent, players: players.online(req.server.id) });
});

router.post('/bulk', auth.authenticate, auth.serverScope('console'), (req, res) => {
  const { action, players: names, args = {} } = req.body || {};
  if (!Array.isArray(names) || !names.length) return res.status(400).json({ error: 'players[] is required' });
  const results = [];
  for (const name of names.slice(0, 50)) {
    try {
      results.push({ player: name, ...players.apply(req.server, name, action, args) });
    } catch (err) {
      results.push({ player: name, error: err.message });
    }
  }
  res.json({ ok: true, results });
});

router.post('/:name/action', auth.authenticate, auth.serverScope('console'), (req, res) => {
  const { action, ...args } = req.body || {};
  try {
    const result = players.apply(req.server, req.params.name, action, args);
    res.json({ ok: true, ...result, player: req.params.name });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

/** Recent join/leave style activity for the players tab. */
router.get('/recent', auth.authenticate, auth.serverScope('console'), (req, res) => {
  const rows = (db.get('activity') || []).filter((a) => a.serverId === req.server.id && String(a.action).startsWith('player.')).slice(0, 40);
  res.json({ activity: rows });
});

module.exports = router;
