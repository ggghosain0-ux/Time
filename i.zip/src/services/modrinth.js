'use strict';
/**
 * Modrinth integration - search, one-click install, dependency resolution,
 * update checking and removal of plugins/mods/datapacks.
 *
 * Docs: https://docs.modrinth.com/api/
 */
const path = require('path');
const fs = require('fs');
const fsp = require('fs/promises');
const crypto = require('crypto');

const cfg = require('../config');
const db = require('../db');
const logger = require('../logger');
const { download, fetchJson, safeJoin, formatBytes, exists } = require('../utils');

const PROJECT_TYPE = { plugin: 'plugin', mod: 'mod', datapack: 'datapack', modpack: 'modpack', shader: 'shader', resourcepack: 'resourcepack' };

const API = () => cfg.modrinthApi || 'https://api.modrinth.com/v2';
const HEADERS = () => ({ 'User-Agent': cfg.modrinthUA, Accept: 'application/json' });

function q(params) {
  const sp = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v === undefined || v === null || v === '') continue;
    sp.set(k, typeof v === 'object' ? JSON.stringify(v) : String(v));
  }
  return sp.toString();
}

/* ------------------------------ search ------------------------------ */
async function search({ query = '', projectType, loader, gameVersion, limit = 20, offset = 0, sort = 'relevance' }) {
  const facets = [];
  if (projectType) facets.push([`project_type:${projectType}`]);
  if (loader) facets.push([`categories:${loader.toLowerCase()}`]);
  if (gameVersion) facets.push([`versions:${gameVersion}`]);
  const url = `${API()}/search?${q({ query, limit, offset, index: sort, facets: facets.length ? facets : undefined })}`;
  const data = await cachedFetch(url, 60e3);
  return {
    total: data.total_hits,
    offset: data.offset,
    limit: data.limit,
    hits: (data.hits || []).map((h) => ({
      projectId: h.project_id, slug: h.slug, title: h.title, description: h.description,
      author: h.author, downloads: h.downloads, follows: h.follows, categories: h.categories,
      versions: h.versions, icon: h.icon_url, projectType: h.project_type, updated: h.date_modified,
      clientSide: h.client_side, serverSide: h.server_side, license: h.license,
    })),
  };
}
exports.search = search;

/** Which Modrinth loaders match a panel server type. */
function loadersFor(serverType) {
  switch (String(serverType || '').toUpperCase()) {
    case 'PAPER': return ['paper', 'spigot', 'bukkit'];
    case 'PURPUR': return ['purpur', 'paper', 'spigot', 'bukkit'];
    case 'SPIGOT': return ['spigot', 'bukkit'];
    case 'FOLIA': return ['folia', 'paper'];
    case 'FABRIC': return ['fabric'];
    case 'QUILT': return ['quilt', 'fabric'];
    case 'FORGE': return ['forge'];
    case 'NEOFORGE': return ['neoforge'];
    case 'VELOCITY': return ['velocity'];
    case 'BUNGEECORD': return ['bungeecord'];
    default: return ['paper', 'spigot', 'fabric', 'forge', 'neoforge'];
  }
}
exports.loadersFor = loadersFor;

function modrinthProjectType(serverType, requested) {
  if (requested) return requested;
  const t = String(serverType || '').toUpperCase();
  if (['FABRIC', 'QUILT', 'FORGE', 'NEOFORGE'].includes(t)) return 'mod';
  return 'plugin';
}
exports.modrinthProjectType = modrinthProjectType;

async function cachedFetch(url, ttlMs) {
  const now = Date.now();
  const hit = cache.get(url);
  if (hit && now - hit.at < ttlMs) return hit.value;
  const value = await fetchJson(url, { headers: HEADERS() });
  cache.set(url, { at: now, value });
  if (cache.size > 300) cache.clear();
  return value;
}
const cache = new Map();

async function project(idOrSlug) {
  const data = await cachedFetch(`${API()}/project/${encodeURIComponent(idOrSlug)}`, 5 * 60e3);
  return {
    id: data.id, slug: data.slug, title: data.title, description: data.description,
    body: typeof data.body === 'string' ? data.body.slice(0, 6000) : '',
    icon: data.icon_url, downloads: data.downloads, followers: data.followers,
    categories: data.categories, loaders: data.loaders, gameVersions: data.game_versions,
    projectType: data.project_type, license: data.license && data.license.name, sourceUrl: data.source_url,
    issuesUrl: data.issues_url, wikiUrl: data.wiki_url, discordUrl: data.discord_url, updated: data.updated,
  };
}
exports.project = project;

async function versions(projectId, { loader, gameVersion } = {}) {
  const params = [];
  if (loader) params.push(`loaders=${JSON.stringify(Array.isArray(loader) ? loader : [loader])}`);
  if (gameVersion) params.push(`game_versions=${JSON.stringify([gameVersion])}`);
  const url = `${API()}/project/${encodeURIComponent(projectId)}/version${params.length ? `?${params.join('&')}` : ''}`;
  const data = await cachedFetch(url, 60e3);
  return data.map((v) => ({
    id: v.id, projectId: v.project_id, name: v.name, versionNumber: v.version_number, versionType: v.version_type,
    gameVersions: v.game_versions, loaders: v.loaders, downloads: v.downloads,
    published: v.date_published, changelog: v.changelog,
    dependencies: v.dependencies || [],
    files: v.files.map((f) => ({
      url: f.url, filename: f.filename, primary: f.primary, size: f.size,
      sha1: f.hashes && f.hashes.sha1, sha512: f.hashes && f.hashes.sha512,
    })),
  }));
}
exports.versions = versions;

/** Server-dir target folder for a project type. */
function targetDir(server, projectType) {
  if (projectType === 'mod') return 'mods';
  if (projectType === 'datapack') return path.join('world', 'datapacks');
  if (projectType === 'plugin') return 'plugins';
  return 'plugins';
}
exports.targetDir = targetDir;

/* ------------------------- installed content ------------------------- */
async function listInstalled(server, projectType) {
  const type = modrinthProjectType(server.serverType, projectType);
  const dirRel = targetDir(server, type);
  const dir = safeJoin(path.join(cfg.serverDataDir, server.id), dirRel);
  const records = (server.packages || []).filter((p) => !projectType || p.projectType === type);

  // Remote servers keep their jars on the node - ask it for the listing so
  // "installed" reflects reality instead of the panel host's empty folder.
  if (require('./runtime').isRemote(server)) {
    const node = require('./remote').nodeFor(server);
    let listing = [];
    try {
      if (node) {
        const res = await require('./remote').request(node, 'GET', `/api/node/servers/${server.id}/files?dir=${encodeURIComponent(dirRel)}`, undefined, { timeout: 8000 });
        listing = res.entries || [];
      }
    } catch (err) {
      logger.warn('modrinth', `could not list ${dirRel} on node: ${err.message}`);
    }
    const byName = new Map(listing.map((e) => [e.name, e]));
    const out = records.map((rec) => {
      const found = byName.get(rec.filename) || byName.get(`${rec.filename}.disabled`);
      return {
        ...rec,
        title: rec.title || rec.filename,
        dir: dirRel,
        node: server.nodeId,
        size: found ? found.size : rec.size || 0,
        sizePretty: formatBytes(found ? found.size : rec.size || 0),
        mtime: found ? found.modified : rec.installedAt,
        exists: Boolean(found),
        enabled: found ? !found.name.endsWith('.disabled') : rec.enabled !== false,
      };
    });
    const known = new Set(records.flatMap((r) => [r.filename, `${r.filename}.disabled`]));
    for (const e of listing) {
      if (e.directory || !/\.jar(\.disabled)?$/i.test(e.name) || known.has(e.name)) continue;
      out.push({
        id: `manual_${e.name}`, projectId: null, title: e.name.replace(/\.jar(\.disabled)?$/, ''), filename: e.name,
        projectType: type, source: 'manual', version: 'unknown', enabled: !e.name.endsWith('.disabled'),
        dir: dirRel, node: server.nodeId, size: e.size, sizePretty: formatBytes(e.size), mtime: e.modified, exists: true,
      });
    }
    return out;
  }

  let entries = [];
  try { entries = await fsp.readdir(dir, { withFileTypes: true }); } catch (_) {}

  const out = [];
  for (const rec of records) {
    const file = safeJoin(dir, rec.filename);
    let size = rec.size || 0;
    let mtime = rec.installedAt;
    try { const st = await fsp.stat(file); size = st.size; mtime = new Date(st.mtimeMs).toISOString(); } catch (_) { /* file deleted manually */ }
    out.push({ ...rec, title: rec.title || rec.filename, dir: dirRel, size, sizePretty: formatBytes(size), mtime, exists: await exists(file) });
  }
  // jars present on disk that Modrinth did not install
  const known = new Set(records.map((r) => r.filename));
  for (const e of entries) {
    if (!e.isFile() || !/\.jar(\.disabled)?$/i.test(e.name)) continue;
    if (known.has(e.name) || known.has(e.name.replace(/\.disabled$/, ''))) continue;
    const st = await fsp.stat(path.join(dir, e.name)).catch(() => null);
    out.push({
      id: `manual_${e.name}`, projectId: null, title: e.name.replace(/\.jar(\.disabled)?$/, ''), filename: e.name,
      projectType: type, source: 'manual', version: 'unknown', enabled: !e.name.endsWith('.disabled'),
      dir: dirRel, size: st ? st.size : 0, sizePretty: formatBytes(st ? st.size : 0),
      mtime: st ? new Date(st.mtimeMs).toISOString() : null, exists: true,
    });
  }
  return out;
}
exports.listInstalled = listInstalled;

/* ------------------------------ install ------------------------------ */
/**
 * Install a Modrinth version (plus required dependencies) into a server.
 * @returns {object} summary { installed: [...], dependencies: [...] }
 */
async function install(server, { projectId, versionId, projectType, resolveDependencies = true, onProgress = () => {} }) {
  const runtimeSvc = require('./runtime');
  const remote = runtimeSvc.isRemote(server);
  const type = modrinthProjectType(server.serverType, projectType);
  const serverRoot = path.join(cfg.serverDataDir, server.id);
  const dirRel = targetDir(server, type);
  const dir = safeJoin(serverRoot, dirRel);
  if (!remote) await fsp.mkdir(dir, { recursive: true });

  let version = null;
  if (versionId) {
    version = (await cachedFetch(`${API()}/version/${encodeURIComponent(versionId)}`, 5 * 60e3));
    version = normalizeVersion(version);
  } else {
    const list = await versions(projectId, { loader: loadersFor(server.serverType), gameVersion: server.version });
    if (!list.length) {
      const loose = await versions(projectId, { loader: loadersFor(server.serverType) });
      version = loose[0] || null;
    } else {
      version = list.find((v) => v.versionType === 'release') || list[0];
    }
    if (!version) throw new Error(`No compatible build of ${projectId} for ${server.serverType} ${server.version}`);
  }

  const proj = await project(version.projectId || projectId).catch(() => null);
  const installed = [];
  const dependencies = [];

  const doInstall = async (ver, isDependency) => {
    const file = ver.files.find((f) => f.primary) || ver.files[0];
    if (!file) return null;
    const dest = safeJoin(dir, file.filename);
    let hash = null;
    if (remote) {
      // the node downloads it itself, so no bytes travel through the panel
      const node = require('./remote').nodeFor(server);
      if (!node) throw new Error('Node for this server no longer exists');
      onProgress(`Asking node "${node.name}" to install ${file.filename} (${formatBytes(file.size)})`);
      const res = await require('./remote').request(node, 'POST', `/api/node/servers/${server.id}/file`, {
        url: file.url, dir: dirRel, filename: file.filename,
      }, { timeout: 10 * 60e3 });
      for (const note of res.notes || []) onProgress(note);
      hash = file.sha512 || null;
    } else {
      onProgress(`Downloading ${file.filename} (${formatBytes(file.size)})`);
      await download(file.url, dest);
      try { hash = crypto.createHash('sha512').update(await fsp.readFile(dest)).digest('hex'); } catch (_) {}
    }
    if (/\.disabled$/i.test(file.filename)) { /* keep as-is */ }
    const meta = await project(ver.projectId).catch(() => null);
    const record = {
      id: `pkg_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`,
      projectId: ver.projectId,
      slug: meta ? meta.slug : null,
      title: meta ? meta.title : ver.projectId,
      icon: meta ? meta.icon : null,
      author: meta && meta.author,
      filename: file.filename,
      versionId: ver.id,
      version: ver.versionNumber,
      versionType: ver.versionType,
      gameVersions: ver.gameVersions,
      loaders: ver.loaders,
      sha512: file.sha512 || hash,
      size: file.size,
      dir: dirRel,
      projectType: isDependency ? (meta && meta.projectType) || type : type,
      dependency: !!isDependency,
      source: 'modrinth',
      enabled: !/\.disabled$/i.test(file.filename),
      node: remote ? server.nodeId : null,
      installedAt: new Date().toISOString(),
    };
    return record;
  };

  const primary = await doInstall(version, false);
  if (primary) installed.push(primary);

  if (resolveDependencies) {
    const seen = new Set([version.id]);
    const walk = async (deps, depth = 0) => {
      if (depth > 3) return;
      for (const dep of deps || []) {
        if (dep.dependency_type !== 'required' && dep.dependency_type !== 'embedded') continue;
        if (!dep.project_id || seen.has(dep.project_id)) continue;
        seen.add(dep.project_id);
        try {
          const list = await versions(dep.project_id, { loader: loadersFor(server.serverType), gameVersion: server.version });
          const pick = list.find((v) => v.versionType === 'release') || list[0];
          if (!pick) continue;
          seen.add(pick.id);
          const rec = await doInstall(pick, true);
          if (rec) { dependencies.push(rec); await walk(pick.dependencies, depth + 1); }
        } catch (err) {
          logger.warn('modrinth', `dependency ${dep.project_id} skipped: ${err.message}`);
        }
      }
    };
    await walk(version.dependencies);
  }

  const added = [...installed, ...dependencies];
  const fresh = db.find('servers', (s) => s.id === server.id);
  // upsert: installing the same file again replaces the old record instead of duplicating it
  const keys = new Set(added.map((a) => `${a.dir}/${a.filename}`));
  const kept = (fresh.packages || []).filter((p) => !keys.has(`${p.dir || 'plugins'}/${p.filename}`));
  db.update('servers', server.id, { packages: [...kept, ...added] });
  db.log({ actor: 'user', action: 'plugin.install', serverId: server.id, serverName: server.name, detail: added.map((a) => a.title).join(', ') });

  return {
    installed: added,
    primary: installed[0] || null,
    note: proj ? `Installed ${proj.title} ${version.versionNumber} to /${dirRel}` : `Installed to /${dirRel}`,
  };
}
exports.install = install;

function normalizeVersion(v) {
  return {
    id: v.id, projectId: v.project_id, name: v.name, versionNumber: v.version_number,
    versionType: v.version_type, gameVersions: v.game_versions, loaders: v.loaders,
    downloads: v.downloads, published: v.date_published, dependencies: v.dependencies || [],
    files: (v.files || []).map((f) => ({ url: f.url, filename: f.filename, primary: f.primary, size: f.size, sha512: f.hashes && f.hashes.sha512 })),
  };
}

/* ------------------------------ remove ------------------------------ */
async function remove(server, { id, filename }) {
  const pkgs = server.packages || [];
  const rec = id ? pkgs.find((p) => p.id === id) : pkgs.find((p) => p.filename === filename);
  const name = (rec && rec.filename) || filename;
  const dirRel = (rec && rec.dir) || 'plugins';
  const onNode = require('./runtime').isRemote(server);
  const target = safeJoin(path.join(cfg.serverDataDir, server.id), path.join(dirRel, name));
  if (onNode) {
    const node = require('./remote').nodeFor(server);
    if (node) {
      await require('./remote').request(node, 'DELETE', `/api/node/servers/${server.id}/file`, { dir: dirRel, filename: name }, { timeout: 20000 }).catch(() => {});
      await require('./remote').request(node, 'DELETE', `/api/node/servers/${server.id}/file`, { dir: dirRel, filename: `${name}.disabled` }, { timeout: 20000 }).catch(() => {});
    }
  } else {
    await fsp.rm(target, { force: true }).catch(() => {});
    await fsp.rm(`${target}.disabled`, { force: true }).catch(() => {});
  }
  db.update('servers', server.id, { packages: pkgs.filter((p) => p !== rec) });
  return { removed: name, node: onNode ? server.nodeId : null };
}
exports.remove = remove;

async function toggle(server, { id, filename, enabled }) {
  const pkgs = server.packages || [];
  const rec = pkgs.find((p) => (id && p.id === id) || p.filename === filename);
  if (!rec) throw new Error('Package not found');
  if (require('./runtime').isRemote(server)) {
    // Disabling on a node = renaming the jar to *.disabled; the agent has no
    // rename endpoint yet, so make the limitation explicit instead of silently
    // doing nothing.
    throw new Error('Enabling/disabling jars is not supported on remote nodes yet - delete and reinstall instead');
  }
  const dir = path.join(cfg.serverDataDir, server.id, rec.dir || 'plugins');
  const active = safeJoin(dir, rec.filename);
  const disabled = `${active}.disabled`;
  if (enabled === false && await exists(active)) await fsp.rename(active, disabled);
  if (enabled === true && await exists(disabled)) await fsp.rename(disabled, active);
  db.update('servers', server.id, { packages: pkgs.map((p) => (p.id === rec.id ? { ...p, enabled: enabled !== false } : p)) });
  return { id: rec.id, enabled: enabled !== false };
}
exports.toggle = toggle;

/* --------------------------- update checks --------------------------- */
async function checkUpdates(server) {
  const installed = (server.packages || []).filter((p) => p.source === 'modrinth' && !p.dependency);
  const results = [];
  for (const rec of installed) {
    try {
      const list = await versions(rec.projectId, { loader: loadersFor(server.serverType), gameVersion: server.version });
      const latest = list.find((v) => v.versionType === 'release') || list[0];
      const newer = latest && latest.id !== rec.versionId;
      results.push({
        id: rec.id, title: rec.title, filename: rec.filename, current: rec.version,
        latest: latest ? latest.versionNumber : null, latestVersionId: latest ? latest.id : null,
        updateAvailable: !!newer, projectId: rec.projectId, patch: latest ? latest.versionType : null,
      });
    } catch (err) {
      results.push({ id: rec.id, title: rec.title, filename: rec.filename, current: rec.version, error: err.message });
    }
  }
  return { count: results.filter((r) => r.updateAvailable).length, results };
}
exports.checkUpdates = checkUpdates;

/** Update one package to its newest compatible version (keeps the old jar as .bak). */
/** (remote servers are handled by install(): the node replaces the file) */
async function update(server, { id, versionId }) {
  const rec = (server.packages || []).find((p) => p.id === id);
  if (!rec) throw new Error('Package not found');
  const onNode = require('./runtime').isRemote(server);
  const dir = path.join(cfg.serverDataDir, server.id, rec.dir || 'plugins');
  const oldPath = safeJoin(dir, rec.filename);
  // keep a .bak of the previous jar next to it (the node does the same when the
  // file API replaces an existing file, so both paths behave the same)
  if (!onNode && await exists(oldPath)) await fsp.rename(oldPath, `${oldPath}.bak`).catch(() => {});
  const res = await install(server, { projectId: rec.projectId, versionId, projectType: rec.projectType, resolveDependencies: false });
  const fresh = db.find('servers', (s) => s.id === server.id);
  // install() de-duplicates by filename; drop the old version's record if the filename changed
  db.update('servers', server.id, { packages: (fresh.packages || []).filter((p) => p.id !== rec.id) });
  return { from: rec.version, to: res.primary.version, filename: res.primary.filename };
}
exports.update = update;
