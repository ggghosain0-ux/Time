'use strict';
/**
 * File manager for a server directory (JTG-style: browse, edit, upload,
 * download, archive, extract, rename, copy, move, chmod-ish, delete).
 * Every path goes through safeJoin, so a malicious filename can never escape
 * the server folder.
 */
const path = require('path');
const fs = require('fs');
const fsp = require('fs/promises');
const { pipeline } = require('stream/promises');

const cfg = require('../config');
const { safeJoin, looksTextual, formatBytes, exists } = require('../utils');
const AdmZip = require('adm-zip');

const PROTECTED = new Set(['.playit']);

function serverRoot(server) { return path.join(cfg.serverDataDir, server.id); }
function resolve(server, rel = '') {
  const full = safeJoin(serverRoot(server), rel);
  const segments = path.relative(serverRoot(server), full).split(path.sep);
  if (segments.some((s) => PROTECTED.has(s))) throw new Error('That folder is reserved by the panel');
  return full;
}
exports.resolve = resolve;

const SKIP = new Set(['.git', 'node_modules']);

async function list(server, rel = '', { showHidden = true } = {}) {
  const dir = resolve(server, rel);
  const entries = await fsp.readdir(dir, { withFileTypes: true });
  const out = [];
  for (const entry of entries) {
    if (!showHidden && entry.name.startsWith('.')) continue;
    if (SKIP.has(entry.name)) continue;
    const full = path.join(dir, entry.name);
    let stat = null;
    try { stat = await fsp.stat(full); } catch (_) { continue; }
    const isDir = entry.isDirectory();
    out.push({
      name: entry.name,
      path: path.posix.join(String(rel || '').replace(/\\/g, '/'), entry.name),
      type: isDir ? 'directory' : entry.isSymbolicLink() ? 'symlink' : 'file',
      size: stat.size,
      sizePretty: formatBytes(stat.size),
      modified: new Date(stat.mtimeMs).toISOString(),
      mode: (stat.mode & 0o777).toString(8),
      editable: !isDir && stat.size < 5 * 1024 * 1024 && looksTextual(entry.name, stat.size),
      archive: /\.(zip|jar)$/i.test(entry.name),
    });
  }
  out.sort((a, b) => (a.type === b.type ? a.name.localeCompare(b.name) : a.type === 'directory' ? -1 : 1));
  const parent = String(rel || '').replace(/\\/g, '/').split('/').filter(Boolean).slice(0, -1).join('/');
  return { path: String(rel || '').replace(/\\/g, '/'), parent, entries: out };
}
exports.list = list;

async function read(server, rel, { tail } = {}) {
  const full = resolve(server, rel);
  const stat = await fsp.stat(full);
  if (stat.isDirectory()) throw new Error('Path is a directory');
  if (stat.size > 20 * 1024 * 1024) throw new Error('File too large to open in the editor (20 MB limit)');
  if (!looksTextual(path.basename(full), stat.size)) throw new Error('Binary file - download it instead');
  let content = await fsp.readFile(full, 'utf8');
  if (tail && content.length > tail) content = content.slice(-tail);
  return { path: rel, content, size: stat.size, modified: new Date(stat.mtimeMs).toISOString() };
}
exports.read = read;

async function write(server, rel, content) {
  const full = resolve(server, rel);
  if (!(await exists(path.dirname(full)))) throw new Error('Parent directory does not exist');
  await fsp.writeFile(full, String(content ?? ''), 'utf8');
  return { path: rel, bytes: Buffer.byteLength(String(content ?? '')) };
}
exports.write = write;

async function mkdir(server, rel) { await fsp.mkdir(resolve(server, rel), { recursive: true }); return { path: rel }; }
exports.mkdir = mkdir;

async function rename(server, from, to) {
  const src = resolve(server, from);
  const dest = resolve(server, to);
  await fsp.mkdir(path.dirname(dest), { recursive: true });
  await fsp.rename(src, dest);
  return { from, to };
}
exports.rename = rename;

async function copy(server, from, to) {
  const src = resolve(server, from);
  const dest = resolve(server, to);
  await fsp.mkdir(path.dirname(dest), { recursive: true });
  await fsp.cp(src, dest, { recursive: true });
  return { from, to };
}
exports.copy = copy;

async function remove(server, paths) {
  const list = Array.isArray(paths) ? paths : [paths];
  const removed = [];
  for (const rel of list) {
    await fsp.rm(resolve(server, rel), { recursive: true, force: true });
    removed.push(rel);
  }
  return { removed };
}
exports.remove = remove;

async function zip(server, rel, destName) {
  const target = resolve(server, rel);
  const zipName = destName || `${path.basename(target) || 'archive'}.zip`;
  const out = resolve(server, path.posix.join(path.dirname(String(rel || '').replace(/\\/g, '/')), zipName));
  const zipFile = new AdmZip();
  const stat = await fsp.stat(target);
  if (stat.isDirectory()) zipFile.addLocalFolder(target, path.basename(target));
  else zipFile.addLocalFile(target);
  await new Promise((res, rej) => zipFile.writeZip(out, (err) => (err ? rej(err) : res())));
  return { path: path.relative(serverRoot(server), out), sizePretty: formatBytes((await fsp.stat(out)).size) };
}
exports.zip = zip;

async function unzip(server, rel, { to } = {}) {
  const archive = resolve(server, rel);
  if (!/\.(zip|jar)$/i.test(archive)) throw new Error('Only .zip and .jar archives can be extracted');
  const stat = await fsp.stat(archive);
  if (stat.size > 2 * 1024 * 1024 * 1024) throw new Error('Archive too large to extract (2 GB limit)');
  const dest = to ? resolve(server, to) : resolve(server, path.dirname(rel));
  await fsp.mkdir(dest, { recursive: true });
  await new Promise((res, rej) => {
    const zipFile = new AdmZip(archive);
    zipFile.extractAllToAsync(dest, true, true, (err) => (err ? rej(err) : res()));
  });
  return { extracted: rel, to: path.relative(serverRoot(server), dest) };
}
exports.unzip = unzip;

/** Save an upload stream to disk (multer gives us the temp file). */
async function saveUpload(server, relDir, originalName, tempPath) {
  const safeName = path.basename(originalName || 'upload.bin').replace(/[/\\]/g, '_');
  const dest = resolve(server, path.posix.join(String(relDir || '').replace(/\\/g, '/'), safeName));
  await fsp.mkdir(path.dirname(dest), { recursive: true });
  await fsp.rename(tempPath, dest);
  const stat = await fsp.stat(dest);
  return { name: safeName, path: path.relative(serverRoot(server), dest), size: stat.size, sizePretty: formatBytes(stat.size) };
}
exports.saveUpload = saveUpload;

function streamDownload(server, rel, res) {
  const full = resolve(server, rel);
  const stat = fs.statSync(full);
  res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(path.basename(full))}"`);
  res.setHeader('Content-Length', stat.size);
  res.setHeader('Content-Type', 'application/octet-stream');
  return pipeline(fs.createReadStream(full), res);
}
exports.streamDownload = streamDownload;

/** Recursive search (name contains) for the quick-file search box. */
async function search(server, query, rel = '', limit = 100) {
  const results = [];
  const needle = String(query || '').toLowerCase();
  const walk = async (dir, depth = 0) => {
    if (results.length >= limit || depth > 8) return;
    let entries = [];
    try { entries = await fsp.readdir(dir, { withFileTypes: true }); } catch { return; }
    for (const e of entries) {
      if (results.length >= limit) return;
      if (SKIP.has(e.name) || PROTECTED.has(e.name)) continue;
      const full = path.join(dir, e.name);
      if (e.isDirectory()) await walk(full, depth + 1);
      else if (e.name.toLowerCase().includes(needle)) {
        const st = await fsp.stat(full).catch(() => null);
        results.push({ name: e.name, path: path.relative(serverRoot(server), full), sizePretty: st ? formatBytes(st.size) : '?' });
      }
    }
  };
  await walk(resolve(server, rel));
  return results;
}
exports.search = search;

exports.serverRoot = serverRoot;
