'use strict';
/**
 * Subdomains (DNS) for servers.
 *
 * Players should be able to join `survival.example.com` instead of
 * `1.2.3.4:25566`. That needs two DNS records per server:
 *
 *   A    survival.example.com            -> <node ip>
 *   SRV  _minecraft._tcp.survival.example.com -> 0 5 25566 survival.example.com
 *
 * Minecraft clients resolve the SRV record, so the port stays out of the address.
 *
 * Providers:
 *   - `cloudflare`: uses a scoped API token + zone, fully automatic.
 *   - `manual` (default when unconfigured): the panel prints exactly which
 *     records to create, with copy buttons, so the feature is still usable.
 *
 * Config lives in panel settings (`dns.*`) or the matching environment vars.
 */
const db = require('../db');
const cfg = require('../config');
const logger = require('../logger');

const CF_API = 'https://api.cloudflare.com/client/v4';

function settings() {
  const s = db.settings() || {};
  return {
    provider: s.dnsProvider || process.env.DNS_PROVIDER || 'manual',
    domain: (s.dnsDomain || process.env.DNS_DOMAIN || '').replace(/^\.+|\.+$/g, '').toLowerCase(),
    token: s.dnsToken || process.env.CLOUDFLARE_TOKEN || '',
    zone: s.dnsZone || process.env.CLOUDFLARE_ZONE || '',        // zone id or domain
    ip: s.dnsIp || process.env.DNS_IP || '',                      // optional override for the A record
    ttl: Math.max(60, parseInt(s.dnsTtl || process.env.DNS_TTL || 300, 10) || 300),
  };
}
exports.settings = settings;

function configured() {
  const s = settings();
  return Boolean(s.domain) && (s.provider !== 'cloudflare' || Boolean(s.token));
}
exports.configured = configured;

function slugify(value) {
  return String(value || '')
    .toLowerCase()
    .replace(/[^a-z0-9-]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 40);
}
exports.slugify = slugify;

/** Full record name for a sub-label, e.g. ("survival", "example.com") */
function fqdn(sub, domain = settings().domain) {
  const label = slugify(sub);
  if (!domain) return label;
  return label.endsWith(`.${domain}`) || label === domain ? label : `${label}.${domain}`;
}
exports.fqdn = fqdn;

/** The exact record set a server needs (also used for the manual instructions). */
function desiredRecords({ sub, name, port, ip }) {
  const s = settings();
  const host = fqdn(sub);
  const target = ip || s.ip || '';
  return {
    host,
    port: Number(port),
    records: [
      { type: 'A', name: host, content: target || '<node-public-ip>', proxied: false, ttl: s.ttl, comment: `Zenith: ${name}` },
      { type: 'SRV', name: `_minecraft._tcp.${host}`, content: host, priority: 0, weight: 5, port: Number(port), ttl: s.ttl, comment: `Zenith: ${name} port` },
    ],
  };
}
exports.desiredRecords = desiredRecords;

/* ----------------------------- cloudflare ----------------------------- */
async function cf(path, { method = 'GET', body } = {}) {
  const s = settings();
  if (!s.token) throw new Error('No Cloudflare API token configured (Admin -> Settings -> Subdomains)');
  const res = await fetch(`${CF_API}${path}`, {
    method,
    headers: { Authorization: `Bearer ${s.token}`, 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  let json = null;
  try { json = text ? JSON.parse(text) : null; } catch (_) { /* html */ }
  if (!res.ok || (json && json.success === false)) {
    const msg = (json && json.errors && json.errors.map((e) => e.message).join('; ')) || `HTTP ${res.status}`;
    throw new Error(`Cloudflare: ${msg}`);
  }
  return json;
}

async function zoneId() {
  const s = settings();
  if (s.zone && /^[0-9a-f]{32}$/i.test(s.zone)) return s.zone;
  const wanted = (s.zone || s.domain).toLowerCase();
  const list = await cf('/zones?per_page=50');
  const match = (list.result || []).find((z) => z.name.toLowerCase() === wanted)
    || (list.result || []).find((z) => wanted.endsWith(z.name.toLowerCase()));
  if (!match) throw new Error(`Cloudflare zone not found for "${wanted}" - check the token's permissions`);
  return match.id;
}
exports.zoneId = zoneId;

/** Create (or update) A + SRV records for a server subdomain. */
async function createRecords({ sub, name, port, ip }) {
  const s = settings();
  const wanted = desiredRecords({ sub, name, port, ip });
  const ipv4 = wanted.records[0].content;
  if (s.provider !== 'cloudflare') {
    // Manual mode: the panel cannot know the node IP for sure, so it hands the
    // admin the exact record set with the IP they configured (if any).
    return { provider: 'manual', ...wanted, created: [] };
  }
  if (!/^\d{1,3}(\.\d{1,3}){3}$/.test(ipv4)) {
    throw new Error('No public IPv4 known for this node - set "Node public IP" in Admin → Settings → Subdomains, or type the IP in the create box');
  }

  const zone = await zoneId();
  const created = [];
  for (const rec of wanted.records) {
    const existing = await cf(`/zones/${zone}/dns_records?type=${rec.type}&name=${encodeURIComponent(rec.name)}`);
    const body = {
      type: rec.type, name: rec.name, ttl: rec.ttl,
      ...(rec.type === 'A' ? { content: rec.content, proxied: false } : { data: { name: rec.content, port: rec.port, priority: rec.priority, weight: rec.weight, proto: '_tcp', service: '_minecraft' } }),
      comment: rec.comment,
    };
    if (rec.type === 'SRV') { delete body.ttl; }
    const hit = (existing.result || [])[0];
    const res = hit
      ? await cf(`/zones/${zone}/dns_records/${hit.id}`, { method: 'PUT', body: { ...body, name: rec.name } })
      : await cf(`/zones/${zone}/dns_records`, { method: 'POST', body });
    created.push({ id: res.result.id, type: rec.type, name: rec.name, content: rec.type === 'A' ? rec.content : `${rec.content}:${rec.port}` });
  }
  logger.ok('dns', `${wanted.host} -> ${ipv4}:${port} (${created.length} record(s))`);
  return { provider: 'cloudflare', ...wanted, created };
}
exports.createRecords = createRecords;

/** Delete the A + SRV records created for a server. */
async function deleteRecords({ sub, port, ip }) {
  const s = settings();
  if (s.provider !== 'cloudflare') return { provider: 'manual', deleted: [] };
  const zone = await zoneId();
  const wanted = desiredRecords({ sub, name: '', port, ip });
  const deleted = [];
  for (const rec of wanted.records) {
    const existing = await cf(`/zones/${zone}/dns_records?type=${rec.type}&name=${encodeURIComponent(rec.name)}`);
    for (const hit of existing.result || []) {
      await cf(`/zones/${zone}/dns_records/${hit.id}`, { method: 'DELETE' });
      deleted.push({ type: rec.type, name: rec.name });
    }
  }
  return { provider: 'cloudflare', deleted };
}
exports.deleteRecords = deleteRecords;

/** Verify the token/zone and report what the panel can do. */
async function verify() {
  const s = settings();
  if (s.provider !== 'cloudflare') {
    return { ok: false, provider: 'manual', message: 'Manual mode: the panel shows the records you have to create at your DNS provider.' };
  }
  if (!s.token) return { ok: false, provider: 'cloudflare', message: 'No API token set.' };
  try {
    const zone = await zoneId();
    const info = await cf(`/zones/${zone}`);
    return { ok: true, provider: 'cloudflare', zone: info.result.name, zoneId: zone, message: `Connected to zone ${info.result.name}` };
  } catch (err) {
    return { ok: false, provider: 'cloudflare', message: err.message };
  }
}
exports.verify = verify;

/** Suggest a free-looking label for a server name. */
function suggest(serverName, taken = []) {
  const base = slugify(serverName) || 'server';
  if (!taken.includes(base)) return base;
  for (let i = 2; i < 50; i += 1) {
    const candidate = `${base}-${i}`;
    if (!taken.includes(candidate)) return candidate;
  }
  return `${base}-${Date.now().toString(36).slice(-4)}`;
}
exports.suggest = suggest;
exports.baseDomain = () => settings().domain || 'example.com';
void cfg;
