'use strict';
/**
 * Backup engine.
 * Uses the system `zip` when present (streaming, low memory) and falls back to
 * adm-zip otherwise. Backups live outside the server folder in BACKUP_DIR.
 */
const path = require('path');
const fs = require('fs');
const fsp = require('fs/promises');
const { execFile, spawn } = require('child_process');
const { pipeline } = require('stream/promises');

const cfg = require('../config');
const db = require('../db');
const logger = require('../logger');
const { uid, formatBytes, ensureDir, exists } = require('../utils');
const AdmZip = require('adm-zip');

const DEFAULT_IGNORES = ['.playit', 'logs/latest.log.gz', 'backups'];
let zipAvailable = null;

function backupDir(serverId) { return path.join(cfg.backupDir, serverId); }

async function hasZip() {
  if (zipAvailable !== null) return zipAvailable;
  zipAvailable = await new Promise((resolve) => {
    execFile('zip', ['-v'], (err) => resolve(!err));
  });
  return zipAvailable;
}

async function list(serverId) {
  const dir = backupDir(serverId);
  const files = await fsp.readdir(dir).catch(() => []);
  const records = db.filter('servers', () => true) && [];
  const stored = (db.find('servers', (s) => s.id === serverId) || {}).backups || [];
  const out = [];
  for (const f of files.filter((f) => /\.(zip|tar\.gz)$/.test(f))) {
    const st = await fsp.stat(path.join(dir, f)).catch(() => null);
    if (!st) continue;
    const rec = stored.find((s) => s.filename === f) || {};
    out.push({
      id: rec.id || `file_${f}`,
      filename: f,
      size: st.size,
      sizePretty: formatBytes(st.size),
      createdAt: rec.createdAt || new Date(st.mtimeMs).toISOString(),
      note: rec.note || '',
      locked: !!rec.locked,
      automatic: !!rec.automatic,
      remote: rec.remote || null,
      remoteNode: rec.remoteNode || null,
      exists: true,
    });
  }
  return out.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}
exports.list = list;

/**
 * Create a backup. `note` is shown in the UI.
 * @returns backup record
 */
async function create(server, { note = '', automatic = false, onProgress = () => {} } = {}) {
  const runtime = require('./runtime');
  if (runtime.isRemote(server)) return createRemote(server, { note, automatic, onProgress });
  const sourceDir = runtime.serverDir(server);
  if (!(await exists(sourceDir))) throw new Error('Server directory does not exist yet');
  const dir = backupDir(server.id);
  await ensureDir(dir);

  const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const filename = `${stamp}_${(server.name || server.id).replace(/[^\w.-]+/g, '_')}.zip`;
  const target = path.join(dir, filename);

  const ignores = DEFAULT_IGNORES.map((i) => `-x ${i}/*`).flatMap((s) => s.split(' '));
  onProgress({ step: 'archive', percent: 5, note: 'Creating archive...' });

  if (await hasZip()) {
    await new Promise((resolve, reject) => {
      // -r recursive, -q quiet, -y keep symlinks as links (worlds use them sometimes)
      const args = ['-r', '-q', '-1', target, '.', ...ignores];
      const proc = spawn('zip', args, { cwd: sourceDir });
      let stderr = '';
      proc.stderr.on('data', (d) => { stderr += d.toString(); });
      proc.on('error', reject);
      proc.on('exit', (code) => (code === 0 ? resolve() : reject(new Error(`zip exited ${code}: ${stderr.slice(0, 400)}`))));
    });
  } else {
    onProgress({ step: 'archive', percent: 5, note: 'Creating archive with the built-in archiver (slower)...' });
    const zipFile = new AdmZip();
    zipFile.addLocalFolder(sourceDir, '', true);
    for (const ig of DEFAULT_IGNORES) {
      const p = path.join(sourceDir, ig);
      if (await exists(p)) { try { zipFile.deleteFile(ig); } catch (_) {} try { zipFile.deleteFile(`${ig}/`); } catch (_) {} }
    }
    await new Promise((res, rej) => zipFile.writeZip(target, (err) => (err ? rej(err) : res())));
  }

  const stat = await fsp.stat(target);
  const record = {
    id: uid('bkp'), filename, size: stat.size, sizePretty: formatBytes(stat.size),
    createdAt: new Date().toISOString(), note, automatic, createdBy: 'panel', locked: false,
  };
  const fresh = db.find('servers', (s) => s.id === server.id) || server;
  db.update('servers', server.id, { backups: [...(fresh.backups || []), record] });
  db.log({ actor: automatic ? 'scheduler' : 'user', action: 'backup.create', serverId: server.id, serverName: server.name, detail: filename });
  logger.ok('backups', `${server.name}: ${filename} (${record.sizePretty})`);
  onProgress({ step: 'done', percent: 100, note: `Backup created (${record.sizePretty})` });
  return record;
}
exports.create = create;

/**
 * Remote backup: ask the node agent to archive its copy of the server, then
 * stream the archive back into the panel's own backup directory so that
 * listing, download, restore and pruning behave exactly like a local backup.
 */
async function createRemote(server, { note = '', automatic = false, onProgress = () => {} } = {}) {
  const runtime = require('./runtime');
  const remote = require('./remote');
  const node = remote.nodeFor(server);
  if (!node) throw new Error('Node for this server no longer exists');

  const wasRunning = runtime.isOnline(server.id);
  if (wasRunning) {
    onProgress({ step: 'stop', percent: 2, note: `Stopping on ${node.name} for a consistent archive...` });
    await runtime.stop(server.id);
    await new Promise((r) => setTimeout(r, 2500));
  }

  const dir = backupDir(server.id);
  await ensureDir(dir);
  const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const base = `${stamp}_${(server.name || server.id).replace(/[^\w.-]+/g, '_')}`;
  const filename = `${base}.zip`;
  const target = path.join(dir, filename);
  let archive = null;

  try {
    onProgress({ step: 'archive', percent: 10, note: `Archiving on node "${node.name}"...` });
    archive = await remote.request(node, 'POST', `/api/node/servers/${server.id}/archive`, { name: base }, { timeout: 20 * 60e3 });

    onProgress({ step: 'transfer', percent: 45, note: `Pulling ${formatBytes(archive.size || 0)} from ${node.name}...` });
    const res = await fetch(`${remote.baseUrl(node)}/api/node/servers/${server.id}/archive?path=${encodeURIComponent(archive.path)}`, {
      headers: { 'x-node-token': node.token || '' },
    });
    if (!res.ok) throw new Error(`node answered HTTP ${res.status} while streaming the archive`);
    await pipeline(res.body, fs.createWriteStream(target));

    const stat = await fsp.stat(target);
    const record = {
      id: uid('bkp'), filename, size: stat.size, sizePretty: formatBytes(stat.size),
      createdAt: new Date().toISOString(), note, automatic, createdBy: 'panel', locked: false,
      remote: node.id, remoteNode: node.name, remotePath: archive.path,
    };
    const fresh = db.find('servers', (s) => s.id === server.id) || server;
    db.update('servers', server.id, { backups: [...(fresh.backups || []), record] });
    db.log({ actor: automatic ? 'scheduler' : 'user', action: 'backup.create', serverId: server.id, serverName: server.name, detail: `${filename} (node ${node.name})` });
    logger.ok('backups', `${server.name}: ${filename} (${record.sizePretty}) pulled from ${node.name}`);
    onProgress({ step: 'done', percent: 100, note: `Backup created (${record.sizePretty})` });
    return record;
  } finally {
    // the node keeps only the live copy; drop its staging archive
    if (archive && archive.path) {
      remote.request(node, 'DELETE', '/api/node/servers/' + server.id + '/archive', { path: archive.path }, { timeout: 15000 }).catch(() => {});
    }
    if (wasRunning) setTimeout(() => runtime.start(db.find('servers', (s) => s.id === server.id)).catch(() => {}), 1500);
  }
}

async function remove(server, ids) {
  const list_ = Array.isArray(ids) ? ids : [ids];
  const records = (server.backups || []).filter((b) => list_.includes(b.id));
  if (records.some((r) => r.locked)) throw new Error('One of the selected backups is locked');
  for (const rec of records) await fsp.rm(path.join(backupDir(server.id), rec.filename), { force: true });
  db.update('servers', server.id, { backups: (server.backups || []).filter((b) => !list_.includes(b.id)) });
  return { removed: records.map((r) => r.filename) };
}
exports.remove = remove;

async function lock(server, id, locked) {
  const backups = (server.backups || []).map((b) => (b.id === id ? { ...b, locked: !!locked } : b));
  db.update('servers', server.id, { backups });
  return { id, locked: !!locked };
}
exports.lock = lock;

/**
 * Restore a backup: stop the server, wipe the current files (keeping the
 * backup itself), extract, done.
 */
async function restore(server, id, { keepCurrent = true } = {}) {
  const runtime = require('./runtime');
  const rec = (server.backups || []).find((b) => b.id === id) || { id, filename: id };
  if (runtime.isRemote(server)) return restoreRemote(server, rec);
  const archive = path.join(backupDir(server.id), rec.filename);
  if (!(await exists(archive))) throw new Error('Backup file is missing on disk');
  if (runtime.isRemote(server)) {
    throw new Error('Backups for servers on a remote node are not implemented yet - use the file manager on that node or run the panel locally.');
  }
  const wasRunning = runtime.isOnline(server.id);
  if (wasRunning) {
    await runtime.stop(server.id);
    await new Promise((r) => setTimeout(r, 1500));
  }
  const dir = runtime.serverDir(server);
  await ensureDir(dir);

  if (keepCurrent) {
    const safety = path.join(dir, `.zenith-before-restore-${Date.now()}.txt`);
    await fsp.writeFile(safety, `Restore of ${rec.filename} performed at ${new Date().toISOString()}\n`).catch(() => {});
  } else {
    for (const entry of await fsp.readdir(dir)) {
      if (entry === '.playit') continue;
      await fsp.rm(path.join(dir, entry), { recursive: true, force: true });
    }
  }

  if (await hasZip()) {
    await new Promise((resolve, reject) => {
      const proc = spawn('unzip', ['-o', '-q', archive, '-d', dir]);
      let stderr = '';
      proc.stderr.on('data', (d) => { stderr += d.toString(); });
      proc.on('error', reject);
      proc.on('exit', (code) => (code === 0 ? resolve() : reject(new Error(`unzip exited ${code}: ${stderr.slice(0, 300)}`))));
    });
  } else {
    await new Promise((res, rej) => new AdmZip(archive).extractAllToAsync(dir, true, true, (e) => (e ? rej(e) : res())));
  }

  const fresh = db.find('servers', (s) => s.id === server.id) || server;
  await runtime.writeEula(fresh);
  db.log({ actor: 'user', action: 'backup.restore', serverId: server.id, serverName: server.name, detail: rec.filename });
  if (wasRunning) setTimeout(() => runtime.start(db.find('servers', (s) => s.id === server.id)).catch(() => {}), 2000);
  return { restored: rec.filename, restarted: wasRunning };
}
exports.restore = restore;

/**
 * Remote restore: stop the server on the node, stream the panel's archive to
 * the agent (which wipes + extracts it), then start the server again.
 */
async function restoreRemote(server, rec) {
  const runtime = require('./runtime');
  const remote = require('./remote');
  const node = remote.nodeFor(server);
  if (!node) throw new Error('Node for this server no longer exists');
  const archive = path.join(backupDir(server.id), rec.filename);
  if (!(await exists(archive))) throw new Error('Backup file is missing on the panel');

  const wasRunning = runtime.isOnline(server.id);
  if (wasRunning) { await runtime.stop(server.id); await new Promise((r) => setTimeout(r, 2000)); }

  remote.request(node, 'POST', `/api/node/servers/${server.id}/archive`, { name: `pre-restore-${Date.now()}` }, { timeout: 10 * 60e3 })
    .catch(() => {}); // best-effort safety copy on the node

  const safeName = rec.filename.replace(/[^\w.-]+/g, '_');
  await remote.raw(node, 'POST', `/api/node/servers/${server.id}/restore`, fs.createReadStream(archive), {
    'content-type': 'application/octet-stream',
    'x-archive-format': rec.filename.endsWith('.tar.gz') ? 'tar.gz' : 'zip',
    'x-archive-name': safeName,
  }, { timeout: 30 * 60e3 });

  if (wasRunning) setTimeout(() => runtime.start(db.find('servers', (s) => s.id === server.id)).catch(() => {}), 2000);
  db.log({ actor: 'user', action: 'backup.restore', serverId: server.id, serverName: server.name, detail: `${rec.filename} -> node ${node.name}` });
  logger.warn('backups', `${server.name}: restored ${rec.filename} on node ${node.name}`);
  return { restored: rec.filename, restarted: wasRunning, remote: true, node: node.name };
}

function streamDownload(server, id, res) {
  const rec = (server.backups || []).find((b) => b.id === id) || { filename: id };
  const file = path.join(backupDir(server.id), rec.filename);
  if (!fs.existsSync(file)) throw new Error('Backup file is missing');
  const stat = fs.statSync(file);
  res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(rec.filename)}"`);
  res.setHeader('Content-Length', stat.size);
  res.setHeader('Content-Type', 'application/zip');
  return pipeline(fs.createReadStream(file), res);
}
exports.streamDownload = streamDownload;

/** Delete the oldest automatic backups beyond `keep`. */
async function prune(server, keep = 10) {
  const autos = (server.backups || []).filter((b) => b.automatic && !b.locked).sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
  if (autos.length <= keep) return { removed: 0 };
  const drop = autos.slice(0, autos.length - keep);
  await remove(server, drop.map((d) => d.id));
  return { removed: drop.length };
}
exports.prune = prune;
exports.backupDir = backupDir;
