'use strict';
/**
 * Per-server scheduled tasks: restart / start / stop / backup / command.
 * Cron expressions are stored per task; the tick runs every 30 s.
 */
const cfg = require('../config');
const db = require('../db');
const logger = require('../logger');
const { uid, cronMatches, describeCron, sleep } = require('../utils');

let interval = null;
const lastRuns = new Map(); // taskId -> "YYYY-MM-DDTHH:mm"

const ACTIONS = ['start', 'restart', 'stop', 'backup', 'command'];

function list(server) { return server.schedules || []; }
exports.list = list;

function create(server, { name, action, cron, payload = '', enabled = true }) {
  if (!ACTIONS.includes(action)) throw new Error(`Invalid action "${action}"`);
  const task = { id: uid('sch'), name: name || `${action} task`, action, cron: cron || '0 4 * * *', payload, enabled, createdAt: new Date().toISOString(), lastRun: null, lastResult: null };
  db.update('servers', server.id, { schedules: [...(server.schedules || []), task] });
  return task;
}
exports.create = create;

function update(server, id, patch) {
  const schedules = (server.schedules || []).map((s) => (s.id === id ? { ...s, ...patch } : s));
  db.update('servers', server.id, { schedules });
  return schedules.find((s) => s.id === id);
}
exports.update = update;

function remove(server, id) {
  db.update('servers', server.id, { schedules: (server.schedules || []).filter((s) => s.id !== id) });
  return { removed: id };
}
exports.remove = remove;

async function run(serverId, task) {
  const runtime = require('./runtime');
  const backups = require('./backups');
  const server = db.find('servers', (s) => s.id === serverId);
  if (!server) return 'server missing';
  try {
    switch (task.action) {
      case 'start': if (!runtime.isOnline(serverId)) await runtime.start(server, { silent: true }); break;
      case 'stop': if (runtime.isOnline(serverId)) await runtime.stop(serverId); break;
      case 'restart':
        if (runtime.isOnline(serverId)) await runtime.restart(serverId);
        else await runtime.start(server, { silent: true });
        break;
      case 'backup': await backups.create(server, { note: `Scheduled: ${task.name}`, automatic: true }); await backups.prune(server, 10); break;
      case 'command': if (runtime.isOnline(serverId)) runtime.sendCommand(serverId, task.payload); else return 'server offline'; break;
      default: return 'unknown action';
    }
    db.log({ actor: 'scheduler', action: `schedule.${task.action}`, serverId, serverName: server.name, detail: task.name });
    return 'ok';
  } catch (err) {
    logger.error('scheduler', `${task.name} -> ${err.message}`);
    return err.message;
  }
}
exports.run = run;

/** Run a task immediately from the UI. */
exports.runNow = (serverId, taskId) => {
  const server = db.find('servers', (s) => s.id === serverId);
  const task = (server && (server.schedules || []).find((s) => s.id === taskId));
  if (!task) throw new Error('Task not found');
  return run(serverId, task);
};

function tick() {
  const now = new Date();
  const bucket = `${now.toISOString().slice(0, 16)}`;
  for (const server of db.get('servers') || []) {
    for (const task of server.schedules || []) {
      if (!task.enabled) continue;
      if (!cronMatches(task.cron, now)) continue;
      if (lastRuns.get(task.id) === bucket) continue;
      lastRuns.set(task.id, bucket);
      logger.info('scheduler', `running "${task.name}" for ${server.name}`);
      run(server.id, task).then((result) => {
        const fresh = db.find('servers', (s) => s.id === server.id);
        if (fresh) {
          db.update('servers', server.id, {
            schedules: (fresh.schedules || []).map((s) => (s.id === task.id ? { ...s, lastRun: new Date().toISOString(), lastResult: result } : s)),
          });
        }
      });
    }
  }
}

function start() {
  if (interval) return;
  interval = setInterval(() => { try { tick(); } catch (err) { logger.error('scheduler', err.message); } }, 30000);
  interval.unref?.();
  logger.info('scheduler', 'cron ticker started (30s resolution)');
}
exports.start = start;
function stopLoop() { if (interval) clearInterval(interval); interval = null; }
exports.stop = stopLoop;

exports.describe = describeCron;
exports.ACTIONS = ACTIONS;
