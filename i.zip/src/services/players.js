'use strict';
/**
 * Player actions.
 *
 * A thin, validated layer over the server console so the UI (and the Discord
 * bot) can do the things an admin actually wants in one click: op someone,
 * hand out items, top up health or hunger, change gamemode, kick, ban,
 * whitelist, teleport, clear inventory, apply effects...
 *
 * Everything runs through `runtime.sendCommand()`, so it works identically for
 * a local server and a server hosted on a remote node (the command is forwarded
 * to that node's agent).
 */
const db = require('../db');
const runtime = require('./runtime');
const logger = require('../logger');

/* --------------------------- output parsing --------------------------- */
/**
 * Keep the online player list in sync by parsing console output. Servers print
 * the roster when they receive `list` ("There are 2 of a max of 20 players
 * online: Notch, Steve"), and a periodic `list` is sent by whoever needs it.
 */
function attachParser() {
  runtime.events.on('event', (ev) => {
    if (!ev || ev.serverId === undefined) return;
    const text = ev.type === 'log' ? String(ev.data || '') : '';
    if (!text) return;
    const m = text.match(/There are (\d+) of a max(?: of)? (\d+) players online:?\s*(.*)$/im);
    if (!m) return;
    const [, count, max, names] = m;
    const state = runtime.state(ev.serverId);
    const list = names.split(',').map((n) => n.trim()).filter(Boolean);
    state.players.clear();
    for (const name of list) state.players.set(name.toLowerCase(), { name, joinedAt: Date.now(), fromList: true });
    state.maxPlayers = parseInt(max, 10) || state.maxPlayers;
    runtime.events.emit('event', { serverId: ev.serverId, type: 'players', data: [...state.players.values()] });
    void count;
  });
}

/* ---------------------------- action table ---------------------------- */
const ACTIONS = {
  op: {
    label: 'Make operator', icon: 'shield', args: [],
    command: (p) => `op ${p}`, danger: false,
    describe: (p) => `Granted operator to ${p}`,
  },
  deop: {
    label: 'Remove operator', icon: 'shield', args: [],
    command: (p) => `deop ${p}`,
    describe: (p) => `Removed operator from ${p}`,
  },
  heal: {
    label: 'Full health', icon: 'heart', args: [],
    command: (p) => `effect give ${p} minecraft:instant_health 1 10 true`,
    describe: (p) => `Restored ${p}'s health`,
    oneClick: true,
  },
  feed: {
    label: 'Full hunger', icon: 'food', args: [],
    command: (p) => `effect give ${p} minecraft:saturation 1 10 true`,
    describe: (p) => `Filled ${p}'s hunger bar`,
    oneClick: true,
  },
  give: {
    label: 'Give items', icon: 'gift', args: ['item', 'count'],
    command: (p, { item, count }) => `give ${p} ${item} ${count || 1}`,
    describe: (p, { item, count }) => `Gave ${count || 1}x ${item} to ${p}`,
  },
  gamemode: {
    label: 'Gamemode', icon: 'gamepad', args: ['mode'],
    command: (p, { mode }) => `gamemode ${mode} ${p}`,
    describe: (p, { mode }) => `Set ${p}'s gamemode to ${mode}`,
  },
  xp: {
    label: 'Give XP', icon: 'star', args: ['levels'],
    command: (p, { levels }) => `xp add ${p} ${levels || 30} levels`,
    describe: (p, { levels }) => `Gave ${levels || 30} levels to ${p}`,
  },
  fly: {
    label: 'Allow flight', icon: 'wind', args: [],
    command: (p) => `effect give ${p} minecraft:levitation 1 0 true`, // placeholder, replaced below
    describe: (p) => `Toggled flight for ${p}`,
  },
  clear: {
    label: 'Clear inventory', icon: 'trash', args: [],
    command: (p) => `clear ${p}`, danger: true,
    describe: (p) => `Cleared ${p}'s inventory`,
  },
  kick: {
    label: 'Kick', icon: 'door', args: ['reason'],
    command: (p, { reason }) => `kick ${p} ${reason || 'Kicked by an operator'}`,
    describe: (p) => `Kicked ${p}`,
    danger: true,
  },
  ban: {
    label: 'Ban', icon: 'ban', args: ['reason'],
    command: (p, { reason }) => `ban ${p} ${reason || 'Banned by an operator'}`,
    describe: (p) => `Banned ${p}`,
    danger: true,
  },
  unban: {
    label: 'Unban', icon: 'check', args: [],
    command: (p) => `pardon ${p}`,
    describe: (p) => `Pardoned ${p}`,
    offline: true,
  },
  whitelistAdd: {
    label: 'Whitelist', icon: 'plus', args: [],
    command: (p) => `whitelist add ${p}`,
    describe: (p) => `Whitelisted ${p}`,
    offline: true,
  },
  whitelistRemove: {
    label: 'Unwhitelist', icon: 'minus', args: [],
    command: (p) => `whitelist remove ${p}`,
    describe: (p) => `Removed ${p} from the whitelist`,
    offline: true,
  },
  tp: {
    label: 'Teleport to spawn', icon: 'pin', args: [],
    command: (p) => `tp ${p} 0 80 0`,
    describe: (p) => `Teleported ${p} to spawn`,
  },
  kill: {
    label: 'Kill', icon: 'skull', args: [],
    command: (p) => `kill ${p}`,
    describe: (p) => `Killed ${p}`,
    danger: true,
  },
  playtime: {
    label: 'Play time', icon: 'clock', args: [],
    command: (p) => `playtime ${p}`,
    describe: (p) => `Requested ${p}'s play time`,
    info: true,
  },
};

/* Give / fly need small special cases to behave well across versions. */
ACTIONS.give.validate = (args = {}) => {
  const item = String(args.item || '').trim().toLowerCase().replace(/^minecraft:/, '');
  if (!/^[a-z0-9_]{2,64}$/.test(item.replace(/^[a-z0-9_]+:/, ''))) throw new Error('Invalid item name');
  const count = Math.max(1, Math.min(2304, parseInt(args.count || 1, 10) || 1));
  return { item: `minecraft:${item}`, count };
};
ACTIONS.gamemode.validate = (args = {}) => {
  const mode = String(args.mode || 'survival').toLowerCase();
  if (!['survival', 'creative', 'adventure', 'spectator'].includes(mode)) throw new Error('Invalid gamemode');
  return { mode };
};
ACTIONS.xp.validate = (args = {}) => ({ levels: Math.max(1, Math.min(10000, parseInt(args.levels || 30, 10) || 30)) });
ACTIONS.kick.validate = (args = {}) => ({ reason: String(args.reason || '').slice(0, 120) || 'Kicked by an operator' });
ACTIONS.ban.validate = (args = {}) => ({ reason: String(args.reason || '').slice(0, 120) || 'Banned by an operator' });
ACTIONS.fly = {
  label: 'Allow flight', icon: 'wind', args: [],
  command: (p) => `execute at ${p} run effect give ${p} minecraft:levitation 1 0 true`,
  describe: (p) => `Lifted ${p} briefly (use creative/spectator for real flight)`,
};

const PLAYER_RE = /^[A-Za-z0-9_]{3,16}$/;

function listActions() {
  return Object.entries(ACTIONS).map(([id, a]) => ({
    id, label: a.label, icon: a.icon, args: a.args || [], danger: !!a.danger,
    oneClick: !!a.oneClick, offline: !!a.offline, info: !!a.info,
  }));
}
exports.actions = listActions;

/** Online players as the runtime knows them (join/leave + `list` parsing). */
function online(serverId) {
  const state = runtime.state(serverId);
  return [...state.players.values()].map((p) => ({ name: p.name, joinedAt: p.joinedAt || null }));
}
exports.online = online;

/**
 * Run an action against a player.
 * @returns {{ command: string, message: string, player: string, action: string }}
 */
function apply(server, playerName, action, args = {}) {
  const name = String(playerName || '').trim();
  if (!PLAYER_RE.test(name)) throw new Error('Invalid player name');
  const entry = ACTIONS[action];
  if (!entry) throw new Error(`Unknown player action "${action}"`);

  const run = runtime.isOnline(server.id);
  if (!run) throw new Error('Start the server first - commands need a running process');

  const clean = entry.validate ? entry.validate(args) : args;
  const command = entry.command(name, clean);
  runtime.sendCommand(server.id, command);

  const message = entry.describe(name, clean);
  db.log({ actor: 'user', action: `player.${action}`, serverId: server.id, serverName: server.name, detail: `${name}: ${command}` });
  logger.info('players', `${server.name}: ${message} (${command})`);
  return { command, message, player: name, action };
}
exports.apply = apply;
exports.applyQuiet = apply;

/** Ask the server for its roster (answers are parsed back into the player list). */
function refresh(server) {
  if (!runtime.isOnline(server.id)) return false;
  runtime.sendCommand(server.id, 'list');
  return true;
}
exports.refresh = refresh;

exports.attachParser = attachParser;
