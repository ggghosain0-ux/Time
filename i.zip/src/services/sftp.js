'use strict';
/**
 * SFTP subsystem.
 *
 * Runs a *real* SSH/SFTP server (ssh2) so users can manage their server files
 * with FileZilla, WinSCP, Cyberduck, `sftp`, ... Every session is chrooted to
 * the server directory: the SFTP protocol handlers below only ever touch paths
 * that `safeJoin()` resolved inside that directory, so `..` and absolute paths
 * are rejected exactly like a normal chroot would.
 *
 * Authentication is the panel's own credentials:
 *   username  <your panel username>.<server id>      e.g. admin.srv_abc123
 *   password  your panel password (bcrypt verified)  or an API key (zen_...)
 *
 * The module is honest about failure:
 *   * `ssh2` is an optional dependency - when it is missing, `status()` says so
 *     and the UI shows the exact npm command instead of pretending SFTP works;
 *   * if the port is taken, the real error is stored in `status().error`.
 */
const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const cfg = require('../config');
const db = require('../db');
const logger = require('../logger');
const { safeJoin, formatBytes } = require('../utils');

let ssh2 = null;
let loadError = null;
try {
  // eslint-disable-next-line global-require
  ssh2 = require('ssh2');
} catch (err) {
  loadError = err.message;
}

const state = {
  server: null,
  port: null,
  host: null,
  startedAt: null,
  error: loadError ? `the ssh2 package is not installed (${loadError}) - run: npm install ssh2` : null,
  sessions: 0,
  totalConnections: 0,
  active: new Map(), // session id -> { username, serverId, since, opened }
};

const OPEN_FLAGS = {
  0x00000001: 'r',    // READ
  0x00000002: 'w',    // WRITE
  0x00000004: 'a',    // APPEND
  0x00000008: 'r+',   // CREAT|...
};

function hostKeyPath() {
  const dir = path.join(cfg.dataDir, 'ssh');
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  return path.join(dir, 'sftp_host_rsa');
}

/** Generate (once) and reuse a real RSA host key, exactly like sshd does. */
function hostKey() {
  const file = hostKeyPath();
  if (!fs.existsSync(file)) {
    const { privateKey } = crypto.generateKeyPairSync('rsa', {
      modulusLength: 3072,
      publicKeyEncoding: { type: 'spki', format: 'pem' },
      privateKeyEncoding: { type: 'pkcs1', format: 'pem' },
    });
    fs.writeFileSync(file, privateKey, { mode: 0o600 });
    logger.ok('sftp', `generated a new SSH host key at ${file}`);
  }
  return fs.readFileSync(file);
}

/* ------------------------------- auth ---------------------------------- */

/**
 * `<panel user>.<server id>` + the panel password (or an API key).
 * @returns {Promise<{user: object, server: object}|null>}
 */
async function authenticate(username, password) {
  const raw = String(username || '');
  const dot = raw.lastIndexOf('.');
  if (dot <= 0) return null;
  const uname = raw.slice(0, dot);
  const serverId = raw.slice(dot + 1);
  const server = db.find('servers', (s) => s.id === serverId);
  if (!server) return null;
  const user = db.find('users', (u) => u.username.toLowerCase() === uname.toLowerCase());
  if (!user) return null;

  const auth = require('../auth');
  // API key path (same hash the HTTP API uses) - handy for scripts and clients
  if (/^zen_/.test(password)) {
    const hash = crypto.createHash('sha256').update(String(password)).digest('hex');
    const record = db.find('apiKeys', (k) => k.hash === hash && !k.revoked);
    if (!record || record.userId !== user.id) return null;
    db.update('apiKeys', record.id, { lastUsedAt: new Date().toISOString() });
    if (!auth.canAccess(user, server)) return null;
    return { user, server, via: 'api-key' };
  }
  if (!user.passwordHash) return null;
  const ok = require('bcryptjs').compareSync(String(password), user.passwordHash);
  if (!ok) return null;
  // the panel's own access rules still apply (owners/admins, server members)
  if (!auth.canAccess(user, server)) return null;
  return { user, server, via: 'password' };
}

/* ----------------------------- fs helpers ------------------------------ */

function rootFor(server) {
  return path.join(cfg.serverDataDir, server.id);
}
function within(root, p) {
  return safeJoin(root, String(p || '.'));
}

function longEntry(stats) {
  const mode = stats.mode;
  const attrs = {};
  if (stats.isDirectory()) attrs.mode = mode | 0o040000;
  else attrs.mode = mode;
  attrs.uid = 0;
  attrs.gid = 0;
  attrs.size = stats.size;
  attrs.atime = Math.floor(stats.atimeMs / 1000);
  attrs.mtime = Math.floor(stats.mtimeMs / 1000);
  return attrs;
}

/* ------------------------------- server -------------------------------- */

function settings() {
  const s = db.settings();
  return {
    enabled: s.sftpEnabled !== false && String(process.env.SFTP_ENABLED || 'true') !== 'false',
    port: parseInt(s.sftpPort || process.env.SFTP_PORT || 2022, 10),
    host: s.sftpHost || process.env.SFTP_HOST || '',
  };
}

/** Honest status payload for the API/UI. */
function status() {
  const conf = settings();
  if (!ssh2) return { available: false, running: false, port: conf.port, error: state.error, reason: 'missing-dependency' };
  if (!conf.enabled) return { available: true, running: false, port: conf.port, error: null, reason: 'disabled' };
  if (!state.server) return { available: true, running: false, port: conf.port, error: state.error, reason: state.error ? 'failed' : 'stopped' };
  return {
    available: true,
    running: true,
    port: state.port,
    host: state.host,
    error: null,
    reason: 'running',
    startedAt: state.startedAt,
    sessions: state.sessions,
    totalConnections: state.totalConnections,
  };
}
exports.status = status;

/** Start the SFTP listener (idempotent). */
async function start({ force = false } = {}) {
  const conf = settings();
  if (!ssh2) {
    state.error = loadError ? `the ssh2 package is not installed (${loadError})` : 'ssh2 is unavailable';
    logger.warn('sftp', `SFTP disabled: ${state.error}`);
    return status();
  }
  if (!conf.enabled && !force) return status();
  if (state.server) return status();

  const server = new ssh2.Server({
    hostKeys: [hostKey()],
    banner: 'Zenith Panel SFTP - authorised users only',
    ident: 'SSH-2.0-ZenithPanel',
  }, (client) => {
    let session = null;
    let auth = null;

    client.on('authentication', (ctx) => {
      if (ctx.method !== 'password') return ctx.reject(['password']);
      authenticate(ctx.username, ctx.password)
        .then((result) => {
          if (!result) return ctx.reject();
          auth = result;
          session = {
            id: crypto.randomBytes(6).toString('hex'),
            username: ctx.username,
            serverId: result.server.id,
            serverName: result.server.name,
            since: new Date().toISOString(),
            opened: 0,
          };
          state.sessions += 1;
          state.totalConnections += 1;
          state.active.set(session.id, session);
          logger.info('sftp', `${ctx.username} authenticated (${result.server.name})`);
          ctx.accept();
        })
        .catch((err) => { logger.warn('sftp', `auth error: ${err.message}`); ctx.reject(); });
    });

    client.on('ready', () => {
      client.on('session', (accept) => {
        const s = accept();
        s.on('sftp', (acceptSftp, rejectSftp) => {
          if (!auth) return rejectSftp();
          const sftp = acceptSftp();
          attachSftp(sftp, auth, session);
        });
      });
    });

    client.on('close', () => {
      if (session) { state.sessions = Math.max(0, state.sessions - 1); state.active.delete(session.id); }
    });
    client.on('error', (err) => { logger.warn('sftp', `client error: ${err.message}`); });
  });

  await new Promise((resolve) => {
    const onError = (err) => {
      state.error = err.code === 'EADDRINUSE'
        ? `port ${conf.port} is already in use by another process (sshd? Pterodactyl wings?): ${err.message}`
        : err.message;
      logger.error('sftp', `could not start the SFTP server: ${state.error}`);
      state.server = null;
      resolve();
    };
    server.once('error', onError);
    server.listen(conf.port, '0.0.0.0', () => {
      state.server = server;
      state.port = conf.port;
      state.host = conf.host || null;
      state.startedAt = new Date().toISOString();
      state.error = null;
      logger.ok('sftp', `SFTP server listening on 0.0.0.0:${conf.port} (chrooted per server)`);
      resolve();
    });
  });
  return status();
}
exports.start = start;

async function stop() {
  if (!state.server) return status();
  const s = state.server;
  state.server = null;
  await new Promise((resolve) => s.close(() => resolve()));
  state.sessions = 0;
  state.active.clear();
  logger.info('sftp', 'SFTP server stopped');
  return status();
}
exports.stop = stop;

async function restart() { await stop(); return start({ force: true }); }
exports.restart = restart;

/** Connection details for a server (used by the UI and the API). */
function connectionInfo(server, user) {
  const conf = settings();
  const localNode = db.find('nodes', (n) => n.local) || {};
  const host = conf.host || db.settings().publicIp || (localNode.fqdn && localNode.fqdn !== 'localhost' ? localNode.fqdn : os.hostname());
  const st = status();
  return {
    enabled: conf.enabled,
    host,
    port: conf.port,
    username: `${user ? user.username : '<username>'}.${server.id}`,
    passwordHint: 'your panel password (or an API key)',
    path: `/`,
    url: `sftp://${user ? user.username : '<username>'}.${server.id}@${host}:${conf.port}/`,
    status: st.running ? 'running' : (st.reason === 'missing-dependency' ? 'unavailable' : st.reason),
    error: st.error,
    sessions: state.sessions,
    totalConnections: state.totalConnections,
  };
}
exports.connectionInfo = connectionInfo;

/* ------------------------- the SFTP implementation --------------------- */

/**
 * Wire the SFTP protocol handlers onto a session.
 * Handles: REALPATH, STAT/LSTAT/FSTAT, OPEN/READ/WRITE/CLOSE, OPENDIR/READDIR,
 * MKDIR, RMDIR, REMOVE, RENAME, SETSTAT/FSETSTAT (mtime+mode only).
 */
function attachSftp(sftp, auth, session) {
  const root = rootFor(auth.server);
  const handles = new Map(); // handle buffer(hex) -> { type, path?, fd?, dir?, entries?, pos? }
  const key = (buf) => (Buffer.isBuffer(buf) ? buf.toString('hex') : String(buf));

  const fail = (sftp_, reqid, code = 4, msg = '') => { try { sftp_.status(reqid, code, msg); } catch (_) { /* closed */ } };
  /**
   * Every SFTP request is answered - including when our own code throws.
   * A handler exception becomes SSH_FX_FAILURE with the real message instead of
   * a dropped session, which is what real SFTP clients show the user.
   */
  const on = (name, handler) => sftp.on(name, (...args) => {
    try { handler(...args); }
    catch (err) {
      logger.warn('sftp', `${name} handler error: ${err.message}`);
      const [reqid] = args;
      if (typeof reqid === 'number') fail(sftp, reqid, 4, err.message);
    }
  });
  const resolvePath = (p) => {
    try { return within(root, p); } catch (err) { throw Object.assign(new Error(err.message), { code: 3 }); }
  };

  on('REALPATH', (reqid, givenPath) => {
    try {
      const abs = resolvePath(givenPath);
      const rel = path.relative(root, abs) || '.';
      sftp.name(reqid, [{ filename: rel === '.' ? '/' : `/${rel.split(path.sep).join('/')}`, longname: rel, attrs: {} }]);
    } catch (err) { fail(sftp, reqid, err.code === 3 ? 3 : 2, err.message); }
  });

  const statHandler = (follow) => (reqid, givenPath) => {
    let abs;
    try { abs = resolvePath(givenPath); } catch (err) { return fail(sftp, reqid, 3, err.message); }
    const fn = follow ? fsp.stat : fsp.lstat;
    fn(abs).then((st) => sftp.attrs(reqid, longEntry(st))).catch((err) => fail(sftp, reqid, err.code === 'ENOENT' ? 2 : 4, err.message));
  };
  on('STAT', statHandler(true));
  on('LSTAT', statHandler(false));

  on('FSTAT', (reqid, handle) => {
    const h = handles.get(key(handle));
    if (!h || !h.fh) return fail(sftp, reqid, 4, 'invalid handle');
    h.fh.stat().then((st) => sftp.attrs(reqid, longEntry(st))).catch((err) => fail(sftp, reqid, 4, err.message));
  });

  on('OPEN', (reqid, filename, flags, attrs) => {
    let abs;
    try { abs = resolvePath(filename); } catch (err) { return fail(sftp, reqid, 3, err.message); }
    let openFlags = '';
    const wantRead = Boolean(flags & 0x00000001);
    const wantWrite = Boolean(flags & 0x00000002);
    const wantAppend = Boolean(flags & 0x00000004);
    const wantCreat = Boolean(flags & 0x00000008);
    const wantTrunc = Boolean(flags & 0x00000010);
    const wantExcl = Boolean(flags & 0x00000020);
    if (wantRead && wantWrite) openFlags = 'r+';
    else if (wantRead) openFlags = 'r';
    else if (wantAppend) openFlags = 'a';
    else if (wantWrite) openFlags = wantTrunc ? 'w' : 'r+';
    else openFlags = 'r';
    if (wantCreat && !fs.existsSync(abs)) {
      try { fs.mkdirSync(path.dirname(abs), { recursive: true }); } catch (_) { /* parent exists */ }
      if (wantExcl && !wantWrite) return fail(sftp, reqid, 4, 'EXCL without WRITE');
      openFlags = wantAppend ? 'a' : 'w';
    }
    fsp.open(abs, openFlags).then((fh) => {
      const handle = crypto.randomBytes(8);
      handles.set(key(handle), { type: 'file', path: abs, fh });
      session.opened += 1;
      sftp.handle(reqid, handle);
    }).catch((err) => fail(sftp, reqid, err.code === 'ENOENT' ? 2 : (err.code === 'EACCES' ? 3 : 4), err.message));
  });

  on('READ', (reqid, handle, offset, length) => {
    const h = handles.get(key(handle));
    if (!h || !h.fh) return fail(sftp, reqid, 4, 'invalid handle');
    const buffer = Buffer.alloc(length);
    h.fh.read(buffer, 0, length, offset)
      .then(({ bytesRead }) => {
        if (!bytesRead) return fail(sftp, reqid, 1, 'EOF');   // SSH_FX_EOF - clients rely on this
        sftp.data(reqid, buffer.subarray(0, bytesRead));
      })
      .catch((err) => fail(sftp, reqid, 4, err.message));
  });

  on('WRITE', (reqid, handle, offset, data) => {
    const h = handles.get(key(handle));
    if (!h || !h.fh) return fail(sftp, reqid, 4, 'invalid handle');
    if (!Buffer.isBuffer(data)) return fail(sftp, reqid, 4, 'no data');
    h.fh.write(data, 0, data.length, offset)
      .then(() => sftp.status(reqid, 0))
      .catch((err) => fail(sftp, reqid, 4, err.message));
  });

  on('CLOSE', (reqid, handle) => {
    const h = handles.get(key(handle));
    handles.delete(key(handle));
    if (!h) return sftp.status(reqid, 0);
    if (h.fh) return h.fh.close().then(() => sftp.status(reqid, 0)).catch(() => sftp.status(reqid, 0));
    return sftp.status(reqid, 0);
  });

  on('OPENDIR', (reqid, givenPath) => {
    let abs;
    try { abs = resolvePath(givenPath); } catch (err) { return fail(sftp, reqid, 3, err.message); }
    fsp.readdir(abs, { withFileTypes: true }).then((entries) => {
      const handle = crypto.randomBytes(8);
      handles.set(key(handle), { type: 'dir', path: abs, entries, pos: 0 });
      sftp.handle(reqid, handle);
    }).catch((err) => fail(sftp, reqid, err.code === 'ENOENT' ? 2 : 4, err.message));
  });

  on('READDIR', (reqid, handle) => {
    const h = handles.get(key(handle));
    if (!h || h.type !== 'dir') return fail(sftp, reqid, 4, 'invalid directory handle');
    const names = [];
    const batch = h.entries.slice(h.pos, h.pos + 50);
    h.pos += batch.length;
    const jobs = batch.map((entry) => {
      const full = path.join(h.path, entry.name);
      return fsp.lstat(full).then((st) => names.push({ filename: entry.name, longname: entry.name, attrs: longEntry(st) }))
        .catch(() => names.push({ filename: entry.name, longname: entry.name, attrs: {} }));
    });
    Promise.all(jobs).then(() => {
      if (!batch.length) return sftp.status(reqid, 1, 'EOF');
      sftp.name(reqid, names);
    }).catch((err) => fail(sftp, reqid, 4, err.message));
  });

  on('MKDIR', (reqid, givenPath, attrs) => {
    let abs;
    try { abs = resolvePath(givenPath); } catch (err) { return fail(sftp, reqid, 3, err.message); }
    fsp.mkdir(abs, { recursive: false, mode: (attrs && attrs.mode) ? (attrs.mode & 0o777) : 0o755 })
      .then(() => sftp.status(reqid, 0))
      .catch((err) => fail(sftp, reqid, err.code === 'EEXIST' ? 4 : 4, err.message));
  });

  on('RMDIR', (reqid, givenPath) => {
    let abs;
    try { abs = resolvePath(givenPath); } catch (err) { return fail(sftp, reqid, 3, err.message); }
    if (abs === root) return fail(sftp, reqid, 4, 'refusing to remove the server root');
    fsp.rmdir(abs).then(() => sftp.status(reqid, 0)).catch((err) => fail(sftp, reqid, err.code === 'ENOENT' ? 2 : 4, err.message));
  });

  on('REMOVE', (reqid, givenPath) => {
    let abs;
    try { abs = resolvePath(givenPath); } catch (err) { return fail(sftp, reqid, 3, err.message); }
    fsp.unlink(abs).then(() => sftp.status(reqid, 0)).catch((err) => fail(sftp, reqid, err.code === 'ENOENT' ? 2 : 4, err.message));
  });

  on('RENAME', (reqid, from, to) => {
    let a; let b;
    try { a = resolvePath(from); b = resolvePath(to); } catch (err) { return fail(sftp, reqid, 3, err.message); }
    if (fs.existsSync(b)) return fail(sftp, reqid, 4, 'target already exists');
    fsp.rename(a, b).then(() => sftp.status(reqid, 0)).catch((err) => fail(sftp, reqid, 4, err.message));
  });

  const setstat = (reqid, abs, attrs) => {
    const jobs = [];
    if (attrs && attrs.mtime) jobs.push(fsp.utimes(abs, new Date(), new Date(attrs.mtime * 1000)));
    if (attrs && attrs.mode) jobs.push(fsp.chmod(abs, attrs.mode & 0o777));
    if (!jobs.length) return sftp.status(reqid, 0);
    Promise.all(jobs).then(() => sftp.status(reqid, 0)).catch((err) => fail(sftp, reqid, 4, err.message));
  };

  on('SETSTAT', (reqid, givenPath, attrs) => {
    let abs;
    try { abs = resolvePath(givenPath); } catch (err) { return fail(sftp, reqid, 3, err.message); }
    setstat(reqid, abs, attrs);
  });

  on('FSETSTAT', (reqid, handle, attrs) => {
    const h = handles.get(key(handle));
    if (!h || !h.path) return fail(sftp, reqid, 4, 'invalid handle');
    setstat(reqid, h.path, attrs);
  });

  sftp.on('end', () => {
    for (const [, h] of handles) { if (h.fh) { h.fh.close().catch(() => {}); } }
    handles.clear();
  });

  logger.info('sftp', `SFTP session open for ${auth.user.username} on ${auth.server.name}`);
}

exports.authenticate = authenticate;
exports.attachSftp = attachSftp;
exports.state = state;
exports.formatBytes = formatBytes;
