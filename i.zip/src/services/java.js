'use strict';
/**
 * Java runtime manager.
 * Detects what is already on the machine and can fetch Temurin (Adoptium)
 * JREs into data/java/jre-<major> so a fresh box needs no manual setup.
 */
const path = require('path');
const fs = require('fs');
const fsp = require('fs/promises');
const os = require('os');

const cfg = require('../config');
const logger = require('../logger');
const { download, exists, formatBytes, ensureDir } = require('../utils');
const { execFileP } = require('./versions');

function osSlug() {
  switch (process.platform) {
    case 'linux': return 'linux';
    case 'darwin': return 'mac';
    case 'win32': return 'windows';
    default: return 'linux';
  }
}
function archSlug() {
  switch (process.arch) {
    case 'x64': return 'x64';
    case 'arm64': return 'aarch64';
    case 'arm': return 'arm';
    default: return 'x64';
  }
}
function ext() { return process.platform === 'win32' ? 'zip' : 'tar.gz'; }

async function versionOf(bin) {
  const res = await execFileP(bin, ['-version']);
  const text = `${res.stdout}\n${res.stderr}`;
  const m = text.match(/version "?(\d+)(?:\.(\d+))?/);
  if (!m) return null;
  const major = parseInt(m[1], 10);
  return { major: major === 1 ? parseInt(m[2] || '0', 10) : major, raw: text.split('\n')[0].trim() };
}

/** All JVMs the panel can see. */
async function list() {
  const found = [];
  const managedRoot = cfg.javaDir;
  const managed = fs.existsSync(managedRoot) ? fs.readdirSync(managedRoot, { withFileTypes: true }).filter((d) => d.isDirectory()) : [];
  for (const dir of managed) {
    const bin = path.join(managedRoot, dir.name, 'bin', process.platform === 'win32' ? 'java.exe' : 'java');
    if (fs.existsSync(bin)) {
      const v = await versionOf(bin);
      found.push({ path: bin, managed: true, label: `Temurin ${v ? `Java ${v.major}` : dir.name} (managed)`, ...(v || {}) });
    }
  }
  const candidates = new Set();
  if (process.env.JAVA_HOME) candidates.add(path.join(process.env.JAVA_HOME, 'bin', process.platform === 'win32' ? 'java.exe' : 'java'));
  candidates.add(cfg.javaBin || 'java');
  for (const base of ['/usr/lib/jvm', '/usr/java', '/opt/java', '/Library/Java/JavaVirtualMachines']) {
    try {
      for (const dir of fs.readdirSync(base)) {
        candidates.add(path.join(base, dir, 'bin', 'java'));
        candidates.add(path.join(base, dir, 'Contents', 'Home', 'bin', 'java'));
      }
    } catch (_) {}
  }
  for (const bin of candidates) {
    try {
      const v = await versionOf(bin);
      if (!v) continue;
      if (found.some((f) => f.path === bin)) continue;
      found.push({ path: bin, managed: false, label: `System Java ${v.major}`, ...v });
    } catch (_) {}
  }
  found.sort((a, b) => (b.major || 0) - (a.major || 0));
  return found;
}
exports.list = list;
exports.versionOf = versionOf;

async function managedPath(major) {
  const bin = path.join(cfg.javaDir, `jre-${major}`, 'bin', process.platform === 'win32' ? 'java.exe' : 'java');
  return (await exists(bin)) ? bin : null;
}
exports.managedPath = managedPath;

/**
 * Ensure a JRE for the given major version exists locally.
 * Returns the java binary path.
 */
async function ensure(major, onProgress = () => {}) {
  const already = await managedPath(major);
  if (already) return already;

  const installed = await list();
  const usable = installed.find((j) => (j.major || 0) === Number(major));
  if (usable && !cfg.settings?.installJavaAutomatically) return usable.path;

  const url = `https://api.adoptium.net/v3/binary/latest/${major}/ga/${osSlug()}/${archSlug()}/jre/hotspot/normal/eclipse`;
  const archive = path.join(cfg.dataDir, 'tmp', `temurin-${major}.${ext()}`);
  await ensureDir(path.dirname(archive));
  logger.info('java', `Downloading Temurin JRE ${major} for ${osSlug()}/${archSlug()}`);
  await download(url, archive, { onProgress });
  onProgress({ percent: 100, received: 0, total: 0 });

  const target = path.join(cfg.javaDir, `jre-${major}`);
  await fsp.rm(target, { recursive: true, force: true });
  await ensureDir(target);

  if (ext() === 'zip') {
    const AdmZip = require('adm-zip');
    new AdmZip(archive).extractAllTo(target, true);
  } else {
    const res = await execFileP('tar', ['-xzf', archive, '-C', target]);
    if (!res.ok) throw new Error(`Failed to extract Java: ${res.stderr || res.error}`);
  }
  // JDK tarballs contain a single nested folder - flatten it
  const entries = await fsp.readdir(target);
  if (entries.length === 1) {
    const nested = path.join(target, entries[0]);
    if ((await fsp.stat(nested)).isDirectory() && fs.existsSync(path.join(nested, 'bin'))) {
      for (const item of await fsp.readdir(nested)) {
        await fsp.rename(path.join(nested, item), path.join(target, item));
      }
      await fsp.rm(nested, { recursive: true, force: true });
    }
  }
  const archiveSize = (await fsp.stat(archive).catch(() => ({ size: 0 }))).size;
  await fsp.unlink(archive).catch(() => {});
  const bin = path.join(target, 'bin', process.platform === 'win32' ? 'java.exe' : 'java');
  if (!(await exists(bin))) throw new Error('Java extraction produced no binary');
  await fsp.chmod(bin, 0o755).catch(() => {});
  logger.ok('java', `Java ${major} installed at ${bin} (${formatBytes(archiveSize)})`);
  onProgress({ percent: 100, note: `Java ${major} installed` });
  return bin;
}
exports.ensure = ensure;

exports.info = async () => ({ platform: process.platform, arch: process.arch, host: os.hostname(), available: await list() });
