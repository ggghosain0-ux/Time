'use strict';
/**
 * World manager.
 *
 * A "world" is a directory inside the server directory that contains a
 * `level.dat` (that is what Minecraft writes). Everything here is real file
 * system work - detection, sizing, activation through server.properties,
 * zip export (adm-zip) and zip import - with the usual `safeJoin` guard so a
 * crafted world name can never escape the server directory.
 */
const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const AdmZip = require('adm-zip');
const cfg = require('../config');
const logger = require('../logger');
const files = require('./files');
const { safeJoin, formatBytes, sleep } = require('../utils');

const WORLD_NAME_RE = /^[A-Za-z0-9._-]{1,48}$/;
const SKIP_DIRS = new Set(['plugins', 'mods', 'config', 'libraries', 'versions', 'logs', 'cache', 'crash-reports', 'logs', 'backups', 'mods', '.fabric', '.paper-remapped']);

function root(server) {
  return path.join(cfg.serverDataDir, server.id);
}

function worldPath(server, name) {
  if (!WORLD_NAME_RE.test(String(name || ''))) throw new Error('Invalid world name (letters, digits, dot, dash and underscore only)');
  const p = safeJoin(root(server), name);
  return p;
}

function dirSize(dir) {
  let total = 0;
  const walk = (d) => {
    let items = [];
    try { items = fs.readdirSync(d, { withFileTypes: true }); } catch { return; }
    for (const item of items) {
      const full = path.join(d, item.name);
      if (item.isDirectory()) walk(full);
      else if (item.isFile()) { try { total += fs.statSync(full).size; } catch { /* raced */ } }
    }
  };
  walk(dir);
  return total;
}

function countFiles(dir) {
  let files_ = 0;
  let regions = 0;
  const walk = (d) => {
    let items = [];
    try { items = fs.readdirSync(d, { withFileTypes: true }); } catch { return; }
    for (const item of items) {
      const full = path.join(d, item.name);
      if (item.isDirectory()) walk(full);
      else if (item.isFile()) {
        files_ += 1;
        if (/\.mca$/i.test(item.name)) regions += 1;
      }
    }
  };
  walk(dir);
  return { files: files_, regions };
}

/** Read `level-name` from server.properties (the world the JVM will load). */
async function activeWorld(server) {
  try {
    const { content } = await files.read(server, 'server.properties');
    const match = content.match(/^level-name=(.*)$/m);
    return match ? match[1].trim() : 'world';
  } catch (_) {
    return 'world';
  }
}

/**
 * Every detected world on disk with its real size, file count and timestamp.
 * @returns {Promise<{worlds: object[], active: string, directory: string}>}
 */
async function list(server) {
  const dir = root(server);
  const active = await activeWorld(server);
  let entries = [];
  try { entries = await fsp.readdir(dir, { withFileTypes: true }); } catch (err) {
    if (err.code === 'ENOENT') return { worlds: [], active, directory: dir, exists: false };
    throw err;
  }
  const worlds = [];
  for (const entry of entries) {
    if (!entry.isDirectory() || entry.name.startsWith('.') || SKIP_DIRS.has(entry.name)) continue;
    const full = path.join(dir, entry.name);
    if (!fs.existsSync(path.join(full, 'level.dat'))) continue;
    let stat = { size: 0, mtime: null };
    try { stat = fs.statSync(path.join(full, 'level.dat')); } catch (_) { /* gone */ }
    let meta = null;
    try {
      // level.dat is gzipped NBT - the human-readable bits live in the header
      const buf = fs.readFileSync(path.join(full, 'level.dat')).subarray(0, 64);
      const zlib = require('zlib');
      const raw = zlib.gunzipSync(fs.readFileSync(path.join(full, 'level.dat')));
      const text = raw.toString('latin1');
      const p = (key) => {
        const idx = text.indexOf(key);
        if (idx < 0) return null;
        const chunk = text.slice(idx + key.length, idx + key.length + 64);
        const m = chunk.match(/[\x20-\x7e]{3,32}/);
        return m ? m[0].replace(/[^\x20-\x7e]/g, '').trim() : null;
      };
      meta = { version: p('version') ? null : null, gameVersion: p('Version') };
      void buf;
    } catch (_) { meta = null; }
    const counts = countFiles(full);
    worlds.push({
      name: entry.name,
      active: entry.name === active,
      bytes: dirSize(full),
      prettyBytes: formatBytes(dirSize(full)),
      files: counts.files,
      regions: counts.regions,
      lastPlayed: stat.mtime ? stat.mtime.toISOString() : null,
      path: path.join(server.id, entry.name),
    });
  }
  worlds.sort((a, b) => (b.active ? 1 : 0) - (a.active ? 1 : 0) || new Date(b.lastPlayed || 0) - new Date(a.lastPlayed || 0));
  return { worlds, active, directory: dir, exists: true };
}
exports.list = list;

/** Point `level-name` at another world (takes effect on the next start). */
async function activate(server, name) {
  const target = worldPath(server, name);
  if (!fs.existsSync(path.join(target, 'level.dat'))) throw new Error(`World "${name}" does not exist on disk`);
  let content;
  try { ({ content } = await files.read(server, 'server.properties')); } catch (_) { content = 'level-name=world\n'; }
  const line = `level-name=${name}`;
  content = /^level-name=/m.test(content)
    ? content.replace(/^level-name=.*$/m, line)
    : `${content.replace(/\s*$/, '\n')}${line}\n`;
  await files.write(server, 'server.properties', content);
  logger.ok('worlds', `${server.name}: active world -> ${name}`);
  return { active: name };
}
exports.activate = activate;

/** Zip a world and stream it back (export). */
async function exportTo(server, name, res) {
  const target = worldPath(server, name);
  if (!fs.existsSync(path.join(target, 'level.dat'))) throw new Error(`World "${name}" does not exist on disk`);
  const zip = new AdmZip();
  zip.addLocalFolder(target, name);
  const buffer = zip.toBuffer();
  const filename = `${server.id}-${name}-${new Date().toISOString().slice(0, 10)}.zip`;
  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
  res.setHeader('Content-Length', String(buffer.length));
  res.end(buffer);
}
exports.exportTo = exportTo;

/**
 * Import a world from an uploaded zip/paste:
 *   * validates the zip really contains a level.dat (peeking one level deep),
 *   * refuses path traversal entries,
 *   * extracts into a new directory and reports what landed on disk.
 */
async function importZip(server, tempPath, { name } = {}) {
  const zip = new AdmZip(tempPath);
  const entries = zip.getEntries();
  if (!entries.length) throw new Error('The archive is empty');
  const evil = entries.find((e) => e.entryName.includes('..') || path.isAbsolute(e.entryName));
  if (evil) throw new Error(`Refusing to extract "${evil.entryName}": the archive contains an unsafe path`);

  // the world root is the folder that holds level.dat
  const levelEntry = entries.find((e) => /(^|\/)level\.dat$/.test(e.entryName));
  if (!levelEntry) throw new Error('No level.dat inside the archive - that is not a Minecraft world');
  const prefix = levelEntry.entryName.replace(/level\.dat$/, ''); // '' or 'world/'

  let target = name || (prefix ? prefix.replace(/\/$/, '').split('/').pop() : 'world');
  target = String(target).replace(/[^\w.-]/g, '_').slice(0, 48) || 'world';
  if (target === 'world' || target === 'world_nether' || target === 'world_the_end') target = `${target}_imported`;
  let candidate = target;
  let n = 2;
  while (fs.existsSync(worldPath(server, candidate))) { candidate = `${target}-${n}`; n += 1; }
  const dest = worldPath(server, candidate);
  await fsp.mkdir(dest, { recursive: true });

  for (const entry of entries) {
    if (entry.isDirectory) continue;
    if (prefix && !entry.entryName.startsWith(prefix)) continue;
    const rel = prefix ? entry.entryName.slice(prefix.length) : entry.entryName;
    if (!rel) continue;
    const out = safeJoin(dest, rel);
    await fsp.mkdir(path.dirname(out), { recursive: true });
    await fsp.writeFile(out, entry.getData());
  }
  if (!fs.existsSync(path.join(dest, 'level.dat'))) throw new Error('Extraction finished but level.dat is missing');
  logger.ok('worlds', `${server.name}: imported world ${candidate} (${formatBytes(dirSize(dest))})`);
  return { name: candidate, bytes: dirSize(dest), prettyBytes: formatBytes(dirSize(dest)) };
}
exports.importZip = importZip;

/** Delete a world directory (never the active one). */
async function remove(server, name) {
  const target = worldPath(server, name);
  const active = await activeWorld(server);
  if (name === active) {
    const check = await list(server);
    const others = check.worlds.filter((w) => !w.active);
    throw new Error(`"${name}" is the active world (level-name) - activate another world (${others.map((o) => o.name).join(', ') || 'import or create one first'}) before deleting it`);
  }
  if (!fs.existsSync(target)) throw new Error(`World "${name}" does not exist on disk`);
  const bytes = dirSize(target);
  await fsp.rm(target, { recursive: true, force: true });
  // a leftover marker (level-name.dat / level-name_nether) is fine to drop too
  for (const suffix of ['_nether', '_the_end']) {
    const extra = safeJoin(root(server), `${name}${suffix}`);
    if (fs.existsSync(extra)) await fsp.rm(extra, { recursive: true, force: true });
  }
  logger.warn('worlds', `${server.name}: deleted world ${name} (${formatBytes(bytes)})`);
  return { name, bytes };
}
exports.remove = remove;

/** Copy a world inside the server dir (a cheap "duplicate" for experiments). */
async function duplicate(server, name) {
  const src = worldPath(server, name);
  if (!fs.existsSync(path.join(src, 'level.dat'))) throw new Error(`World "${name}" does not exist on disk`);
  let candidate = `${name}-copy`;
  let n = 2;
  while (fs.existsSync(worldPath(server, candidate))) { candidate = `${name}-copy-${n}`; n += 1; }
  await fsp.cp(src, worldPath(server, candidate), { recursive: true, errorOnExist: true });
  await sleep(50);
  return { name: candidate, prettyBytes: formatBytes(dirSize(worldPath(server, candidate))) };
}
exports.duplicate = duplicate;
exports.WORLD_NAME_RE = WORLD_NAME_RE;
