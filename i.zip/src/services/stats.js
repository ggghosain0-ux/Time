'use strict';
/**
 * Resource sampling.
 *
 * Linux: parsed straight from /proc (no native deps, works inside containers).
 * Other platforms: falls back to `ps` and os.freemem().
 */
const fs = require('fs');
const os = require('os');
const { execFile } = require('child_process');

const IS_LINUX = process.platform === 'linux';
const CLK_TCK = 100; // Linux USER_HZ
const PAGES = 4096;

const prev = new Map(); // pid -> { cpuTicks, at }

function readProcStat(pid) {
  try {
    const raw = fs.readFileSync(`/proc/${pid}/stat`, 'utf8');
    const close = raw.lastIndexOf(')');
    const fields = raw.slice(close + 2).split(' ');
    // after comm: state=0 ppid=1 ... utime=11 stime=12 rss=21
    return {
      ppid: parseInt(fields[1], 10),
      utime: parseInt(fields[11], 10),
      stime: parseInt(fields[12], 10),
      rssPages: parseInt(fields[21], 10),
    };
  } catch { return null; }
}

function allPids() {
  try { return fs.readdirSync('/proc').filter((f) => /^\d+$/.test(f)).map(Number); } catch { return []; }
}

/** Collect pid + all descendants. */
function processTreePids(rootPid) {
  const parents = new Map();
  for (const pid of allPids()) {
    const stat = readProcStat(pid);
    if (!stat) continue;
    if (!parents.has(stat.ppid)) parents.set(stat.ppid, []);
    parents.get(stat.ppid).push(pid);
  }
  const out = [];
  const stack = [rootPid];
  while (stack.length) {
    const pid = stack.pop();
    out.push(pid);
    for (const child of parents.get(pid) || []) stack.push(child);
  }
  return out;
}

/**
 * CPU% + RSS for a process and its children.
 * CPU is normalised against one core (a Minecraft server saturating 1 core = 100%).
 */
async function processTree(pid) {
  if (!pid) return { cpu: 0, rss: 0, processes: 0 };
  if (!IS_LINUX) return psFallback(pid);

  const pids = processTreePids(pid);
  let cpuTicks = 0;
  let rssBytes = 0;
  for (const p of pids) {
    const stat = readProcStat(p);
    if (!stat) continue;
    cpuTicks += stat.utime + stat.stime;
    rssBytes += stat.rssPages * PAGES;
  }
  const now = Date.now();
  const last = prev.get(pid);
  prev.set(pid, { cpuTicks, at: now });

  let cpu = 0;
  if (last && now > last.at) {
    const deltaTicks = cpuTicks - last.cpuTicks;
    const deltaSec = (now - last.at) / 1000;
    cpu = (deltaTicks / CLK_TCK / deltaSec) * 100;
  }
  if (cpu < 0 || !Number.isFinite(cpu)) cpu = 0;
  return { cpu: Math.min(cpu, 100 * os.cpus().length * 4), rss: rssBytes, processes: pids.length };
}

function psFallback(pid) {
  return new Promise((resolve) => {
    execFile('ps', ['-o', 'rss=', '-o', 'pcpu=', '-p', String(pid)], (err, stdout) => {
      if (err) return resolve({ cpu: 0, rss: 0, processes: 0 });
      const [rss, pcpu] = String(stdout).trim().split(/\s+/).map(Number);
      resolve({ cpu: pcpu || 0, rss: (rss || 0) * 1024, processes: 1 });
    });
  });
}

/** Host-wide metrics for the dashboard. */
async function system() {
  const cpus = os.cpus();
  const load = os.loadavg();
  const totalMem = os.totalmem();
  const freeMem = os.freemem();

  // CPU% from /proc/stat deltas on Linux, loadavg otherwise
  let cpuPercent = 0;
  if (IS_LINUX) {
    try {
      const line = fs.readFileSync('/proc/stat', 'utf8').split('\n')[0].split(/\s+/).slice(1).map(Number);
      const idle = line[3] + (line[4] || 0);
      const total = line.reduce((a, b) => a + b, 0);
      const last = prev.get('__sys__');
      prev.set('__sys__', { idle, total });
      if (last) {
        const dTotal = total - last.total;
        const dIdle = idle - last.idle;
        cpuPercent = dTotal > 0 ? ((dTotal - dIdle) / dTotal) * 100 : 0;
      }
    } catch (_) {}
  } else {
    cpuPercent = Math.min(100, (load[0] / cpus.length) * 100);
  }

  let disk = null;
  try {
    const st = fs.statfsSync ? fs.statfsSync(require('../config').dataDir) : null;
    if (st) disk = { total: st.blocks * st.bsize, free: st.bfree * st.bsize, used: (st.blocks - st.bfree) * st.bsize };
  } catch (_) {}

  return {
    cpu: Number(cpuPercent.toFixed(1)),
    cores: cpus.length,
    cpuModel: (cpus[0] && cpus[0].model) || 'unknown',
    load: { '1m': Number(load[0].toFixed(2)), '5m': Number(load[1].toFixed(2)), '15m': Number(load[2].toFixed(2)) },
    memory: { total: totalMem, used: totalMem - freeMem, free: freeMem, percent: Number((((totalMem - freeMem) / totalMem) * 100).toFixed(1)) },
    disk,
    uptime: os.uptime(),
    platform: `${os.type()} ${os.release()}`,
    arch: os.arch(),
    hostname: os.hostname(),
    node: process.version,
    panelUptime: process.uptime(),
    memoryOfPanel: process.memoryUsage().rss,
  };
}

module.exports = { processTree, system, CLK_TCK };
