'use strict';
/**
 * Tiny dependency-free JSON database.
 * Whole DB lives in data/db.json, written atomically with a debounce.
 * Good for a self-hosted panel (thousands of servers) and zero setup.
 */
const path = require('path');
const cfg = require('./config');
const { writeJson, readJson, ensureDir } = require('./utils');

const FILE = path.join(cfg.dataDir, 'db.json');

const DEFAULTS = {
  users: [],
  servers: [],
  nodes: [],
  apiKeys: [],
  activity: [],
  settings: {
    panelName: cfg.panelName,
    allowRegistration: cfg.allowRegistration,
    defaultJava: cfg.javaBin,
    defaultMemory: 2048,
    defaultPort: 25565,
    maxServersPerUser: 5,
    theme: 'dark',
    installJavaAutomatically: true,
    autoRestartOnCrash: false,
  },
};

let data = structuredClone(DEFAULTS);
let dirty = false;
let timer = null;

function load() {
  const disk = require('fs').existsSync(FILE) ? readJsonSync(FILE) : null;
  if (disk && typeof disk === 'object') {
    data = { ...structuredClone(DEFAULTS), ...disk };
    for (const key of Object.keys(DEFAULTS)) {
      if (data[key] === undefined || data[key] === null) data[key] = structuredClone(DEFAULTS[key]);
    }
    data.settings = { ...DEFAULTS.settings, ...(disk.settings || {}) };
  }
  return data;
}

function readJsonSync(file) {
  try { return JSON.parse(require('fs').readFileSync(file, 'utf8')); } catch { return null; }
}

function scheduleFlush() {
  dirty = true;
  if (timer) return;
  timer = setTimeout(async () => {
    timer = null;
    if (!dirty) return;
    dirty = false;
    try {
      await ensureDir(path.dirname(FILE));
      await writeJson(FILE, data);
    } catch (err) {
      console.error('[db] flush failed:', err.message);
    }
  }, 250);
}

async function flush() {
  if (timer) { clearTimeout(timer); timer = null; }
  dirty = false;
  await ensureDir(path.dirname(FILE));
  await writeJson(FILE, data);
}

const db = {
  load,
  flush,
  /** raw collection accessor */
  get(key) { return data[key]; },
  set(key, value) { data[key] = value; scheduleFlush(); return value; },

  /* ------- generic helpers ------- */
  find(key, predicate) { return (data[key] || []).find(predicate); },
  filter(key, predicate) { return (data[key] || []).filter(predicate); },
  insert(key, doc) { (data[key] = data[key] || []).push(doc); scheduleFlush(); return doc; },
  update(key, id, patch) {
    const list = data[key] || [];
    const i = list.findIndex((d) => d.id === id);
    if (i === -1) return null;
    list[i] = { ...list[i], ...patch };
    scheduleFlush();
    return list[i];
  },
  remove(key, id) {
    const list = data[key] || [];
    const i = list.findIndex((d) => d.id === id);
    if (i === -1) return null;
    const [doc] = list.splice(i, 1);
    scheduleFlush();
    return doc;
  },
  settings() { return data.settings; },
  setSettings(patch) { data.settings = { ...data.settings, ...patch }; scheduleFlush(); return data.settings; },

  /** activity log, capped at 500 entries */
  log(entry) {
    data.activity.unshift({ id: `act_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`, at: new Date().toISOString(), ...entry });
    if (data.activity.length > 500) data.activity.length = 500;
    scheduleFlush();
  },
};

module.exports = db;
