#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
if [[ ${EUID:-$(id -u)} -ne 0 ]]; then exec sudo -E bash "$0" "$@"; fi
export DEBIAN_FRONTEND=noninteractive
log(){ printf '\n==> %s\n' "$*"; }
trap 'echo "INSTALL FAILED at line $LINENO" >&2' ERR

log 'Installing host dependencies'
apt-get update
apt-get install -y ca-certificates curl docker.io python3 python3-venv python3-pip
systemctl enable --now docker

docker info >/dev/null 2>&1 || { echo 'Docker daemon is unavailable. Start Docker and run this installer again.' >&2; exit 1; }

log 'Preparing configuration'
if [[ ! -f .env ]]; then
  cp .env.example .env
  python3 - <<'PYSETENV'
from pathlib import Path
import secrets
p=Path('.env')
s=p.read_text().replace('SKVM_SECRET_KEY=CHANGE_ME','SKVM_SECRET_KEY='+secrets.token_hex(32))
p.write_text(s)
PYSETENV
fi
chmod 600 .env

log 'Preparing Python environment'
if [[ ! -x .venv/bin/python ]] || ! .venv/bin/python -m pip --version >/dev/null 2>&1; then rm -rf .venv; fi
python3 -m venv .venv
.venv/bin/python -m ensurepip --upgrade >/dev/null 2>&1 || true
.venv/bin/python -m pip install --upgrade pip setuptools wheel
.venv/bin/python -m pip install -r requirements.txt

log 'Building local guest images'
for spec in "ubuntu22:docker/Dockerfile.ubuntu22" "ubuntu24:docker/Dockerfile.ubuntu24" "debian12:docker/Dockerfile.debian12"; do
  tag="${spec%%:*}"; file="${spec#*:}"
  docker build --pull -t "skvm/${tag}:latest" -f "$file" docker
  docker image inspect "skvm/${tag}:latest" >/dev/null
  echo "Built skvm/${tag}:latest"
done

log 'Initializing database'
.venv/bin/python -c 'import app; print("Database ready")'

log 'Installing systemd service'
sed "s#__SKVM_DIR__#$PWD#g" systemd/skvm.service > /etc/systemd/system/skvm.service
systemctl daemon-reload
systemctl enable --now skvm
sleep 2
if ! systemctl is-active --quiet skvm; then
  journalctl -u skvm -n 100 --no-pager || true
  exit 1
fi

log 'SKVM installed successfully'
echo "Panel: http://SERVER_IP:${SKVM_PORT:-5555}"
echo 'Default admin: admin / admin123'
echo 'IMPORTANT: change the admin password after first login.'
echo "SSH host-port range: ${SKVM_SSH_PORT_START:-10000}-${SKVM_SSH_PORT_END:-20000}"
