#!/usr/bin/env bash
set -euo pipefail
sudo apt-get update
sudo apt-get install -y ca-certificates curl python3 python3-venv python3-pip docker.io
sudo systemctl enable --now docker || true
if ! sudo docker image inspect skvm/ubuntu22-tmate:latest >/dev/null 2>&1; then
  sudo docker build -t skvm/ubuntu22-tmate:latest -f Dockerfile.ubuntu22 .
fi
python3 -m venv .venv
. .venv/bin/activate
pip install -U pip
pip install -r requirements.txt
[ -f .env ] || cp .env.example .env
echo "SKVM v6 installed. Start with: sudo -E .venv/bin/python app.py"
