#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export DEBIAN_FRONTEND=noninteractive

echo "[SKVM] Installing host dependencies..."
if command -v apt-get >/dev/null 2>&1; then
  sudo apt-get update -y
  sudo apt-get install -y python3 python3-venv python3-pip qemu-system-x86 qemu-utils cloud-image-utils curl sshpass iproute2
else
  echo "This installer currently requires Debian/Ubuntu (apt-get)." >&2
  exit 1
fi

python3 -m venv .venv
. .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

# Generate a persistent secret once.
if [ ! -f .env ]; then
  SECRET="$(python3 -c 'import secrets; print(secrets.token_hex(32))')"
  cat > .env <<EOF
SKVM_SECRET_KEY=$SECRET
SKVM_HOST=0.0.0.0
SKVM_PORT=5555
SKVM_ADMIN_PASSWORD=admin123
EOF
  chmod 600 .env
fi

# systemd service (when systemd is available).
if command -v systemctl >/dev/null 2>&1 && [ "$(id -u)" = 0 ]; then
  cat > /etc/systemd/system/skvm.service <<EOF
[Unit]
Description=SKVM VPS Panel
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=$PWD
EnvironmentFile=$PWD/.env
ExecStart=$PWD/.venv/bin/python $PWD/skvm.py
Restart=always
RestartSec=3
User=root

[Install]
WantedBy=multi-user.target
EOF
  systemctl daemon-reload
  systemctl enable --now skvm
  echo "[SKVM] Service started."
else
  echo "[SKVM] systemd unavailable or installer is not root; run: .venv/bin/python skvm.py"
fi

echo
echo "SKVM installed."
echo "Login: admin / admin123"
echo "Panel: http://SERVER-IP:5555"
