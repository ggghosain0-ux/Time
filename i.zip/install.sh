#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_USER="${SUDO_USER:-${USER}}"
APP_HOME="$(getent passwd "$APP_USER" | cut -d: -f6)"
VENV="$APP_DIR/venv"

echo "[1/7] Installing OS packages..."
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y python3 python3-venv python3-pip python3-dev build-essential ca-certificates curl docker.io

echo "[2/7] Starting Docker..."
systemctl enable --now docker
usermod -aG docker "$APP_USER" || true

echo "[3/7] Creating Python environment..."
python3 -m venv "$VENV"
"$VENV/bin/pip" install --upgrade pip wheel
"$VENV/bin/pip" install -r "$APP_DIR/requirements.txt"

echo "[4/7] Creating secure environment..."
if [[ ! -f "$APP_DIR/.env" ]]; then
  SECRET="$(python3 -c 'import secrets; print(secrets.token_hex(32))')"
  cat > "$APP_DIR/.env" <<EOF
SKVM_SECRET_KEY=$SECRET
SKVM_PORT=5555
SKVM_ADMIN_USERNAME=admin
SKVM_ADMIN_PASSWORD=admin123
SKVM_TUNNEL_TIMEOUT=300
SKVM_DOCKER_NETWORK=bridge
SKVM_TUNNEL_IMAGE=ubuntu:22.04
SKVM_DEBUG=0
EOF
fi
chmod 600 "$APP_DIR/.env"
chown -R "$APP_USER":"$APP_USER" "$APP_DIR"

echo "[5/7] Installing systemd service..."
cat > /etc/systemd/system/skvm.service <<EOF
[Unit]
Description=SKVM VPS Management Panel
After=docker.service network-online.target
Requires=docker.service
Wants=network-online.target

[Service]
Type=simple
User=$APP_USER
WorkingDirectory=$APP_DIR
EnvironmentFile=$APP_DIR/.env
ExecStart=$VENV/bin/gunicorn --bind 0.0.0.0:5555 --workers 1 --threads 8 --timeout 3600 skvm:app
Restart=always
RestartSec=5
NoNewPrivileges=false

[Install]
WantedBy=multi-user.target
EOF

echo "[6/7] Opening firewall port..."
if command -v ufw >/dev/null 2>&1; then
  ufw allow 5555/tcp || true
fi

echo "[7/7] Starting SKVM..."
systemctl daemon-reload
systemctl enable --now skvm

echo
echo "SKVM is running."
echo "Panel: http://$(hostname -I | awk '{print $1}'):5555"
echo "Admin username: admin"
echo "Admin password: admin123"
echo
systemctl --no-pager --full status skvm | head -25
