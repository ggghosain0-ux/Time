#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if [[ $EUID -ne 0 ]]; then exec sudo -E bash "$0" "$@"; fi
export DEBIAN_FRONTEND=noninteractive

echo '[1/7] Installing host dependencies...'
apt-get update
apt-get install -y ca-certificates curl docker.io python3 python3-venv python3-pip
systemctl enable --now docker

if ! docker info >/dev/null 2>&1; then
  echo 'ERROR: Docker daemon is not available.' >&2
  exit 1
fi

echo '[2/7] Preparing environment...'
if [[ ! -f .env ]]; then
  cp .env.example .env
  SECRET=$(python3 - <<'PY'
import secrets
print(secrets.token_hex(32))
PY
)
  sed -i "s/^SKVM_SECRET_KEY=.*/SKVM_SECRET_KEY=$SECRET/" .env
fi
chmod 600 .env

if [[ ! -d .venv ]]; then python3 -m venv .venv; fi
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements.txt

# Keep the image local: no Docker Hub repository called skvm/ubuntu22-tmate is required.
echo '[3/7] Building SKVM guest image locally...'
docker build -t skvm/ubuntu22:latest -f docker/Dockerfile.ubuntu22 docker
docker build -t skvm/ubuntu24:latest -f docker/Dockerfile.ubuntu24 docker
docker build -t skvm/debian12:latest -f docker/Dockerfile.debian12 docker

echo '[4/7] Initializing database...'
set -a; source .env; set +a
.venv/bin/python - <<'PY'
import app
print('Database initialized.')
PY

echo '[5/7] Installing systemd service...'
sed "s#__SKVM_DIR__#$PWD#g" systemd/skvm.service > /etc/systemd/system/skvm.service
systemctl daemon-reload
systemctl enable skvm

# The service runs as root because Docker socket access is equivalent to root on the host.
echo '[6/7] Starting SKVM...'
systemctl restart skvm
sleep 2

if systemctl is-active --quiet skvm; then
  echo '[7/7] SKVM is running.'
  echo 'Panel: http://SERVER_IP:5555'
  echo 'Default admin: admin / admin123'
else
  echo 'SKVM failed to start. Logs:' >&2
  journalctl -u skvm -n 80 --no-pager >&2 || true
  exit 1
fi
