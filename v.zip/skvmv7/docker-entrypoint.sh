#!/bin/bash
set -e
PASS="${SKVM_ROOT_PASSWORD:-admin123}"
HOSTNAME_VALUE="${SKVM_HOSTNAME:-skvm-vps}"
hostname "$HOSTNAME_VALUE" 2>/dev/null || true
printf 'root:%s\n' "$PASS" | chpasswd
mkdir -p /run/sshd
cat >/etc/ssh/sshd_config.d/99-skvm.conf <<CFG
PermitRootLogin yes
PasswordAuthentication yes
KbdInteractiveAuthentication no
UsePAM yes
CFG
/usr/sbin/sshd
# Keep the guest alive. tmate is started by SKVM after SSH becomes reachable.
exec tail -f /dev/null
