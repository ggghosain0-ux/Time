# SKVM v7

A Docker-based VPS control panel rebuilt from the supplied Nissal VMS panel concept. It focuses on reliable lifecycle operations instead of coupling VPS creation to tmate relay registration.

## Features
- Admin and user authentication
- VPS creation with Ubuntu 22.04 / 24.04 / Debian 12 labels
- Docker-backed VPS containers
- Start / Stop / Restart / Delete
- Reprovision after a failed container
- Automatic SSH port allocation
- Per-VPS random root password
- Background, best-effort tmate registration
- Notifications and audit log
- User management and roles
- Profile/password change
- Health endpoint
- systemd auto-start/restart
- Local guest image build; no nonexistent `skvm/ubuntu22-tmate` image is pulled

## Install
```bash
unzip skvmv7.zip
cd skvmv7
chmod +x install.sh
./install.sh
```

Then open `http://SERVER_IP:5555`.

Default admin: `admin` / `admin123`.
Change it from the profile page or `.env` before production use.

## Logs
```bash
sudo systemctl status skvm
sudo journalctl -u skvm -f
```

## Health
```bash
curl http://127.0.0.1:5555/healthz
```

## Important networking note
A VPS must have a host/network environment that supports Docker and exposes the allocated SSH ports. CodeSandbox can be useful for development, but it is not a reliable production hypervisor. For production, use a real Linux server with Docker and firewall rules permitting the SSH port range (default 10000+).

## Disk quota
The UI records the requested disk size, but Docker's default overlay storage does not guarantee a hard per-container disk quota on every filesystem. For strict customer disk limits, deploy on a filesystem/driver configured for project quotas or another storage backend that supports hard limits.
