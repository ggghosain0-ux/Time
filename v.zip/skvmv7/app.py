#!/usr/bin/env python3
import os, sqlite3, secrets, subprocess, threading, time, uuid, socket, logging, re
from pathlib import Path
from functools import wraps
from datetime import datetime

from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify, abort
from werkzeug.security import generate_password_hash, check_password_hash

try:
    import docker
except ImportError:
    docker = None

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
DATA.mkdir(exist_ok=True)
DB = DATA / "skvm.db"
ENV_FILE = BASE / ".env"


def load_env():
    if ENV_FILE.exists():
        for line in ENV_FILE.read_text().splitlines():
            line=line.strip()
            if not line or line.startswith('#') or '=' not in line: continue
            k,v=line.split('=',1); os.environ.setdefault(k, v)
load_env()

SECRET = os.getenv("SKVM_SECRET_KEY") or secrets.token_hex(32)
ADMIN_USER = os.getenv("SKVM_ADMIN_USERNAME", "admin")
ADMIN_PASS = os.getenv("SKVM_ADMIN_PASSWORD", "admin123")
HOST_IP = os.getenv("SKVM_HOST", "127.0.0.1")
PORT_START = int(os.getenv("SKVM_PORT_START", "10000"))
IMAGE = os.getenv("SKVM_IMAGE", "skvm/ubuntu22:latest")
IMAGE_MAP = {"ubuntu22":"skvm/ubuntu22:latest", "ubuntu24":"skvm/ubuntu24:latest", "debian12":"skvm/debian12:latest"}

app = Flask(__name__)
app.secret_key = SECRET
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")
if os.getenv("SKVM_HTTPS", "0") == "1":
    app.config["SESSION_COOKIE_SECURE"] = True

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("skvm")


def db():
    c=sqlite3.connect(DB, timeout=30, check_same_thread=False)
    c.row_factory=sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA foreign_keys=ON")
    return c


def init_db():
    c=db()
    c.executescript('''
    CREATE TABLE IF NOT EXISTS users(
      id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
      email TEXT UNIQUE NOT NULL, password TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'user',
      active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      last_login TEXT
    );
    CREATE TABLE IF NOT EXISTS vps(
      id INTEGER PRIMARY KEY AUTOINCREMENT, vps_id TEXT UNIQUE NOT NULL, user_id INTEGER NOT NULL,
      name TEXT NOT NULL, image TEXT NOT NULL, ram_mb INTEGER NOT NULL, cpu_cores INTEGER NOT NULL,
      disk_gb INTEGER NOT NULL, ssh_port INTEGER UNIQUE NOT NULL, ssh_password TEXT NOT NULL,
      container TEXT UNIQUE, status TEXT NOT NULL DEFAULT 'creating', error TEXT,
      tmate_ssh TEXT, tmate_web TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS audit(
      id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, action TEXT NOT NULL,
      details TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS notifications(
      id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, title TEXT NOT NULL,
      message TEXT NOT NULL, kind TEXT DEFAULT 'info', read INTEGER DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
    ''')
    admin=c.execute("SELECT id FROM users WHERE username=?",(ADMIN_USER,)).fetchone()
    if not admin:
        c.execute("INSERT INTO users(username,email,password,role) VALUES(?,?,?,'admin')",
                  (ADMIN_USER, os.getenv('SKVM_ADMIN_EMAIL','admin@skvm.local'), generate_password_hash(ADMIN_PASS, method='scrypt')))
    defaults={"site_name":"SKVM Panel","maintenance":"0"}
    for k,v in defaults.items(): c.execute("INSERT OR IGNORE INTO settings VALUES(?,?)",(k,v))
    c.commit(); c.close()

init_db()


def audit(action, details="", uid=None):
    try:
        c=db(); c.execute("INSERT INTO audit(user_id,action,details) VALUES(?,?,?)",(uid or session.get('user_id'),action,details)); c.commit(); c.close()
    except Exception: pass


def notify(uid,title,message,kind="info"):
    try:
        c=db(); c.execute("INSERT INTO notifications(user_id,title,message,kind) VALUES(?,?,?,?)",(uid,title,message,kind)); c.commit(); c.close()
    except Exception: pass


def csrf_token():
    if "csrf" not in session: session["csrf"] = secrets.token_urlsafe(24)
    return session["csrf"]
app.jinja_env.globals["csrf_token"] = csrf_token

@app.before_request
def protect():
    if request.method in ("POST","PUT","PATCH","DELETE"):
        supplied=request.form.get("csrf") or request.headers.get("X-CSRF-Token")
        if not supplied or supplied != session.get("csrf"):
            return jsonify(success=False,message="Invalid CSRF token"), 403

@app.context_processor
def globals_():
    c=db(); s={r["key"]:r["value"] for r in c.execute("SELECT key,value FROM settings").fetchall()}; c.close()
    return {"site_name":s.get("site_name","SKVM Panel"),"current_user":session.get("username"),"role":session.get("role")}


def login_required(f):
    @wraps(f)
    def w(*a,**kw):
        if not session.get("user_id"): return redirect(url_for("login", next=request.path))
        return f(*a,**kw)
    return w

def admin_required(f):
    @wraps(f)
    def w(*a,**kw):
        if not session.get("user_id"): return redirect(url_for("login"))
        if session.get("role") != "admin": abort(403)
        return f(*a,**kw)
    return w

def get_vps(vps_id):
    c=db(); v=c.execute("SELECT v.*,u.username FROM vps v JOIN users u ON u.id=v.user_id WHERE v.vps_id=?",(vps_id,)).fetchone(); c.close(); return v

def owner_required(f):
    @wraps(f)
    def w(vps_id,*a,**kw):
        v=get_vps(vps_id)
        if not v: abort(404)
        if session.get("role") != "admin" and v["user_id"] != session.get("user_id"): abort(403)
        return f(vps_id,*a,**kw)
    return w

lock=threading.RLock()

def docker_client():
    if docker is None: raise RuntimeError("Docker SDK is not installed")
    return docker.from_env(timeout=30)

def docker_available():
    try: docker_client().ping(); return True
    except Exception: return False

def find_free_port():
    c=db(); used={r[0] for r in c.execute("SELECT ssh_port FROM vps").fetchall()}; c.close()
    for p in range(PORT_START, 65500):
        if p in used: continue
        s=socket.socket(); s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
        try: s.bind(("0.0.0.0",p)); s.close(); return p
        except OSError: s.close()
    raise RuntimeError("No free SSH ports")

def container_state(v):
    try:
        c=docker_client(); x=c.containers.get(v["container"]); x.reload(); st=x.status
        return st
    except Exception: return "missing"

def update_status(vps_id,status,error=None,**extra):
    fields=["status=?","error=?","updated_at=CURRENT_TIMESTAMP"]; vals=[status,error]
    for k,val in extra.items(): fields.append(f"{k}=?"); vals.append(val)
    vals.append(vps_id)
    c=db(); c.execute(f"UPDATE vps SET {','.join(fields)} WHERE vps_id=?",vals); c.commit(); c.close()

def create_container(v):
    c=docker_client()
    name=f"skvm-{v['vps_id'][:12]}"
    env={"SKVM_ROOT_PASSWORD":v["ssh_password"],"SKVM_HOSTNAME":re.sub(r'[^a-zA-Z0-9-]','-',v['name'])[:40] or 'skvm-vps'}
    container=c.containers.create(
        IMAGE_MAP.get(v["image"], IMAGE), name=name, hostname=env["SKVM_HOSTNAME"], detach=True,
        mem_limit=f"{v['ram_mb']}m", nano_cpus=int(v['cpu_cores']*1_000_000_000),
        ports={"22/tcp": v["ssh_port"]}, environment=env,
        restart_policy={"Name":"unless-stopped"},
        labels={"com.skvm.vps_id":v["vps_id"]}
    )
    c.close(); return name

def provision(vps_id):
    try:
        v=get_vps(vps_id)
        if not v: return
        update_status(vps_id,"provisioning",None)
        if not docker_available(): raise RuntimeError("Docker daemon is unavailable")
        name=create_container(v)
        update_status(vps_id,"starting",None,container=name)
        c=docker_client(); cont=c.containers.get(name); cont.start(); c.close()
        for _ in range(30):
            time.sleep(1)
            st=container_state(v)
            if st=="running":
                update_status(vps_id,"running",None)
                notify(v["user_id"],"VPS ready",f"{v['name']} is running on SSH port {v['ssh_port']}","success")
                audit("vps.created",f"{v['name']} ({vps_id})",v["user_id"])
                # tmate is deliberately best-effort and asynchronous.
                threading.Thread(target=tmate_worker,args=(vps_id,),daemon=True).start()
                return
            if st in ("exited","dead"):
                raise RuntimeError("Container exited during startup")
        raise RuntimeError("Container startup timeout")
    except Exception as e:
        log.exception("Provisioning failed")
        update_status(vps_id,"error",str(e))
        v=get_vps(vps_id)
        if v: notify(v["user_id"],"VPS provisioning failed",str(e),"danger")

def tmate_worker(vps_id):
    v=get_vps(vps_id)
    if not v or container_state(v)!="running": return
    try:
        c=docker_client(); x=c.containers.get(v["container"])
        # tmate is optional. If unavailable/network-blocked, VPS stays healthy.
        r=x.exec_run("bash -lc 'command -v tmate >/dev/null 2>&1 && tmate -S /tmp/skvm.sock new-session -d && sleep 2 && tmate -S /tmp/skvm.sock display -p \'#{tmate_ssh}\' && tmate -S /tmp/skvm.sock display -p \'#{tmate_web}\' || true'",demux=False)
        out=(r.output or b'').decode(errors='ignore').splitlines(); vals=[x.strip() for x in out if x.strip()]
        ssh=next((x for x in vals if x.startswith('ssh ')),None); web=next((x for x in vals if x.startswith('https://')),None)
        if ssh or web: update_status(vps_id,"running",None,tmate_ssh=ssh,tmate_web=web)
        c.close()
    except Exception as e: log.info("tmate unavailable for %s: %s",vps_id,e)

def remove_container(v):
    try:
        c=docker_client(); x=c.containers.get(v["container"]); x.remove(force=True); c.close()
    except Exception: pass

# ---------- pages ----------
@app.route('/')
def index(): return redirect(url_for("dashboard" if session.get("user_id") else "login"))

@app.route('/login',methods=['GET','POST'])
def login():
    if request.method=='POST':
        u=request.form.get('username','').strip(); p=request.form.get('password','')
        c=db(); user=c.execute("SELECT * FROM users WHERE username=? AND active=1",(u,)).fetchone()
        if user and check_password_hash(user['password'],p):
            session.clear(); session['user_id']=user['id']; session['username']=user['username']; session['role']=user['role']; csrf_token()
            c.execute("UPDATE users SET last_login=CURRENT_TIMESTAMP WHERE id=?",(user['id'],)); c.commit(); c.close(); audit("auth.login","successful",user['id'])
            return redirect(request.args.get('next') or url_for('admin_dashboard' if user['role']=='admin' else 'dashboard'))
        c.close(); flash('Invalid username or password.','danger')
    return render_template('login.html')

@app.route('/logout')
def logout():
    audit("auth.logout"); session.clear(); return redirect(url_for('login'))

@app.route('/register',methods=['GET','POST'])
def register():
    if request.method=='POST':
        u=request.form.get('username','').strip(); e=request.form.get('email','').strip(); p=request.form.get('password','')
        if not re.fullmatch(r'[A-Za-z0-9_.-]{3,32}',u) or len(p)<8: flash('Use a valid username and an 8+ character password.','danger'); return render_template('register.html')
        try:
            c=db(); c.execute("INSERT INTO users(username,email,password) VALUES(?,?,?)",(u,e,generate_password_hash(p,method='scrypt'))); c.commit(); c.close(); flash('Account created.','success'); return redirect(url_for('login'))
        except sqlite3.IntegrityError: flash('Username or email already exists.','danger')
    return render_template('register.html')

@app.route('/dashboard')
@login_required
def dashboard():
    c=db(); rows=c.execute("SELECT * FROM vps WHERE user_id=? ORDER BY id DESC",(session['user_id'],)).fetchall(); unread=c.execute("SELECT COUNT(*) FROM notifications WHERE user_id=? AND read=0",(session['user_id'],)).fetchone()[0]; c.close()
    return render_template('dashboard.html',vps=rows,unread=unread)

@app.route('/vps/create',methods=['GET','POST'])
@admin_required
def create_vps():
    if request.method=='POST':
        try:
            name=request.form.get('name','').strip(); uid=int(request.form.get('user_id','0')); ram=int(request.form.get('ram_mb','1024')); cpu=int(request.form.get('cpu_cores','1')); disk=int(request.form.get('disk_gb','10')); image=request.form.get('image','ubuntu22')
            if not name or uid<=0: raise ValueError('Name and user are required')
            if not (128<=ram<=131072 and 1<=cpu<=64 and 1<=disk<=2048): raise ValueError('Resource values are outside allowed limits')
            if image not in ('ubuntu22','ubuntu24','debian12'): raise ValueError('Unsupported OS image')
            port=find_free_port(); vid=str(uuid.uuid4()); pw=secrets.token_urlsafe(12)
            c=db(); c.execute("INSERT INTO vps(vps_id,user_id,name,image,ram_mb,cpu_cores,disk_gb,ssh_port,ssh_password,status) VALUES(?,?,?,?,?,?,?,?,?,'creating')",(vid,uid,name,image,ram,cpu,disk,port,pw)); c.commit(); c.close()
            threading.Thread(target=provision,args=(vid,),daemon=True).start(); flash('VPS provisioning started.','success'); return redirect(url_for('manage_vps',vps_id=vid))
        except Exception as e: flash(str(e),'danger')
    c=db(); users=c.execute("SELECT id,username FROM users WHERE active=1 ORDER BY username").fetchall(); c.close(); return render_template('create_vps.html',users=users)

@app.route('/vps/<vps_id>')
@login_required
@owner_required
def manage_vps(vps_id):
    v=get_vps(vps_id); st=container_state(v); c=db(); logs=c.execute("SELECT * FROM audit WHERE details LIKE ? ORDER BY id DESC LIMIT 30",(f'%{vps_id}%',)).fetchall(); c.close()
    return render_template('manage_vps.html',v=v,real_status=st,logs=logs)

def action(vps_id,op):
    v=get_vps(vps_id); 
    if not v: return jsonify(success=False,message='VPS not found'),404
    try:
        c=docker_client()
        try: x=c.containers.get(v['container'])
        except Exception: x=None
        if op=='start':
            if not x: raise RuntimeError('Container is missing; use Reprovision')
            x.start(); status='running'
        elif op=='stop':
            if not x: raise RuntimeError('Container is missing')
            x.stop(timeout=10); status='stopped'
        elif op=='restart':
            if not x: raise RuntimeError('Container is missing')
            x.restart(timeout=10); status='running'
        else: raise RuntimeError('Unsupported action')
        c.close(); update_status(vps_id,status,None); audit(f'vps.{op}',v['name'],session['user_id']); return jsonify(success=True,status=status)
    except Exception as e:
        update_status(vps_id,'error',str(e)); return jsonify(success=False,message=str(e)),500

@app.route('/vps/<vps_id>/start',methods=['POST'])
@login_required
@owner_required
def start(vps_id): return action(vps_id,'start')
@app.route('/vps/<vps_id>/stop',methods=['POST'])
@login_required
@owner_required
def stop(vps_id): return action(vps_id,'stop')
@app.route('/vps/<vps_id>/restart',methods=['POST'])
@login_required
@owner_required
def restart(vps_id): return action(vps_id,'restart')

@app.route('/vps/<vps_id>/reprovision',methods=['POST'])
@admin_required
def reprovision(vps_id):
    v=get_vps(vps_id)
    if not v: return jsonify(success=False,message='Not found'),404
    remove_container(v); update_status(vps_id,'creating',None,container=None,tmate_ssh=None,tmate_web=None); threading.Thread(target=provision,args=(vps_id,),daemon=True).start(); return jsonify(success=True)

@app.route('/vps/<vps_id>/delete',methods=['POST'])
@admin_required
def delete_vps(vps_id):
    v=get_vps(vps_id)
    if not v: return jsonify(success=False,message='Not found'),404
    remove_container(v); c=db(); c.execute("DELETE FROM vps WHERE vps_id=?",(vps_id,)); c.commit(); c.close(); audit('vps.deleted',v['name']); return jsonify(success=True)

@app.route('/vps/<vps_id>/status')
@login_required
@owner_required
def vps_status(vps_id):
    v=get_vps(vps_id); st=container_state(v); mapped={'running':'running','exited':'stopped','created':'created','restarting':'starting','missing':'missing'}; return jsonify(success=True,status=mapped.get(st,st),error=v['error'],tmate_ssh=v['tmate_ssh'],tmate_web=v['tmate_web'])

@app.route('/vps/<vps_id>/tmate',methods=['POST'])
@login_required
@owner_required
def tmate(vps_id):
    threading.Thread(target=tmate_worker,args=(vps_id,),daemon=True).start(); return jsonify(success=True,message='tmate refresh started')

@app.route('/vps/<vps_id>/terminal')
@login_required
@owner_required
def terminal(vps_id): return render_template('terminal.html',v=get_vps(vps_id))

@app.route('/profile',methods=['GET','POST'])
@login_required
def profile():
    if request.method=='POST':
        p=request.form.get('password','')
        if len(p)<8: flash('Password must be at least 8 characters.','danger')
        else:
            c=db(); c.execute("UPDATE users SET password=? WHERE id=?",(generate_password_hash(p,method='scrypt'),session['user_id'])); c.commit(); c.close(); flash('Password updated.','success'); audit('profile.password_changed')
    c=db(); u=c.execute("SELECT * FROM users WHERE id=?",(session['user_id'],)).fetchone(); c.close(); return render_template('profile.html',user=u)

@app.route('/notifications')
@login_required
def notifications():
    c=db(); n=c.execute("SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 100",(session['user_id'],)).fetchall(); c.close(); return render_template('notifications.html',notifications=n)
@app.route('/notifications/read-all',methods=['POST'])
@login_required
def read_all():
    c=db(); c.execute("UPDATE notifications SET read=1 WHERE user_id=?",(session['user_id'],)); c.commit(); c.close(); return jsonify(success=True)

# ---------- admin ----------
@app.route('/admin')
@admin_required
def admin_dashboard():
    c=db(); total=c.execute('SELECT COUNT(*) FROM vps').fetchone()[0]; users=c.execute('SELECT COUNT(*) FROM users').fetchone()[0]; running=sum(1 for r in c.execute('SELECT * FROM vps').fetchall() if container_state(r)=='running'); errors=c.execute("SELECT COUNT(*) FROM vps WHERE status='error'").fetchone()[0]; logs=c.execute('SELECT a.*,u.username FROM audit a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 10').fetchall(); c.close(); return render_template('admin/dashboard.html',total=total,users=users,running=running,errors=errors,logs=logs,docker_ok=docker_available())

@app.route('/admin/vps')
@admin_required
def admin_vps():
    c=db(); vps=c.execute('SELECT v.*,u.username FROM vps v JOIN users u ON u.id=v.user_id ORDER BY v.id DESC').fetchall(); c.close(); return render_template('admin/vps.html',vps=vps)

@app.route('/admin/users')
@admin_required
def admin_users():
    c=db(); users=c.execute('SELECT u.*,COUNT(v.id) vm_count FROM users u LEFT JOIN vps v ON v.user_id=u.id GROUP BY u.id ORDER BY u.id DESC').fetchall(); c.close(); return render_template('admin/users.html',users=users)
@app.route('/admin/users/create',methods=['GET','POST'])
@admin_required
def admin_create_user():
    if request.method=='POST':
        try:
            u=request.form['username'].strip(); e=request.form['email'].strip(); p=request.form['password']; role=request.form.get('role','user'); c=db(); c.execute('INSERT INTO users(username,email,password,role) VALUES(?,?,?,?)',(u,e,generate_password_hash(p,method='scrypt'),role)); c.commit(); c.close(); flash('User created.','success'); return redirect(url_for('admin_users'))
        except Exception as e: flash(str(e),'danger')
    return render_template('admin/user_form.html',user=None)
@app.route('/admin/users/<int:user_id>/edit',methods=['GET','POST'])
@admin_required
def admin_edit_user(user_id):
    c=db(); u=c.execute('SELECT * FROM users WHERE id=?',(user_id,)).fetchone()
    if not u: c.close(); abort(404)
    if request.method=='POST':
        role=request.form.get('role','user'); active=1 if request.form.get('active')=='on' else 0; p=request.form.get('password','')
        if p: c.execute('UPDATE users SET username=?,email=?,role=?,active=?,password=? WHERE id=?',(request.form['username'],request.form['email'],role,active,generate_password_hash(p,method='scrypt'),user_id))
        else: c.execute('UPDATE users SET username=?,email=?,role=?,active=? WHERE id=?',(request.form['username'],request.form['email'],role,active,user_id))
        c.commit(); c.close(); flash('User updated.','success'); return redirect(url_for('admin_users'))
    c.close(); return render_template('admin/user_form.html',user=u)
@app.route('/admin/users/<int:user_id>/delete',methods=['POST'])
@admin_required
def admin_delete_user(user_id):
    if user_id==session['user_id']: return jsonify(success=False,message='You cannot delete yourself'),400
    c=db(); vps=c.execute('SELECT * FROM vps WHERE user_id=?',(user_id,)).fetchall(); c.close()
    for v in vps: remove_container(v)
    c=db(); c.execute('DELETE FROM users WHERE id=?',(user_id,)); c.commit(); c.close(); audit('user.deleted',str(user_id)); return jsonify(success=True)

@app.route('/admin/settings',methods=['GET','POST'])
@admin_required
def settings():
    c=db()
    if request.method=='POST':
        for k in ('site_name','maintenance'):
            if k in request.form: c.execute('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',(k,request.form[k]))
        c.commit(); flash('Settings saved.','success'); audit('settings.updated')
    s=c.execute('SELECT * FROM settings ORDER BY key').fetchall(); c.close(); return render_template('admin/settings.html',settings=s)
@app.route('/admin/audit')
@admin_required
def audit_page():
    c=db(); logs=c.execute('SELECT a.*,u.username FROM audit a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 200').fetchall(); c.close(); return render_template('admin/audit.html',logs=logs)

@app.route('/healthz')
def healthz():
    ok=docker_available()
    return jsonify(status='ok' if ok else 'degraded',docker=ok),200 if ok else 503

@app.errorhandler(403)
def e403(e): return render_template('errors/403.html'),403
@app.errorhandler(404)
def e404(e): return render_template('errors/404.html'),404
@app.errorhandler(500)
def e500(e): return render_template('errors/500.html'),500

if __name__=='__main__':
    app.run(host=os.getenv('SKVM_BIND','0.0.0.0'),port=int(os.getenv('SKVM_PORT','5555')),debug=False)
