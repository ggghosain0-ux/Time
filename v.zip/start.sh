#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"

PYTHON="${PYTHON:-python3}"
command -v "$PYTHON" >/dev/null 2>&1 || { echo "ERROR: python3 is required." >&2; exit 1; }

# This launcher is intentionally independent of systemd and Docker.
# It works in CodeSandbox-like environments and on normal Linux hosts.
VENV=".venv"
USE_VENV=1

if [[ ! -x "$VENV/bin/python" ]]; then
  rm -rf "$VENV"
  if ! "$PYTHON" -m venv "$VENV" >/dev/null 2>&1; then
    USE_VENV=0
  fi
fi

if [[ "$USE_VENV" == 1 ]]; then
  # Some pre-created virtualenvs have a Python binary but no pip.
  if ! "$VENV/bin/python" -m pip --version >/dev/null 2>&1; then
    if ! "$VENV/bin/python" -m ensurepip --upgrade >/dev/null 2>&1; then
      rm -rf "$VENV"
      USE_VENV=0
    fi
  fi
fi

if [[ "$USE_VENV" == 1 ]]; then
  PY="$VENV/bin/python"
  "$PY" -m pip install --disable-pip-version-check --upgrade pip setuptools wheel
  "$PY" -m pip install --disable-pip-version-check -r requirements.txt
else
  echo "WARNING: Python venv is unavailable; using the system Python environment."
  if "$PYTHON" -m pip --version >/dev/null 2>&1; then
    PY="$PYTHON"
  elif command -v pip3 >/dev/null 2>&1; then
    PY="$PYTHON"
  else
    echo "ERROR: pip is not available. On Ubuntu run: sudo apt-get install -y python3-pip python3-venv" >&2
    exit 1
  fi
  "$PY" -m pip install --disable-pip-version-check -r requirements.txt || {
    echo "ERROR: Could not install Python requirements." >&2
    echo "On Ubuntu use: sudo apt-get install -y python3-pip python3-venv" >&2
    exit 1
  }
fi

[[ -f .env ]] || cp .env.example .env
chmod 600 .env 2>/dev/null || true

# Build the guest images automatically whenever a Docker daemon is available.
# This fixes the common "skvm/ubuntu22:latest is missing" error when using start.sh.
if command -v docker >/dev/null 2>&1 && docker info >/dev/null 2>&1; then
  echo "==> Docker detected; checking SKVM guest images..."
  for spec in "ubuntu22:docker/Dockerfile.ubuntu22" "ubuntu24:docker/Dockerfile.ubuntu24" "debian12:docker/Dockerfile.debian12"; do
    tag="${spec%%:*}"; file="${spec#*:}"
    if ! docker image inspect "skvm/${tag}:latest" >/dev/null 2>&1; then
      echo "==> Building skvm/${tag}:latest"
      docker build --pull -t "skvm/${tag}:latest" -f "$file" docker
    else
      echo "==> skvm/${tag}:latest already exists"
    fi
  done
else
  echo "WARNING: Docker daemon is unavailable. The panel can start, but real VPS provisioning is unavailable until Docker is available."
fi

exec "$PY" app.py
