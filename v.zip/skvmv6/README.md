# SKVM v6

A self-contained Docker VPS control panel for a Linux host.

## What v6 fixes
- Builds the Ubuntu 22.04 + OpenSSH + tmate guest image locally, so Docker does not try to pull a nonexistent `skvm/ubuntu22-tmate` image.
- VPS provisioning is asynchronous: tmate relay registration never blocks VPS creation.
- If tmate is unavailable, the VPS still receives a host-mapped SSH port and generated SSH password.
- Background tmate refresh retries automatically.
- Dashboard, VPS detail, admin/audit, settings, login, health check and JSON API pages.
- Start/stop/restart/delete and SSH-password regeneration.
- SQLite persistence and automatic systemd startup.
- No Flask development debug mode.

## Install on a real Ubuntu/Debian VPS

```bash
chmod +x install.sh
./install.sh
```

Then open `http://SERVER_IP:5555` (or the `PORT` configured in `.env`).

Default login is `admin / admin123` unless changed in `.env`.

## Production notes

This panel talks to the Docker daemon and can create privileged containers. Treat it as an administrative service. Put it behind HTTPS, firewall the panel port, use a strong `SKVM_SECRET_KEY` and strong admin password, and do not expose the Docker socket to untrusted applications.

The `disk` field is a request/metadata value. A generic Docker `overlay2` host does not provide a portable hard per-container disk quota, so v6 intentionally does not pretend that `10g` is an enforced quota. Implement XFS/project quotas or a dedicated volume/storage backend if hard disk limits are required.

### tmate

tmate is inherently dependent on outbound connectivity to its relay. v6 deliberately treats tmate as an optional convenience instead of the provisioning mechanism. Direct SSH is the reliable path when the host firewall/security group exposes the allocated port range.

### Useful commands

```bash
sudo systemctl status skvm
sudo journalctl -u skvm -f
sudo docker ps
sudo docker images | grep skvm
```
