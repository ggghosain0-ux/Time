#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
SUDO=""; [ "$(id -u)" -eq 0 ] || SUDO=sudo
$SUDO apt-get update
$SUDO DEBIAN_FRONTEND=noninteractive apt-get install -y ca-certificates curl python3 python3-venv python3-pip docker.io
$SUDO systemctl enable --now docker
if ! $SUDO docker image inspect skvm/ubuntu22-tmate:latest >/dev/null 2>&1; then
  $SUDO docker build --pull -t skvm/ubuntu22-tmate:latest -f Dockerfile.ubuntu22 .
fi
[ -f .env ] || cp .env.example .env
python3 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
# Install a systemd service so the panel starts automatically after reboot.
$SUDO tee /etc/systemd/system/skvm.service >/dev/null <<EOF
[Unit]
Description=SKVM VPS Panel v6
After=docker.service network-online.target
Wants=network-online.target
Requires=docker.service

[Service]
Type=simple
WorkingDirectory=$(pwd)
EnvironmentFile=$(pwd)/.env
ExecStart=$(pwd)/.venv/bin/python $(pwd)/app.py
Restart=always
RestartSec=3
NoNewPrivileges=false

[Install]
WantedBy=multi-user.target
EOF
$SUDO systemctl daemon-reload
$SUDO systemctl enable --now skvm
printf '\nSKVM v6 installed and started.\nPanel: http://YOUR_SERVER_IP:%s\nLogin: %s / %s\n\n' "$(grep '^PORT=' .env | cut -d= -f2 || echo 5555)" "$(grep '^SKVM_ADMIN_USERNAME=' .env | cut -d= -f2 || echo admin)" "$(grep '^SKVM_ADMIN_PASSWORD=' .env | cut -d= -f2 || echo admin123)"
