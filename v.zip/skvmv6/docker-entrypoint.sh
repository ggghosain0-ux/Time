#!/bin/sh
set -eu
mkdir -p /run/sshd
if [ -n "${SKVM_ROOT_PASSWORD:-}" ]; then
  echo "root:${SKVM_ROOT_PASSWORD}" | chpasswd
fi
# Allow root password SSH for the isolated VPS container.
sed -ri 's/^#?PasswordAuthentication.*/PasswordAuthentication yes/' /etc/ssh/sshd_config
sed -ri 's/^#?PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config
ssh-keygen -A >/dev/null 2>&1 || true
exec /usr/sbin/sshd -D -e
