import os, sqlite3, secrets, time, threading, subprocess, re
from functools import wraps
from flask import Flask, request, jsonify, render_template, session, redirect, url_for, abort
import docker
from docker.errors import NotFound

BASE=os.path.dirname(os.path.abspath(__file__))
# Load local .env without requiring an extra dependency.
envfile=os.path.join(BASE,'.env')
if os.path.exists(envfile):
    for line in open(envfile,encoding='utf-8'):
        line=line.strip()
        if not line or line.startswith('#') or '=' not in line: continue
        k,v=line.split('=',1); os.environ.setdefault(k.strip(),v.strip().strip('\"').strip("'"))
DB=os.path.join(BASE,'skvm.db')
SECRET=os.getenv('SKVM_SECRET_KEY','') or secrets.token_hex(32)
ADMIN_USER=os.getenv('SKVM_ADMIN_USERNAME','admin')
ADMIN_PASS=os.getenv('SKVM_ADMIN_PASSWORD','admin123')
IMAGE=os.getenv('SKVM_TUNNEL_IMAGE','skvm/ubuntu22-tmate:latest')
PORT_BASE=int(os.getenv('SKVM_SSH_PORT_BASE','22000'))
APP_PORT=int(os.getenv('PORT','5555'))
TMATE_TIMEOUT=int(os.getenv('SKVM_TMATE_TIMEOUT','8'))
TMATE_ENABLED=os.getenv('SKVM_ENABLE_TMATE','1') == '1'

app=Flask(__name__, static_folder='static', template_folder='templates')
app.secret_key=SECRET
app.config['SESSION_COOKIE_HTTPONLY']=True
app.config['SESSION_COOKIE_SAMESITE']='Lax'
try: client=docker.from_env()
except Exception: client=None

DB_LOCK=threading.Lock()

def conn():
    c=sqlite3.connect(DB, timeout=30); c.row_factory=sqlite3.Row
    return c

def init_db():
    with DB_LOCK:
        c=conn()
        c.execute('''CREATE TABLE IF NOT EXISTS vps(
          id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
          container_id TEXT, ssh_port INTEGER, ssh_password TEXT,
          tmate_ssh TEXT, status TEXT NOT NULL DEFAULT 'provisioning',
          error TEXT, ram TEXT, cpu REAL, disk TEXT, os TEXT,
          created INTEGER NOT NULL, updated INTEGER NOT NULL)''')
        c.execute('''CREATE TABLE IF NOT EXISTS audit(
          id INTEGER PRIMARY KEY AUTOINCREMENT, action TEXT, detail TEXT, created INTEGER NOT NULL)''')
        c.commit(); c.close()
init_db()

def logged_in(): return session.get('admin') is True

def require_auth(f):
    @wraps(f)
    def w(*a,**kw):
        if not logged_in(): return jsonify(error='unauthorized'),401
        return f(*a,**kw)
    return w

def page_auth(f):
    @wraps(f)
    def w(*a,**kw):
        if not logged_in(): return redirect(url_for('login'))
        return f(*a,**kw)
    return w

def audit(action,detail=''):
    with DB_LOCK:
        c=conn(); c.execute('INSERT INTO audit(action,detail,created) VALUES(?,?,?)',(action,detail,int(time.time()))); c.commit(); c.close()

def get_vps(vid):
    c=conn(); r=c.execute('SELECT * FROM vps WHERE id=?',(vid,)).fetchone(); c.close(); return r

def next_port():
    c=conn(); used={r[0] for r in c.execute('SELECT ssh_port FROM vps WHERE ssh_port IS NOT NULL')}; c.close()
    p=PORT_BASE
    while p in used: p += 1
    return p

def update(vid,**fields):
    if not fields: return
    fields['updated']=int(time.time())
    sql='UPDATE vps SET '+','.join(k+'=?' for k in fields)+' WHERE id=?'
    with DB_LOCK:
        c=conn(); c.execute(sql,tuple(fields.values())+(vid,)); c.commit(); c.close()

def tmate_worker(vid, cid):
    if not TMATE_ENABLED:
        return
    # Retry in the background. VPS provisioning is already complete and never waits for relay registration.
    for delay in (0,2,5,10):
        if delay: time.sleep(delay)
        try:
            cmd=['docker','exec',cid,'sh','-lc',
                 "tmate -S /tmp/skvm-tmate.sock kill-session -a >/dev/null 2>&1 || true; "
                 "tmate -S /tmp/skvm-tmate.sock new-session -d; "
                 "tmate -S /tmp/skvm-tmate.sock wait tmate-ready >/dev/null 2>&1; "
                 "tmate -S /tmp/skvm-tmate.sock display -p '#{tmate_ssh}'"]
            p=subprocess.run(cmd,capture_output=True,text=True,timeout=TMATE_TIMEOUT)
            out=(p.stdout or '')+'\n'+(p.stderr or '')
            m=re.search(r'(ssh\s+[^\s]+@[^\s]+)',out)
            if m:
                update(vid,tmate_ssh=m.group(1),error=None)
                audit('tmate_ready',f'VPS {vid}')
                return
        except Exception:
            pass
    update(vid,error='tmate relay unavailable; direct SSH remains available when the host SSH port is reachable.')

def provision(vid,name,ram,cpu,disk):
    try:
        if client is None: raise RuntimeError('Docker is not available.')
        port=next_port(); password=secrets.token_urlsafe(12)
        cname='skvm-'+secrets.token_hex(6)
        c=client.containers.run(
            IMAGE,detach=True,name=cname,
            mem_limit=ram,nano_cpus=max(1,int(float(cpu)*1e9)),
            ports={'22/tcp':port},
            environment={'SKVM_ROOT_PASSWORD':password,'TZ':'UTC'},
            restart_policy={'Name':'unless-stopped'},
            labels={'skvm':'v6','skvm.vps_id':str(vid)})
        update(vid,container_id=c.id,ssh_port=port,ssh_password=password,status='running',error=None)
        audit('vps_created',f'VPS {vid} / {name}')
        threading.Thread(target=tmate_worker,args=(vid,c.id),daemon=True).start()
    except Exception as e:
        update(vid,status='error',error=str(e))
        audit('provision_failed',f'VPS {vid}: {e}')

def stats():
    c=conn(); rows=c.execute('SELECT status FROM vps').fetchall(); c.close()
    return {'total':len(rows),'running':sum(r['status']=='running' for r in rows),'stopped':sum(r['status']=='stopped' for r in rows),'errors':sum(r['status']=='error' for r in rows)}

@app.get('/')
@page_auth
def dashboard():
    c=conn(); rows=c.execute('SELECT * FROM vps ORDER BY id DESC').fetchall(); logs=c.execute('SELECT * FROM audit ORDER BY id DESC LIMIT 8').fetchall(); c.close()
    return render_template('dashboard.html',vps=rows,logs=logs,stats=stats())

@app.get('/vps/<int:vid>')
@page_auth
def vps_page(vid):
    v=get_vps(vid)
    if not v: abort(404)
    return render_template('vps.html',v=v)

@app.get('/admin')
@page_auth
def admin_page():
    c=conn(); logs=c.execute('SELECT * FROM audit ORDER BY id DESC LIMIT 50').fetchall(); c.close()
    return render_template('admin.html',logs=logs)

@app.get('/settings')
@page_auth
def settings(): return render_template('settings.html')

@app.route('/login',methods=['GET','POST'])
def login():
    if request.method=='POST':
        if secrets.compare_digest(request.form.get('username',''),ADMIN_USER) and secrets.compare_digest(request.form.get('password',''),ADMIN_PASS):
            session.clear(); session['admin']=True; audit('login','admin'); return redirect('/')
        return render_template('login.html',error='Invalid username or password.')
    return render_template('login.html',error=None)

@app.get('/logout')
def logout(): session.clear(); return redirect('/login')

@app.get('/healthz')
def healthz():
    docker_ok=False
    try: client.ping(); docker_ok=True
    except Exception: pass
    return jsonify(ok=True,docker=docker_ok,time=int(time.time()))

@app.get('/api/stats')
@require_auth
def api_stats(): return jsonify(stats())

@app.get('/api/vps')
@require_auth
def api_list():
    c=conn(); rows=c.execute('SELECT * FROM vps ORDER BY id DESC').fetchall(); c.close(); return jsonify([dict(r) for r in rows])

@app.post('/api/vps')
@require_auth
def api_create():
    d=request.get_json(silent=True) or {}
    name=(str(d.get('name') or 'VPS').strip()[:60] or 'VPS')
    ram=str(d.get('ram') or '1g').strip(); cpu=float(d.get('cpu') or 1); disk=str(d.get('disk') or '10g').strip()
    if cpu<=0 or cpu>64: return jsonify(error='CPU must be between 0 and 64 cores.'),400
    if not re.fullmatch(r'\d+(?:\.\d+)?[kKmMgGtT]?[bB]?',ram): return jsonify(error='Invalid RAM format.'),400
    now=int(time.time())
    with DB_LOCK:
        c=conn(); cur=c.execute('INSERT INTO vps(name,status,ram,cpu,disk,os,created,updated) VALUES(?,?,?,?,?,?,?,?)',(name,'provisioning',ram,cpu,disk,'Ubuntu 22.04',now,now)); vid=cur.lastrowid; c.commit(); c.close()
    threading.Thread(target=provision,args=(vid,name,ram,cpu,disk),daemon=True).start()
    return jsonify(id=vid,status='provisioning'),202

@app.get('/api/vps/<int:vid>')
@require_auth
def api_info(vid):
    v=get_vps(vid)
    if not v:return jsonify(error='not found'),404
    return jsonify(dict(v))

@app.post('/api/vps/<int:vid>/<action>')
@require_auth
def api_action(vid,action):
    v=get_vps(vid)
    if not v:return jsonify(error='not found'),404
    if not client:return jsonify(error='Docker unavailable'),500
    try:
        c=client.containers.get(v['container_id'])
        if action=='start': c.start()
        elif action=='stop': c.stop(timeout=10)
        elif action=='restart': c.restart(timeout=10)
        elif action=='delete':
            c.remove(force=True)
            with DB_LOCK:
                x=conn(); x.execute('DELETE FROM vps WHERE id=?',(vid,)); x.commit(); x.close()
            audit('vps_deleted',f'VPS {vid}'); return jsonify(ok=True)
        elif action=='refresh-tmate':
            threading.Thread(target=tmate_worker,args=(vid,c.id),daemon=True).start(); return jsonify(ok=True,message='tmate refresh started')
        else:return jsonify(error='unknown action'),400
        update(vid,status=c.status,error=None if c.status in ('running','exited','created') else v['error'])
        audit(action,f'VPS {vid}')
        return jsonify(ok=True,status=c.status)
    except NotFound:
        update(vid,status='error',error='Docker container no longer exists.')
        return jsonify(error='Docker container no longer exists.'),404
    except Exception as e:
        update(vid,error=str(e)); return jsonify(error=str(e)),500

@app.post('/api/vps/<int:vid>/regenerate-ssh')
@require_auth
def regenerate_ssh(vid):
    v=get_vps(vid)
    if not v:return jsonify(error='not found'),404
    password=secrets.token_urlsafe(12)
    try:
        c=client.containers.get(v['container_id'])
        # image entrypoint reads SKVM_ROOT_PASSWORD only at first boot; update the account directly here.
        c.exec_run(['sh','-lc',f"echo 'root:{password}' | chpasswd"])
        update(vid,ssh_password=password); audit('ssh_password_regenerated',f'VPS {vid}')
        return jsonify(ok=True,password=password)
    except Exception as e:return jsonify(error=str(e)),500

if __name__=='__main__':
    app.run(host='0.0.0.0',port=APP_PORT,debug=False)

def ts_filter(value):
    return time.strftime('%Y-%m-%d %H:%M', time.localtime(int(value)))
app.jinja_env.filters['ts']=ts_filter

if __name__=='__main__':
    app.run(host='0.0.0.0',port=APP_PORT,debug=False)
