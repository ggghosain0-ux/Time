import os
import re
import secrets
import shlex
import subprocess
import threading
import time
from datetime import datetime, timezone
from functools import wraps

from flask import Flask, render_template, request, redirect, url_for, flash, abort, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash

try:
    import docker
    from docker.errors import DockerException
except Exception:
    docker = None
    DockerException = Exception

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
app = Flask(__name__, template_folder=os.path.join(BASE_DIR, "templates"))
app.config.update(
    SECRET_KEY=os.environ.get("SKVM_SECRET_KEY", secrets.token_hex(32)),
    SQLALCHEMY_DATABASE_URI=f"sqlite:///{os.path.join(BASE_DIR, 'skvm.db')}",
    SQLALCHEMY_TRACK_MODIFICATIONS=False,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("SKVM_COOKIE_SECURE", "0") == "1",
)
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default="user")
    created_at = db.Column(db.DateTime, nullable=False, default=lambda: datetime.now(timezone.utc))
    vps = db.relationship("VPS", backref="owner", lazy=True, cascade="all, delete-orphan")
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class VPS(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False, index=True)
    node = db.Column(db.String(100), nullable=False, default="Local-Node-1")
    ram = db.Column(db.Integer, nullable=False)   # MB
    disk = db.Column(db.Integer, nullable=False)  # GB requested
    cpu = db.Column(db.Integer, nullable=False)
    os = db.Column(db.String(50), nullable=False)
    container_id = db.Column(db.String(128), nullable=True, index=True)
    tmate_token = db.Column(db.Text, nullable=True)
    status = db.Column(db.String(30), nullable=False, default="Provisioning")
    error_message = db.Column(db.Text, nullable=True)
    progress = db.Column(db.Integer, nullable=False, default=0)
    progress_message = db.Column(db.String(255), nullable=True)
    provision_attempt = db.Column(db.Integer, nullable=False, default=0)
    disk_enforced = db.Column(db.Boolean, nullable=False, default=False)
    disk_status = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, nullable=False, default=lambda: datetime.now(timezone.utc))

class Settings(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    panel_name = db.Column(db.String(120), nullable=False, default="SKVM Panel")
    logo_url = db.Column(db.String(1000))
    banner_url = db.Column(db.String(1000))
    background_url = db.Column(db.String(1000))

def now():
    return datetime.now(timezone.utc)

def get_docker():
    if docker is None:
        return None
    try:
        c = docker.from_env(timeout=10)
        c.ping()
        return c
    except Exception:
        return None

def csrf():
    token = session.get("_csrf")
    if not token:
        token = secrets.token_urlsafe(32)
        session["_csrf"] = token
    return token

app.jinja_env.globals["csrf_token"] = csrf

@app.before_request
def csrf_guard():
    if request.method in {"POST", "PUT", "PATCH", "DELETE"}:
        sent = request.form.get("_csrf") or request.headers.get("X-CSRF-Token")
        expected = session.get("_csrf")
        if not expected or not sent or not secrets.compare_digest(str(sent), str(expected)):
            abort(400, description="Invalid CSRF token.")

@app.context_processor
def inject_globals():
    return {"site": Settings.query.first() or Settings(panel_name="SKVM Panel"), "now": now()}

@login_manager.user_loader
def load_user(user_id):
    try:
        return db.session.get(User, int(user_id))
    except Exception:
        return None

def admin_required(fn):
    @wraps(fn)
    @login_required
    def wrapper(*args, **kwargs):
        if current_user.role != "admin":
            abort(403)
        return fn(*args, **kwargs)
    return wrapper


def migrate_schema():
    """Small SQLite migration for installations upgrading from SKVM v2/v3."""
    db.create_all()
    inspector = db.inspect(db.engine)
    columns = {c["name"] for c in inspector.get_columns("vps")}
    additions = {
        "progress": "INTEGER NOT NULL DEFAULT 0",
        "progress_message": "VARCHAR(255)",
        "provision_attempt": "INTEGER NOT NULL DEFAULT 0",
        "disk_enforced": "BOOLEAN NOT NULL DEFAULT 0",
        "disk_status": "VARCHAR(255)",
    }
    with db.engine.begin() as conn:
        for name, ddl in additions.items():
            if name not in columns:
                conn.exec_driver_sql(f"ALTER TABLE vps ADD COLUMN {name} {ddl}")

def seed():
    db.create_all()
    settings = Settings.query.first()
    if not settings:
        db.session.add(Settings(panel_name="SKVM Panel"))
    admin_name = os.environ.get("SKVM_ADMIN_USERNAME", "admin")
    admin_password = os.environ.get("SKVM_ADMIN_PASSWORD", "admin123")
    admin = User.query.filter_by(username=admin_name).first()
    if not admin:
        admin = User(username=admin_name, role="admin")
        admin.set_password(admin_password)
        db.session.add(admin)
    else:
        admin.role = "admin"
    db.session.commit()

def parse_ram(value):
    m = re.fullmatch(r"\s*(\d+)\s*(GB|MB)?\s*", value or "", re.I)
    if not m:
        raise ValueError("RAM must be like 1GB or 1024MB.")
    n = int(m.group(1))
    mb = n if (m.group(2) or "GB").upper() == "MB" else n * 1024
    if mb < 128 or mb > 131072:
        raise ValueError("RAM must be between 128MB and 128GB.")
    return mb

def parse_disk(value):
    m = re.fullmatch(r"\s*(\d+)\s*(GB)?\s*", value or "", re.I)
    if not m:
        raise ValueError("Disk must be like 10GB.")
    gb = int(m.group(1))
    if gb < 1 or gb > 2048:
        raise ValueError("Disk must be between 1GB and 2048GB.")
    return gb

def parse_cpu(value):
    m = re.fullmatch(r"\s*(\d+)\s*(Core|Cores|CPU)?\s*", value or "", re.I)
    if not m:
        raise ValueError("CPU must be like 1 Core.")
    cpu = int(m.group(1))
    if cpu < 1 or cpu > 64:
        raise ValueError("CPU must be between 1 and 64 cores.")
    return cpu

def image_for(os_name):
    return {"Ubuntu 22.04": "ubuntu:22.04", "Ubuntu 20.04": "ubuntu:20.04"}.get(os_name)

def exec_container(container, command, timeout=300):
    """Execute a multiline shell script with safe shell quoting."""
    script = str(command).replace("\x00", "")
    # Do not use Python repr() to quote shell scripts: embedded single quotes
    # (notably tmate's #{tmate_ssh}) otherwise corrupt the script.
    wrapped = f"timeout --preserve-status {int(timeout)}s bash -lc {shlex.quote(script)}"
    result = container.exec_run(["bash", "-lc", wrapped], stdout=True, stderr=True)
    output = result.output
    if isinstance(output, tuple): output = b"".join(x or b"" for x in output)
    text = (output or b"").decode(errors="replace")
    if result.exit_code != 0:
        raise RuntimeError(text[-6000:] or f"Container command exited with {result.exit_code}")
    return text

def extract_tmate_ssh(text):
    # Handles ssh user@host, optional -p port, and ignores surrounding log noise.
    patterns = [
        r"(?m)^\s*(ssh\s+(?:-p\s+\d+\s+)?\S+@\S+)\s*$",
        r"(ssh\s+(?:-p\s+\d+\s+)?\S+@\S+)",
    ]
    for p in patterns:
        m = re.search(p, text)
        if m:
            return m.group(1).strip()
    return None


def update_progress(vps, percent, message, status=None):
    vps.progress = max(0, min(100, int(percent)))
    vps.progress_message = message
    if status:
        vps.status = status
    db.session.commit()


def docker_storage_driver(client):
    try:
        return (client.info().get("Driver") or "unknown").lower()
    except Exception:
        return "unknown"

def try_real_disk_quota(client, image, vps):
    """
    Probe the node once per provisioning attempt. A Docker storage driver name
    alone is not enough: overlay2 commonly reports the driver while the backing
    filesystem still rejects storage_opt=size with EPERM.
    """
    name = f"skvm-quota-probe-{secrets.token_hex(5)}"
    probe = None
    try:
        probe = client.containers.run(
            image=image,
            command=["bash", "-lc", "sleep 3"],
            detach=True,
            storage_opt={"size": f"{vps.disk}G"},
            remove=False,
            name=name,
            labels={"com.skvm.probe": "disk-quota"},
        )
        probe.reload()
        applied = (probe.attrs.get("HostConfig", {}).get("StorageOpt") or {}).get("size")
        if str(applied) != f"{vps.disk}G":
            raise RuntimeError(f"Docker accepted the request but reported StorageOpt={applied!r}.")
        return True, f"Real Docker root filesystem quota: {vps.disk} GB"
    except Exception as exc:
        return False, str(exc)[-3000:]
    finally:
        if probe:
            try:
                probe.remove(force=True)
            except Exception:
                pass
        else:
            try:
                client.containers.get(name).remove(force=True)
            except Exception:
                pass

def create_container(client, image, vps):
    labels = {
        "com.skvm.managed": "true",
        "com.skvm.vps_id": str(vps.id),
        "com.skvm.user_id": str(vps.user_id),
        "com.skvm.disk_limit": f"{vps.disk}G",
    }
    common = dict(
        image=image,
        command=["bash", "-lc", "sleep infinity"],
        detach=True,
        mem_limit=vps.ram * 1024 * 1024,
        nano_cpus=vps.cpu * 1_000_000_000,
        restart_policy={"Name": "unless-stopped"},
        labels=labels,
        name=f"skvm-{vps.id}-{secrets.token_hex(4)}",
    )

    # Strict is the production-safe default. Auto can fall back only when the
    # node cannot provide a real quota (e.g. many hosted/Docker-in-Docker nodes).
    mode = os.environ.get("SKVM_DISK_MODE", "auto").lower()
    quota_ok, quota_error = try_real_disk_quota(client, image, vps)

    if quota_ok:
        common["storage_opt"] = {"size": f"{vps.disk}G"}
        c = client.containers.run(**common)
        return c, True, f"Real Docker disk quota enforced: {vps.disk} GB"

    if mode == "strict":
        raise RuntimeError(
            f"Real disk quota is unavailable on this Docker node. "
            f"Requested {vps.disk} GB. Docker reported: {quota_error}"
        )

    if mode not in {"auto", "compat", "best-effort"}:
        raise RuntimeError(f"Invalid SKVM_DISK_MODE={mode!r}. Use strict, auto, or compat.")

    # Compatibility mode keeps the panel functional on restricted Docker-in-Docker
    # hosts, but never claims that the quota is enforced.
    common["labels"]["com.skvm.disk_enforced"] = "false"
    c = client.containers.run(**common)
    return c, False, (
        f"Disk quota NOT enforced by this Docker node. Requested {vps.disk} GB. "
        f"Real quota probe failed: {quota_error}"
    )

def provision(vps_id):
    with app.app_context():
        vps = db.session.get(VPS, vps_id)
        if not vps:
            return

        max_attempts = 3
        last_error = None

        for attempt in range(1, max_attempts + 1):
            container = None
            vps.provision_attempt = attempt
            vps.error_message = None
            vps.tmate_token = None
            vps.disk_enforced = False
            vps.disk_status = None
            db.session.commit()

            try:
                client = get_docker()
                if not client:
                    raise RuntimeError(
                        "Docker Engine is unavailable. Verify Docker is running and "
                        "the SKVM process can access its socket."
                    )

                update_progress(vps, 4, f"Attempt {attempt}/{max_attempts}: connecting to Docker…", "Provisioning")
                image = image_for(vps.os)
                if not image:
                    raise RuntimeError(f"Unsupported OS: {vps.os}")

                update_progress(vps, 10, f"Checking {image}…")
                try:
                    client.images.get(image)
                except Exception:
                    update_progress(vps, 16, f"Pulling {image} from Docker Hub…")
                    client.images.pull(image)

                update_progress(vps, 25, "Testing real disk quota support…")
                container, enforced, disk_message = create_container(client, image, vps)
                vps.container_id = container.id
                vps.disk_enforced = enforced
                vps.disk_status = disk_message
                db.session.commit()

                update_progress(vps, 35, "Container created. Installing tmate…")
                install_script = r"""
set -e
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
if ! apt-cache show tmate >/dev/null 2>&1; then
    apt-get install -y --no-install-recommends software-properties-common
    add-apt-repository -y universe || true
    apt-get update -y
fi
apt-get install -y --no-install-recommends ca-certificates tmate
test -x "$(command -v tmate)"
tmate -V
"""
                exec_container(container, install_script, 360)

                update_progress(vps, 60, "Starting tmate session…")
                exec_container(container, r"""
set -e
rm -f /tmp/skvm-tmate.sock
tmate -S /tmp/skvm-tmate.sock new-session -d
sleep 1
""", 60)

                update_progress(vps, 70, "Waiting for tmate relay registration…")
                ssh = None
                output = ""
                for relay_try in range(1, 11):
                    output = exec_container(
                        container,
                        r"""tmate -S /tmp/skvm-tmate.sock wait tmate-ready && tmate -S /tmp/skvm-tmate.sock display -p '#{tmate_ssh}'""",
                        35,
                    )
                    ssh = extract_tmate_ssh(output)
                    if ssh:
                        break
                    update_progress(vps, 70 + min(relay_try * 2, 18),
                                    f"Waiting for tmate relay… ({relay_try}/10)")
                    time.sleep(2)

                if not ssh:
                    raise RuntimeError(
                        "tmate did not return an SSH session after 10 relay checks. "
                        f"Last output: {output[-5000:]}"
                    )

                update_progress(vps, 94, "Verifying container and SSH session…")
                container.reload()
                if container.status != "running":
                    raise RuntimeError(f"Container stopped unexpectedly (status={container.status}).")

                vps.tmate_token = ssh
                vps.status = "Active"
                vps.progress = 100
                vps.progress_message = "VPS is ready."
                vps.error_message = None
                db.session.commit()
                return

            except Exception as exc:
                last_error = str(exc)
                vps.error_message = last_error[-8000:]
                vps.status = "Failed" if attempt == max_attempts else "Retrying"
                vps.progress_message = (
                    f"Attempt {attempt}/{max_attempts} failed. "
                    + ("Retrying automatically…" if attempt < max_attempts else "Automatic retries exhausted.")
                )
                db.session.commit()

                if container:
                    try:
                        container.remove(force=True)
                    except Exception:
                        pass
                vps.container_id = None
                vps.tmate_token = None
                db.session.commit()

                if attempt < max_attempts:
                    time.sleep(3 * attempt)

        vps.status = "Failed"
        vps.progress_message = "Provisioning failed. Review the detailed error below."
        vps.error_message = last_error or "Unknown provisioning error."
        db.session.commit()

def owned_vps(vps_id):
    vps = db.session.get(VPS, vps_id)
    if not vps:
        abort(404)
    if vps.user_id != current_user.id and current_user.role != "admin":
        abort(403)
    return vps

@app.route("/")
def starter():
    return redirect(url_for("dashboard")) if current_user.is_authenticated else render_template("starter.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        user = User.query.filter_by(username=request.form.get("username", "").strip()).first()
        if user and user.check_password(request.form.get("password", "")):
            login_user(user, remember=True)
            return redirect(url_for("dashboard"))
        flash("Invalid username or password.", "error")
    return render_template("login.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if not re.fullmatch(r"[A-Za-z0-9_.-]{3,32}", username):
            flash("Username must be 3–32 characters.", "error")
        elif len(password) < 8:
            flash("Password must be at least 8 characters.", "error")
        elif User.query.filter_by(username=username).first():
            flash("Username already exists.", "error")
        else:
            u = User(username=username, role="user")
            u.set_password(password)
            db.session.add(u)
            db.session.commit()
            flash("Account created. Please sign in.", "success")
            return redirect(url_for("login"))
    return render_template("register.html")

@app.post("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("starter"))

@app.route("/dashboard")
@login_required
def dashboard():
    vps = VPS.query.filter_by(user_id=current_user.id).order_by(VPS.created_at.desc()).all()
    return render_template("dashboard.html", vps_list=vps, active=sum(x.status == "Active" for x in vps))

@app.route("/myvps")
@login_required
def myvps():
    return render_template("myvps.html", vps_list=VPS.query.filter_by(user_id=current_user.id).order_by(VPS.created_at.desc()).all())

@app.route("/vps/<int:vps_id>")
@login_required
def vps_details(vps_id):
    return render_template("vps_details.html", vps=owned_vps(vps_id))

@app.post("/vps/<int:vps_id>/action/<action>")
@login_required
def vps_action(vps_id, action):
    vps = owned_vps(vps_id)
    container, client = (None, get_docker())
    if client and vps.container_id:
        try:
            container = client.containers.get(vps.container_id)
        except Exception:
            container = None
    if not container:
        flash("Docker container is unavailable.", "error")
        return redirect(url_for("vps_details", vps_id=vps.id))
    try:
        if action == "start":
            container.start()
            vps.status = "Active"
        elif action == "stop":
            container.stop(timeout=10)
            vps.status = "Stopped"
        elif action == "restart":
            container.restart(timeout=10)
            vps.status = "Active"
        else:
            abort(400)
        db.session.commit()
        flash(f"Container {action} successful.", "success")
    except Exception as exc:
        flash(str(exc), "error")
    return redirect(url_for("vps_details", vps_id=vps.id))

@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    if request.method == "POST":
        if not current_user.check_password(request.form.get("current_password", "")):
            flash("Current password is incorrect.", "error")
        elif len(request.form.get("new_password", "")) < 8:
            flash("New password must be at least 8 characters.", "error")
        else:
            current_user.set_password(request.form["new_password"])
            db.session.commit()
            flash("Password updated.", "success")
    return render_template("profile.html")

@app.route("/admin")
@admin_required
def admin_dashboard():
    client = get_docker()
    running = total = 0
    docker_ok = bool(client)
    if client:
        try:
            cs = client.containers.list(all=True, filters={"label": "com.skvm.managed=true"})
            total = len(cs)
            running = sum(c.status == "running" for c in cs)
        except Exception:
            docker_ok = False
    return render_template(
        "admin_dashboard.html", docker_ok=docker_ok, running=running,
        total_containers=total, users_count=User.query.count(),
        vps_count=VPS.query.count(),
        recent_vps=VPS.query.order_by(VPS.created_at.desc()).limit(10).all()
    )

@app.route("/admin/create-vps", methods=["GET", "POST"])
@admin_required
def create_vps():
    users = User.query.order_by(User.username.asc()).all()
    if request.method == "POST":
        try:
            owner = db.session.get(User, int(request.form["user_id"]))
            if not owner:
                raise ValueError("Selected user does not exist.")
            name = request.form.get("name", "").strip()
            if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9 _.-]{1,99}", name):
                raise ValueError("VPS name must be 2–100 characters.")
            v = VPS(
                name=name, user_id=owner.id,
                node="Local-Node-1",
                ram=parse_ram(request.form.get("ram")),
                disk=parse_disk(request.form.get("disk")),
                cpu=parse_cpu(request.form.get("cpu")),
                os=request.form.get("os", ""),
                status="Provisioning"
            )
            if not image_for(v.os):
                raise ValueError("Unsupported OS.")
            db.session.add(v)
            db.session.commit()
            threading.Thread(target=provision, args=(v.id,), daemon=True).start()
            return redirect(url_for("vps_details", vps_id=v.id))
        except Exception as exc:
            db.session.rollback()
            flash(str(exc), "error")
    return render_template("create_vps.html", users=users)

@app.route("/admin/users")
@admin_required
def user_management():
    return render_template("user_management.html", users=User.query.order_by(User.created_at.desc()).all())

@app.post("/admin/users/<int:user_id>/role")
@admin_required
def change_role(user_id):
    u = db.session.get(User, user_id)
    if not u:
        abort(404)
    if u.id == current_user.id:
        flash("You cannot change your own role here.", "error")
    else:
        u.role = "user" if u.role == "admin" else "admin"
        db.session.commit()
        flash("Role updated.", "success")
    return redirect(url_for("user_management"))

@app.post("/admin/users/<int:user_id>/delete")
@admin_required
def delete_user(user_id):
    u = db.session.get(User, user_id)
    if not u:
        abort(404)
    if u.id == current_user.id or u.role == "admin":
        flash("This account cannot be deleted here.", "error")
    else:
        client = get_docker()
        for v in list(u.vps):
            if client and v.container_id:
                try:
                    client.containers.get(v.container_id).remove(force=True)
                except Exception:
                    pass
        db.session.delete(u)
        db.session.commit()
        flash("User deleted.", "success")
    return redirect(url_for("user_management"))

@app.route("/admin/settings", methods=["GET", "POST"])
@admin_required
def settings():
    s = Settings.query.first()
    if request.method == "POST":
        s.panel_name = request.form.get("panel_name", "").strip()[:120] or "SKVM Panel"
        s.logo_url = request.form.get("logo_url", "").strip()[:1000] or None
        s.banner_url = request.form.get("banner_url", "").strip()[:1000] or None
        s.background_url = request.form.get("background_url", "").strip()[:1000] or None
        db.session.commit()
        flash("Settings saved.", "success")
    return render_template("settings.html")

@app.post("/vps/<int:vps_id>/retry")
@login_required
def retry_provision(vps_id):
    vps = owned_vps(vps_id)
    if vps.status not in {"Failed"}:
        flash("This VPS is not currently eligible for manual reprovisioning.", "error")
        return redirect(url_for("vps_details", vps_id=vps.id))
    vps.status = "Provisioning"
    vps.progress = 0
    vps.progress_message = "Manual retry queued…"
    vps.error_message = None
    db.session.commit()
    threading.Thread(target=provision, args=(vps.id,), daemon=True).start()
    flash("Provisioning retry started.", "success")
    return redirect(url_for("vps_details", vps_id=vps.id))

@app.get("/api/vps/<int:vps_id>/status")
@login_required
def vps_status_api(vps_id):
    v = owned_vps(vps_id)
    return jsonify(status=v.status, ssh=v.tmate_token, error=v.error_message, progress=v.progress, message=v.progress_message, attempt=v.provision_attempt, disk_enforced=v.disk_enforced, disk_status=v.disk_status)

@app.errorhandler(403)
def e403(_): return render_template("error.html", code=403, message="Access denied."), 403

@app.errorhandler(404)
def e404(_): return render_template("error.html", code=404, message="Page not found."), 404

@app.errorhandler(400)
def e400(e): return render_template("error.html", code=400, message=getattr(e, "description", "Bad request.")), 400

with app.app_context():
    migrate_schema()
    seed()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("SKVM_PORT", "5555")), debug=False, threaded=True)
