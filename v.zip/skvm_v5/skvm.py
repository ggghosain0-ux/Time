import os, re, time, secrets, threading, logging
from datetime import datetime, timezone
from functools import wraps

import docker
from docker.errors import DockerException, NotFound, APIError
from flask import Flask, render_template, request, redirect, url_for, flash, abort, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.path.join(BASE_DIR, "skvm.db")

app = Flask(__name__)
app.config.update(
    SECRET_KEY=os.getenv("SKVM_SECRET_KEY") or secrets.token_hex(32),
    SQLALCHEMY_DATABASE_URI=f"sqlite:///{DB_PATH}",
    SQLALCHEMY_TRACK_MODIFICATIONS=False,
    MAX_CONTENT_LENGTH=2 * 1024 * 1024,
)
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("skvm")

DOCKER_NETWORK = os.getenv("SKVM_DOCKER_NETWORK", "bridge")
# Keep both names for backwards compatibility with older V4 .env files.
SKVM_TUNNEL_IMAGE = os.getenv("SKVM_TUNNEL_IMAGE", "skvm/ubuntu22-tmate:latest")
SKVM_TUNNEL_IMAGE_20 = os.getenv("SKVM_TUNNEL_IMAGE_20", "skvm/ubuntu20-tmate:latest")
TUNNEL_IMAGE = SKVM_TUNNEL_IMAGE
TUNNEL_TIMEOUT = int(os.getenv("SKVM_TUNNEL_TIMEOUT", "90"))

_docker_client = None
_docker_lock = threading.Lock()

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default="user")
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    vps = db.relationship("VPS", backref="owner", lazy=True, cascade="all, delete-orphan")

class VPS(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False, index=True)
    node = db.Column(db.String(100), default="Local-Node-1", nullable=False)
    ram = db.Column(db.Integer, nullable=False, default=1024)       # MB
    disk = db.Column(db.Integer, nullable=False, default=10)        # GB requested; hard quota only when host supports it
    cpu = db.Column(db.Float, nullable=False, default=1)
    os = db.Column(db.String(50), nullable=False, default="Ubuntu 22.04")
    container_id = db.Column(db.String(128))
    tmate_token = db.Column(db.Text)
    status = db.Column(db.String(30), nullable=False, default="Provisioning")
    provisioning_error = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)

class Settings(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    panel_name = db.Column(db.String(120), default="SKVM Panel", nullable=False)
    logo_url = db.Column(db.String(500), default="")
    banner_url = db.Column(db.String(500), default="")
    background_url = db.Column(db.String(500), default="")

@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))

def admin_required(fn):
    @wraps(fn)
    @login_required
    def wrapper(*args, **kwargs):
        if current_user.role != "admin":
            abort(403)
        return fn(*args, **kwargs)
    return wrapper

def docker_client():
    global _docker_client
    with _docker_lock:
        if _docker_client is not None:
            try:
                _docker_client.ping()
                return _docker_client
            except Exception:
                _docker_client = None
        try:
            _docker_client = docker.from_env(timeout=30)
            _docker_client.ping()
            return _docker_client
        except Exception as exc:
            log.warning("Docker unavailable: %s", exc)
            return None

def exec_shell(container, command, timeout=180):
    result = container.exec_run(["bash", "-lc", command], stdout=True, stderr=True, demux=False)
    output = result.output.decode("utf-8", "replace") if result.output else ""
    if result.exit_code != 0:
        raise RuntimeError(output[-12000:] or f"Command failed with exit code {result.exit_code}")
    return output

def normalize_os(value):
    return "Ubuntu 20.04" if value == "Ubuntu 20.04" else "Ubuntu 22.04"

def image_for_os(os_name):
    return SKVM_TUNNEL_IMAGE_20 if os_name == "Ubuntu 20.04" else SKVM_TUNNEL_IMAGE

def safe_name(value):
    value = re.sub(r"[^a-zA-Z0-9_.-]+", "-", value.strip()).strip("-")[:45]
    return value or "skvm-vps"

def create_container(client, vps):
    image = image_for_os(vps.os)
    try:
        client.images.get(image)
    except NotFound:
        client.images.pull(image)
    mem = int(vps.ram) * 1024 * 1024
    nano_cpus = max(100_000_000, int(float(vps.cpu) * 1_000_000_000))
    kwargs = dict(
        image=image,
        name=f"skvm-{vps.id}-{safe_name(vps.name)}",
        detach=True,
        mem_limit=mem,
        nano_cpus=nano_cpus,
        restart_policy={"Name": "unless-stopped"},
        labels={"com.skvm.vps_id": str(vps.id), "com.skvm.managed": "true"},
    )
    if DOCKER_NETWORK == "host":
        kwargs["network_mode"] = "host"
    else:
        kwargs["network"] = DOCKER_NETWORK
    # Do not set storage_opt: many VPS/Docker-in-Docker hosts do not support
    # btrfs project quotas and Docker returns HTTP 500 when asked to enable them.
    return client.containers.run(**kwargs)

def provision_vps(vps_id):
    """Provision a prebuilt Ubuntu+tmate container and wait only for relay registration."""
    with app.app_context():
        vps = db.session.get(VPS, vps_id)
        if not vps:
            return
        client = docker_client()
        if not client:
            vps.status = "Error"
            vps.provisioning_error = "Docker Engine is unavailable. Check docker.service and the Docker socket."
            db.session.commit()
            return

        last_error = ""
        for attempt in range(1, 4):
            container = None
            try:
                vps.status = f"Provisioning ({attempt}/3)"
                vps.provisioning_error = None
                db.session.commit()

                if vps.container_id:
                    try:
                        client.containers.get(vps.container_id).remove(force=True)
                    except Exception:
                        pass
                    vps.container_id = None
                    db.session.commit()

                container = create_container(client, vps)
                vps.container_id = container.id
                vps.status = "Connecting to tmate"
                db.session.commit()

                # The image CMD has already started tmate. We only poll its socket.
                socket = "/tmp/skvm-tmate.sock"
                deadline = time.monotonic() + TUNNEL_TIMEOUT
                ssh = ""
                last_output = ""
                while time.monotonic() < deadline:
                    try:
                        result = container.exec_run(
                            ["bash", "-lc",
                             f"tmate -S {socket} display -p '#{{tmate_ssh}}' 2>&1"],
                            stdout=True, stderr=True
                        )
                        last_output = result.output.decode("utf-8", "replace").strip() if result.output else ""
                        # tmate returns an SSH URI such as ssh user@host.
                        match = re.search(r"\bssh\s+([A-Za-z0-9._-]+@[A-Za-z0-9._:-]+)", last_output)
                        if match:
                            ssh = "ssh " + match.group(1)
                            break
                    except Exception as exc:
                        last_output = str(exc)
                    time.sleep(0.5)

                if not ssh:
                    try:
                        log_output = container.exec_run(
                            ["bash", "-lc", "cat /tmp/skvm-tmate.log 2>/dev/null || true"],
                            stdout=True, stderr=True
                        ).output
                        tmate_log = log_output.decode("utf-8", "replace").strip() if log_output else ""
                    except Exception:
                        tmate_log = ""
                    detail = tmate_log or last_output or "No tmate output was returned."
                    raise RuntimeError(
                        "tmate relay registration timed out. The Docker container needs outbound DNS/TCP connectivity. "
                        f"Last output: {detail[-3000:]}"
                    )

                vps.tmate_token = ssh
                vps.status = "Active"
                vps.provisioning_error = None
                db.session.commit()
                log.info("VPS %s provisioned: %s", vps.id, ssh)
                return

            except Exception as exc:
                last_error = str(exc)
                log.exception("Provisioning attempt %s failed for VPS %s", attempt, vps_id)
                vps.provisioning_error = last_error[-10000:]
                vps.status = f"Retrying ({attempt}/3)" if attempt < 3 else "Error"
                db.session.commit()
                if container is not None and attempt < 3:
                    try:
                        container.remove(force=True)
                    except Exception:
                        pass
                if attempt < 3:
                    time.sleep(1.5 * attempt)

        vps.status = "Error"
        vps.provisioning_error = last_error[-10000:]
        db.session.commit()

def ensure_seed():
    db.create_all()
    settings = Settings.query.first()
    if not settings:
        db.session.add(Settings(panel_name="SKVM Panel"))
    username = os.getenv("SKVM_ADMIN_USERNAME", "admin").strip() or "admin"
    password = os.getenv("SKVM_ADMIN_PASSWORD", "admin123")
    admin = User.query.filter_by(username=username).first()
    if not admin:
        admin = User(username=username, role="admin", password_hash=generate_password_hash(password))
        db.session.add(admin)
    else:
        # Keep the requested fixed default on a fresh/default installation.
        if username == "admin" and os.getenv("SKVM_ADMIN_PASSWORD") in (None, "", "admin123"):
            admin.password_hash = generate_password_hash("admin123")
        admin.role = "admin"
    db.session.commit()

@app.context_processor
def globals_context():
    settings = Settings.query.first()
    return {"site": settings or Settings(panel_name="SKVM Panel")}

@app.after_request
def security_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "SAMEORIGIN"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    return response

@app.route("/")
def starter():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))
    return render_template("starter.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = User.query.filter_by(username=request.form.get("username","").strip()).first()
        if u and check_password_hash(u.password_hash, request.form.get("password","")):
            login_user(u, remember=True)
            return redirect(url_for("dashboard"))
        flash("Invalid username or password.", "error")
    return render_template("login.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username","").strip()
        password = request.form.get("password","")
        if len(username) < 3 or len(username) > 80 or len(password) < 8:
            flash("Username must be 3-80 characters and password must be at least 8 characters.", "error")
        elif User.query.filter_by(username=username).first():
            flash("Username already exists.", "error")
        else:
            db.session.add(User(username=username, password_hash=generate_password_hash(password), role="user"))
            db.session.commit()
            flash("Account created. You can now sign in.", "success")
            return redirect(url_for("login"))
    return render_template("register.html")

@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("starter"))

@app.route("/dashboard")
@login_required
def dashboard():
    mine = VPS.query.filter_by(user_id=current_user.id).all()
    return render_template("dashboard.html", vps_list=mine, active=sum(v.status=="Active" for v in mine))

@app.route("/myvps")
@login_required
def myvps():
    return render_template("myvps.html", vps_list=VPS.query.filter_by(user_id=current_user.id).order_by(VPS.created_at.desc()).all())

@app.route("/vps/<int:vps_id>")
@login_required
def vps_details(vps_id):
    vps = db.session.get(VPS, vps_id)
    if not vps or (vps.user_id != current_user.id and current_user.role != "admin"):
        abort(404)
    return render_template("vps_details.html", vps=vps)

@app.route("/vps/<int:vps_id>/action/<action>", methods=["POST"])
@login_required
def vps_action(vps_id, action):
    vps = db.session.get(VPS, vps_id)
    if not vps or (vps.user_id != current_user.id and current_user.role != "admin"):
        abort(404)
    client = docker_client()
    if not client or not vps.container_id:
        flash("Docker container is not available.", "error")
        return redirect(url_for("vps_details", vps_id=vps.id))
    try:
        c = client.containers.get(vps.container_id)
        if action == "start":
            c.start()
        elif action == "stop":
            c.stop(timeout=10)
        elif action == "restart":
            c.restart(timeout=10)
        else:
            abort(400)
        vps.status = "Active" if action in ("start","restart") else "Stopped"
        db.session.commit()
        flash(f"Container {action} completed.", "success")
    except Exception as exc:
        flash(f"Docker action failed: {exc}", "error")
    return redirect(url_for("vps_details", vps_id=vps.id))

@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    if request.method == "POST":
        old = request.form.get("old_password","")
        new = request.form.get("new_password","")
        if not check_password_hash(current_user.password_hash, old):
            flash("Current password is incorrect.", "error")
        elif len(new) < 8:
            flash("New password must be at least 8 characters.", "error")
        else:
            current_user.password_hash = generate_password_hash(new)
            db.session.commit()
            flash("Password updated.", "success")
    return render_template("profile.html")

@app.route("/admin")
@admin_required
def admin_dashboard():
    client = docker_client()
    containers = 0
    if client:
        try: containers = sum(1 for c in client.containers.list())
        except Exception: pass
    return render_template("admin_dashboard.html", users=User.query.count(), vps_count=VPS.query.count(), containers=containers, docker_ok=bool(client))

@app.route("/create-vps", methods=["GET", "POST"])
@app.route("/admin/create-vps", methods=["GET", "POST"])
@admin_required
def create_vps():
    users = User.query.order_by(User.username).all()
    if request.method == "POST":
        try:
            user_id = int(request.form["user_id"])
            user = db.session.get(User, user_id)
            if not user: raise ValueError("Selected user does not exist.")
            name = request.form.get("name","").strip()[:100]
            if not name: raise ValueError("VPS name is required.")
            ram = max(256, min(int(request.form.get("ram",1024)), 65536))
            disk = max(1, min(int(request.form.get("disk",10)), 10000))
            cpu = max(0.25, min(float(request.form.get("cpu",1)), 64))
            os_name = normalize_os(request.form.get("os"))
            vps = VPS(name=name, user_id=user.id, ram=ram, disk=disk, cpu=cpu, os=os_name, status="Provisioning")
            db.session.add(vps)
            db.session.commit()
            threading.Thread(target=provision_vps, args=(vps.id,), daemon=True).start()
            flash("VPS provisioning started. Open its details page to watch progress.", "success")
            return redirect(url_for("vps_details", vps_id=vps.id))
        except Exception as exc:
            db.session.rollback()
            flash(str(exc), "error")
    return render_template("create_vps.html", users=users)

@app.route("/admin/users")
@app.route("/user-management")
@admin_required
def user_management():
    users = User.query.order_by(User.created_at.desc()).all()
    return render_template("user_management.html", users=users)

@app.route("/admin/users/<int:user_id>/role", methods=["POST"])
@admin_required
def change_role(user_id):
    u = db.session.get(User, user_id)
    if not u: abort(404)
    if u.id == current_user.id:
        flash("You cannot change your own role.", "error")
    else:
        u.role = "admin" if u.role == "user" else "user"
        db.session.commit()
    return redirect(url_for("user_management"))

@app.route("/admin/users/<int:user_id>/delete", methods=["POST"])
@admin_required
def delete_user(user_id):
    u = db.session.get(User, user_id)
    if not u or u.id == current_user.id:
        abort(400)
    for v in list(u.vps):
        if v.container_id:
            client = docker_client()
            if client:
                try: client.containers.get(v.container_id).remove(force=True)
                except Exception: pass
    db.session.delete(u)
    db.session.commit()
    return redirect(url_for("user_management"))

@app.route("/settings", methods=["GET", "POST"])
@app.route("/admin/settings", methods=["GET", "POST"])
@admin_required
def settings():
    s = Settings.query.first() or Settings(panel_name="SKVM Panel")
    if request.method == "POST":
        s.panel_name = request.form.get("panel_name","SKVM Panel").strip()[:120] or "SKVM Panel"
        s.logo_url = request.form.get("logo_url","").strip()[:500]
        s.banner_url = request.form.get("banner_url","").strip()[:500]
        s.background_url = request.form.get("background_url","").strip()[:500]
        db.session.add(s); db.session.commit()
        flash("Settings saved.", "success")
    return render_template("settings.html")

@app.route("/health")
def health():
    client = docker_client()
    return jsonify(status="ok", docker=bool(client), database=True, tmate_images={"ubuntu22": SKVM_TUNNEL_IMAGE, "ubuntu20": SKVM_TUNNEL_IMAGE_20}), 200

@app.errorhandler(403)
def forbidden(_): return render_template("starter.html", error="Forbidden"), 403

with app.app_context():
    ensure_seed()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("SKVM_PORT","5555")), debug=os.getenv("SKVM_DEBUG","0") == "1")
