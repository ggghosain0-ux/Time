# SKVM V5

Production-oriented Docker VPS management panel with prebuilt Ubuntu + tmate images.

## Default login
- Username: `admin`
- Password: `admin123`

## Install
```bash
sudo bash install.sh
```

The installer:
1. Installs Docker Engine and Python.
2. Builds the Ubuntu 22.04 and 20.04 images with tmate preinstalled.
3. Creates the Python virtual environment and installs dependencies.
4. Creates/updates `.env`.
5. Initializes SQLite and the fixed admin account.
6. Installs and enables the `skvm.service` systemd unit.
7. Opens TCP 5555 and verifies the service.

## Fast tmate provisioning
The VPS container image starts tmate from its Docker CMD. SKVM does not run `apt-get` or install tmate during VPS creation. It polls the tmate socket every 0.5 seconds for `#{tmate_ssh}`.

A real tmate SSH URL still depends on the remote relay registration. No application can guarantee zero network latency. If the container has blocked outbound DNS/TCP connectivity, tmate cannot register.

## Disk
SKVM intentionally does not pass Docker `storage_opt`/btrfs quota settings because unsupported Docker storage drivers return HTTP 500 and can break provisioning. The requested disk size is recorded/displayed but is not a hard filesystem quota unless you add a host-specific storage/quota implementation.

## V4 bug fixed in V5
V4 could call `SKVM_TUNNEL_IMAGE` and `SKVM_TUNNEL_IMAGE_20` without defining those Python variables. V5 defines both variables explicitly and keeps `TUNNEL_IMAGE` as a backwards-compatible alias.
