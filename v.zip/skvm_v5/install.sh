#!/usr/bin/env bash
set -Eeuo pipefail
trap 'echo; echo "ERROR: install failed at line $LINENO" >&2; echo "Check: sudo journalctl -u skvm -n 100 --no-pager" >&2' ERR

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_USER="${SUDO_USER:-${USER}}"
VENV="$APP_DIR/venv"

[[ $EUID -eq 0 ]] || { echo "Run: sudo bash install.sh"; exit 1; }
id "$APP_USER" >/dev/null 2>&1 || { echo "Could not determine the normal login user."; exit 1; }

export DEBIAN_FRONTEND=noninteractive

echo "[1/9] Installing base packages..."
apt-get update -y
apt-get install -y ca-certificates curl gnupg lsb-release python3 python3-venv python3-pip python3-dev build-essential ufw

# Install Docker Engine from Docker's repository when possible. If the repository
# cannot be reached, fall back to the distro package.
echo "[2/9] Installing Docker Engine..."
if ! command -v docker >/dev/null 2>&1; then
  install -m 0755 -d /etc/apt/keyrings
  if curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc; then
    chmod a+r /etc/apt/keyrings/docker.asc
    . /etc/os-release
    echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu ${VERSION_CODENAME} stable" > /etc/apt/sources.list.d/docker.list
    apt-get update -y
    apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin || true
  fi
fi
if ! command -v docker >/dev/null 2>&1; then
  apt-get update -y
  apt-get install -y docker.io
fi

systemctl enable --now docker
usermod -aG docker "$APP_USER" || true

echo "[3/9] Validating Docker..."
docker version >/dev/null
docker info >/dev/null

# Build the tmate-enabled images once. VPS creation never runs apt-get.
echo "[4/9] Building SKVM fast VPS images..."
docker build --pull -f "$APP_DIR/Dockerfile.ubuntu22-tmate" -t skvm/ubuntu22-tmate:latest "$APP_DIR"
docker build --pull -f "$APP_DIR/Dockerfile.ubuntu20-tmate" -t skvm/ubuntu20-tmate:latest "$APP_DIR"

echo "[5/9] Installing Python dependencies..."
python3 -m venv "$VENV"
"$VENV/bin/python" -m pip install --upgrade pip wheel
"$VENV/bin/pip" install -r "$APP_DIR/requirements.txt"

# Generate a secret only once; do not overwrite an existing secret.
echo "[6/9] Configuring SKVM..."
if [[ ! -f "$APP_DIR/.env" ]]; then
  SECRET="$(python3 -c 'import secrets; print(secrets.token_hex(32))')"
  cat > "$APP_DIR/.env" <<ENV
SKVM_SECRET_KEY=$SECRET
SKVM_PORT=5555
SKVM_ADMIN_USERNAME=admin
SKVM_ADMIN_PASSWORD=admin123
SKVM_TUNNEL_TIMEOUT=90
SKVM_DOCKER_NETWORK=bridge
SKVM_TUNNEL_IMAGE=skvm/ubuntu22-tmate:latest
SKVM_TUNNEL_IMAGE_20=skvm/ubuntu20-tmate:latest
SKVM_DEBUG=0
ENV
else
  # Normalize required production settings while preserving the existing secret.
  grep -q '^SKVM_SECRET_KEY=' "$APP_DIR/.env" || echo "SKVM_SECRET_KEY=$(python3 -c 'import secrets; print(secrets.token_hex(32))')" >> "$APP_DIR/.env"
  for pair in \
    'SKVM_PORT=5555' \
    'SKVM_ADMIN_USERNAME=admin' \
    'SKVM_ADMIN_PASSWORD=admin123' \
    'SKVM_TUNNEL_TIMEOUT=90' \
    'SKVM_DOCKER_NETWORK=bridge' \
    'SKVM_TUNNEL_IMAGE=skvm/ubuntu22-tmate:latest' \
    'SKVM_TUNNEL_IMAGE_20=skvm/ubuntu20-tmate:latest' \
    'SKVM_DEBUG=0'; do
      key="${pair%%=*}"
      if grep -q "^${key}=" "$APP_DIR/.env"; then
        sed -i "s#^${key}=.*#${pair}#" "$APP_DIR/.env"
      else
        echo "$pair" >> "$APP_DIR/.env"
      fi
  done
fi
chmod 600 "$APP_DIR/.env"
chown -R "$APP_USER":"$APP_USER" "$APP_DIR"

# Reset/create the fixed default admin account exactly as requested.
echo "[7/9] Initializing database and admin account..."
cd "$APP_DIR"
set -a
. "$APP_DIR/.env"
set +a
"$VENV/bin/python" - <<'PY'
from skvm import app, db, User, ensure_seed
from werkzeug.security import generate_password_hash
with app.app_context():
    db.create_all()
    u = User.query.filter_by(username="admin").first()
    if u is None:
        u = User(username="admin", role="admin", password_hash=generate_password_hash("admin123"))
        db.session.add(u)
    else:
        u.role = "admin"
        u.password_hash = generate_password_hash("admin123")
    db.session.commit()
print("Database ready")
PY

# Make systemd run as the selected user, with access to Docker's socket.
echo "[8/9] Installing systemd service and firewall rule..."
cat > /etc/systemd/system/skvm.service <<SERVICE
[Unit]
Description=SKVM VPS Management Panel
Documentation=https://example.invalid/skvm
After=docker.service network-online.target
Requires=docker.service
Wants=network-online.target

[Service]
Type=simple
User=$APP_USER
WorkingDirectory=$APP_DIR
EnvironmentFile=$APP_DIR/.env
ExecStartPre=/usr/bin/docker info
ExecStart=$VENV/bin/gunicorn --bind 0.0.0.0:5555 --workers 2 --threads 4 --timeout 300 --access-logfile - --error-logfile - skvm:app
Restart=always
RestartSec=3
KillSignal=SIGTERM
TimeoutStopSec=30

[Install]
WantedBy=multi-user.target
SERVICE

ufw allow 5555/tcp >/dev/null 2>&1 || true
systemctl daemon-reload
systemctl enable skvm
systemctl restart skvm
sleep 2

echo "[9/9] Verifying service..."
if ! systemctl is-active --quiet skvm; then
  systemctl --no-pager --full status skvm || true
  journalctl -u skvm -n 80 --no-pager || true
  exit 1
fi

IP="$(hostname -I | awk '{print $1}')"
echo
echo "=========================================="
echo " SKVM V5 INSTALLED SUCCESSFULLY"
echo "=========================================="
echo "Panel: http://${IP}:5555"
echo "Admin username: admin"
echo "Admin password: admin123"
echo "tmate: preinstalled in images"
echo "quota: no btrfs probe / no storage_opt"
echo "=========================================="
