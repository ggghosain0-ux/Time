#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [ "$(id -u)" -ne 0 ]; then echo "Run: sudo ./install.sh"; exit 1; fi
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y python3 python3-venv python3-pip ca-certificates curl docker.io
systemctl enable --now docker || true
python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip setuptools wheel
.venv/bin/python -m pip install -r requirements.txt
cat >/etc/systemd/system/sky-panel.service <<EOF
[Unit]
Description=SKY Panel V2
After=docker.service network-online.target
Requires=docker.service
[Service]
WorkingDirectory=$(pwd)
Environment=PORT=5555
Environment=SKY_SECRET_KEY=$(python3 -c 'import secrets; print(secrets.token_hex(32))')
ExecStart=$(pwd)/.venv/bin/gunicorn --workers 2 --threads 4 --timeout 180 --bind 0.0.0.0:5555 app:app
Restart=always
RestartSec=3
[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable --now sky-panel
echo "SKY Panel V2 installed."
echo "Open: http://SERVER_IP:5555"
echo "Admin: admin / admin123"
