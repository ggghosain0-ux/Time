# SKY Panel V2

A new web UI over the Docker/tmate engine pattern from the supplied Discord VPS deployer.

## Important
SKY Panel creates **Docker containers**, not full KVM virtual machines. Resource limits are Docker limits.

### Login
- Username: `admin`
- Password: `admin123`

Change the admin password immediately from Profile.

### Ubuntu/Debian host
```bash
chmod +x install.sh
sudo ./install.sh
```

Open TCP 5555.

### CodeSandbox / development
Docker must be available to the workspace if you want real VPS creation:
```bash
chmod +x start.sh
./start.sh
```

If Docker is not exposed by the workspace, the panel UI can run but container creation cannot.

## tmate behavior
A container is marked `running` as soon as Docker starts it. tmate setup then runs in a background worker. The panel displays only the `tmate_ssh` command when it is successfully returned.

A tmate relay/network failure does not make the Docker container fail.

## Pages
- Dashboard
- VPS details
- Create VPS (admin)
- Admin
- Settings
- Profile
- Error/health

## OS images
- Ubuntu 22.04
- Ubuntu 24.04
- Debian 12

Images are pulled from the official Docker registry only when absent locally.

## Security
This is intended for a trusted VPS node. Do not expose Docker's socket or the panel to untrusted users. Use HTTPS/reverse proxy for production and change the default admin password.
