import os, re, json, time, secrets, sqlite3, threading, subprocess, shlex
from datetime import datetime, timezone
from functools import wraps

from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, abort
from werkzeug.security import generate_password_hash, check_password_hash

try:
    import docker
    from docker.errors import DockerException, NotFound, APIError
except Exception:
    docker = None

APP_NAME = "SKY Panel V2"
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("SKY_DB", os.path.join(BASE_DIR, "sky_panel.db"))
PORT = int(os.environ.get("PORT", "5555"))
SECRET_KEY = os.environ.get("SKY_SECRET_KEY") or secrets.token_hex(32)
ADMIN_USER = os.environ.get("SKY_ADMIN_USER", "admin")
ADMIN_PASS = os.environ.get("SKY_ADMIN_PASS", "admin123")
DATA_DIR = os.environ.get("SKY_DATA_DIR", os.path.join(BASE_DIR, "vps_data"))

app = Flask(__name__)
app.secret_key = SECRET_KEY
os.makedirs(DATA_DIR, exist_ok=True)

OS_IMAGES = {
    "ubuntu22": "ubuntu:22.04",
    "ubuntu24": "ubuntu:24.04",
    "debian12": "debian:12",
}
TMATE_INSTALL = (
    "export DEBIAN_FRONTEND=noninteractive; "
    "apt-get update -qq; "
    "apt-get install -y -qq tmate openssh-client ca-certificates >/dev/null 2>&1"
)

def now():
    return datetime.now(timezone.utc).isoformat()

def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    con = db()
    con.executescript("""
    CREATE TABLE IF NOT EXISTS users(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'user',
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS vps(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      owner_id INTEGER NOT NULL,
      os TEXT NOT NULL,
      ram_mb INTEGER NOT NULL,
      cpu REAL NOT NULL,
      disk_gb INTEGER NOT NULL,
      container_id TEXT,
      container_name TEXT UNIQUE,
      status TEXT NOT NULL DEFAULT 'provisioning',
      tmate_ssh TEXT,
      tmate_status TEXT NOT NULL DEFAULT 'pending',
      error TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY(owner_id) REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS settings(
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS audit(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      actor TEXT NOT NULL,
      action TEXT NOT NULL,
      details TEXT,
      created_at TEXT NOT NULL
    );
    """)
    admin = con.execute("SELECT id FROM users WHERE username=?", (ADMIN_USER,)).fetchone()
    if not admin:
        con.execute("INSERT INTO users(username,password_hash,role,created_at) VALUES(?,?,?,?)",
                    (ADMIN_USER, generate_password_hash(ADMIN_PASS), "admin", now()))
    for k,v in {
        "panel_name": APP_NAME,
        "registration": "false",
        "tmate_enabled": "true",
        "maintenance": "false",
    }.items():
        con.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (k,v))
    con.commit(); con.close()

def audit(actor, action, details=""):
    con=db(); con.execute("INSERT INTO audit(actor,action,details,created_at) VALUES(?,?,?,?)",
                          (actor,action,details,now())); con.commit(); con.close()

def setting(key, default=""):
    con=db(); row=con.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone(); con.close()
    return row["value"] if row else default

def docker_client():
    if docker is None:
        raise RuntimeError("Python Docker SDK is not installed.")
    try:
        return docker.from_env()
    except Exception as e:
        raise RuntimeError(f"Docker daemon unavailable: {e}")

def login_required(f):
    @wraps(f)
    def w(*a,**kw):
        if not session.get("uid"): return redirect(url_for("login", next=request.path))
        return f(*a,**kw)
    return w

def admin_required(f):
    @wraps(f)
    def w(*a,**kw):
        if not session.get("uid"): return redirect(url_for("login", next=request.path))
        if session.get("role") != "admin": abort(403)
        return f(*a,**kw)
    return w

def get_vps(vps_id):
    con=db(); row=con.execute("""
      SELECT v.*, u.username owner_name FROM vps v JOIN users u ON u.id=v.owner_id WHERE v.id=?
    """,(vps_id,)).fetchone(); con.close(); return row

def allowed_owner(vps_id):
    row=get_vps(vps_id)
    return row and (session.get("role")=="admin" or row["owner_id"]==session.get("uid"))

def set_vps(vps_id, **fields):
    if not fields: return
    con=db()
    parts=[]; vals=[]
    for k,v in fields.items(): parts.append(f"{k}=?"); vals.append(v)
    parts.append("updated_at=?"); vals.append(now()); vals.append(vps_id)
    con.execute(f"UPDATE vps SET {', '.join(parts)} WHERE id=?", vals)
    con.commit(); con.close()

def safe_name(s):
    s=re.sub(r"[^a-zA-Z0-9_.-]+","-",s.strip()).strip("-").lower()
    return (s[:40] or "sky-vps")

def create_container(vps_id):
    row=get_vps(vps_id)
    client=docker_client()
    image=OS_IMAGES[row["os"]]
    try:
        client.images.get(image)
    except Exception:
        client.images.pull(image)
    name=f"skyv2_{row['id']}_{safe_name(row['name'])}"
    host_dir=os.path.join(DATA_DIR, str(row["id"]))
    os.makedirs(host_dir, exist_ok=True)
    mem=row["ram_mb"]*1024*1024
    nano=max(100_000_000, int(float(row["cpu"])*1_000_000_000))
    c=client.containers.run(
        image=image,
        name=name,
        command=["bash","-lc","while true; do sleep 3600; done"],
        detach=True, tty=True, stdin_open=True,
        mem_limit=mem, nano_cpus=nano,
        volumes={host_dir: {"bind":"/data","mode":"rw"}},
        restart_policy={"Name":"unless-stopped"},
        labels={"sky.panel":"v2","sky.vps_id":str(row["id"])}
    )
    set_vps(vps_id, container_id=c.id, container_name=name, status="running", error=None)
    return c

def run_exec(c, command, timeout=180):
    # Docker SDK exec is synchronous; run it in a worker thread for Flask requests.
    r=c.exec_run(["bash","-lc",command], demux=False)
    out=(r.output or b"").decode("utf-8","replace").strip()
    if r.exit_code != 0:
        raise RuntimeError(out[-3000:] or f"Command failed with exit code {r.exit_code}")
    return out

def tmate_worker(vps_id):
    try:
        row=get_vps(vps_id)
        if setting("tmate_enabled","true") != "true":
            set_vps(vps_id, tmate_status="disabled"); return
        client=docker_client(); c=client.containers.get(row["container_id"])
        set_vps(vps_id, tmate_status="installing", error=None)
        run_exec(c, TMATE_INSTALL, 180)
        # Create a detached tmate session and ask tmate for the SSH command.
        cmd = (
          "rm -f /tmp/sky-tmate.sock; "
          "tmate -S /tmp/sky-tmate.sock new-session -d; "
          "tmate -S /tmp/sky-tmate.sock wait tmate-ready; "
          "tmate -S /tmp/sky-tmate.sock display -p '#{tmate_ssh}'"
        )
        ssh = run_exec(c, cmd, 120)
        if not ssh.startswith("ssh ") or "@" not in ssh:
            raise RuntimeError("tmate did not return an SSH session command.")
        set_vps(vps_id, tmate_ssh=ssh, tmate_status="ready", status="running")
        audit("system","tmate_ready",f"VPS {vps_id}")
    except Exception as e:
        set_vps(vps_id, tmate_status="error", error=str(e))
        audit("system","tmate_error",f"VPS {vps_id}: {e}")

def start_tmate(vps_id):
    t=threading.Thread(target=tmate_worker,args=(vps_id,),daemon=True); t.start()

def container_action(vps_id, action):
    row=get_vps(vps_id)
    if not row: abort(404)
    client=docker_client(); c=client.containers.get(row["container_id"])
    if action=="start": c.start()
    elif action=="stop": c.stop(timeout=10)
    elif action=="restart": c.restart(timeout=10)
    elif action=="delete": c.remove(force=True)
    else: raise ValueError("Unknown action")
    status={"start":"running","stop":"stopped","restart":"running"}.get(action)
    if status: set_vps(vps_id,status=status)
    audit(session.get("username","unknown"), action, f"VPS {vps_id}")
    return True

@app.context_processor
def inject():
    return {"panel_name":setting("panel_name",APP_NAME), "user_role":session.get("role")}

@app.route("/")
def index():
    if not session.get("uid"): return redirect(url_for("login"))
    return redirect(url_for("dashboard"))

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method=="POST":
        con=db(); u=con.execute("SELECT * FROM users WHERE username=?", (request.form.get("username",""),)).fetchone(); con.close()
        if u and check_password_hash(u["password_hash"],request.form.get("password","")):
            session.clear(); session.update(uid=u["id"],username=u["username"],role=u["role"])
            return redirect(request.args.get("next") or url_for("dashboard"))
        flash("Invalid username or password.","error")
    return render_template("login.html")

@app.post("/logout")
def logout():
    session.clear(); return redirect(url_for("login"))

@app.route("/dashboard")
@login_required
def dashboard():
    con=db()
    if session["role"]=="admin":
        rows=con.execute("SELECT v.*,u.username owner_name FROM vps v JOIN users u ON u.id=v.owner_id ORDER BY v.id DESC").fetchall()
        users=con.execute("SELECT id,username FROM users WHERE role='user' ORDER BY username").fetchall()
    else:
        rows=con.execute("SELECT v.*,u.username owner_name FROM vps v JOIN users u ON u.id=v.owner_id WHERE owner_id=? ORDER BY v.id DESC",(session["uid"],)).fetchall()
        users=[]
    con.close()
    return render_template("dashboard.html", vps=rows, users=users)

@app.route("/vps/<int:vps_id>")
@login_required
def vps_details(vps_id):
    row=get_vps(vps_id)
    if not row or not allowed_owner(vps_id): abort(404)
    return render_template("vps_details.html", vps=row)

@app.post("/admin/vps/create")
@admin_required
def create_vps():
    try:
        name=request.form.get("name","VPS").strip()
        owner=int(request.form["owner_id"]); oskey=request.form["os"]
        ram=int(request.form["ram_mb"]); cpu=float(request.form["cpu"]); disk=int(request.form["disk_gb"])
        if oskey not in OS_IMAGES or ram < 256 or ram > 65536 or cpu <= 0 or cpu > 64 or disk < 1 or disk > 4096:
            raise ValueError("Invalid VPS resources.")
        con=db(); u=con.execute("SELECT id FROM users WHERE id=?",(owner,)).fetchone()
        if not u: raise ValueError("Selected user does not exist.")
        cur=con.execute("""INSERT INTO vps(name,owner_id,os,ram_mb,cpu,disk_gb,status,created_at,updated_at)
                           VALUES(?,?,?,?,?,?,?,?,?)""",
                        (name,owner,oskey,ram,cpu,disk,"provisioning",now(),now()))
        vid=cur.lastrowid; con.commit(); con.close()
        try:
            create_container(vid)
            start_tmate(vid)
            audit(session["username"],"create_vps",f"VPS {vid}")
            flash("VPS created. tmate generation is running in the background.","success")
        except Exception as e:
            set_vps(vid,status="error",error=str(e)); audit(session["username"],"create_vps_error",f"VPS {vid}: {e}")
            flash(f"Container creation failed: {e}","error")
        return redirect(url_for("vps_details",vps_id=vid))
    except Exception as e:
        flash(str(e),"error"); return redirect(url_for("dashboard"))

@app.post("/vps/<int:vps_id>/action/<action>")
@login_required
def vps_action(vps_id,action):
    if not allowed_owner(vps_id): abort(403)
    if action=="delete" and session["role"]!="admin": abort(403)
    try:
        if action in ("start","stop","restart"):
            container_action(vps_id,action)
            if action in ("start","restart"): start_tmate(vps_id)
        elif action=="tmate":
            start_tmate(vps_id)
        elif action=="reprovision":
            if session["role"]!="admin": abort(403)
            row=get_vps(vps_id); client=docker_client()
            try: client.containers.get(row["container_id"]).remove(force=True)
            except Exception: pass
            set_vps(vps_id,container_id=None,container_name=None,status="provisioning",tmate_ssh=None,tmate_status="pending",error=None)
            create_container(vps_id); start_tmate(vps_id)
        elif action=="delete":
            container_action(vps_id,"delete")
            con=db(); con.execute("DELETE FROM vps WHERE id=?",(vps_id,)); con.commit(); con.close()
            flash("VPS deleted.","success"); return redirect(url_for("dashboard"))
        else: abort(404)
        flash(f"{action.title()} request completed.","success")
    except Exception as e:
        set_vps(vps_id,status="error",error=str(e)); flash(str(e),"error")
    return redirect(url_for("vps_details",vps_id=vps_id))

@app.route("/admin")
@admin_required
def admin():
    con=db(); users=con.execute("SELECT id,username,role,created_at FROM users ORDER BY id").fetchall()
    vps=con.execute("SELECT v.*,u.username owner_name FROM vps v JOIN users u ON u.id=v.owner_id ORDER BY v.id DESC").fetchall()
    logs=con.execute("SELECT * FROM audit ORDER BY id DESC LIMIT 50").fetchall(); con.close()
    return render_template("admin.html",users=users,vps=vps,logs=logs)

@app.post("/admin/users/create")
@admin_required
def user_create():
    username=request.form.get("username","").strip(); password=request.form.get("password","")
    if not re.fullmatch(r"[A-Za-z0-9_.-]{3,32}",username) or len(password)<6:
        flash("Username must be 3-32 characters and password at least 6 characters.","error"); return redirect(url_for("admin"))
    try:
        con=db(); con.execute("INSERT INTO users(username,password_hash,role,created_at) VALUES(?,?,?,?)",
                              (username,generate_password_hash(password),"user",now())); con.commit(); con.close()
        audit(session["username"],"create_user",username); flash("User created.","success")
    except sqlite3.IntegrityError: flash("Username already exists.","error")
    return redirect(url_for("admin"))

@app.post("/admin/users/<int:user_id>/delete")
@admin_required
def user_delete(user_id):
    if user_id==session["uid"]: abort(400)
    con=db(); rows=con.execute("SELECT id,container_id FROM vps WHERE owner_id=?",(user_id,)).fetchall()
    con.close()
    client=docker_client()
    for r in rows:
        try: client.containers.get(r["container_id"]).remove(force=True)
        except Exception: pass
    con=db(); con.execute("DELETE FROM vps WHERE owner_id=?",(user_id,)); con.execute("DELETE FROM users WHERE id=? AND role!='admin'",(user_id,)); con.commit(); con.close()
    flash("User and assigned VPS records removed.","success"); return redirect(url_for("admin"))

@app.route("/system")
@admin_required
def system_page():
    info={"docker":"error","containers":0}
    try:
        c=docker_client()
        info["docker"]="ok"
        info["containers"]=len(c.containers.list(all=True))
        info["running"]=len(c.containers.list())
        info["images"]=len(c.images.list())
    except Exception as e:
        info["error"]=str(e)
    return render_template("system.html", info=info)

@app.post("/admin/reset")
@admin_required
def reset_system():
    con=db(); rows=con.execute("SELECT container_id FROM vps").fetchall()
    con.close()
    try:
        client=docker_client()
        for r in rows:
            try: client.containers.get(r["container_id"]).remove(force=True)
            except Exception: pass
    except Exception as e:
        flash(f"Docker reset warning: {e}","error")
    con=db(); con.execute("DELETE FROM vps"); con.commit(); con.close()
    audit(session["username"],"system_reset","All VPS records and containers removed")
    flash("System reset completed.","success")
    return redirect(url_for("admin"))

@app.route("/settings",methods=["GET","POST"])
@admin_required
def settings():
    if request.method=="POST":
        vals={k:request.form.get(k,"") for k in ["panel_name","registration","tmate_enabled","maintenance"]}
        con=db()
        for k,v in vals.items(): con.execute("INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)",(k,v))
        con.commit(); con.close(); audit(session["username"],"settings_updated",json.dumps(vals))
        flash("Settings saved.","success")
    return render_template("settings.html",
        panel_name=setting("panel_name",APP_NAME),
        registration=setting("registration")=="true",
        tmate_enabled=setting("tmate_enabled","true")=="true",
        maintenance=setting("maintenance")=="true")

@app.post("/profile")
@login_required
def profile():
    current=request.form.get("current",""); new=request.form.get("new","")
    con=db(); u=con.execute("SELECT * FROM users WHERE id=?",(session["uid"],)).fetchone()
    if not check_password_hash(u["password_hash"],current) or len(new)<6:
        con.close(); flash("Current password is incorrect or new password is too short.","error"); return redirect(url_for("dashboard"))
    con.execute("UPDATE users SET password_hash=? WHERE id=?",(generate_password_hash(new),session["uid"])); con.commit(); con.close()
    flash("Password changed.","success"); return redirect(url_for("dashboard"))

@app.route("/profile",methods=["GET"])
@login_required
def profile_page():
    return render_template("profile.html")

@app.get("/health")
def health():
    out={"panel":"ok","docker":"error"}
    try:
        c=docker_client(); out["docker"]="ok"; out["containers"]=len(c.containers.list(all=True))
    except Exception as e: out["docker_error"]=str(e)
    return jsonify(out)

@app.errorhandler(403)
def forbidden(e): return render_template("error.html",code=403,message="You do not have permission to perform this action."),403
@app.errorhandler(404)
def not_found(e): return render_template("error.html",code=404,message="Page or VPS not found."),404

init_db()

if __name__=="__main__":
    app.run(host="0.0.0.0",port=PORT,debug=False)
