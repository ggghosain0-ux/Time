#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
PYTHON_BIN="${PYTHON_BIN:-python3}"
if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
  echo "Python 3 is required."; exit 1
fi
if [ ! -d .venv ] || ! .venv/bin/python -c 'import pip' >/dev/null 2>&1; then
  rm -rf .venv
  "$PYTHON_BIN" -m venv .venv --without-pip 2>/dev/null || "$PYTHON_BIN" -m venv .venv
fi
if ! .venv/bin/python -c 'import pip' >/dev/null 2>&1; then
  .venv/bin/python -m ensurepip --upgrade >/dev/null 2>&1 || true
fi
.venv/bin/python -m pip install -q --upgrade pip setuptools wheel
.venv/bin/python -m pip install -q -r requirements.txt
export PORT="${PORT:-5555}"
exec .venv/bin/python app.py
