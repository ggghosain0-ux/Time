# SKVM Production V4

Fast Docker VPS panel with prebuilt Ubuntu+tmate images.

## Install
```bash
sudo bash install.sh
```

The installer builds the tmate base images once. Each VPS then starts tmate without running apt-get inside the new container.

Default admin: `admin` / `admin123`

Panel: `http://SERVER_IP:5555`

## Important
A tmate SSH address is created by a remote relay, so literally zero-latency generation is impossible. V4 minimizes local provisioning latency by preinstalling tmate and polling the relay every 0.75 seconds. The Docker container must have outbound DNS/TCP access.

Storage quota enforcement is intentionally disabled when the Docker host does not support it; CPU/RAM limits remain real Docker limits.
