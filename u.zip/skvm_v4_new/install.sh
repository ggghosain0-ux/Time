#!/usr/bin/env bash
set -Eeuo pipefail
trap 'echo "ERROR: install failed at line $LINENO. Run: sudo journalctl -u skvm -n 100 --no-pager" >&2' ERR

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_USER="${SUDO_USER:-${USER}}"
VENV="$APP_DIR/venv"

if [[ $EUID -ne 0 ]]; then echo "Run: sudo bash install.sh"; exit 1; fi
if ! id "$APP_USER" >/dev/null 2>&1; then echo "Cannot determine a normal login user."; exit 1; fi

echo "[1/8] Installing system packages..."
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y python3 python3-venv python3-pip python3-dev build-essential ca-certificates curl docker.io

echo "[2/8] Starting Docker..."
systemctl enable --now docker
usermod -aG docker "$APP_USER" || true

echo "[3/8] Building fast tmate base images (one-time)..."
docker build -f "$APP_DIR/Dockerfile.ubuntu22-tmate" -t skvm/ubuntu22-tmate:latest "$APP_DIR"
docker build -f "$APP_DIR/Dockerfile.ubuntu20-tmate" -t skvm/ubuntu20-tmate:latest "$APP_DIR"

echo "[4/8] Creating Python environment..."
python3 -m venv "$VENV"
"$VENV/bin/pip" install --upgrade pip wheel
"$VENV/bin/pip" install -r "$APP_DIR/requirements.txt"

echo "[5/8] Creating secure environment..."
if [[ ! -f "$APP_DIR/.env" ]]; then
  SECRET="$(python3 -c 'import secrets; print(secrets.token_hex(32))')"
  cat > "$APP_DIR/.env" <<ENV
SKVM_SECRET_KEY=$SECRET
SKVM_PORT=5555
SKVM_ADMIN_USERNAME=admin
SKVM_ADMIN_PASSWORD=admin123
SKVM_TUNNEL_TIMEOUT=120
SKVM_DOCKER_NETWORK=bridge
SKVM_TUNNEL_IMAGE=skvm/ubuntu22-tmate:latest
SKVM_TUNNEL_IMAGE_20=skvm/ubuntu20-tmate:latest
SKVM_DEBUG=0
ENV
else
  sed -i 's/^SKVM_ADMIN_USERNAME=.*/SKVM_ADMIN_USERNAME=admin/' "$APP_DIR/.env" || true
  if grep -q '^SKVM_ADMIN_PASSWORD=' "$APP_DIR/.env"; then sed -i 's/^SKVM_ADMIN_PASSWORD=.*/SKVM_ADMIN_PASSWORD=admin123/' "$APP_DIR/.env"; else echo 'SKVM_ADMIN_PASSWORD=admin123' >> "$APP_DIR/.env"; fi
  if grep -q '^SKVM_TUNNEL_TIMEOUT=' "$APP_DIR/.env"; then sed -i 's/^SKVM_TUNNEL_TIMEOUT=.*/SKVM_TUNNEL_TIMEOUT=120/' "$APP_DIR/.env"; else echo 'SKVM_TUNNEL_TIMEOUT=120' >> "$APP_DIR/.env"; fi
  if grep -q '^SKVM_TUNNEL_IMAGE=' "$APP_DIR/.env"; then sed -i 's#^SKVM_TUNNEL_IMAGE=.*#SKVM_TUNNEL_IMAGE=skvm/ubuntu22-tmate:latest#' "$APP_DIR/.env"; else echo 'SKVM_TUNNEL_IMAGE=skvm/ubuntu22-tmate:latest' >> "$APP_DIR/.env"; fi
  if grep -q '^SKVM_TUNNEL_IMAGE_20=' "$APP_DIR/.env"; then sed -i 's#^SKVM_TUNNEL_IMAGE_20=.*#SKVM_TUNNEL_IMAGE_20=skvm/ubuntu20-tmate:latest#' "$APP_DIR/.env"; else echo 'SKVM_TUNNEL_IMAGE_20=skvm/ubuntu20-tmate:latest' >> "$APP_DIR/.env"; fi
fi
chmod 600 "$APP_DIR/.env"
chown -R "$APP_USER":"$APP_USER" "$APP_DIR"

# Remove stale database only on explicit fresh-install request; otherwise preserve user data.

echo "[6/8] Installing systemd service..."
cat > /etc/systemd/system/skvm.service <<SERVICE
[Unit]
Description=SKVM VPS Management Panel
After=docker.service network-online.target
Requires=docker.service
Wants=network-online.target

[Service]
Type=simple
User=$APP_USER
WorkingDirectory=$APP_DIR
EnvironmentFile=$APP_DIR/.env
ExecStart=$VENV/bin/gunicorn --bind 0.0.0.0:5555 --workers 1 --threads 8 --timeout 300 skvm:app
Restart=always
RestartSec=3
NoNewPrivileges=false

[Install]
WantedBy=multi-user.target
SERVICE

echo "[7/8] Firewall..."
if command -v ufw >/dev/null 2>&1; then ufw allow 5555/tcp || true; fi

echo "[8/8] Starting SKVM..."
systemctl daemon-reload
systemctl enable --now skvm
sleep 2
if ! systemctl is-active --quiet skvm; then systemctl --no-pager --full status skvm; exit 1; fi

IP="$(hostname -I | awk '{print $1}')"
echo
echo "=========================================="
echo " SKVM READY"
echo "=========================================="
echo "Panel: http://${IP}:5555"
echo "Admin: admin / admin123"
echo "tmate images: prebuilt (fast provisioning)"
echo "Disk quotas: compatibility mode (no btrfs probe)"
echo "=========================================="
