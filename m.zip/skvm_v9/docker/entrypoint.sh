#!/bin/bash
set -e
mkdir -p /run/sshd
PASS="${ROOT_PASSWORD:-$(head -c 18 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 18)}"
echo "root:${PASS}" | chpasswd
sed -ri 's/^#?PermitRootLogin .*/PermitRootLogin yes/' /etc/ssh/sshd_config
sed -ri 's/^#?PasswordAuthentication .*/PasswordAuthentication yes/' /etc/ssh/sshd_config
/usr/sbin/sshd
exec tail -f /dev/null
