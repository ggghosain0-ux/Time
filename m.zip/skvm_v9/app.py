#!/usr/bin/env python3
import os, sqlite3, secrets, subprocess, threading, time, re
from pathlib import Path
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, abort
from werkzeug.security import generate_password_hash, check_password_hash

try:
    import docker
except ImportError:
    docker = None

BASE=Path(__file__).resolve().parent
DATA=BASE/'data'; DATA.mkdir(exist_ok=True)
DB=DATA/'skvm.db'
PORT=int(os.getenv('SKVM_PORT','5555'))
BIND=os.getenv('SKVM_BIND','0.0.0.0')
ADMIN_USER=os.getenv('SKVM_ADMIN_USERNAME','admin')
ADMIN_PASS=os.getenv('SKVM_ADMIN_PASSWORD','admin123')
SECRET=os.getenv('SKVM_SECRET_KEY') or secrets.token_hex(32)
IMAGE=os.getenv('SKVM_IMAGE','skvm/ubuntu22-tmate:latest')
TMATE_TIMEOUT=int(os.getenv('SKVM_TMATE_TIMEOUT','25'))
app=Flask(__name__); app.secret_key=SECRET
app.config['SESSION_COOKIE_HTTPONLY']=True; app.config['SESSION_COOKIE_SAMESITE']='Lax'
lock=threading.RLock()

def db():
    c=sqlite3.connect(DB, timeout=30, check_same_thread=False); c.row_factory=sqlite3.Row
    c.execute('PRAGMA journal_mode=WAL'); c.execute('PRAGMA foreign_keys=ON'); return c

def init_db():
    c=db(); c.executescript('''
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'user', active INTEGER NOT NULL DEFAULT 1, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS vps(id INTEGER PRIMARY KEY AUTOINCREMENT, vps_id TEXT UNIQUE NOT NULL, user_id INTEGER NOT NULL, name TEXT NOT NULL, ram_mb INTEGER NOT NULL, cpu REAL NOT NULL, image TEXT NOT NULL, container TEXT, status TEXT NOT NULL DEFAULT 'creating', error TEXT, tmate_ssh TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);
    CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,action TEXT,details TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    ''')
    if not c.execute('SELECT 1 FROM users WHERE username=?',(ADMIN_USER,)).fetchone():
        c.execute('INSERT INTO users(username,password,role) VALUES(?,?,?)',(ADMIN_USER,generate_password_hash(ADMIN_PASS,method='scrypt'),'admin'))
    for k,v in {'site_name':'SKVM Panel','registration':'0','maintenance':'0','tmate_timeout':str(TMATE_TIMEOUT)}.items():
        c.execute('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)',(k,v))
    c.commit(); c.close()
init_db()

def csrf():
    if 'csrf' not in session: session['csrf']=secrets.token_urlsafe(24)
    return session['csrf']
app.jinja_env.globals['csrf_token']=csrf

@app.before_request
def csrf_check():
    if request.method=='POST':
        token=request.form.get('csrf')
        if not token or token != session.get('csrf'): abort(403)

@app.context_processor
def context():
    c=db(); s={r['key']:r['value'] for r in c.execute('SELECT key,value FROM settings')}; c.close()
    return {'site_name':s.get('site_name','SKVM Panel'),'username':session.get('username'),'role':session.get('role'),'csrf_token':csrf}

def logged(f):
    @wraps(f)
    def w(*a,**kw):
        if not session.get('user_id'): return redirect(url_for('login'))
        return f(*a,**kw)
    return w

def admin(f):
    @wraps(f)
    def w(*a,**kw):
        if not session.get('user_id'): return redirect(url_for('login'))
        if session.get('role')!='admin': abort(403)
        return f(*a,**kw)
    return w

def vps_row(vid):
    c=db(); v=c.execute('SELECT v.*,u.username FROM vps v JOIN users u ON u.id=v.user_id WHERE v.vps_id=?',(vid,)).fetchone(); c.close(); return v

def owner(f):
    @wraps(f)
    def w(vid,*a,**kw):
        v=vps_row(vid)
        if not v: abort(404)
        if session.get('role')!='admin' and v['user_id']!=session.get('user_id'): abort(403)
        return f(vid,*a,**kw)
    return w

def docker_client():
    if docker is None: raise RuntimeError('Docker SDK is not installed')
    c=docker.from_env(timeout=30); c.ping(); return c

def log_action(action,details='',uid=None):
    try:
        c=db(); c.execute('INSERT INTO audit(user_id,action,details) VALUES(?,?,?)',(uid or session.get('user_id'),action,details)); c.commit(); c.close()
    except Exception: pass

def setv(vid,**kw):
    allowed={'container','status','error','tmate_ssh'}; parts=[]; vals=[]
    for k,v in kw.items():
        if k in allowed: parts.append(k+'=?'); vals.append(v)
    if not parts:return
    parts.append('updated_at=CURRENT_TIMESTAMP'); vals.append(vid)
    c=db(); c.execute('UPDATE vps SET '+','.join(parts)+' WHERE vps_id=?',vals); c.commit(); c.close()

def ensure_image():
    c=docker_client()
    try:
        try: c.images.get(IMAGE); return
        except Exception: pass
        path=str(BASE/'docker')
        c.images.build(path=path,dockerfile='Dockerfile',tag=IMAGE,rm=True,pull=True)
    finally:c.close()

def remove_container(name):
    if not name:return
    try:
        c=docker_client(); x=c.containers.get(name); x.remove(force=True); c.close()
    except Exception: pass

def create_container(v):
    ensure_image(); c=docker_client()
    name='skvm-'+v['vps_id'].lower()
    rootpw=secrets.token_urlsafe(18)
    try:
        x=c.containers.create(IMAGE,name=name,hostname=re.sub(r'[^a-zA-Z0-9-]','-',v['name'])[:50] or 'skvm',detach=True,
            mem_limit=f"{int(v['ram_mb'])}m",nano_cpus=max(1,int(float(v['cpu'])*1_000_000_000)),
            environment={'ROOT_PASSWORD':rootpw},restart_policy={'Name':'unless-stopped'},
            labels={'skvm.vps_id':v['vps_id']})
        return x.name
    finally:c.close()

def get_container(v):
    if not v or not v['container']: return None
    c=docker_client()
    try:
        x=c.containers.get(v['container']); x.reload(); return x
    except Exception:return None
    finally:c.close()

def tmate_worker(vid):
    v=vps_row(vid)
    if not v or not v['container']:return
    try:
        c=docker_client(); x=c.containers.get(v['container'])
        # Only return the tmate SSH session string. No web URL is stored or shown.
        cmd=("set -e; command -v tmate >/dev/null; "
             "rm -f /tmp/skvm-tmate.sock; "
             "tmate -S /tmp/skvm-tmate.sock new-session -d; "
             f"timeout {TMATE_TIMEOUT} tmate -S /tmp/skvm-tmate.sock wait tmate-ready; "
             "tmate -S /tmp/skvm-tmate.sock display -p '#{tmate_ssh}'")
        result=x.exec_run(['bash','-lc',cmd],demux=False)
        out=(result.output or b'').decode(errors='ignore')
        c.close()
        ssh=next((line.strip() for line in out.splitlines() if line.strip().startswith('ssh ')),None)
        if ssh: setv(vid,tmate_ssh=ssh,status='running',error=None)
        else: setv(vid,error='tmate did not return an SSH session. Check outbound DNS/TCP connectivity.',status='running')
    except Exception as e:
        setv(vid,status='running',error='tmate unavailable: '+str(e))

def provision(vid,refresh=False):
    try:
        v=vps_row(vid)
        if not v:return
        setv(vid,status='provisioning',error=None,tmate_ssh=None)
        old=v['container']; remove_container(old)
        name=create_container(v); setv(vid,container=name,status='starting')
        c=docker_client(); x=c.containers.get(name); x.start(); c.close()
        # Do not wait for tmate here. VPS is considered running once Docker says running.
        for _ in range(20):
            time.sleep(.5); v=vps_row(vid); x=get_container(v)
            if x and x.status=='running':
                setv(vid,status='running',error=None)
                threading.Thread(target=tmate_worker,args=(vid,),daemon=True).start()
                log_action('vps.provisioned',vid,v['user_id']); return
        raise RuntimeError('Container startup timeout')
    except Exception as e:
        setv(vid,status='error',error=str(e)); log_action('vps.error',str(e))

def image_status():
    try:
        c=docker_client()
        try:c.images.get(IMAGE); ok=True
        except Exception:ok=False
        c.close(); return ok
    except Exception:return False

@app.route('/')
def index(): return redirect(url_for('admin_dashboard' if session.get('role')=='admin' else 'dashboard' if session.get('user_id') else 'login'))

@app.route('/login',methods=['GET','POST'])
def login():
    if request.method=='POST':
        u=request.form.get('username','').strip(); p=request.form.get('password','')
        c=db(); row=c.execute('SELECT * FROM users WHERE username=? AND active=1',(u,)).fetchone(); c.close()
        if row and check_password_hash(row['password'],p):
            session.clear(); session.update(user_id=row['id'],username=row['username'],role=row['role']); csrf(); return redirect(url_for('index'))
        flash('Invalid login.','danger')
    return render_template('login.html')

@app.route('/logout')
def logout(): session.clear(); return redirect(url_for('login'))

@app.route('/dashboard')
@logged
def dashboard():
    c=db(); vs=c.execute('SELECT * FROM vps WHERE user_id=? ORDER BY id DESC',(session['user_id'],)).fetchall(); c.close(); return render_template('dashboard.html',vps=vs)

@app.route('/vps/<vid>')
@owner
def vps_details(vid):
    return render_template('vps_details.html',vps=vps_row(vid))

@app.route('/vps/<vid>/action/<action>',methods=['POST'])
@owner
def vps_action(vid,action):
    v=vps_row(vid)
    try:
        c=docker_client(); x=c.containers.get(v['container'])
        if action=='start': x.start()
        elif action=='stop': x.stop(timeout=8)
        elif action=='restart': x.restart(timeout=8)
        elif action=='tmate':
            threading.Thread(target=tmate_worker,args=(vid,),daemon=True).start(); flash('tmate SSH session is being generated. Refresh in a few seconds.','info'); return redirect(url_for('vps_details',vid=vid))
        else: abort(400)
        c.close(); flash(action.title()+' completed.','success')
    except Exception as e: flash(str(e),'danger')
    return redirect(url_for('vps_details',vid=vid))

@app.route('/admin')
@admin
def admin_dashboard():
    c=db(); users=c.execute('SELECT * FROM users ORDER BY id DESC').fetchall(); vs=c.execute('SELECT v.*,u.username FROM vps v JOIN users u ON u.id=v.user_id ORDER BY v.id DESC').fetchall(); c.close(); return render_template('admin_dashboard.html',users=users,vps=vs,image_ok=image_status())

@app.route('/admin/users',methods=['GET','POST'])
@admin
def users():
    if request.method=='POST':
        u=request.form.get('username','').strip(); p=request.form.get('password','')
        if not re.fullmatch(r'[A-Za-z0-9_.-]{3,32}',u) or len(p)<8: flash('Username 3-32 chars; password at least 8 chars.','danger')
        else:
            try:
                c=db(); c.execute('INSERT INTO users(username,password,role) VALUES(?,?,?)',(u,generate_password_hash(p,method='scrypt'),'user')); c.commit(); c.close(); flash('User created.','success')
            except sqlite3.IntegrityError: flash('Username already exists.','danger')
    c=db(); rows=c.execute('SELECT * FROM users ORDER BY id DESC').fetchall(); c.close(); return render_template('users.html',users=rows)

@app.route('/admin/create',methods=['GET','POST'])
@admin
def create_vps():
    c=db(); users=c.execute("SELECT id,username FROM users WHERE active=1 ORDER BY username").fetchall(); c.close()
    if request.method=='POST':
        try:
            name=request.form.get('name','India').strip()[:64] or 'VPS'
            uid=int(request.form.get('user_id'))
            ram=max(256,min(32768,int(request.form.get('ram_mb','1024'))))
            cpu=max(.25,min(16,float(request.form.get('cpu','1'))))
            vid=secrets.token_hex(6)
            c=db(); c.execute('INSERT INTO vps(vps_id,user_id,name,ram_mb,cpu,image) VALUES(?,?,?,?,?,?)',(vid,uid,name,ram,cpu,IMAGE)); c.commit(); c.close()
            threading.Thread(target=provision,args=(vid,),daemon=True).start(); flash('VPS creation started. Open it to watch status and get the tmate SSH key.','success'); return redirect(url_for('vps_details',vid=vid))
        except Exception as e: flash(str(e),'danger')
    return render_template('create_vps.html',users=users)

@app.route('/admin/vps/<vid>/delete',methods=['POST'])
@admin
def delete_vps(vid):
    v=vps_row(vid); 
    if not v: abort(404)
    remove_container(v['container']); c=db(); c.execute('DELETE FROM vps WHERE vps_id=?',(vid,)); c.commit(); c.close(); flash('VPS deleted.','success'); return redirect(url_for('admin_dashboard'))

@app.route('/settings',methods=['GET','POST'])
@admin
def settings():
    if request.method=='POST':
        vals={'site_name':request.form.get('site_name','SKVM Panel').strip()[:80] or 'SKVM Panel','registration':'1' if request.form.get('registration') else '0','maintenance':'1' if request.form.get('maintenance') else '0'}
        c=db()
        for k,v in vals.items(): c.execute('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',(k,v))
        c.commit(); c.close(); flash('Settings saved.','success')
    c=db(); s={r['key']:r['value'] for r in c.execute('SELECT key,value FROM settings')}; c.close(); return render_template('settings.html',settings=s)

@app.route('/healthz')
def healthz(): return {'ok':True,'docker':image_status()}

if __name__=='__main__':
    app.run(host=BIND,port=PORT,debug=False)
