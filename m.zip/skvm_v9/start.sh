#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PIP_DISABLE_PIP_VERSION_CHECK=1
if [ ! -d .venv ] || [ ! -x .venv/bin/python ]; then rm -rf .venv; python3 -m venv .venv || { python3 -m pip install --user virtualenv; python3 -m virtualenv .venv; }; fi
if ! .venv/bin/python -m pip --version >/dev/null 2>&1; then
  rm -rf .venv
  python3 -m venv .venv || { python3 -m pip install --user virtualenv; python3 -m virtualenv .venv; }
fi
.venv/bin/python -m pip install -q --upgrade pip setuptools wheel
.venv/bin/python -m pip install -q -r requirements.txt
if ! command -v docker >/dev/null 2>&1; then echo 'ERROR: Docker CLI is required to create VPS containers.'; exit 1; fi
if ! docker info >/dev/null 2>&1; then echo 'ERROR: Docker daemon is not available in this environment.'; exit 1; fi
if ! docker image inspect skvm/ubuntu22-tmate:latest >/dev/null 2>&1; then
  docker build -t skvm/ubuntu22-tmate:latest ./docker
fi
exec .venv/bin/python app.py
