#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [ "$(id -u)" -ne 0 ]; then echo 'Run with sudo: sudo ./install.sh'; exit 1; fi
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y python3 python3-venv python3-pip docker.io
systemctl enable --now docker || true
rm -rf .venv
python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip setuptools wheel
.venv/bin/python -m pip install -r requirements.txt
docker build -t skvm/ubuntu22-tmate:latest ./docker
cp .env.example .env
cat > /etc/systemd/system/skvm.service <<EOF
[Unit]
Description=SKVM Docker VPS Panel
After=docker.service network-online.target
Requires=docker.service
[Service]
WorkingDirectory=$(pwd)
ExecStart=$(pwd)/.venv/bin/python $(pwd)/app.py
Restart=always
RestartSec=3
EnvironmentFile=$(pwd)/.env
[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable --now skvm
printf '\nSKVM installed. Open http://SERVER_IP:5555\nLogin: %s / %s\n' "${SKVM_ADMIN_USERNAME:-admin}" "${SKVM_ADMIN_PASSWORD:-admin123}"
