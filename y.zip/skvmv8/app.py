#!/usr/bin/env python3
import os, re, sqlite3, secrets, socket, threading, time, uuid, logging, subprocess
from pathlib import Path
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify, abort
from werkzeug.security import generate_password_hash, check_password_hash
try:
    import docker
except ImportError:
    docker = None

BASE=Path(__file__).resolve().parent
DATA=BASE/'data'; DATA.mkdir(exist_ok=True)
DB=DATA/'skvm.db'


def load_env():
    f=BASE/'.env'
    if f.exists():
        for raw in f.read_text().splitlines():
            line=raw.strip()
            if not line or line.startswith('#') or '=' not in line: continue
            k,v=line.split('=',1); os.environ.setdefault(k.strip(),v.strip().strip('"').strip("'"))
load_env()

SECRET=os.getenv('SKVM_SECRET_KEY') or secrets.token_hex(32)
PORT=int(os.getenv('SKVM_PORT','5555'))
BIND=os.getenv('SKVM_BIND','0.0.0.0')
PORT_START=int(os.getenv('SKVM_SSH_PORT_START','10000'))
PUBLIC_HOST=os.getenv('SKVM_PUBLIC_HOST','')
DEFAULT_USER=os.getenv('SKVM_ADMIN_USERNAME','admin')
DEFAULT_PASS=os.getenv('SKVM_ADMIN_PASSWORD','admin123')
IMAGE_MAP={'ubuntu22':'skvm/ubuntu22:latest','ubuntu24':'skvm/ubuntu24:latest','debian12':'skvm/debian12:latest'}

app=Flask(__name__)
app.secret_key=SECRET
app.config.update(SESSION_COOKIE_HTTPONLY=True,SESSION_COOKIE_SAMESITE='Lax',MAX_CONTENT_LENGTH=2*1024*1024)
log=logging.getLogger('skvm'); logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
lock=threading.RLock()


def db():
    c=sqlite3.connect(DB,timeout=30,check_same_thread=False)
    c.row_factory=sqlite3.Row
    c.execute('PRAGMA journal_mode=WAL'); c.execute('PRAGMA foreign_keys=ON')
    return c

def init_db():
    c=db(); c.executescript('''
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE NOT NULL,email TEXT UNIQUE NOT NULL,password TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'user',active INTEGER NOT NULL DEFAULT 1,created_at TEXT DEFAULT CURRENT_TIMESTAMP,last_login TEXT);
    CREATE TABLE IF NOT EXISTS vps(id INTEGER PRIMARY KEY AUTOINCREMENT,vps_id TEXT UNIQUE NOT NULL,user_id INTEGER NOT NULL,name TEXT NOT NULL,image TEXT NOT NULL,ram_mb INTEGER NOT NULL,cpu_cores INTEGER NOT NULL,disk_gb INTEGER NOT NULL,ssh_port INTEGER UNIQUE NOT NULL,ssh_password TEXT NOT NULL,container TEXT UNIQUE,status TEXT NOT NULL DEFAULT 'creating',error TEXT,tmate_ssh TEXT,tmate_web TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);
    CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,action TEXT NOT NULL,details TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,title TEXT NOT NULL,message TEXT NOT NULL,kind TEXT DEFAULT 'info',read INTEGER DEFAULT 0,created_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);
    CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
    ''')
    if not c.execute('SELECT 1 FROM users WHERE username=?',(DEFAULT_USER,)).fetchone():
        c.execute('INSERT INTO users(username,email,password,role) VALUES(?,?,?,?)',(DEFAULT_USER,os.getenv('SKVM_ADMIN_EMAIL','admin@skvm.local'),generate_password_hash(DEFAULT_PASS,method='scrypt'),'admin'))
    for k,v in {'site_name':'SKVM Panel','maintenance':'0'}.items(): c.execute('INSERT OR IGNORE INTO settings VALUES(?,?)',(k,v))
    c.commit(); c.close()
init_db()


def audit(action,details='',uid=None):
    try:
        c=db(); c.execute('INSERT INTO audit(user_id,action,details) VALUES(?,?,?)',(uid if uid is not None else session.get('user_id'),action,details)); c.commit(); c.close()
    except Exception: pass

def notify(uid,title,message,kind='info'):
    try:
        c=db(); c.execute('INSERT INTO notifications(user_id,title,message,kind) VALUES(?,?,?,?)',(uid,title,message,kind)); c.commit(); c.close()
    except Exception: pass

def csrf():
    if 'csrf' not in session: session['csrf']=secrets.token_urlsafe(24)
    return session['csrf']
app.jinja_env.globals['csrf_token']=csrf

@app.before_request
def csrf_check():
    if request.method in {'POST','PUT','PATCH','DELETE'}:
        token=request.form.get('csrf') or request.headers.get('X-CSRF-Token')
        if not token or token!=session.get('csrf'): return jsonify(ok=False,error='Invalid CSRF token'),403

@app.context_processor
def ctx():
    c=db(); s={r['key']:r['value'] for r in c.execute('SELECT key,value FROM settings')}; c.close()
    return {'site_name':s.get('site_name','SKVM Panel'),'current_user':session.get('username'),'role':session.get('role'),'docker_ok':docker_available()}

def login_required(f):
    @wraps(f)
    def w(*a,**kw):
        if not session.get('user_id'): return redirect(url_for('login',next=request.path))
        return f(*a,**kw)
    return w

def admin_required(f):
    @wraps(f)
    def w(*a,**kw):
        if not session.get('user_id'): return redirect(url_for('login'))
        if session.get('role')!='admin': abort(403)
        return f(*a,**kw)
    return w

def get_vps(vid):
    c=db(); v=c.execute('SELECT v.*,u.username FROM vps v JOIN users u ON u.id=v.user_id WHERE v.vps_id=?',(vid,)).fetchone(); c.close(); return v

def owner_required(f):
    @wraps(f)
    def w(vid,*a,**kw):
        v=get_vps(vid)
        if not v: abort(404)
        if session.get('role')!='admin' and v['user_id']!=session.get('user_id'): abort(403)
        return f(vid,*a,**kw)
    return w

def docker_client():
    if docker is None: raise RuntimeError('Docker SDK is not installed')
    return docker.from_env(timeout=20)

def docker_available():
    try:
        c=docker_client(); c.ping(); c.close(); return True
    except Exception: return False

def image_ready(image):
    try:
        c=docker_client(); c.images.get(IMAGE_MAP.get(image,image)); c.close(); return True
    except Exception: return False

def free_port():
    c=db(); used={r[0] for r in c.execute('SELECT ssh_port FROM vps')}; c.close()
    for p in range(PORT_START,65500):
        if p in used: continue
        s=socket.socket(); s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
        try: s.bind(('0.0.0.0',p)); s.close(); return p
        except OSError: s.close()
    raise RuntimeError('No free host SSH port')

def set_vps(vid,**kw):
    if not kw:return
    allowed={'status','error','container','tmate_ssh','tmate_web','updated_at'}
    fields=[]; vals=[]
    for k,v in kw.items():
        if k in allowed:
            fields.append(f'{k}=?'); vals.append(v)
    fields.append('updated_at=CURRENT_TIMESTAMP'); vals.append(vid)
    c=db(); c.execute(f"UPDATE vps SET {','.join(fields)} WHERE vps_id=?",vals); c.commit(); c.close()

def state(v):
    if not v['container']: return 'missing'
    try:
        c=docker_client(); x=c.containers.get(v['container']); x.reload(); s=x.status; c.close(); return s
    except Exception:return 'missing'

def remove_container(v):
    if not v['container']: return
    try:
        c=docker_client(); x=c.containers.get(v['container']); x.remove(force=True); c.close()
    except Exception: pass

def make_container(v):
    if not image_ready(v['image']): raise RuntimeError(f"Guest image {IMAGE_MAP[v['image']]} is not built. Run ./install.sh first.")
    c=docker_client(); name=f"skvm-{v['vps_id'][:12]}"
    env={'SKVM_ROOT_PASSWORD':v['ssh_password'],'SKVM_HOSTNAME':re.sub(r'[^A-Za-z0-9-]','-',v['name'])[:48] or 'skvm-vps'}
    try:
        x=c.containers.create(IMAGE_MAP[v['image']],name=name,hostname=env['SKVM_HOSTNAME'],detach=True,mem_limit=f"{v['ram_mb']}m",nano_cpus=v['cpu_cores']*1_000_000_000,ports={'22/tcp':v['ssh_port']},environment=env,restart_policy={'Name':'unless-stopped'},labels={'com.skvm.vps_id':v['vps_id']})
        return x.name
    finally:c.close()

def provision(vid):
    try:
        v=get_vps(vid)
        if not v:return
        set_vps(vid,status='provisioning',error=None,tmate_ssh=None,tmate_web=None)
        if not docker_available(): raise RuntimeError('Docker daemon is unavailable on this host.')
        remove_container(v)
        name=make_container(v); set_vps(vid,container=name,status='starting')
        c=docker_client(); x=c.containers.get(name); x.start(); c.close()
        for _ in range(20):
            time.sleep(.5); v=get_vps(vid); s=state(v)
            if s=='running':
                set_vps(vid,status='running',error=None); notify(v['user_id'],'VPS ready',f"{v['name']} is running. SSH port: {v['ssh_port']}",'success'); audit('vps.provisioned',vid,v['user_id'])
                threading.Thread(target=tmate_worker,args=(vid,),daemon=True).start(); return
            if s in {'exited','dead'}: raise RuntimeError('Guest container exited during startup.')
        raise RuntimeError('Container startup timeout. Check Docker logs and guest image.')
    except Exception as e:
        log.exception('Provisioning failed for %s',vid); set_vps(vid,status='error',error=str(e)); v=get_vps(vid)
        if v: notify(v['user_id'],'VPS provisioning failed',str(e),'danger')

def tmate_worker(vid):
    v=get_vps(vid)
    if not v or state(v)!='running': return
    try:
        c=docker_client(); x=c.containers.get(v['container'])
        # Start tmate independently. Never fail VPS provisioning because relay registration fails.
        cmd="bash -lc \"if ! command -v tmate >/dev/null 2>&1; then exit 20; fi; rm -f /tmp/skvm-tmate.sock; tmate -S /tmp/skvm-tmate.sock new-session -d; timeout 10 tmate -S /tmp/skvm-tmate.sock wait tmate-ready || exit 21; tmate -S /tmp/skvm-tmate.sock display -p '#{tmate_ssh}'; tmate -S /tmp/skvm-tmate.sock display -p '#{tmate_web}'\""
        r=x.exec_run(cmd,demux=False); out=(r.output or b'').decode(errors='ignore').splitlines(); c.close()
        ssh=next((s.strip() for s in out if s.strip().startswith('ssh ')),None); web=next((s.strip() for s in out if s.strip().startswith('https://')),None)
        if ssh or web: set_vps(vid,status='running',error=None,tmate_ssh=ssh,tmate_web=web); notify(v['user_id'],'tmate ready',ssh or web,'success')
        else: log.info('tmate unavailable for %s; SSH remains available',vid)
    except Exception as e: log.info('tmate worker failed for %s: %s',vid,e)

@app.route('/')
def index(): return redirect(url_for('admin_dashboard' if session.get('role')=='admin' else 'dashboard' if session.get('user_id') else 'login'))
@app.route('/login',methods=['GET','POST'])
def login():
    if request.method=='POST':
        u=request.form.get('username','').strip(); p=request.form.get('password',''); c=db(); user=c.execute('SELECT * FROM users WHERE username=? AND active=1',(u,)).fetchone()
        if user and check_password_hash(user['password'],p):
            session.clear(); session.update(user_id=user['id'],username=user['username'],role=user['role']); csrf(); c.execute('UPDATE users SET last_login=CURRENT_TIMESTAMP WHERE id=?',(user['id'],)); c.commit(); c.close(); audit('auth.login','success',user['id']); return redirect(request.args.get('next') or url_for('index'))
        c.close(); flash('Invalid username or password.','danger')
    return render_template('login.html')
@app.route('/logout')
def logout(): audit('auth.logout'); session.clear(); return redirect(url_for('login'))
@app.route('/register',methods=['GET','POST'])
def register():
    if request.method=='POST':
        u=request.form.get('username','').strip(); e=request.form.get('email','').strip(); p=request.form.get('password','')
        if not re.fullmatch(r'[A-Za-z0-9_.-]{3,32}',u) or len(p)<8: flash('Username must be 3-32 characters and password at least 8 characters.','danger')
        else:
            try:
                c=db(); c.execute('INSERT INTO users(username,email,password) VALUES(?,?,?)',(u,e,generate_password_hash(p,method='scrypt'))); c.commit(); c.close(); flash('Account created.','success'); return redirect(url_for('login'))
            except sqlite3.IntegrityError: flash('Username or email already exists.','danger')
    return render_template('register.html')
@app.route('/dashboard')
@login_required
def dashboard():
    c=db(); vps=c.execute('SELECT * FROM vps WHERE user_id=? ORDER BY id DESC',(session['user_id'],)).fetchall(); unread=c.execute('SELECT COUNT(*) FROM notifications WHERE user_id=? AND read=0',(session['user_id'],)).fetchone()[0]; c.close(); return render_template('dashboard.html',vps=vps,unread=unread)

@app.route('/vps/create',methods=['GET','POST'])
@admin_required
def create_vps():
    if request.method=='POST':
        try:
            name=request.form.get('name','').strip(); uid=int(request.form.get('user_id','0')); ram=int(request.form.get('ram_mb','1024')); cpu=int(request.form.get('cpu_cores','1')); disk=int(request.form.get('disk_gb','10')); image=request.form.get('image','ubuntu22')
            if not name or uid<=0: raise ValueError('Name and user are required.')
            if image not in IMAGE_MAP: raise ValueError('Unsupported OS.')
            if not (128<=ram<=131072 and 1<=cpu<=64 and 1<=disk<=2048): raise ValueError('Resource limits are invalid.')
            if not docker_available(): raise ValueError('Docker is unavailable. The VPS was not created.')
            if not image_ready(image): raise ValueError(f'{IMAGE_MAP[image]} is missing. Run ./install.sh to build guest images.')
            vid=str(uuid.uuid4()); port=free_port(); pw=secrets.token_urlsafe(12)
            c=db(); c.execute('INSERT INTO vps(vps_id,user_id,name,image,ram_mb,cpu_cores,disk_gb,ssh_port,ssh_password,status) VALUES(?,?,?,?,?,?,?,?,?,?)',(vid,uid,name,image,ram,cpu,disk,port,pw,'creating')); c.commit(); c.close()
            threading.Thread(target=provision,args=(vid,),daemon=True).start(); flash('VPS creation started. It will appear here when ready.','success'); return redirect(url_for('manage_vps',vid=vid))
        except Exception as e: flash(str(e),'danger')
    c=db(); users=c.execute("SELECT id,username FROM users WHERE active=1 ORDER BY username").fetchall(); c.close(); return render_template('create_vps.html',users=users)

@app.route('/vps/<vid>')
@login_required
@owner_required
def manage_vps(vid):
    v=get_vps(vid); return render_template('manage_vps.html',v=v,real_status=state(v))

def act(vid,op):
    v=get_vps(vid)
    try:
        if not v:return jsonify(ok=False,error='VPS not found'),404
        c=docker_client(); x=c.containers.get(v['container']) if v['container'] else None
        if not x: raise RuntimeError('Container is missing. Use Reprovision.')
        if op=='start': x.start(); status='running'
        elif op=='stop': x.stop(timeout=10); status='stopped'
        elif op=='restart': x.restart(timeout=10); status='running'
        else: raise RuntimeError('Invalid action')
        c.close(); set_vps(vid,status=status,error=None); audit('vps.'+op,v['name']); return jsonify(ok=True,status=status)
    except Exception as e: set_vps(vid,status='error',error=str(e)); return jsonify(ok=False,error=str(e)),500

def _action_endpoint(vid, op):
    return act(vid,op)

for _op in ('start','stop','restart'):
    _fn=login_required(owner_required(lambda vid, _op=_op: _action_endpoint(vid,_op)))
    app.add_url_rule(f'/vps/<vid>/{_op}', endpoint=f'vps_{_op}', view_func=_fn, methods=['POST'])

@app.post('/vps/<vid>/reprovision')
@admin_required
def reprovision(vid):
    v=get_vps(vid)
    if not v:return jsonify(ok=False,error='VPS not found'),404
    remove_container(v); set_vps(vid,status='creating',error=None,container=None,tmate_ssh=None,tmate_web=None); threading.Thread(target=provision,args=(vid,),daemon=True).start(); audit('vps.reprovisioned',vid); return jsonify(ok=True)
@app.post('/vps/<vid>/delete')
@admin_required
def delete_vps(vid):
    v=get_vps(vid)
    if not v:return jsonify(ok=False,error='VPS not found'),404
    remove_container(v); c=db(); c.execute('DELETE FROM vps WHERE vps_id=?',(vid,)); c.commit(); c.close(); audit('vps.deleted',vid); return jsonify(ok=True)
@app.get('/vps/<vid>/status')
@login_required
@owner_required
def status_api(vid):
    v=get_vps(vid); s=state(v); return jsonify(ok=True,status=s,error=v['error'],ssh_port=v['ssh_port'],tmate_ssh=v['tmate_ssh'],tmate_web=v['tmate_web'])
@app.post('/vps/<vid>/tmate')
@login_required
@owner_required
def tmate(vid): threading.Thread(target=tmate_worker,args=(vid,),daemon=True).start(); return jsonify(ok=True,message='tmate refresh started independently of VPS state')
@app.route('/vps/<vid>/terminal',methods=['GET','POST'])
@login_required
@owner_required
def terminal(vid):
    v=get_vps(vid); output=None
    if request.method=='POST':
        cmd=request.form.get('command','').strip()
        if not cmd: flash('Enter a command.','danger')
        elif len(cmd)>2000: flash('Command is too long.','danger')
        else:
            try:
                c=docker_client(); x=c.containers.get(v['container']); r=x.exec_run(['bash','-lc',cmd],demux=False); output=(r.output or b'').decode(errors='replace'); c.close()
            except Exception as e: output='ERROR: '+str(e)
    return render_template('terminal.html',v=v,output=output)
@app.route('/profile',methods=['GET','POST'])
@login_required
def profile():
    if request.method=='POST':
        p=request.form.get('password','')
        if len(p)<8: flash('Password must be at least 8 characters.','danger')
        else:
            c=db(); c.execute('UPDATE users SET password=? WHERE id=?',(generate_password_hash(p,method='scrypt'),session['user_id'])); c.commit(); c.close(); flash('Password updated.','success'); audit('profile.password_changed')
    c=db(); u=c.execute('SELECT * FROM users WHERE id=?',(session['user_id'],)).fetchone(); c.close(); return render_template('profile.html',user=u)
@app.route('/notifications')
@login_required
def notifications():
    c=db(); n=c.execute('SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 100',(session['user_id'],)).fetchall(); c.close(); return render_template('notifications.html',notifications=n)
@app.post('/notifications/read-all')
@login_required
def read_all():
    c=db(); c.execute('UPDATE notifications SET read=1 WHERE user_id=?',(session['user_id'],)); c.commit(); c.close(); return jsonify(ok=True)

@app.route('/admin')
@admin_required
def admin_dashboard():
    c=db(); total=c.execute('SELECT COUNT(*) FROM vps').fetchone()[0]; users=c.execute('SELECT COUNT(*) FROM users').fetchone()[0]; running=0
    for v in c.execute('SELECT * FROM vps').fetchall(): running+=state(v)=='running'
    errors=c.execute("SELECT COUNT(*) FROM vps WHERE status='error'").fetchone()[0]; logs=c.execute('SELECT a.*,u.username FROM audit a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 12').fetchall(); c.close(); return render_template('admin/dashboard.html',total=total,users=users,running=running,errors=errors,logs=logs)
@app.route('/admin/vps')
@admin_required
def admin_vps():
    c=db(); vps=c.execute('SELECT v.*,u.username FROM vps v JOIN users u ON u.id=v.user_id ORDER BY v.id DESC').fetchall(); c.close(); return render_template('admin/vps.html',vps=vps)
@app.route('/admin/users')
@admin_required
def admin_users():
    c=db(); users=c.execute('SELECT u.*,COUNT(v.id) vm_count FROM users u LEFT JOIN vps v ON v.user_id=u.id GROUP BY u.id ORDER BY u.id DESC').fetchall(); c.close(); return render_template('admin/users.html',users=users)
@app.route('/admin/users/create',methods=['GET','POST'])
@admin_required
def admin_create_user():
    if request.method=='POST':
        try:
            u=request.form['username'].strip(); e=request.form['email'].strip(); p=request.form['password']; role=request.form.get('role','user')
            if role not in ('user','admin') or len(p)<8: raise ValueError('Invalid role or password.')
            c=db(); c.execute('INSERT INTO users(username,email,password,role) VALUES(?,?,?,?)',(u,e,generate_password_hash(p,method='scrypt'),role)); c.commit(); c.close(); flash('User created.','success'); return redirect(url_for('admin_users'))
        except Exception as e: flash(str(e),'danger')
    return render_template('admin/user_form.html',user=None)
@app.route('/admin/users/<int:uid>/edit',methods=['GET','POST'])
@admin_required
def admin_edit_user(uid):
    c=db(); u=c.execute('SELECT * FROM users WHERE id=?',(uid,)).fetchone()
    if not u:c.close();abort(404)
    if request.method=='POST':
        role=request.form.get('role','user'); active=1 if request.form.get('active')=='on' else 0; p=request.form.get('password','')
        if role not in ('user','admin'): flash('Invalid role.','danger')
        elif uid==session['user_id'] and active==0: flash('You cannot disable your own account.','danger')
        else:
            if p and len(p)>=8:c.execute('UPDATE users SET username=?,email=?,role=?,active=?,password=? WHERE id=?',(request.form['username'],request.form['email'],role,active,generate_password_hash(p,method='scrypt'),uid))
            else:c.execute('UPDATE users SET username=?,email=?,role=?,active=? WHERE id=?',(request.form['username'],request.form['email'],role,active,uid))
            c.commit(); c.close(); flash('User updated.','success'); return redirect(url_for('admin_users'))
    c.close(); return render_template('admin/user_form.html',user=u)
@app.post('/admin/users/<int:uid>/delete')
@admin_required
def admin_delete_user(uid):
    if uid==session['user_id']: return jsonify(ok=False,error='You cannot delete yourself'),400
    c=db(); vs=c.execute('SELECT * FROM vps WHERE user_id=?',(uid,)).fetchall(); c.close()
    for v in vs: remove_container(v)
    c=db(); c.execute('DELETE FROM users WHERE id=?',(uid,)); c.commit(); c.close(); audit('user.deleted',str(uid)); return jsonify(ok=True)
@app.route('/admin/settings',methods=['GET','POST'])
@admin_required
def settings():
    c=db()
    if request.method=='POST':
        for k in ('site_name','maintenance'):
            if k in request.form:c.execute('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',(k,request.form[k]))
        c.commit(); flash('Settings saved.','success'); audit('settings.updated')
    rows=c.execute('SELECT * FROM settings ORDER BY key').fetchall(); c.close(); return render_template('admin/settings.html',settings={r['key']:r['value'] for r in rows})
@app.route('/admin/audit')
@admin_required
def audit_page():
    c=db(); logs=c.execute('SELECT a.*,u.username FROM audit a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 300').fetchall(); c.close(); return render_template('admin/audit.html',logs=logs)
@app.get('/healthz')
def healthz():
    d=docker_available(); return jsonify(status='ok' if d else 'degraded',docker=d,version='8.0.0'),200 if d else 503
@app.errorhandler(403)
def e403(e):return render_template('errors/403.html'),403
@app.errorhandler(404)
def e404(e):return render_template('errors/404.html'),404
@app.errorhandler(500)
def e500(e):return render_template('errors/500.html'),500

if __name__=='__main__': app.run(host=BIND,port=PORT,debug=False)
