#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
if [[ ${EUID:-$(id -u)} -ne 0 ]]; then exec sudo -E bash "$0" "$@"; fi
export DEBIAN_FRONTEND=noninteractive
log(){ printf '\n==> %s\n' "$*"; }
trap 'echo "INSTALL FAILED at line $LINENO" >&2' ERR

log 'Installing host packages'
apt-get update
apt-get install -y ca-certificates curl docker.io python3 python3-venv python3-pip
systemctl enable --now docker

docker info >/dev/null 2>&1 || { echo 'Docker daemon is unavailable.' >&2; exit 1; }

log 'Preparing environment'
if [[ ! -f .env ]]; then
  cp .env.example .env
  python3 - <<'PY'
from pathlib import Path
import secrets
p=Path('.env'); s=p.read_text(); s=s.replace('SKVM_SECRET_KEY=CHANGE_ME','SKVM_SECRET_KEY='+secrets.token_hex(32)); p.write_text(s)
PY
fi
chmod 600 .env
python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements.txt

log 'Building local guest images (no Docker Hub SKVM image is required)'
docker build -t skvm/ubuntu22:latest -f docker/Dockerfile.ubuntu22 docker
docker build -t skvm/ubuntu24:latest -f docker/Dockerfile.ubuntu24 docker
docker build -t skvm/debian12:latest -f docker/Dockerfile.debian12 docker

log 'Initializing database'
.venv/bin/python -c 'import app; print("Database ready")'

log 'Installing systemd service'
sed "s#__SKVM_DIR__#$PWD#g" systemd/skvm.service > /etc/systemd/system/skvm.service
systemctl daemon-reload
systemctl enable --now skvm
sleep 2
systemctl is-active --quiet skvm || { journalctl -u skvm -n 100 --no-pager; exit 1; }

log 'SKVM v8 installed successfully'
echo 'Panel: http://SERVER_IP:5555'
echo 'Admin: admin / admin123'
echo 'Change the admin password after first login.'
echo 'SSH ports: 10000-65500 (open the range in your firewall if required).'
