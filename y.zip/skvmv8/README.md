# SKVM v8

A clean Flask + Docker VPS control panel designed to run on a normal Linux VPS and in development environments that expose a Docker daemon.

## Default login
`admin / admin123`

Change the password immediately after installation.

## Linux VPS install
```bash
unzip skvmv8.zip
cd skvmv8
chmod +x install.sh
sudo ./install.sh
```

Open `http://SERVER_IP:5555`.

Open the SSH host-port range if your firewall requires it:
```bash
sudo ufw allow 5555/tcp
sudo ufw allow 10000:10100/tcp
```

## CodeSandbox / Docker development
If your CodeSandbox environment provides a Docker daemon/socket, run:
```bash
chmod +x install.sh
sudo ./install.sh
```
If Docker is unavailable in the sandbox, SKVM can still be developed/run as a web app, but it cannot create real Docker VPS containers. That is a platform limitation, not a panel bug.

For a non-root dev environment where Docker is already available, you can run:
```bash
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/python app.py
```

## Important architecture fixes
- Guest images are built locally during installation. SKVM never tries to pull a nonexistent `skvm/ubuntu22-tmate` repository.
- VPS provisioning does not wait for tmate. A tmate relay/network failure cannot mark a healthy VPS as failed.
- tmate starts asynchronously after the SSH container is running.
- SSH works independently of tmate.
- Admin-only VPS creation prevents normal users from creating VPSs.
- Start/stop/restart/reprovision/delete have explicit permission checks.
- CSRF protection, password hashing, audit logs, notifications and health checks are included.
- Installation uses valid shell syntax and does not export variables with hyphens.

## tmate
A tmate SSH/web session is generated only when the container can reach the tmate relay. There is no legitimate way to guarantee an instant tmate relay token when the host has blocked outbound DNS/TCP or the relay is unavailable. SKVM therefore keeps direct SSH available and treats tmate as an optional access path.

## Disk
The `disk_gb` value is stored and shown in the panel. A normal Docker overlay filesystem does not automatically provide a strict per-container disk quota. Use a quota-capable storage driver/filesystem if you need hard customer disk limits.
