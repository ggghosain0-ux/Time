import { User, VM, LocalNodeInfo, ActivityLog, ApiKey, SystemSettings, HealthReport } from './types';

const TOKEN_KEY = 'skvm_auth_token';

export function getStoredToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setStoredToken(token: string | null) {
  if (token) {
    localStorage.setItem(TOKEN_KEY, token);
  } else {
    localStorage.removeItem(TOKEN_KEY);
  }
}

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = getStoredToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string>),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(endpoint, {
    ...options,
    headers,
  });

  const data = await response.json().catch(() => null);

  if (!response.ok) {
    const errorMsg = data?.error || `Request failed with status ${response.status}`;
    throw new Error(errorMsg);
  }

  return data as T;
}

export const api = {
  // Auth
  login: (credentials: { username: string; password: string }) =>
    request<{ token: string; user: User }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials),
    }),

  register: (data: { username: string; email: string; password: string; role?: string }) =>
    request<{ token: string; user: User }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  getMe: () => request<User>('/api/auth/me'),

  changePassword: (data: { currentPassword?: string; newPassword: string }) =>
    request<{ message: string }>('/api/auth/change-password', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  getUsers: () => request<{ users: User[] }>('/api/auth/users'),

  createUser: (data: { username: string; email: string; password: string; role?: string }) =>
    request<{ user: User }>('/api/auth/users', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  deleteUser: (id: string) =>
    request<{ message: string }>(`/api/auth/users/${id}`, {
      method: 'DELETE',
    }),

  // Node & Overview
  getNodeStats: () =>
    request<{
      node: LocalNodeInfo;
      overview: {
        totalUsers: number;
        totalVms: number;
        runningVms: number;
        stoppedVms: number;
        failedVms: number;
      };
    }>('/api/node/stats'),

  // VMs
  getVMs: () => request<{ vms: VM[] }>('/api/vms'),

  getVM: (id: string) => request<{ vm: VM }>(`/api/vms/${id}`),

  createVM: (data: {
    name: string;
    os: string;
    ram_mb: number;
    cpu_cores: number;
    disk_gb: number;
    username?: string;
    password?: string;
    hostname?: string;
    target_user_id?: string;
  }) =>
    request<{ message: string; vmId: string }>('/api/vms', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  startVM: (id: string) =>
    request<{ message: string; status: string; ip_address?: string }>(`/api/vms/${id}/start`, {
      method: 'POST',
    }),

  stopVM: (id: string) =>
    request<{ message: string; status: string }>(`/api/vms/${id}/stop`, {
      method: 'POST',
    }),

  restartVM: (id: string) =>
    request<{ message: string; status: string; ip_address?: string }>(`/api/vms/${id}/restart`, {
      method: 'POST',
    }),

  deleteVM: (id: string) =>
    request<{ message: string }>(`/api/vms/${id}`, {
      method: 'DELETE',
    }),

  getVMStatus: (id: string) =>
    request<{
      db_status: string;
      engine_status: string;
      ip: string | null;
      uptime?: number;
      error_message?: string | null;
    }>(`/api/vms/${id}/status`),

  getVMLogs: (id: string) =>
    request<{ logs: string }>(`/api/vms/${id}/logs`),

  getVMFiles: (id: string, path?: string) =>
    request<{
      path: string;
      files: Array<{ name: string; isDir: boolean; size: string; permissions: string; updated: string }>;
      raw?: string;
      message?: string;
    }>(`/api/vms/${id}/files?path=${encodeURIComponent(path || '')}`),

  sendVMCommand: (id: string, command: string) =>
    request<{ exitCode: number; output: string }>(`/api/vms/${id}/command`, {
      method: 'POST',
      body: JSON.stringify({ command }),
    }),

  getVMMetrics: (id: string) =>
    request<{
      status: string;
      cpu_percent: number;
      memory_usage_mb: number;
      total_ram_mb: number;
      disk_gb: number;
      uptime_seconds: number;
    }>(`/api/vms/${id}/metrics`),

  getVMNetwork: (id: string) =>
    request<{
      ip: string | null;
      ssh_port: number | null;
      ssh_command: string | null;
      gateway: string;
      subnet: string;
      dns: string[];
    }>(`/api/vms/${id}/network`),

  initiateTmate: (id: string) =>
    request<{
      success: boolean;
      tmate_ssh: string;
      tmate_web: string;
    }>(`/api/vms/${id}/tmate`, {
      method: 'POST',
    }),

  // Settings
  getSettings: () => request<{ settings: SystemSettings }>('/api/settings'),

  updateSettings: (settings: Partial<SystemSettings>) =>
    request<{ message: string; settings: Partial<SystemSettings> }>('/api/settings', {
      method: 'PUT',
      body: JSON.stringify(settings),
    }),

  // Health
  getHealth: () => request<HealthReport>('/api/health'),

  // Logs
  getLogs: (limit = 50) => request<{ logs: ActivityLog[] }>(`/api/logs?limit=${limit}`),

  // API Keys
  getKeys: () => request<{ keys: ApiKey[] }>('/api/keys'),

  createKey: (name: string) =>
    request<{ key: ApiKey; warning: string }>('/api/keys', {
      method: 'POST',
      body: JSON.stringify({ name }),
    }),

  deleteKey: (id: string) =>
    request<{ message: string }>(`/api/keys/${id}`, {
      method: 'DELETE',
    }),
};
