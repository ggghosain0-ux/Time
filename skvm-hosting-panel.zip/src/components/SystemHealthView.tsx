import React, { useState, useEffect } from 'react';
import { api } from '../api';
import { HealthReport } from '../types';
import {
  Activity,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Server,
  Layers,
  Database,
  Cpu,
  RefreshCw,
  Terminal,
} from 'lucide-react';

export const SystemHealthView: React.FC = () => {
  const [report, setReport] = useState<HealthReport | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchHealth = async () => {
    setLoading(true);
    try {
      const data = await api.getHealth();
      setReport(data);
    } catch (err) {
      console.error('Failed to query system health:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHealth();
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-100 font-mono flex items-center space-x-2">
            <Activity className="w-5 h-5 text-emerald-400" />
            <span>Infrastructure Health Diagnostics</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Real hardware capability probes, container daemon socket checks, and cgroups validation.
          </p>
        </div>

        <button
          onClick={fetchHealth}
          className="px-3 py-2 rounded-lg bg-slate-900 text-slate-300 hover:text-white border border-slate-800 hover:border-slate-700 transition-colors text-xs font-mono flex items-center space-x-1.5"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Re-run Probes</span>
        </button>
      </div>

      {loading && !report ? (
        <div className="p-12 text-center text-xs font-mono text-slate-500">
          Running infrastructure diagnostic checks...
        </div>
      ) : report ? (
        <div className="space-y-4">
          {/* Main Status Header */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-sm flex items-center justify-between">
            <div className="flex items-center space-x-3">
              {report.infrastructure_ready ? (
                <div className="w-10 h-10 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
              ) : (
                <div className="w-10 h-10 rounded-full bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
                  <AlertTriangle className="w-6 h-6" />
                </div>
              )}
              <div>
                <div className="text-base font-bold font-mono text-slate-100">
                  {report.infrastructure_ready
                    ? 'Infrastructure Ready for Container Provisioning'
                    : 'Infrastructure Incomplete (Limited Environment)'}
                </div>
                <div className="text-xs text-slate-400 font-mono mt-0.5">
                  Last probed: {new Date(report.timestamp).toLocaleString()}
                </div>
              </div>
            </div>

            <span
              className={`px-3 py-1 rounded-full text-xs font-mono font-bold uppercase border ${
                report.infrastructure_ready
                  ? 'bg-emerald-950 text-emerald-300 border-emerald-800'
                  : 'bg-amber-950 text-amber-300 border-amber-800'
              }`}
            >
              {report.status}
            </span>
          </div>

          {/* Component Diagnostics Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Docker Engine */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-sm">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center space-x-2 font-mono font-semibold text-sm text-slate-200">
                  <Layers className="w-4 h-4 text-emerald-400" />
                  <span>Docker Container Engine</span>
                </div>
                {report.components.engines.docker.available ? (
                  <span className="text-xs text-emerald-400 font-mono flex items-center space-x-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Operational</span>
                  </span>
                ) : (
                  <span className="text-xs text-amber-400 font-mono flex items-center space-x-1">
                    <XCircle className="w-3.5 h-3.5" />
                    <span>Unavailable</span>
                  </span>
                )}
              </div>
              <div className="mt-3 text-xs font-mono space-y-2 text-slate-400">
                <div>
                  Version:{' '}
                  <span className="text-slate-200">
                    {report.components.engines.docker.version || 'Not Detected'}
                  </span>
                </div>
                <div>
                  Socket Path: <span className="text-slate-200">/var/run/docker.sock</span>
                </div>
                {report.components.engines.docker.error && (
                  <div className="p-2.5 bg-slate-950 rounded border border-slate-800 text-rose-300">
                    {report.components.engines.docker.error}
                  </div>
                )}
              </div>
            </div>

            {/* LXC Engine */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-sm">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center space-x-2 font-mono font-semibold text-sm text-slate-200">
                  <Terminal className="w-4 h-4 text-sky-400" />
                  <span>LXC / LXD Engine</span>
                </div>
                {report.components.engines.lxc.available ? (
                  <span className="text-xs text-emerald-400 font-mono flex items-center space-x-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Operational</span>
                  </span>
                ) : (
                  <span className="text-xs text-amber-400 font-mono flex items-center space-x-1">
                    <XCircle className="w-3.5 h-3.5" />
                    <span>Unavailable</span>
                  </span>
                )}
              </div>
              <div className="mt-3 text-xs font-mono space-y-2 text-slate-400">
                <div>
                  CLI Version:{' '}
                  <span className="text-slate-200">
                    {report.components.engines.lxc.version || 'Not Installed'}
                  </span>
                </div>
                {report.components.engines.lxc.error && (
                  <div className="p-2.5 bg-slate-950 rounded border border-slate-800 text-rose-300">
                    {report.components.engines.lxc.error}
                  </div>
                )}
              </div>
            </div>

            {/* QEMU Hardware VM Engine */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-sm">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center space-x-2 font-mono font-semibold text-sm text-slate-200">
                  <Cpu className="w-4 h-4 text-purple-400" />
                  <span>QEMU / KVM Virtual Machine Engine</span>
                </div>
                {report.components.engines.qemu?.available ? (
                  <span className="text-xs text-emerald-400 font-mono flex items-center space-x-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Operational</span>
                  </span>
                ) : (
                  <span className="text-xs text-amber-400 font-mono flex items-center space-x-1">
                    <XCircle className="w-3.5 h-3.5" />
                    <span>Unavailable</span>
                  </span>
                )}
              </div>
              <div className="mt-3 text-xs font-mono space-y-2 text-slate-400">
                <div>
                  Version:{' '}
                  <span className="text-slate-200">
                    {report.components.engines.qemu?.version || 'Not Installed'}
                  </span>
                </div>
                {report.components.engines.qemu?.error && (
                  <div className="p-2.5 bg-slate-950 rounded border border-slate-800 text-rose-300">
                    {report.components.engines.qemu.error}
                  </div>
                )}
              </div>
            </div>

            {/* Database Engine */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-sm">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center space-x-2 font-mono font-semibold text-sm text-slate-200">
                  <Database className="w-4 h-4 text-purple-400" />
                  <span>Persistent Relational Database</span>
                </div>
                <span className="text-xs text-emerald-400 font-mono flex items-center space-x-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Healthy</span>
                </span>
              </div>
              <div className="mt-3 text-xs font-mono space-y-2 text-slate-400">
                <div>Driver: <span className="text-slate-200 uppercase">{report.components.database.driver}</span></div>
                <div>Status: <span className="text-slate-200">{report.components.database.details}</span></div>
              </div>
            </div>

            {/* Kernel & Resource Controls */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-sm">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center space-x-2 font-mono font-semibold text-sm text-slate-200">
                  <Cpu className="w-4 h-4 text-amber-400" />
                  <span>Kernel & Host Isolation Capabilities</span>
                </div>
                <span className="text-xs font-mono text-slate-300">
                  {report.components.capabilities.architecture}
                </span>
              </div>
              <div className="mt-3 text-xs font-mono space-y-2 text-slate-400">
                <div>Process Root: <span className="text-slate-200">{report.components.capabilities.is_root ? 'Yes (UID 0)' : 'No'}</span></div>
                <div>cgroups Resource Control: <span className="text-slate-200">{report.components.capabilities.cgroups_support ? 'Mounted' : 'Restricted'}</span></div>
                <div>Platform: <span className="text-slate-200">{report.components.capabilities.platform}</span></div>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
};
