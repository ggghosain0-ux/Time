import React, { useEffect, useRef, useState } from 'react';
import { Terminal as XTerm } from '@xterm/xterm';
import { FitAddon } from '@xterm/addon-fit';
import { VM } from '../types';
import { useAuth } from '../context/AuthContext';
import { Terminal as TerminalIcon, Maximize2, Minimize2, RefreshCw, X, Trash2, AlertCircle } from 'lucide-react';

interface TerminalModalProps {
  vm: VM;
  onClose: () => void;
}

export const TerminalModal: React.FC<TerminalModalProps> = ({ vm, onClose }) => {
  const { token } = useAuth();
  const terminalRef = useRef<HTMLDivElement>(null);
  const xtermInstance = useRef<XTerm | null>(null);
  const fitAddonRef = useRef<FitAddon | null>(null);
  const wsRef = useRef<WebSocket | null>(null);

  const [connectionStatus, setConnectionStatus] = useState<
    'connecting' | 'connected' | 'disconnected' | 'error'
  >('connecting');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const connectTerminal = () => {
    if (!token) {
      setConnectionStatus('error');
      setErrorMessage('Authentication token missing. Please sign in again.');
      return;
    }

    if (vm.status !== 'READY') {
      setConnectionStatus('error');
      setErrorMessage(`Cannot open terminal: Virtual machine is in status ${vm.status}. It must be running.`);
      return;
    }

    setConnectionStatus('connecting');
    setErrorMessage(null);

    // Close any previous socket
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/api/vms/${vm.id}/terminal?token=${encodeURIComponent(
      token
    )}`;

    const socket = new WebSocket(wsUrl);
    wsRef.current = socket;

    socket.onopen = () => {
      setConnectionStatus('connected');
      if (xtermInstance.current && fitAddonRef.current) {
        try {
          fitAddonRef.current.fit();
          const cols = xtermInstance.current.cols;
          const rows = xtermInstance.current.rows;
          socket.send(JSON.stringify({ type: 'resize', cols, rows }));
        } catch (e) {
          // ignore
        }
      }
    };

    socket.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);
        if (msg.type === 'stdout' && xtermInstance.current) {
          xtermInstance.current.write(msg.data);
        } else if (msg.type === 'error') {
          setConnectionStatus('error');
          setErrorMessage(msg.message);
          xtermInstance.current?.write(`\r\n\x1b[31;1m[SKVM Error: ${msg.message}]\x1b[0m\r\n`);
        } else if (msg.type === 'status') {
          xtermInstance.current?.write(`\r\n\x1b[33m[SKVM: ${msg.message}]\x1b[0m\r\n`);
        }
      } catch {
        // Plain text fallback
        if (xtermInstance.current) {
          xtermInstance.current.write(event.data);
        }
      }
    };

    socket.onclose = (event) => {
      setConnectionStatus('disconnected');
      if (event.code !== 1000) {
        const reason = event.reason || `Session closed (Code ${event.code})`;
        setErrorMessage(reason);
      }
    };

    socket.onerror = (err) => {
      console.error('Terminal WebSocket encountered an error:', err);
      setConnectionStatus('error');
      setErrorMessage('WebSocket connection failure. Check host engine and container availability.');
    };
  };

  useEffect(() => {
    if (!terminalRef.current) return;

    // Initialize xterm
    const term = new XTerm({
      cursorBlink: true,
      cursorStyle: 'block',
      fontFamily: 'Menlo, Monaco, "Courier New", monospace, Consolas',
      fontSize: 14,
      theme: {
        background: '#090d16',
        foreground: '#e2e8f0',
        cursor: '#10b981',
        selectionBackground: 'rgba(16, 185, 129, 0.3)',
        black: '#1e293b',
        red: '#ef4444',
        green: '#10b981',
        yellow: '#f59e0b',
        blue: '#3b82f6',
        magenta: '#d946ef',
        cyan: '#06b6d4',
        white: '#f8fafc',
        brightBlack: '#64748b',
        brightRed: '#f87171',
        brightGreen: '#34d399',
        brightYellow: '#fbbf24',
        brightBlue: '#60a5fa',
        brightMagenta: '#e879f9',
        brightCyan: '#22d3ee',
        brightWhite: '#ffffff',
      },
      convertEol: true,
    });

    const fitAddon = new FitAddon();
    term.loadAddon(fitAddon);
    term.open(terminalRef.current);

    try {
      fitAddon.fit();
    } catch {
      // ignore initial fit
    }

    xtermInstance.current = term;
    fitAddonRef.current = fitAddon;

    // Send keystrokes directly to backend container
    term.onData((data) => {
      if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({ type: 'input', data }));
      }
    });

    // Handle terminal resize
    term.onResize(({ cols, rows }) => {
      if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({ type: 'resize', cols, rows }));
      }
    });

    const handleWindowResize = () => {
      try {
        fitAddon.fit();
      } catch {
        // ignore
      }
    };
    window.addEventListener('resize', handleWindowResize);

    // Initial connection
    connectTerminal();

    return () => {
      window.removeEventListener('resize', handleWindowResize);
      if (wsRef.current) {
        wsRef.current.close();
        wsRef.current = null;
      }
      term.dispose();
      xtermInstance.current = null;
    };
  }, [vm.id, token]);

  const clearTerminal = () => {
    if (xtermInstance.current) {
      xtermInstance.current.clear();
    }
  };

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
    setTimeout(() => {
      fitAddonRef.current?.fit();
    }, 100);
  };

  const sendRawKey = (chars: string) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: 'input', data: chars }));
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className={`bg-slate-950 border border-slate-800 rounded-xl shadow-2xl flex flex-col overflow-hidden transition-all duration-200 ${
          isFullscreen
            ? 'w-full h-full fixed inset-0 rounded-none border-none'
            : 'w-full max-w-5xl h-[85vh] max-h-[800px]'
        }`}
      >
        {/* Terminal Header Bar */}
        <div className="bg-slate-900/90 border-b border-slate-800 px-4 py-3 flex items-center justify-between select-none">
          <div className="flex items-center space-x-3">
            <div className="flex space-x-1.5 items-center mr-2">
              <span className="w-3 h-3 rounded-full bg-rose-500/80 inline-block"></span>
              <span className="w-3 h-3 rounded-full bg-amber-500/80 inline-block"></span>
              <span className="w-3 h-3 rounded-full bg-emerald-500/80 inline-block"></span>
            </div>

            <div className="flex items-center space-x-2">
              <TerminalIcon className="w-4 h-4 text-emerald-400" />
              <span className="font-mono text-sm font-semibold text-slate-200">{vm.name}</span>
              <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-400 font-mono border border-slate-700">
                {vm.engine.toUpperCase()}
              </span>
              <span className="text-xs text-slate-500 font-mono hidden md:inline">
                {vm.os}
              </span>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            {/* Real Connection Status Indicator */}
            <div className="flex items-center space-x-1.5 px-2.5 py-1 rounded-full text-xs font-mono border">
              {connectionStatus === 'connected' && (
                <span className="flex items-center space-x-1.5 text-emerald-400 border-emerald-800/60 bg-emerald-950/40">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                  <span>Connected</span>
                </span>
              )}
              {connectionStatus === 'connecting' && (
                <span className="flex items-center space-x-1.5 text-amber-400 border-amber-800/60 bg-amber-950/40">
                  <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping"></span>
                  <span>Connecting...</span>
                </span>
              )}
              {connectionStatus === 'disconnected' && (
                <span className="flex items-center space-x-1.5 text-slate-400 border-slate-700 bg-slate-800/50">
                  <span className="w-2 h-2 rounded-full bg-slate-500"></span>
                  <span>Disconnected</span>
                </span>
              )}
              {connectionStatus === 'error' && (
                <span className="flex items-center space-x-1.5 text-rose-400 border-rose-800/60 bg-rose-950/40">
                  <span className="w-2 h-2 rounded-full bg-rose-500"></span>
                  <span>Error</span>
                </span>
              )}
            </div>

            {/* Actions */}
            <div className="flex items-center space-x-1">
              <button
                onClick={clearTerminal}
                title="Clear screen buffer"
                className="p-1.5 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
              >
                <Trash2 className="w-4 h-4" />
              </button>

              <button
                onClick={connectTerminal}
                title="Reconnect terminal session"
                className="p-1.5 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
              >
                <RefreshCw className="w-4 h-4" />
              </button>

              <button
                onClick={toggleFullscreen}
                title={isFullscreen ? 'Exit fullscreen' : 'Fullscreen'}
                className="p-1.5 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
              >
                {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
              </button>

              <button
                onClick={onClose}
                title="Close terminal"
                className="p-1.5 rounded text-slate-400 hover:text-rose-400 hover:bg-rose-950/30 transition-colors ml-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Error notification banner if any */}
        {errorMessage && (
          <div className="bg-rose-950/80 border-b border-rose-900/60 px-4 py-2 flex items-center justify-between text-xs text-rose-200 font-mono">
            <div className="flex items-center space-x-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{errorMessage}</span>
            </div>
            <button
              onClick={() => setErrorMessage(null)}
              className="text-rose-400 hover:text-rose-200"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Interactive Virtual Shortcuts Toolbar */}
        <div className="bg-slate-900/60 border-b border-slate-800/80 px-4 py-1.5 flex items-center justify-between overflow-x-auto text-[11px] font-mono">
          <div className="flex items-center space-x-1.5 shrink-0">
            <span className="text-slate-500 mr-1 hidden sm:inline">Shortcuts:</span>
            <button
              onClick={() => sendRawKey('\x03')}
              className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 font-semibold"
              title="Send SIGINT (Interrupt)"
            >
              Ctrl+C
            </button>
            <button
              onClick={() => sendRawKey('\t')}
              className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 font-semibold"
              title="Send Tab (Autocomplete)"
            >
              Tab
            </button>
            <button
              onClick={() => sendRawKey('\x0c')}
              className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 font-semibold"
              title="Clear terminal screen"
            >
              Ctrl+L
            </button>
            <button
              onClick={() => sendRawKey('\x1b')}
              className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 font-semibold"
              title="Send Escape"
            >
              Esc
            </button>
            <button
              onClick={() => sendRawKey('\x1b[A')}
              className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 font-semibold"
              title="Previous command"
            >
              ▲ Up
            </button>
            <button
              onClick={() => sendRawKey('\x1b[B')}
              className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 font-semibold"
              title="Next command"
            >
              ▼ Down
            </button>
          </div>

          <div className="text-[10px] text-slate-500 hidden md:block">
            Direct pseudo-terminal attached
          </div>
        </div>

        {/* Real Container Interactive Terminal Container */}
        <div className="flex-1 p-3 bg-[#090d16] overflow-hidden cursor-text">
          <div ref={terminalRef} className="w-full h-full" />
        </div>

        {/* Terminal Footer with container metadata */}
        <div className="bg-slate-900/80 border-t border-slate-800/80 px-4 py-1.5 text-[11px] font-mono text-slate-400 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <span>Container ID: <span className="text-slate-300">{vm.container_id ? vm.container_id.substring(0, 12) : 'None'}</span></span>
            <span>IP: <span className="text-slate-300">{vm.ip_address || 'Unavailable'}</span></span>
            <span>Shell: <span className="text-slate-300">/bin/bash (fallback /bin/sh)</span></span>
          </div>
          <div className="text-slate-500 hidden sm:block">
            Input routes directly to real container process
          </div>
        </div>
      </div>
    </div>
  );
};
