import React, { useState, useEffect } from 'react';
import { VM } from '../types';
import { api } from '../api';
import {
  Layers,
  Terminal,
  Cpu,
  HardDrive,
  Globe,
  Clock,
  RefreshCw,
  X,
  FileText,
  Info,
  Play,
  Square,
  RotateCw,
  Folder,
  File,
  ChevronRight,
  Send,
  Copy,
  Check,
  Archive,
  Network,
  Download,
  AlertCircle,
} from 'lucide-react';

interface VMDetailsModalProps {
  vm: VM;
  onClose: () => void;
  onOpenTerminal: (vm: VM) => void;
  onRefreshVM: () => void;
}

export const VMDetailsModal: React.FC<VMDetailsModalProps> = ({
  vm,
  onClose,
  onOpenTerminal,
  onRefreshVM,
}) => {
  const [activeTab, setActiveTab] = useState<
    'details' | 'files' | 'commands' | 'network' | 'logs' | 'backups'
  >('details');

  // Logs state
  const [logs, setLogs] = useState<string>('');
  const [logsLoading, setLogsLoading] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);

  // Files state
  const [currentPath, setCurrentPath] = useState('/root');
  const [files, setFiles] = useState<
    Array<{ name: string; isDir: boolean; size: string; permissions: string; updated: string }>
  >([]);
  const [filesLoading, setFilesLoading] = useState(false);
  const [filesError, setFilesError] = useState<string | null>(null);
  const [viewingFile, setViewingFile] = useState<{ name: string; content: string } | null>(null);

  // Commands state
  const [customCommand, setCustomCommand] = useState('');
  const [commandOutput, setCommandOutput] = useState<string | null>(null);
  const [commandRunning, setCommandRunning] = useState(false);

  // SSH copy state
  const [copiedSSH, setCopiedSSH] = useState(false);

  // Backups state
  const [backups, setBackups] = useState<Array<{ id: string; name: string; size: string; date: string }>>([
    {
      id: 'snap-1',
      name: `snap-${vm.name}-init`,
      size: `${(vm.disk_gb * 0.15).toFixed(1)} GB`,
      date: new Date(vm.created_at).toLocaleDateString(),
    },
  ]);
  const [creatingBackup, setCreatingBackup] = useState(false);

  const fetchLogs = async () => {
    setLogsLoading(true);
    try {
      const res = await api.getVMLogs(vm.id);
      setLogs(res.logs || 'No log output returned from container.');
    } catch (err: any) {
      setLogs(`Failed to retrieve logs: ${err.message}`);
    } finally {
      setLogsLoading(false);
    }
  };

  const fetchFiles = async (targetPath = currentPath) => {
    if (vm.status !== 'READY') return;
    setFilesLoading(true);
    setFilesError(null);
    try {
      const res = await api.getVMFiles(vm.id, targetPath);
      setCurrentPath(res.path || targetPath);
      setFiles(res.files || []);
      if (res.message) {
        setFilesError(res.message);
      }
    } catch (err: any) {
      setFilesError(err.message || 'Failed to list container files');
    } finally {
      setFilesLoading(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'logs') {
      fetchLogs();
    } else if (activeTab === 'files') {
      fetchFiles(currentPath);
    }
  }, [activeTab, vm.id]);

  const handleStart = async () => {
    setActionLoading(true);
    try {
      await api.startVM(vm.id);
      onRefreshVM();
    } finally {
      setActionLoading(false);
    }
  };

  const handleStop = async () => {
    setActionLoading(true);
    try {
      await api.stopVM(vm.id);
      onRefreshVM();
    } finally {
      setActionLoading(false);
    }
  };

  const handleRestart = async () => {
    setActionLoading(true);
    try {
      await api.restartVM(vm.id);
      onRefreshVM();
    } finally {
      setActionLoading(false);
    }
  };

  const handleExecuteCommand = async (cmd: string) => {
    if (!cmd.trim() || vm.status !== 'READY') return;
    setCommandRunning(true);
    try {
      const res = await api.sendVMCommand(vm.id, cmd);
      setCommandOutput(`$ ${cmd}\n\n${res.output || '(No output returned)'}`);
    } catch (err: any) {
      setCommandOutput(`$ ${cmd}\n\n[Error: ${err.message}]`);
    } finally {
      setCommandRunning(false);
    }
  };

  const handleFileClick = (file: { name: string; isDir: boolean }) => {
    if (file.isDir) {
      const newPath = currentPath === '/' ? `/${file.name}` : `${currentPath}/${file.name}`;
      fetchFiles(newPath);
    } else {
      const filePath = currentPath === '/' ? `/${file.name}` : `${currentPath}/${file.name}`;
      api.sendVMCommand(vm.id, `head -n 250 "${filePath}"`)
        .then((res) => {
          setViewingFile({ name: file.name, content: res.output });
        })
        .catch((err) => {
          setFilesError(err.message);
        });
    }
  };

  const handleCreateSnapshot = () => {
    setCreatingBackup(true);
    setTimeout(() => {
      setBackups([
        {
          id: `snap-${Date.now()}`,
          name: `snapshot-${new Date().toISOString().slice(0, 10)}-manual`,
          size: `${(vm.disk_gb * 0.18).toFixed(1)} GB`,
          date: new Date().toLocaleDateString(),
        },
        ...backups,
      ]);
      setCreatingBackup(false);
    }, 1200);
  };

  const sshCommand = `ssh ${vm.username}@${vm.ip_address || '127.0.0.1'}`;

  const copySSH = () => {
    navigator.clipboard.writeText(sshCommand);
    setCopiedSSH(true);
    setTimeout(() => setCopiedSSH(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-3xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Top Header */}
        <div className="bg-slate-950 px-5 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center font-mono font-bold text-emerald-400 text-sm">
              {vm.engine === 'docker' ? 'D' : 'L'}
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-base font-bold font-mono text-slate-100">{vm.name}</h3>
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                  {vm.engine}
                </span>
                <span
                  className={`text-[10px] font-mono px-2 py-0.5 rounded-full ${
                    vm.status === 'READY'
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                      : 'bg-slate-800 text-slate-400 border border-slate-700'
                  }`}
                >
                  {vm.status}
                </span>
              </div>
              <div className="text-xs text-slate-500 font-mono mt-0.5">
                Hostname: {vm.hostname} • OS: {vm.os}
              </div>
            </div>
          </div>

          <button onClick={onClose} className="p-1 rounded text-slate-400 hover:text-slate-200">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector Bar */}
        <div className="bg-slate-950/70 px-5 border-b border-slate-800 flex space-x-2 overflow-x-auto text-xs font-mono">
          <button
            onClick={() => setActiveTab('details')}
            className={`py-3 px-2 font-semibold border-b-2 flex items-center space-x-1.5 transition-colors whitespace-nowrap ${
              activeTab === 'details'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Info className="w-3.5 h-3.5" />
            <span>Specifications</span>
          </button>

          <button
            onClick={() => setActiveTab('files')}
            className={`py-3 px-2 font-semibold border-b-2 flex items-center space-x-1.5 transition-colors whitespace-nowrap ${
              activeTab === 'files'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Folder className="w-3.5 h-3.5" />
            <span>Container Files</span>
          </button>

          <button
            onClick={() => setActiveTab('commands')}
            className={`py-3 px-2 font-semibold border-b-2 flex items-center space-x-1.5 transition-colors whitespace-nowrap ${
              activeTab === 'commands'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>Quick Commands</span>
          </button>

          <button
            onClick={() => setActiveTab('network')}
            className={`py-3 px-2 font-semibold border-b-2 flex items-center space-x-1.5 transition-colors whitespace-nowrap ${
              activeTab === 'network'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Network className="w-3.5 h-3.5" />
            <span>Network</span>
          </button>

          <button
            onClick={() => setActiveTab('logs')}
            className={`py-3 px-2 font-semibold border-b-2 flex items-center space-x-1.5 transition-colors whitespace-nowrap ${
              activeTab === 'logs'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Logs</span>
          </button>

          <button
            onClick={() => setActiveTab('backups')}
            className={`py-3 px-2 font-semibold border-b-2 flex items-center space-x-1.5 transition-colors whitespace-nowrap ${
              activeTab === 'backups'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Archive className="w-3.5 h-3.5" />
            <span>Snapshots</span>
          </button>
        </div>

        {/* Modal Body Viewport */}
        <div className="p-5 overflow-y-auto flex-1 text-xs font-mono text-slate-300 space-y-4">
          {/* TAB 1: Specifications */}
          {activeTab === 'details' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <div className="text-slate-500 text-[11px] mb-1">Operating System</div>
                  <div className="font-semibold text-slate-200">{vm.os}</div>
                </div>

                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <div className="text-slate-500 text-[11px] mb-1">CPU Allocation</div>
                  <div className="font-semibold text-slate-200">{vm.cpu_cores} Core(s)</div>
                </div>

                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <div className="text-slate-500 text-[11px] mb-1">Memory (RAM)</div>
                  <div className="font-semibold text-slate-200">{vm.ram_mb} MB</div>
                </div>

                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <div className="text-slate-500 text-[11px] mb-1">Disk Storage</div>
                  <div className="font-semibold text-slate-200">{vm.disk_gb} GB</div>
                </div>

                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <div className="text-slate-500 text-[11px] mb-1">Real IP Address</div>
                  <div className={`font-semibold ${vm.ip_address ? 'text-emerald-400' : 'text-slate-500'}`}>
                    {vm.ip_address || 'Unavailable'}
                  </div>
                </div>

                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <div className="text-slate-500 text-[11px] mb-1">Host Engine</div>
                  <div className="font-semibold text-slate-200 uppercase">{vm.engine}</div>
                </div>
              </div>

              {/* SSH Connect Snippet */}
              <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="text-slate-500 text-[11px]">SSH Connect Command</div>
                  <code className="text-emerald-400 font-semibold text-xs select-all mt-0.5 block">
                    {sshCommand}
                  </code>
                </div>
                <button
                  onClick={copySSH}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center space-x-1"
                >
                  {copiedSSH ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedSSH ? 'Copied' : 'Copy'}</span>
                </button>
              </div>

              {/* Host Engine Metadata */}
              <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-2 text-[11px]">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Host Engine Container ID:</span>
                  <span className="text-slate-300 select-all font-bold">
                    {vm.container_id || 'None allocated'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Created At:</span>
                  <span className="text-slate-300">{new Date(vm.created_at).toLocaleString()}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Last Synchronized:</span>
                  <span className="text-slate-300">{new Date(vm.updated_at).toLocaleString()}</span>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: Container Files */}
          {activeTab === 'files' && (
            <div className="space-y-3">
              {vm.status !== 'READY' ? (
                <div className="p-8 text-center text-slate-500 bg-slate-950 rounded-xl border border-slate-800">
                  <AlertCircle className="w-8 h-8 text-amber-500 mx-auto mb-2" />
                  <p>Start the virtual machine to explore its real container filesystem.</p>
                </div>
              ) : (
                <>
                  {/* Path bar */}
                  <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between">
                    <div className="flex items-center space-x-1">
                      <span className="text-slate-500">Path:</span>
                      <span className="text-emerald-400 font-semibold">{currentPath}</span>
                    </div>
                    {currentPath !== '/' && (
                      <button
                        onClick={() => {
                          const segs = currentPath.split('/').filter(Boolean);
                          segs.pop();
                          fetchFiles(segs.length === 0 ? '/' : `/${segs.join('/')}`);
                        }}
                        className="px-2 py-0.5 rounded bg-slate-800 text-[10px] text-slate-300"
                      >
                        Up One Level
                      </button>
                    )}
                  </div>

                  {filesError && (
                    <div className="p-2 bg-rose-950/40 border border-rose-900/60 rounded text-rose-300 text-xs">
                      {filesError}
                    </div>
                  )}

                  {/* Files table */}
                  <div className="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden max-h-64 overflow-y-auto">
                    {filesLoading ? (
                      <div className="p-8 text-center text-slate-500">Reading directory...</div>
                    ) : (
                      <table className="w-full text-left text-xs">
                        <thead className="bg-slate-900 border-b border-slate-800 text-slate-400 text-[11px]">
                          <tr>
                            <th className="px-3 py-2">Name</th>
                            <th className="px-3 py-2">Size</th>
                            <th className="px-3 py-2">Permissions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800/60">
                          {files.map((f) => (
                            <tr
                              key={f.name}
                              onClick={() => handleFileClick(f)}
                              className="hover:bg-slate-800/40 cursor-pointer"
                            >
                              <td className="px-3 py-2 flex items-center space-x-2">
                                {f.isDir ? (
                                  <Folder className="w-3.5 h-3.5 text-emerald-400" />
                                ) : (
                                  <File className="w-3.5 h-3.5 text-slate-400" />
                                )}
                                <span className={f.isDir ? 'text-emerald-300 font-semibold' : 'text-slate-200'}>
                                  {f.name}
                                </span>
                              </td>
                              <td className="px-3 py-2 text-slate-400">{f.size}</td>
                              <td className="px-3 py-2 text-slate-500 text-[10px]">{f.permissions}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    )}
                  </div>
                </>
              )}
            </div>
          )}

          {/* TAB 3: Quick Commands */}
          {activeTab === 'commands' && (
            <div className="space-y-3">
              {vm.status !== 'READY' ? (
                <div className="p-8 text-center text-slate-500 bg-slate-950 rounded-xl border border-slate-800">
                  <AlertCircle className="w-8 h-8 text-amber-500 mx-auto mb-2" />
                  <p>Start the virtual machine to run commands inside the container.</p>
                </div>
              ) : (
                <>
                  {/* Preset Command Chips */}
                  <div>
                    <div className="text-[11px] text-slate-400 mb-1.5">Quick Diagnostics:</div>
                    <div className="flex flex-wrap gap-1.5">
                      {['uptime', 'uname -a', 'free -m', 'df -h', 'ps aux', 'ip a', 'cat /etc/os-release'].map(
                        (cmd) => (
                          <button
                            key={cmd}
                            onClick={() => handleExecuteCommand(cmd)}
                            disabled={commandRunning}
                            className="px-2.5 py-1 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-[11px] text-emerald-300"
                          >
                            {cmd}
                          </button>
                        )
                      )}
                    </div>
                  </div>

                  {/* Custom Command Input */}
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      handleExecuteCommand(customCommand);
                    }}
                    className="flex space-x-2"
                  >
                    <input
                      type="text"
                      placeholder="Type custom command (e.g. whoami, env, cat /etc/hosts)..."
                      value={customCommand}
                      onChange={(e) => setCustomCommand(e.target.value)}
                      className="flex-1 px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
                    />
                    <button
                      type="submit"
                      disabled={commandRunning || !customCommand.trim()}
                      className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center space-x-1"
                    >
                      <span>{commandRunning ? 'Running...' : 'Execute'}</span>
                      <Send className="w-3 h-3" />
                    </button>
                  </form>

                  {/* Output Preview */}
                  {commandOutput && (
                    <pre className="p-3 bg-[#080c14] border border-slate-800 rounded-xl text-slate-200 text-xs overflow-y-auto max-h-60 select-text whitespace-pre-wrap">
                      {commandOutput}
                    </pre>
                  )}
                </>
              )}
            </div>
          )}

          {/* TAB 4: Network */}
          {activeTab === 'network' && (
            <div className="space-y-3">
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2.5">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-500">Container IP:</span>
                  <span className="text-emerald-400 font-bold">{vm.ip_address || '172.17.0.2'}</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-500">Default Gateway:</span>
                  <span className="text-slate-300">172.17.0.1</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-500">Subnet Mask:</span>
                  <span className="text-slate-300">255.255.0.0 (/16)</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-500">Primary SSH Port:</span>
                  <span className="text-cyan-300">22 (TCP)</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-500">DNS Resolvers:</span>
                  <span className="text-slate-300">1.1.1.1, 8.8.8.8</span>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: Logs */}
          {activeTab === 'logs' && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-slate-400 text-[11px]">Container Stdout & Stderr Stream:</span>
                <button
                  onClick={fetchLogs}
                  className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center space-x-1"
                >
                  <RefreshCw className={`w-3 h-3 ${logsLoading ? 'animate-spin' : ''}`} />
                  <span>Refresh Logs</span>
                </button>
              </div>

              <pre className="p-4 bg-[#090d16] border border-slate-800 rounded-xl text-slate-300 text-xs font-mono max-h-72 overflow-y-auto whitespace-pre-wrap select-text">
                {logsLoading ? 'Retrieving container log stream...' : logs || 'No log entries available.'}
              </pre>
            </div>
          )}

          {/* TAB 6: Snapshots & Backups */}
          {activeTab === 'backups' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-slate-400 text-xs">Saved Snapshots:</span>
                <button
                  onClick={handleCreateSnapshot}
                  disabled={creatingBackup}
                  className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold"
                >
                  {creatingBackup ? 'Creating...' : '+ Create Snapshot'}
                </button>
              </div>

              <div className="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-900 border-b border-slate-800 text-slate-400 text-[11px]">
                    <tr>
                      <th className="px-3 py-2">Snapshot</th>
                      <th className="px-3 py-2">Size</th>
                      <th className="px-3 py-2">Date</th>
                      <th className="px-3 py-2 text-right">Download</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {backups.map((b) => (
                      <tr key={b.id} className="hover:bg-slate-800/30">
                        <td className="px-3 py-2 text-emerald-300 font-semibold">{b.name}</td>
                        <td className="px-3 py-2 text-slate-400">{b.size}</td>
                        <td className="px-3 py-2 text-slate-500">{b.date}</td>
                        <td className="px-3 py-2 text-right">
                          <button
                            onClick={() => alert(`Starting download of ${b.name}.tar.gz`)}
                            className="p-1 rounded text-slate-400 hover:text-slate-200"
                          >
                            <Download className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        {/* Modal Bottom Footer Actions */}
        <div className="bg-slate-950 px-5 py-3 border-t border-slate-800 flex items-center justify-between">
          <button
            onClick={() => {
              onClose();
              onOpenTerminal(vm);
            }}
            disabled={vm.status !== 'READY'}
            className={`px-4 py-2 rounded-xl font-mono text-xs font-semibold flex items-center space-x-2 transition-all ${
              vm.status === 'READY'
                ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-950 cursor-pointer'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700/50'
            }`}
          >
            <Terminal className="w-4 h-4" />
            <span>Open Browser Terminal</span>
          </button>

          <div className="flex items-center space-x-2">
            {vm.status === 'STOPPED' && (
              <button
                onClick={handleStart}
                disabled={actionLoading}
                className="px-3 py-1.5 rounded-lg bg-emerald-950 text-emerald-300 border border-emerald-800 flex items-center space-x-1 text-xs"
              >
                <Play className="w-3.5 h-3.5" />
                <span>Start</span>
              </button>
            )}

            {vm.status === 'READY' && (
              <>
                <button
                  onClick={handleRestart}
                  disabled={actionLoading}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 flex items-center space-x-1 text-xs"
                >
                  <RotateCw className="w-3.5 h-3.5" />
                  <span>Restart</span>
                </button>
                <button
                  onClick={handleStop}
                  disabled={actionLoading}
                  className="px-3 py-1.5 rounded-lg bg-amber-950 text-amber-300 border border-amber-800 flex items-center space-x-1 text-xs"
                >
                  <Square className="w-3.5 h-3.5" />
                  <span>Stop</span>
                </button>
              </>
            )}

            <button
              onClick={onClose}
              className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs"
            >
              Close
            </button>
          </div>
        </div>

        {/* Modal File Viewer Popup */}
        {viewingFile && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-4 flex flex-col max-h-[75vh]">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800 text-slate-200 font-bold text-xs">
                <span>{viewingFile.name}</span>
                <button onClick={() => setViewingFile(null)} className="text-slate-400 hover:text-white">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <pre className="p-3 bg-slate-950 text-slate-300 text-xs font-mono overflow-y-auto flex-1 select-text whitespace-pre-wrap mt-2 rounded-xl">
                {viewingFile.content || 'File is empty.'}
              </pre>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
