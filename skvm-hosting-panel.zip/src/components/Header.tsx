import React from 'react';
import { useAuth } from '../context/AuthContext';
import { Server, Terminal, Shield, Key, FileText, Settings, Activity, LogOut, Cpu, HardDrive } from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  systemName?: string;
  isInfrastructureReady?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  systemName = 'SKVM Panel',
  isInfrastructureReady = false,
}) => {
  const { user, logout } = useAuth();

  return (
    <header className="bg-slate-900 border-b border-slate-800 sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Node Indicator */}
          <div className="flex items-center space-x-6">
            <div
              onClick={() => setActiveTab('overview')}
              className="flex items-center space-x-3 cursor-pointer group"
            >
              <div className="w-9 h-9 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 group-hover:border-emerald-500 transition-colors shadow-sm shadow-emerald-950">
                <Server className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <span className="font-bold text-slate-100 tracking-wider text-base font-mono">SKVM</span>
                  <span className="text-xs px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 font-mono border border-slate-700">v1.0</span>
                </div>
                <div className="text-[11px] text-slate-400 font-medium tracking-tight">
                  {systemName}
                </div>
              </div>
            </div>

            {/* Infrastructure Engine Status Tag */}
            <div className="hidden md:flex items-center space-x-2 pl-4 border-l border-slate-800 text-xs">
              <span className="text-slate-500">Host Engine:</span>
              {isInfrastructureReady ? (
                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium bg-emerald-950 text-emerald-300 border border-emerald-800">
                  <span className="w-1.5 h-1.5 mr-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  Active
                </span>
              ) : (
                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium bg-amber-950/80 text-amber-300 border border-amber-800">
                  <span className="w-1.5 h-1.5 mr-1.5 rounded-full bg-amber-400"></span>
                  Host Limited
                </span>
              )}
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="flex items-center space-x-1 sm:space-x-2">
            <button
              onClick={() => setActiveTab('overview')}
              className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors flex items-center space-x-1.5 ${
                activeTab === 'overview'
                  ? 'bg-slate-800 text-white border border-slate-700'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <Cpu className="w-4 h-4" />
              <span>{user?.role === 'admin' ? 'Overview' : 'My Dashboard'}</span>
            </button>

            <button
              onClick={() => setActiveTab('vms')}
              className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors flex items-center space-x-1.5 ${
                activeTab === 'vms'
                  ? 'bg-slate-800 text-white border border-slate-700'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <Terminal className="w-4 h-4" />
              <span>{user?.role === 'admin' ? 'Virtual Machines' : 'My VMs'}</span>
            </button>

            {user?.role === 'admin' && (
              <>
                <button
                  onClick={() => setActiveTab('users')}
                  className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors flex items-center space-x-1.5 ${
                    activeTab === 'users'
                      ? 'bg-slate-800 text-white border border-slate-700'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                  }`}
                >
                  <Shield className="w-4 h-4" />
                  <span className="hidden sm:inline">Users</span>
                </button>

                <button
                  onClick={() => setActiveTab('keys')}
                  className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors flex items-center space-x-1.5 ${
                    activeTab === 'keys'
                      ? 'bg-slate-800 text-white border border-slate-700'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                  }`}
                >
                  <Key className="w-4 h-4" />
                  <span className="hidden sm:inline">API Keys</span>
                </button>

                <button
                  onClick={() => setActiveTab('logs')}
                  className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors flex items-center space-x-1.5 ${
                    activeTab === 'logs'
                      ? 'bg-slate-800 text-white border border-slate-700'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                  }`}
                >
                  <FileText className="w-4 h-4" />
                  <span className="hidden sm:inline">Logs</span>
                </button>

                <button
                  onClick={() => setActiveTab('health')}
                  className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors flex items-center space-x-1.5 ${
                    activeTab === 'health'
                      ? 'bg-slate-800 text-white border border-slate-700'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                  }`}
                >
                  <Activity className="w-4 h-4" />
                  <span className="hidden sm:inline">Health</span>
                </button>

                <button
                  onClick={() => setActiveTab('settings')}
                  className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors flex items-center space-x-1.5 ${
                    activeTab === 'settings'
                      ? 'bg-slate-800 text-white border border-slate-700'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                  }`}
                >
                  <Settings className="w-4 h-4" />
                  <span className="hidden sm:inline">Settings</span>
                </button>
              </>
            )}

            {user?.role !== 'admin' && (
              <button
                onClick={() => setActiveTab('user-settings')}
                className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors flex items-center space-x-1.5 ${
                  activeTab === 'user-settings'
                    ? 'bg-slate-800 text-white border border-slate-700'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                }`}
              >
                <Settings className="w-4 h-4" />
                <span>Settings</span>
              </button>
            )}
          </nav>

          {/* User Profile & Logout */}
          <div className="flex items-center space-x-3">
            <div className="text-right hidden sm:block">
              <div className="text-xs font-semibold text-slate-200 flex items-center justify-end space-x-1.5">
                <span>{user?.username}</span>
                <span className={`text-[10px] uppercase font-mono px-1.5 py-0.2 rounded border ${
                  user?.role === 'admin'
                    ? 'bg-purple-950/70 text-purple-300 border-purple-800'
                    : 'bg-blue-950/70 text-blue-300 border-blue-800'
                }`}>
                  {user?.role}
                </span>
              </div>
              <div className="text-[10px] text-slate-500 font-mono">{user?.email}</div>
            </div>

            <button
              onClick={logout}
              title="Sign Out"
              className="p-2 rounded-md text-slate-400 hover:text-rose-400 hover:bg-rose-950/30 transition-colors border border-transparent hover:border-rose-900/50"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
