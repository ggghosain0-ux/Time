import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { api } from '../api';
import { Server, Lock, User as UserIcon, ShieldAlert, ArrowRight, AlertCircle, Key } from 'lucide-react';

export const LoginModal: React.FC = () => {
  const { login, user, refreshUser } = useAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Forced password change state
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [changeLoading, setChangeLoading] = useState(false);
  const [changeError, setChangeError] = useState<string | null>(null);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      await login(username.trim(), password);
    } catch (err: any) {
      setError(err.message || 'Authentication failed');
    } finally {
      setLoading(false);
    }
  };

  const handleFirstPasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    setChangeError(null);

    if (newPassword.length < 8) {
      setChangeError('New password must be at least 8 characters long');
      return;
    }

    if (newPassword !== confirmPassword) {
      setChangeError('Passwords do not match');
      return;
    }

    setChangeLoading(true);
    try {
      await api.changePassword({ newPassword });
      await refreshUser();
    } catch (err: any) {
      setChangeError(err.message || 'Failed to update password');
    } finally {
      setChangeLoading(false);
    }
  };

  // If user is logged in but flagged with must_change_password
  if (user && user.must_change_password) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
        <div className="bg-slate-900 border border-amber-800/80 rounded-2xl p-6 sm:p-8 max-w-md w-full shadow-2xl">
          <div className="flex items-center space-x-3 text-amber-400 mb-4">
            <ShieldAlert className="w-8 h-8" />
            <div>
              <h2 className="text-lg font-bold text-slate-100 font-mono">Password Change Required</h2>
              <p className="text-xs text-slate-400">First-time login security protocol</p>
            </div>
          </div>

          <p className="text-xs text-slate-300 mb-5 bg-slate-950 p-3 rounded-lg border border-slate-800 font-mono">
            You are logged in with the initial installation credentials. For security, please define a new administrative password.
          </p>

          {changeError && (
            <div className="mb-4 p-3 bg-rose-950/60 border border-rose-900/60 rounded-lg text-xs text-rose-300 font-mono flex items-center space-x-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{changeError}</span>
            </div>
          )}

          <form onSubmit={handleFirstPasswordChange} className="space-y-4">
            <div>
              <label className="block text-xs font-mono font-semibold text-slate-300 mb-1">
                New Password (min 8 characters) *
              </label>
              <input
                type="password"
                required
                minLength={8}
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 text-sm focus:outline-none focus:border-amber-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-mono font-semibold text-slate-300 mb-1">
                Confirm New Password *
              </label>
              <input
                type="password"
                required
                minLength={8}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 text-sm focus:outline-none focus:border-amber-500 font-mono"
              />
            </div>

            <button
              type="submit"
              disabled={changeLoading}
              className="w-full py-2.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-white font-mono text-xs font-semibold tracking-wide transition-all shadow-md shadow-amber-950 flex items-center justify-center space-x-2"
            >
              <Key className="w-4 h-4" />
              <span>{changeLoading ? 'Updating Password...' : 'Save & Enter Control Panel'}</span>
            </button>
          </form>
        </div>
      </div>
    );
  }

  // Standard Login Form
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 max-w-md w-full shadow-2xl relative overflow-hidden">
        {/* Glow decoration */}
        <div className="absolute -top-24 -left-24 w-48 h-48 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="text-center mb-6">
          <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 mx-auto mb-3 shadow-md shadow-emerald-950">
            <Server className="w-6 h-6" />
          </div>
          <h1 className="text-2xl font-bold text-slate-100 font-mono tracking-wider">SKVM</h1>
          <p className="text-xs text-slate-400 mt-1">Linux Container Infrastructure Panel</p>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-rose-950/60 border border-rose-900/60 rounded-lg text-xs text-rose-300 font-mono flex items-center space-x-2">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-xs font-mono font-semibold text-slate-300 mb-1">
              Username or Email
            </label>
            <div className="relative">
              <input
                type="text"
                required
                autoFocus
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="admin@gmail.com"
                className="w-full pl-9 pr-3 py-2.5 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 text-sm focus:outline-none focus:border-emerald-500 font-mono"
              />
              <UserIcon className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
            </div>
          </div>

          <div>
            <label className="block text-xs font-mono font-semibold text-slate-300 mb-1">
              Password
            </label>
            <div className="relative">
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="admin123"
                className="w-full pl-9 pr-3 py-2.5 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 text-sm focus:outline-none focus:border-emerald-500 font-mono"
              />
              <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs font-semibold tracking-wide transition-all shadow-md shadow-emerald-950 flex items-center justify-center space-x-2 cursor-pointer"
          >
            <span>{loading ? 'Authenticating...' : 'Sign In to Panel'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <div className="mt-6 pt-4 border-t border-slate-800/80 text-center">
          <div className="text-[11px] font-mono text-slate-500">
            Default Admin: <code className="text-slate-300 font-bold">admin@gmail.com</code> • Password: <code className="text-slate-300 font-bold">admin123</code>
          </div>
        </div>
      </div>
    </div>
  );
};
