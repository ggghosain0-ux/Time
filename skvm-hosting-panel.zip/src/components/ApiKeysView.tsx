import React, { useState, useEffect } from 'react';
import { api } from '../api';
import { ApiKey } from '../types';
import { Key, Plus, Trash2, Copy, Check, AlertTriangle, ShieldCheck } from 'lucide-react';

export const ApiKeysView: React.FC = () => {
  const [keys, setKeys] = useState<ApiKey[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Modal for new key
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [keyName, setKeyName] = useState('');
  const [createdSecret, setCreatedSecret] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const fetchKeys = async () => {
    setLoading(true);
    try {
      const res = await api.getKeys();
      setKeys(res.keys);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchKeys();
  }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!keyName.trim()) return;

    setSubmitting(true);
    setError(null);
    try {
      const res = await api.createKey(keyName.trim());
      setCreatedSecret(res.key.secret_token || null);
      fetchKeys();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to revoke this API key? Applications using it will lose access immediately.')) {
      return;
    }

    try {
      await api.deleteKey(id);
      fetchKeys();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const closeCreateModal = () => {
    setIsCreateOpen(false);
    setCreatedSecret(null);
    setKeyName('');
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-100 font-mono flex items-center space-x-2">
            <Key className="w-5 h-5 text-emerald-400" />
            <span>Infrastructure API Keys</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Cryptographically generated API keys for programmatic automation and CI/CD pipelines.
          </p>
        </div>

        <button
          onClick={() => setIsCreateOpen(true)}
          className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs font-semibold flex items-center space-x-1.5 transition-all shadow-md shadow-emerald-950 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Generate API Key</span>
        </button>
      </div>

      {error && (
        <div className="p-3 bg-rose-950/50 border border-rose-900/60 rounded-lg text-xs text-rose-300 font-mono flex items-center space-x-2">
          <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Keys List */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        {loading ? (
          <div className="p-8 text-center text-xs font-mono text-slate-500">Loading API keys...</div>
        ) : keys.length === 0 ? (
          <div className="p-12 text-center">
            <Key className="w-8 h-8 text-slate-600 mx-auto mb-2" />
            <h3 className="text-sm font-semibold text-slate-300">No API Keys Generated</h3>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              Create an API key to access SKVM REST endpoints externally using the <code>X-API-Key</code> header.
            </p>
          </div>
        ) : (
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-950/80 border-b border-slate-800 text-slate-400">
              <tr>
                <th className="px-4 py-3 font-semibold">Key Name</th>
                <th className="px-4 py-3 font-semibold">Prefix</th>
                <th className="px-4 py-3 font-semibold">Created Date</th>
                <th className="px-4 py-3 font-semibold">Last Used</th>
                <th className="px-4 py-3 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {keys.map((k) => (
                <tr key={k.id} className="hover:bg-slate-800/40">
                  <td className="px-4 py-3 font-semibold text-slate-200">{k.name}</td>
                  <td className="px-4 py-3 font-mono text-slate-400">
                    <span className="bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                      {k.key_prefix}...
                    </span>
                  </td>
                  <td className="px-4 py-3 text-slate-400">{new Date(k.created_at).toLocaleDateString()}</td>
                  <td className="px-4 py-3 text-slate-500">
                    {k.last_used_at ? new Date(k.last_used_at).toLocaleString() : 'Never'}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button
                      onClick={() => handleDelete(k.id)}
                      className="p-1.5 rounded text-slate-500 hover:text-rose-400 hover:bg-rose-950/30 transition-colors"
                      title="Revoke Key"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Generate Key Modal */}
      {isCreateOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 max-w-md w-full shadow-2xl">
            {!createdSecret ? (
              <form onSubmit={handleCreate}>
                <div className="flex items-center space-x-2 text-slate-100 font-mono font-bold text-base mb-4">
                  <Key className="w-5 h-5 text-emerald-400" />
                  <span>Generate New API Key</span>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-mono font-semibold text-slate-300 mb-1">
                      Key Name / Identifier *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. CI/CD Pipeline Worker"
                      value={keyName}
                      onChange={(e) => setKeyName(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 text-sm focus:outline-none focus:border-emerald-500 font-mono"
                    />
                  </div>

                  <p className="text-xs text-slate-400">
                    API keys allow complete administrative control over SKVM virtual machines and containers.
                    Keys are hashed with SHA-256 before storage.
                  </p>
                </div>

                <div className="mt-6 flex items-center justify-end space-x-3">
                  <button
                    type="button"
                    onClick={closeCreateModal}
                    className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono text-xs font-medium transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs font-semibold tracking-wide transition-all shadow-md shadow-emerald-950"
                  >
                    {submitting ? 'Generating...' : 'Generate Secret'}
                  </button>
                </div>
              </form>
            ) : (
              <div>
                <div className="flex items-center space-x-2 text-emerald-400 font-mono font-bold text-base mb-2">
                  <ShieldCheck className="w-5 h-5" />
                  <span>API Key Generated Successfully</span>
                </div>

                <div className="p-3 bg-amber-950/40 border border-amber-800/80 rounded-lg text-xs text-amber-300 font-mono mb-4">
                  <div className="font-bold flex items-center space-x-1.5 mb-1">
                    <AlertTriangle className="w-4 h-4 text-amber-400" />
                    <span>Important: Save this key now!</span>
                  </div>
                  <span>
                    For security reasons, this secret is hashed immediately and will never be displayed again.
                  </span>
                </div>

                <div className="relative">
                  <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg font-mono text-xs text-emerald-400 break-all select-all">
                    {createdSecret}
                  </div>
                  <button
                    onClick={() => copyToClipboard(createdSecret)}
                    className="absolute top-2 right-2 p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
                    title="Copy API Key"
                  >
                    {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>

                <div className="mt-6 flex justify-end">
                  <button
                    onClick={closeCreateModal}
                    className="px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs font-semibold"
                  >
                    I have saved this key
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
