import React, { useState, useEffect } from 'react';
import { api } from '../api';
import { User, LocalNodeInfo, SupportedOS } from '../types';
import { X, Layers, Cpu, HardDrive, Shield, AlertCircle, CheckCircle2 } from 'lucide-react';

interface CreateVMModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  nodeInfo?: LocalNodeInfo | null;
}

const SUPPORTED_OS_OPTIONS: { id: SupportedOS; name: string; tag: string }[] = [
  { id: 'Ubuntu 22.04', name: 'Ubuntu 22.04 LTS (Jammy Jellyfish)', tag: 'Recommended' },
  { id: 'Ubuntu 20.04', name: 'Ubuntu 20.04 LTS (Focal Fossa)', tag: 'LTS' },
  { id: 'Debian 12', name: 'Debian 12 (Bookworm)', tag: 'Stable' },
  { id: 'Debian 11', name: 'Debian 11 (Bullseye)', tag: 'Oldstable' },
];

export const CreateVMModal: React.FC<CreateVMModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  nodeInfo,
}) => {
  const [name, setName] = useState('');
  const [os, setOs] = useState<SupportedOS>('Ubuntu 22.04');
  const [cpuCores, setCpuCores] = useState(1);
  const [ramMb, setRamMb] = useState(1024);
  const [diskGb, setDiskGb] = useState(10);
  const [username, setUsername] = useState('root');
  const [password, setPassword] = useState('');
  const [hostname, setHostname] = useState('');
  const [targetUserId, setTargetUserId] = useState('');
  const [users, setUsers] = useState<User[]>([]);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      api.getUsers()
        .then((res) => setUsers(res.users))
        .catch(() => {});
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    // Front-end pre-validation
    if (!name.trim()) {
      setError('Please provide a Virtual Machine name');
      return;
    }

    if (!/^[a-zA-Z0-9_-]+$/.test(name.trim())) {
      setError('VM name can only contain letters, numbers, hyphens, and underscores');
      return;
    }

    setLoading(true);
    try {
      await api.createVM({
        name: name.trim(),
        os,
        cpu_cores: Number(cpuCores),
        ram_mb: Number(ramMb),
        disk_gb: Number(diskGb),
        username: username.trim() || 'root',
        password: password ? password : undefined,
        hostname: hostname.trim() || undefined,
        target_user_id: targetUserId || undefined,
      });

      onSuccess();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to submit provisioning task');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 max-w-xl w-full shadow-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center space-x-2 text-slate-100 font-mono font-bold text-base">
            <Layers className="w-5 h-5 text-emerald-400" />
            <span>Provision Linux Virtual Machine</span>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 transition-colors p-1"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="mt-4 p-3 bg-rose-950/50 border border-rose-900/60 rounded-lg text-xs text-rose-300 font-mono flex items-start space-x-2">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <div>
              <div className="font-bold">Provisioning Error:</div>
              <div>{error}</div>
            </div>
          </div>
        )}

        {/* Real Host Resource Capacity Guide */}
        {nodeInfo && (
          <div className="mt-4 p-3 bg-slate-950 rounded-lg border border-slate-800 text-[11px] font-mono text-slate-400">
            <div className="text-slate-300 font-semibold mb-1 flex items-center space-x-1.5">
              <Cpu className="w-3.5 h-3.5 text-emerald-400" />
              <span>Real Host Available Capacity ({nodeInfo.hostname}):</span>
            </div>
            <div className="grid grid-cols-3 gap-2 mt-2 text-slate-400">
              <div>Total CPU: <span className="text-slate-200">{nodeInfo.total_cpu_cores} Cores</span></div>
              <div>Free RAM: <span className="text-slate-200">{nodeInfo.total_ram_mb - nodeInfo.used_ram_mb} MB</span></div>
              <div>Free Disk: <span className="text-slate-200">{nodeInfo.total_disk_gb - nodeInfo.used_disk_gb} GB</span></div>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          <div>
            <label className="block text-xs font-mono font-semibold text-slate-300 mb-1">
              VM Name *
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. dev-srv-01"
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 text-sm focus:outline-none focus:border-emerald-500 font-mono"
            />
          </div>

          <div>
            <label className="block text-xs font-mono font-semibold text-slate-300 mb-1">
              Operating System *
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {SUPPORTED_OS_OPTIONS.map((item) => (
                <div
                  key={item.id}
                  onClick={() => setOs(item.id)}
                  className={`p-3 rounded-lg border cursor-pointer transition-all ${
                    os === item.id
                      ? 'bg-emerald-950/40 border-emerald-500/80 text-white'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-semibold">{item.name}</span>
                    <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 font-mono">
                      {item.tag}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-mono font-semibold text-slate-300 mb-1">
                CPU Cores
              </label>
              <input
                type="number"
                min="1"
                max={nodeInfo ? nodeInfo.total_cpu_cores : 16}
                required
                value={cpuCores}
                onChange={(e) => setCpuCores(parseInt(e.target.value, 10))}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 text-sm focus:outline-none focus:border-emerald-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-mono font-semibold text-slate-300 mb-1">
                RAM (MB)
              </label>
              <input
                type="number"
                min="256"
                step="256"
                required
                value={ramMb}
                onChange={(e) => setRamMb(parseInt(e.target.value, 10))}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 text-sm focus:outline-none focus:border-emerald-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-mono font-semibold text-slate-300 mb-1">
                Disk (GB)
              </label>
              <input
                type="number"
                min="1"
                max="500"
                required
                value={diskGb}
                onChange={(e) => setDiskGb(parseInt(e.target.value, 10))}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 text-sm focus:outline-none focus:border-emerald-500 font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-mono font-semibold text-slate-300 mb-1">
                Default User
              </label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="root"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 text-sm focus:outline-none focus:border-emerald-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-mono font-semibold text-slate-300 mb-1">
                Optional Password
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 text-sm focus:outline-none focus:border-emerald-500 font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-mono font-semibold text-slate-300 mb-1">
                Hostname (Optional)
              </label>
              <input
                type="text"
                value={hostname}
                onChange={(e) => setHostname(e.target.value)}
                placeholder="leave blank to use VM name"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 text-sm focus:outline-none focus:border-emerald-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-mono font-semibold text-slate-300 mb-1">
                Assign to User
              </label>
              <select
                value={targetUserId}
                onChange={(e) => setTargetUserId(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 text-sm focus:outline-none focus:border-emerald-500 font-mono"
              >
                <option value="">Myself (Current Admin)</option>
                {users.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.username} ({u.email})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800 flex items-center justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono text-xs font-medium transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs font-semibold tracking-wide transition-all shadow-md shadow-emerald-950 flex items-center space-x-2 disabled:opacity-50"
            >
              <Layers className="w-4 h-4" />
              <span>{loading ? 'Validating & Queueing...' : 'Provision VM'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
