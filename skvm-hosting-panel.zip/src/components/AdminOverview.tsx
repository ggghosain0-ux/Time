import React from 'react';
import { LocalNodeInfo, VM } from '../types';
import {
  Cpu,
  Layers,
  HardDrive,
  Activity,
  Server,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Play,
  Square,
  Users,
  Terminal,
  ShieldAlert,
} from 'lucide-react';

interface AdminOverviewProps {
  nodeInfo: LocalNodeInfo | null;
  overview: {
    totalUsers: number;
    totalVms: number;
    runningVms: number;
    stoppedVms: number;
    failedVms: number;
  } | null;
  vms: VM[];
  isInfrastructureReady: boolean;
  limitedReasons: string[];
  onOpenTerminal: (vm: VM) => void;
  onNavigateToVMs: () => void;
}

export const AdminOverview: React.FC<AdminOverviewProps> = ({
  nodeInfo,
  overview,
  vms,
  isInfrastructureReady,
  limitedReasons,
  onOpenTerminal,
  onNavigateToVMs,
}) => {
  const formatUptime = (seconds: number) => {
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return `${days}d ${hours}h ${minutes}m`;
  };

  return (
    <div className="space-y-6">
      {/* Limited Environment Banner if host lacks Docker/LXC */}
      {!isInfrastructureReady && (
        <div className="bg-amber-950/40 border border-amber-800/80 rounded-xl p-4 sm:p-5 shadow-sm">
          <div className="flex items-start space-x-3">
            <ShieldAlert className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <h3 className="text-sm font-bold text-amber-200 font-mono">
                Host Infrastructure Notice: Limited Environment Detected
              </h3>
              <p className="text-xs text-amber-300/90 mt-1">
                The current host where SKVM is running does not have an active Docker daemon or LXC tools.
                Per system rules, mock or fake containers are strictly prohibited.
              </p>
              {limitedReasons.length > 0 && (
                <ul className="mt-2 space-y-1 text-xs font-mono text-amber-400/90 bg-amber-950/60 p-2.5 rounded border border-amber-900/60">
                  {limitedReasons.map((reason, idx) => (
                    <li key={idx} className="flex items-center space-x-1.5">
                      <span>•</span>
                      <span>{reason}</span>
                    </li>
                  ))}
                </ul>
              )}
              <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px] font-mono">
                <div className="bg-slate-950/80 p-2.5 rounded border border-amber-900/40">
                  <div className="text-slate-300 font-semibold mb-1">To enable Docker Engine (Debian/Ubuntu):</div>
                  <code className="text-emerald-400 select-all block bg-slate-900 p-1.5 rounded">
                    curl -fsSL https://get.docker.com | sh
                  </code>
                </div>
                <div className="bg-slate-950/80 p-2.5 rounded border border-amber-900/40">
                  <div className="text-slate-300 font-semibold mb-1">To enable LXC/LXD Engine:</div>
                  <code className="text-sky-400 select-all block bg-slate-900 p-1.5 rounded">
                    apt-get update && apt-get install -y lxc lxc-templates
                  </code>
                </div>
              </div>

              <p className="text-[11px] text-amber-400/80 mt-2.5 font-mono">
                Or run the safe non-destructive installer: <code className="bg-amber-900/50 px-1.5 py-0.5 rounded text-amber-200">chmod +x install.sh && ./install.sh</code>
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Real Host Metrics Gauges */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Host CPU */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono text-slate-400 flex items-center space-x-1.5">
              <Cpu className="w-4 h-4 text-emerald-400" />
              <span>Host CPU Usage</span>
            </span>
            <span className="text-xs font-mono text-slate-500">
              {nodeInfo ? `${nodeInfo.total_cpu_cores} Cores` : '--'}
            </span>
          </div>
          <div className="mt-3 flex items-baseline justify-between">
            <span className="text-2xl font-bold font-mono text-slate-100">
              {nodeInfo ? `${nodeInfo.used_cpu_percent}%` : '--%'}
            </span>
            <span className="text-xs text-slate-400 font-mono">Real-time</span>
          </div>
          <div className="w-full bg-slate-800 h-2 rounded-full mt-3 overflow-hidden">
            <div
              className="bg-emerald-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${nodeInfo ? nodeInfo.used_cpu_percent : 0}%` }}
            />
          </div>
        </div>

        {/* Host Memory */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono text-slate-400 flex items-center space-x-1.5">
              <Layers className="w-4 h-4 text-sky-400" />
              <span>Host Memory (RAM)</span>
            </span>
            <span className="text-xs font-mono text-slate-500">
              {nodeInfo ? `${nodeInfo.total_ram_mb} MB Total` : '--'}
            </span>
          </div>
          <div className="mt-3 flex items-baseline justify-between">
            <span className="text-2xl font-bold font-mono text-slate-100">
              {nodeInfo ? `${Math.round((nodeInfo.used_ram_mb / nodeInfo.total_ram_mb) * 100)}%` : '--%'}
            </span>
            <span className="text-xs text-slate-400 font-mono">
              {nodeInfo ? `${nodeInfo.used_ram_mb} MB used` : '--'}
            </span>
          </div>
          <div className="w-full bg-slate-800 h-2 rounded-full mt-3 overflow-hidden">
            <div
              className="bg-sky-500 h-full rounded-full transition-all duration-500"
              style={{
                width: `${nodeInfo ? Math.round((nodeInfo.used_ram_mb / nodeInfo.total_ram_mb) * 100) : 0}%`,
              }}
            />
          </div>
        </div>

        {/* Host Storage */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono text-slate-400 flex items-center space-x-1.5">
              <HardDrive className="w-4 h-4 text-purple-400" />
              <span>Host Storage (Disk)</span>
            </span>
            <span className="text-xs font-mono text-slate-500">
              {nodeInfo ? `${nodeInfo.total_disk_gb} GB Total` : '--'}
            </span>
          </div>
          <div className="mt-3 flex items-baseline justify-between">
            <span className="text-2xl font-bold font-mono text-slate-100">
              {nodeInfo && nodeInfo.total_disk_gb > 0
                ? `${Math.round((nodeInfo.used_disk_gb / nodeInfo.total_disk_gb) * 100)}%`
                : '--%'}
            </span>
            <span className="text-xs text-slate-400 font-mono">
              {nodeInfo ? `${nodeInfo.used_disk_gb} GB used` : '--'}
            </span>
          </div>
          <div className="w-full bg-slate-800 h-2 rounded-full mt-3 overflow-hidden">
            <div
              className="bg-purple-500 h-full rounded-full transition-all duration-500"
              style={{
                width: `${
                  nodeInfo && nodeInfo.total_disk_gb > 0
                    ? Math.round((nodeInfo.used_disk_gb / nodeInfo.total_disk_gb) * 100)
                    : 0
                }%`,
              }}
            />
          </div>
        </div>

        {/* Local Node Status */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono text-slate-400 flex items-center space-x-1.5">
              <Server className="w-4 h-4 text-amber-400" />
              <span>Local Host Node</span>
            </span>
            <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-mono bg-emerald-950 text-emerald-300 border border-emerald-800">
              ONLINE
            </span>
          </div>
          <div className="mt-3">
            <div className="text-sm font-semibold font-mono text-slate-200 truncate">
              {nodeInfo?.hostname || 'localhost'}
            </div>
            <div className="text-[11px] text-slate-400 font-mono mt-1 truncate">
              Uptime: {nodeInfo ? formatUptime(nodeInfo.uptime_seconds) : '--'}
            </div>
          </div>
          <div className="mt-2 text-[10px] font-mono text-slate-500 truncate">
            Kernel: {nodeInfo?.kernel_version || '--'}
          </div>
        </div>
      </div>

      {/* VM Counts & Overview */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-4">
          <div className="text-xs text-slate-400 font-mono">Total VMs</div>
          <div className="text-2xl font-bold font-mono text-slate-100 mt-1">
            {overview?.totalVms ?? 0}
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-4">
          <div className="text-xs text-emerald-400 font-mono flex items-center space-x-1">
            <Play className="w-3.5 h-3.5" />
            <span>Running</span>
          </div>
          <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">
            {overview?.runningVms ?? 0}
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-4">
          <div className="text-xs text-slate-400 font-mono flex items-center space-x-1">
            <Square className="w-3.5 h-3.5" />
            <span>Stopped</span>
          </div>
          <div className="text-2xl font-bold font-mono text-slate-300 mt-1">
            {overview?.stoppedVms ?? 0}
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-4">
          <div className="text-xs text-rose-400 font-mono flex items-center space-x-1">
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Failed</span>
          </div>
          <div className="text-2xl font-bold font-mono text-rose-400 mt-1">
            {overview?.failedVms ?? 0}
          </div>
        </div>
      </div>

      {/* Aggregate Virtual Infrastructure Allocation Summary */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-sm">
        <h3 className="text-sm font-bold font-mono text-slate-100 flex items-center space-x-2 mb-3">
          <Layers className="w-4 h-4 text-cyan-400" />
          <span>Virtual Machine Resource Commitments</span>
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
          {/* Allocated CPU */}
          {(() => {
            const totalAllocCpu = vms.reduce((acc, v) => acc + (v.cpu_cores || 1), 0);
            const hostCpu = nodeInfo?.total_cpu_cores || 2;
            const cpuPct = Math.min(100, Math.round((totalAllocCpu / hostCpu) * 100));
            return (
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>Committed vCPU</span>
                  <span className="text-slate-200 font-semibold">{totalAllocCpu} / {hostCpu} Cores</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden mt-2">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      cpuPct > 90 ? 'bg-amber-500' : 'bg-cyan-500'
                    }`}
                    style={{ width: `${cpuPct}%` }}
                  />
                </div>
              </div>
            );
          })()}

          {/* Allocated RAM */}
          {(() => {
            const totalAllocRam = vms.reduce((acc, v) => acc + (v.ram_mb || 512), 0);
            const hostRam = nodeInfo?.total_ram_mb || 4096;
            const ramPct = Math.min(100, Math.round((totalAllocRam / hostRam) * 100));
            return (
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>Committed Memory</span>
                  <span className="text-slate-200 font-semibold">{totalAllocRam} / {hostRam} MB</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden mt-2">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      ramPct > 90 ? 'bg-amber-500' : 'bg-purple-500'
                    }`}
                    style={{ width: `${ramPct}%` }}
                  />
                </div>
              </div>
            );
          })()}

          {/* Allocated Disk */}
          {(() => {
            const totalAllocDisk = vms.reduce((acc, v) => acc + (v.disk_gb || 10), 0);
            const hostDisk = nodeInfo?.total_disk_gb || 50;
            const diskPct = Math.min(100, Math.round((totalAllocDisk / hostDisk) * 100));
            return (
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>Committed Disk Storage</span>
                  <span className="text-slate-200 font-semibold">{totalAllocDisk} / {hostDisk} GB</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden mt-2">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      diskPct > 90 ? 'bg-amber-500' : 'bg-emerald-500'
                    }`}
                    style={{ width: `${diskPct}%` }}
                  />
                </div>
              </div>
            );
          })()}
        </div>
      </div>

      {/* Recent Virtual Machines Preview */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div>
            <h3 className="text-sm font-bold font-mono text-slate-100 flex items-center space-x-2">
              <Server className="w-4 h-4 text-emerald-400" />
              <span>Active Containers on Local Node</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Live status synchronized with host container daemon.
            </p>
          </div>
          <button
            onClick={onNavigateToVMs}
            className="text-xs font-mono text-emerald-400 hover:text-emerald-300 transition-colors"
          >
            View All VMs &rarr;
          </button>
        </div>

        {vms.length === 0 ? (
          <div className="py-8 text-center text-xs text-slate-500 font-mono">
            No virtual machines created yet.
          </div>
        ) : (
          <div className="divide-y divide-slate-800/60 mt-2">
            {vms.slice(0, 5).map((vm) => (
              <div key={vm.id} className="py-3 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 rounded bg-slate-800 flex items-center justify-center font-mono text-xs font-bold text-slate-300 border border-slate-700">
                    {vm.engine === 'docker' ? 'D' : 'L'}
                  </div>
                  <div>
                    <div className="text-sm font-semibold font-mono text-slate-200 flex items-center space-x-2">
                      <span>{vm.name}</span>
                      <span className="text-[10px] uppercase font-mono px-1.5 py-0.2 rounded bg-slate-800 text-slate-400">
                        {vm.os}
                      </span>
                    </div>
                    <div className="text-xs text-slate-500 font-mono">
                      IP: {vm.ip_address || 'Unavailable'} • {vm.ram_mb} MB RAM • {vm.cpu_cores} Core(s)
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-3">
                  <span
                    className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-mono font-medium ${
                      vm.status === 'READY'
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                        : vm.status === 'STOPPED'
                        ? 'bg-slate-800 text-slate-400'
                        : 'bg-rose-950 text-rose-300 border border-rose-800'
                    }`}
                  >
                    {vm.status}
                  </span>

                  <button
                    onClick={() => onOpenTerminal(vm)}
                    disabled={vm.status !== 'READY'}
                    className={`px-3 py-1.5 rounded text-xs font-mono font-semibold flex items-center space-x-1.5 transition-all ${
                      vm.status === 'READY'
                        ? 'bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer'
                        : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                    }`}
                  >
                    <Terminal className="w-3.5 h-3.5" />
                    <span>Terminal</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
