import React, { useState } from 'react';
import { VM } from '../types';
import { api } from '../api';
import { useAuth } from '../context/AuthContext';
import { VMDetailsModal } from './VMDetailsModal';
import {
  Terminal,
  Play,
  Square,
  RotateCw,
  Trash2,
  AlertTriangle,
  Cpu,
  Layers,
  HardDrive,
  Globe,
  Plus,
  RefreshCw,
  Search,
  Filter,
  Eye,
  Copy,
  Download,
} from 'lucide-react';

interface VMListProps {
  vms: VM[];
  loading: boolean;
  onRefresh: () => void;
  onOpenTerminal: (vm: VM) => void;
  onCreateVMClick?: () => void;
}

export const VMList: React.FC<VMListProps> = ({
  vms,
  loading,
  onRefresh,
  onOpenTerminal,
  onCreateVMClick,
}) => {
  const { user } = useAuth();
  const [actionLoadingId, setActionLoadingId] = useState<string | null>(null);
  const [actionError, setActionError] = useState<{ id: string; message: string } | null>(null);
  const [deleteConfirmVM, setDeleteConfirmVM] = useState<VM | null>(null);
  const [selectedVMForDetails, setSelectedVMForDetails] = useState<VM | null>(null);

  // Search & Filters
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'READY' | 'STOPPED' | 'FAILED'>('ALL');

  const handleStart = async (vm: VM) => {
    setActionLoadingId(vm.id);
    setActionError(null);
    try {
      await api.startVM(vm.id);
      onRefresh();
    } catch (err: any) {
      setActionError({ id: vm.id, message: err.message });
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleStop = async (vm: VM) => {
    setActionLoadingId(vm.id);
    setActionError(null);
    try {
      await api.stopVM(vm.id);
      onRefresh();
    } catch (err: any) {
      setActionError({ id: vm.id, message: err.message });
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleRestart = async (vm: VM) => {
    setActionLoadingId(vm.id);
    setActionError(null);
    try {
      await api.restartVM(vm.id);
      onRefresh();
    } catch (err: any) {
      setActionError({ id: vm.id, message: err.message });
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleDelete = async () => {
    if (!deleteConfirmVM) return;
    setActionLoadingId(deleteConfirmVM.id);
    try {
      await api.deleteVM(deleteConfirmVM.id);
      setDeleteConfirmVM(null);
      onRefresh();
    } catch (err: any) {
      setActionError({ id: deleteConfirmVM.id, message: err.message });
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleCloneVM = async (vm: VM) => {
    setActionLoadingId(vm.id);
    setActionError(null);
    try {
      await api.createVM({
        name: `${vm.name}-clone`,
        os: vm.os,
        ram_mb: vm.ram_mb,
        cpu_cores: vm.cpu_cores,
        disk_gb: vm.disk_gb,
        username: vm.username,
        hostname: `${vm.hostname}-clone`,
      });
      onRefresh();
    } catch (err: any) {
      setActionError({ id: vm.id, message: `Clone failed: ${err.message}` });
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleExportVM = (vm: VM) => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(vm, null, 2));
    const a = document.createElement('a');
    a.setAttribute('href', dataStr);
    a.setAttribute('download', `vm-${vm.name}.json`);
    document.body.appendChild(a);
    a.click();
    a.remove();
  };

  const getStatusBadge = (status: VM['status']) => {
    switch (status) {
      case 'READY':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-950/80 text-emerald-300 border border-emerald-800">
            <span className="w-1.5 h-1.5 mr-1.5 rounded-full bg-emerald-400"></span>
            Running
          </span>
        );
      case 'STOPPED':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-800 text-slate-400 border border-slate-700">
            <span className="w-1.5 h-1.5 mr-1.5 rounded-full bg-slate-500"></span>
            Stopped
          </span>
        );
      case 'FAILED':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-rose-950/80 text-rose-300 border border-rose-800">
            <span className="w-1.5 h-1.5 mr-1.5 rounded-full bg-rose-400"></span>
            Failed
          </span>
        );
      case 'DELETING':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-950/80 text-amber-300 border border-amber-800">
            <span className="w-1.5 h-1.5 mr-1.5 rounded-full bg-amber-400 animate-pulse"></span>
            Deleting...
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-sky-950/80 text-sky-300 border border-sky-800">
            <span className="w-1.5 h-1.5 mr-1.5 rounded-full bg-sky-400 animate-pulse"></span>
            {status}
          </span>
        );
    }
  };

  const filteredVMs = vms.filter((vm) => {
    const matchesSearch =
      vm.name.toLowerCase().includes(search.toLowerCase()) ||
      vm.hostname.toLowerCase().includes(search.toLowerCase()) ||
      vm.os.toLowerCase().includes(search.toLowerCase()) ||
      (vm.ip_address && vm.ip_address.includes(search));

    const matchesStatus =
      statusFilter === 'ALL' ||
      (statusFilter === 'READY' && vm.status === 'READY') ||
      (statusFilter === 'STOPPED' && vm.status === 'STOPPED') ||
      (statusFilter === 'FAILED' && vm.status === 'FAILED');

    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Top action header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-100 font-mono flex items-center space-x-2">
            <Layers className="w-5 h-5 text-emerald-400" />
            <span>{user?.role === 'admin' ? 'Managed Containers / VMs' : 'Assigned Virtual Machines'}</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Real Linux container infrastructure backed by Docker & LXC engines.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 sm:gap-3">
          {/* Search box */}
          <div className="relative">
            <input
              type="text"
              placeholder="Search VMs or IPs..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-8 pr-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-emerald-500 font-mono w-44"
            />
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-2" />
          </div>

          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="px-2.5 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-slate-300 font-mono focus:outline-none focus:border-emerald-500"
          >
            <option value="ALL">All Statuses</option>
            <option value="READY">Running</option>
            <option value="STOPPED">Stopped</option>
            <option value="FAILED">Failed</option>
          </select>

          <button
            onClick={onRefresh}
            className="px-3 py-1.5 rounded-lg bg-slate-900 text-slate-300 hover:text-white border border-slate-800 hover:border-slate-700 transition-colors text-xs font-mono flex items-center space-x-1.5"
            title="Refresh state"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>

          {user?.role === 'admin' && onCreateVMClick && (
            <button
              onClick={onCreateVMClick}
              className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs tracking-wide transition-all shadow-md shadow-emerald-950 flex items-center space-x-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Create VM</span>
            </button>
          )}
        </div>
      </div>

      {/* VM List Table / Cards */}
      {loading && vms.length === 0 ? (
        <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-12 text-center">
          <RefreshCw className="w-8 h-8 text-emerald-400 animate-spin mx-auto mb-3" />
          <p className="text-sm text-slate-400 font-mono">Querying real infrastructure status...</p>
        </div>
      ) : vms.length === 0 ? (
        <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-12 text-center">
          <div className="w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center mx-auto mb-3 text-slate-500">
            <Layers className="w-6 h-6" />
          </div>
          <h3 className="text-base font-semibold text-slate-200">No Virtual Machines Found</h3>
          <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
            {user?.role === 'admin'
              ? 'No containers have been provisioned yet. Use the Create VM button to deploy a real container.'
              : 'You do not have any virtual machines assigned to your account yet.'}
          </p>
          {user?.role === 'admin' && onCreateVMClick && (
            <button
              onClick={onCreateVMClick}
              className="mt-4 px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs inline-flex items-center space-x-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Provision First VM</span>
            </button>
          )}
        </div>
      ) : filteredVMs.length === 0 ? (
        <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-8 text-center text-xs font-mono text-slate-400">
          No virtual machines matching "{search}".
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {filteredVMs.map((vm) => {
            const isBusy = actionLoadingId === vm.id;
            const hasError = actionError?.id === vm.id;

            return (
              <div
                key={vm.id}
                className="bg-slate-900/90 border border-slate-800 hover:border-slate-700/80 rounded-xl p-5 transition-all shadow-sm flex flex-col justify-between"
              >
                <div>
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 rounded-lg bg-slate-800 border border-slate-700/80 flex items-center justify-center font-mono font-bold text-emerald-400 text-sm">
                        {vm.engine === 'docker' ? 'D' : 'L'}
                      </div>
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="font-mono text-base font-semibold text-slate-100">
                            {vm.name}
                          </span>
                          {getStatusBadge(vm.status)}
                          <span className="text-[11px] px-2 py-0.5 rounded bg-slate-800/80 text-slate-400 font-mono border border-slate-700/60 uppercase">
                            {vm.engine}
                          </span>
                        </div>
                        <div className="text-xs text-slate-400 font-mono mt-0.5 flex items-center space-x-2">
                          <span>Hostname: {vm.hostname}</span>
                          <span>•</span>
                          <span>OS: {vm.os}</span>
                        </div>
                      </div>
                    </div>

                    {/* Primary Interactive Terminal & Details Button */}
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => setSelectedVMForDetails(vm)}
                        className="px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono text-xs font-semibold flex items-center space-x-1.5 transition-colors border border-slate-700"
                        title="View Specifications & Container Logs"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>Inspect</span>
                      </button>

                      <button
                        onClick={() => onOpenTerminal(vm)}
                        disabled={vm.status !== 'READY'}
                        className={`px-4 py-2 rounded-lg font-mono text-xs font-semibold flex items-center space-x-2 transition-all shadow-sm ${
                          vm.status === 'READY'
                            ? 'bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer shadow-emerald-950/60 hover:scale-[1.02]'
                            : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700/50'
                        }`}
                        title={vm.status === 'READY' ? 'Open Interactive Terminal' : 'VM must be running to open terminal'}
                      >
                        <Terminal className="w-4 h-4" />
                        <span>Open Terminal</span>
                      </button>
                    </div>
                  </div>

                  {/* Resource & Network Metadata */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 py-3 text-xs font-mono text-slate-300">
                    <div className="bg-slate-950/50 p-2.5 rounded-lg border border-slate-800/60">
                      <div className="text-slate-500 text-[11px] flex items-center space-x-1 mb-1">
                        <Cpu className="w-3.5 h-3.5 text-slate-400" />
                        <span>CPU Cores</span>
                      </div>
                      <div className="font-semibold">{vm.cpu_cores} Core(s)</div>
                    </div>

                    <div className="bg-slate-950/50 p-2.5 rounded-lg border border-slate-800/60">
                      <div className="text-slate-500 text-[11px] flex items-center space-x-1 mb-1">
                        <Layers className="w-3.5 h-3.5 text-slate-400" />
                        <span>Memory (RAM)</span>
                      </div>
                      <div className="font-semibold">{vm.ram_mb} MB</div>
                    </div>

                    <div className="bg-slate-950/50 p-2.5 rounded-lg border border-slate-800/60">
                      <div className="text-slate-500 text-[11px] flex items-center space-x-1 mb-1">
                        <HardDrive className="w-3.5 h-3.5 text-slate-400" />
                        <span>Storage (Disk)</span>
                      </div>
                      <div className="font-semibold">{vm.disk_gb} GB</div>
                    </div>

                    <div className="bg-slate-950/50 p-2.5 rounded-lg border border-slate-800/60">
                      <div className="text-slate-500 text-[11px] flex items-center space-x-1 mb-1">
                        <Globe className="w-3.5 h-3.5 text-slate-400" />
                        <span>IP Address</span>
                      </div>
                      <div className={`font-semibold ${vm.ip_address ? 'text-emerald-400' : 'text-slate-500'}`}>
                        {vm.ip_address || 'Unavailable'}
                      </div>
                    </div>
                  </div>

                  {/* Error display if failed or action failed */}
                  {(vm.error_message || vm.failure_message || hasError) && (
                    <div className="mt-2 p-3 bg-rose-950/40 border border-rose-900/60 rounded-lg text-xs text-rose-300 font-mono flex items-start space-x-2">
                      <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                      <div>
                        <div className="font-bold flex items-center space-x-2">
                          <span>Provisioning / Infrastructure Error</span>
                          {vm.failure_stage && (
                            <span className="px-1.5 py-0.2 rounded bg-rose-900/60 text-rose-200 text-[10px] border border-rose-800">
                              Stage: {vm.failure_stage}
                            </span>
                          )}
                        </div>
                        <div className="mt-0.5">{hasError ? actionError?.message : (vm.failure_message || vm.error_message)}</div>
                        {vm.failure_timestamp && (
                          <div className="text-[10px] text-rose-400/80 mt-1">
                            Logged: {new Date(vm.failure_timestamp).toLocaleString()}
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>

                {/* Footer Controls & Details */}
                <div className="pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
                  <div className="text-slate-500 font-mono text-[11px] flex items-center space-x-3">
                    <span>Created: {new Date(vm.created_at).toLocaleDateString()}</span>
                    <span>Container: {vm.container_id ? vm.container_id.substring(0, 12) : 'None'}</span>
                  </div>

                  {/* Power Management & Deletion */}
                  <div className="flex items-center space-x-2">
                    {vm.status === 'STOPPED' && (
                      <button
                        onClick={() => handleStart(vm)}
                        disabled={isBusy}
                        className="px-2.5 py-1.5 rounded bg-emerald-950/60 hover:bg-emerald-900/80 text-emerald-300 border border-emerald-800 font-mono text-xs flex items-center space-x-1 transition-colors cursor-pointer"
                        title="Start Container"
                      >
                        <Play className="w-3.5 h-3.5" />
                        <span>Start</span>
                      </button>
                    )}

                    {vm.status === 'READY' && (
                      <>
                        <button
                          onClick={() => handleRestart(vm)}
                          disabled={isBusy}
                          className="px-2.5 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 font-mono text-xs flex items-center space-x-1 transition-colors cursor-pointer"
                          title="Restart Container"
                        >
                          <RotateCw className={`w-3.5 h-3.5 ${isBusy ? 'animate-spin' : ''}`} />
                          <span>Restart</span>
                        </button>

                        <button
                          onClick={() => handleStop(vm)}
                          disabled={isBusy}
                          className="px-2.5 py-1.5 rounded bg-amber-950/60 hover:bg-amber-900/80 text-amber-300 border border-amber-800 font-mono text-xs flex items-center space-x-1 transition-colors cursor-pointer"
                          title="Stop Container"
                        >
                          <Square className="w-3.5 h-3.5" />
                          <span>Stop</span>
                        </button>
                      </>
                    )}

                    {user?.role === 'admin' && (
                      <button
                        onClick={() => handleCloneVM(vm)}
                        disabled={isBusy}
                        className="p-1.5 rounded text-slate-500 hover:text-cyan-400 hover:bg-slate-800 transition-colors"
                        title="Duplicate / Clone VM Configuration"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                    )}

                    <button
                      onClick={() => handleExportVM(vm)}
                      className="p-1.5 rounded text-slate-500 hover:text-slate-300 hover:bg-slate-800 transition-colors"
                      title="Export VM Specification JSON"
                    >
                      <Download className="w-4 h-4" />
                    </button>

                    {(user?.role === 'admin' || vm.user_id === user?.id) && (
                      <button
                        onClick={() => setDeleteConfirmVM(vm)}
                        disabled={isBusy}
                        className="p-1.5 rounded text-slate-500 hover:text-rose-400 hover:bg-rose-950/30 border border-transparent hover:border-rose-900/50 transition-colors ml-1"
                        title="Delete VM & Cleanup Container"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmVM && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 max-w-md w-full shadow-2xl">
            <div className="flex items-center space-x-3 text-rose-400 mb-3">
              <AlertTriangle className="w-6 h-6" />
              <h3 className="text-lg font-bold text-slate-100">Delete Virtual Machine?</h3>
            </div>
            <p className="text-sm text-slate-300">
              Are you sure you want to permanently delete{' '}
              <span className="font-mono font-bold text-white">{deleteConfirmVM.name}</span>?
            </p>
            <p className="text-xs text-slate-400 mt-2 bg-slate-950 p-2.5 rounded border border-slate-800 font-mono">
              This will destroy the real {deleteConfirmVM.engine.toUpperCase()} container on the host
              and delete all container storage and records. This action cannot be undone.
            </p>
            <div className="mt-6 flex items-center justify-end space-x-3">
              <button
                onClick={() => setDeleteConfirmVM(null)}
                className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-xs transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleDelete}
                disabled={actionLoadingId === deleteConfirmVM.id}
                className="px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-medium text-xs transition-colors shadow-md shadow-rose-950 flex items-center space-x-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{actionLoadingId === deleteConfirmVM.id ? 'Deleting...' : 'Permanently Delete'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* VM Details Modal */}
      {selectedVMForDetails && (
        <VMDetailsModal
          vm={selectedVMForDetails}
          onClose={() => setSelectedVMForDetails(null)}
          onOpenTerminal={onOpenTerminal}
          onRefreshVM={onRefresh}
        />
      )}
    </div>
  );
};
