import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { api } from './api';
import { VM, LocalNodeInfo, HealthReport, SystemSettings } from './types';
import { Header } from './components/Header';
import { LoginModal } from './components/LoginModal';
import { AdminOverview } from './components/AdminOverview';
import { VMList } from './components/VMList';
import { CreateVMModal } from './components/CreateVMModal';
import { TerminalModal } from './components/TerminalModal';
import { ApiKeysView } from './components/ApiKeysView';
import { ActivityLogsView } from './components/ActivityLogsView';
import { SystemHealthView } from './components/SystemHealthView';
import { SettingsView } from './components/SettingsView';
import { UsersView } from './components/UsersView';
import { Server, RefreshCw } from 'lucide-react';

const DashboardContent: React.FC = () => {
  const { user, loading: authLoading } = useAuth();

  const [activeTab, setActiveTab] = useState<string>('overview');
  const [nodeInfo, setNodeInfo] = useState<LocalNodeInfo | null>(null);
  const [overview, setOverview] = useState<{
    totalUsers: number;
    totalVms: number;
    runningVms: number;
    stoppedVms: number;
    failedVms: number;
  } | null>(null);
  const [vms, setVms] = useState<VM[]>([]);
  const [health, setHealth] = useState<HealthReport | null>(null);
  const [settings, setSettings] = useState<SystemSettings | null>(null);
  const [vmsLoading, setVmsLoading] = useState<boolean>(true);

  // Modals
  const [isCreateVMOpen, setIsCreateVMOpen] = useState(false);
  const [activeTerminalVM, setActiveTerminalVM] = useState<VM | null>(null);

  const fetchData = async () => {
    try {
      const [nodeRes, vmRes, healthRes] = await Promise.allSettled([
        api.getNodeStats(),
        api.getVMs(),
        api.getHealth(),
      ]);

      if (nodeRes.status === 'fulfilled') {
        setNodeInfo(nodeRes.value.node);
        setOverview(nodeRes.value.overview);
      }
      if (vmRes.status === 'fulfilled') {
        setVms(vmRes.value.vms);
      }
      if (healthRes.status === 'fulfilled') {
        setHealth(healthRes.value);
      }
    } catch (e) {
      console.error('Data sync error:', e);
    } finally {
      setVmsLoading(false);
    }
  };

  useEffect(() => {
    if (user) {
      fetchData();
      const interval = setInterval(fetchData, 5000);
      return () => clearInterval(interval);
    }
  }, [user]);

  if (authLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-slate-400 font-mono text-xs">
        <Server className="w-8 h-8 text-emerald-500 animate-pulse mb-3" />
        <span>Loading SKVM Panel...</span>
      </div>
    );
  }

  if (!user || user.must_change_password) {
    return <LoginModal />;
  }

  const isInfrastructureReady = health ? health.infrastructure_ready : false;
  const limitedReasons = health ? health.limited_environment_reasons : [];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500/30">
      {/* Navigation Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        systemName={settings?.panel_name || 'SKVM Control Panel'}
        isInfrastructureReady={isInfrastructureReady}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'overview' && (
          <AdminOverview
            nodeInfo={nodeInfo}
            overview={overview}
            vms={vms}
            isInfrastructureReady={isInfrastructureReady}
            limitedReasons={limitedReasons}
            onOpenTerminal={(vm) => setActiveTerminalVM(vm)}
            onNavigateToVMs={() => setActiveTab('vms')}
          />
        )}

        {activeTab === 'vms' && (
          <VMList
            vms={vms}
            loading={vmsLoading}
            onRefresh={fetchData}
            onOpenTerminal={(vm) => setActiveTerminalVM(vm)}
            onCreateVMClick={() => setIsCreateVMOpen(true)}
          />
        )}

        {activeTab === 'users' && user.role === 'admin' && <UsersView />}

        {activeTab === 'keys' && user.role === 'admin' && <ApiKeysView />}

        {activeTab === 'logs' && user.role === 'admin' && <ActivityLogsView />}

        {activeTab === 'health' && user.role === 'admin' && <SystemHealthView />}

        {(activeTab === 'settings' || activeTab === 'user-settings') && <SettingsView />}
      </main>

      {/* Footer */}
      <footer className="bg-slate-900/60 border-t border-slate-800/80 py-4 text-center text-xs font-mono text-slate-500">
        SKVM — Linux Container Infrastructure Panel • Real Docker & LXC Execution • No Simulation
      </footer>

      {/* Create VM Modal (Admin) */}
      <CreateVMModal
        isOpen={isCreateVMOpen}
        onClose={() => setIsCreateVMOpen(false)}
        onSuccess={() => {
          fetchData();
          setActiveTab('vms');
        }}
        nodeInfo={nodeInfo}
      />

      {/* Real-time Interactive Web Terminal Modal */}
      {activeTerminalVM && (
        <TerminalModal
          vm={activeTerminalVM}
          onClose={() => setActiveTerminalVM(null)}
        />
      )}
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <DashboardContent />
    </AuthProvider>
  );
}
