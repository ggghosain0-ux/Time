import express from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import authRoutes from './server/routes/auth.js';
import vmRoutes from './server/routes/vms.js';
import settingsRoutes from './server/routes/settings.js';
import healthRoutes from './server/routes/health.js';
import logsRoutes from './server/routes/logs.js';
import keysRoutes from './server/routes/keys.js';
import nodeRoutes from './server/routes/node.js';
import { getDb } from './server/db.js';
import { reconcileVMs } from './server/provisioner.js';
import { setupTerminalWebSocket } from './server/terminal.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const server = http.createServer(app);
  const port = parseInt(process.env.PORT || '3000', 10);

  // Initialize DB and startup reconciliation
  await getDb();
  await reconcileVMs();

  // Middleware
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // API Routes
  app.use('/api/auth', authRoutes);
  app.use('/api/vms', vmRoutes);
  app.use('/api/settings', settingsRoutes);
  app.use('/api/health', healthRoutes);
  app.use('/api/logs', logsRoutes);
  app.use('/api/keys', keysRoutes);
  app.use('/api/node', nodeRoutes);

  // Setup WebSocket Terminal Server
  setupTerminalWebSocket(server);

  // Serve Frontend
  const isProduction = process.env.NODE_ENV === 'production';
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  server.listen(port, '0.0.0.0', () => {
    console.log(`SKVM Server running on http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Fatal error starting SKVM Server:', err);
  process.exit(1);
});
