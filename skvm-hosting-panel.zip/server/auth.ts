import crypto from 'crypto';
import { Request, Response, NextFunction } from 'express';
import { getDb, queryOne, execute } from './db.js';
import { User } from './types.js';

const JWT_SECRET = process.env.JWT_SECRET || 'skvm-secret-super-secure-key-2026';

export interface AuthPayload {
  userId: string;
  username: string;
  role: 'admin' | 'user';
  exp: number;
}

export interface AuthenticatedRequest extends Request {
  user?: AuthPayload;
}

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, salt, 100000, 64, 'sha512').toString('hex');
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  try {
    const [salt, hash] = storedHash.split(':');
    if (!salt || !hash) return false;
    const testHash = crypto.pbkdf2Sync(password, salt, 100000, 64, 'sha512').toString('hex');
    return crypto.timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(testHash, 'hex'));
  } catch {
    return false;
  }
}

export function createToken(user: { id: string; username: string; role: 'admin' | 'user' }, expiresInHours = 24): string {
  const header = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
  const exp = Math.floor(Date.now() / 1000) + expiresInHours * 3600;
  const payload = Buffer.from(
    JSON.stringify({
      userId: user.id,
      username: user.username,
      role: user.role,
      exp,
    })
  ).toString('base64url');

  const signature = crypto
    .createHmac('sha256', JWT_SECRET)
    .update(`${header}.${payload}`)
    .digest('base64url');

  return `${header}.${payload}.${signature}`;
}

export function verifyToken(token: string): AuthPayload | null {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    const [header, payload, signature] = parts;

    const expectedSignature = crypto
      .createHmac('sha256', JWT_SECRET)
      .update(`${header}.${payload}`)
      .digest('base64url');

    if (signature !== expectedSignature) {
      return null;
    }

    const decoded = JSON.parse(Buffer.from(payload, 'base64url').toString('utf-8')) as AuthPayload;
    if (decoded.exp && decoded.exp < Math.floor(Date.now() / 1000)) {
      return null;
    }

    return decoded;
  } catch {
    return null;
  }
}

export function hashApiKey(key: string): string {
  return crypto.createHash('sha256').update(key).digest('hex');
}

export async function authenticateToken(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  const authHeader = req.headers['authorization'];
  let token: string | null = null;

  if (authHeader && authHeader.startsWith('Bearer ')) {
    token = authHeader.substring(7);
  } else if (req.query.token && typeof req.query.token === 'string') {
    token = req.query.token;
  }

  // Also support X-API-Key
  const apiKey = req.headers['x-api-key'] as string;
  if (apiKey) {
    const db = await getDb();
    const keyHash = hashApiKey(apiKey);
    const keyRecord = queryOne(db, 'SELECT * FROM api_keys WHERE key_hash = ?', [keyHash]);
    if (keyRecord) {
      const user = queryOne<User>(db, 'SELECT * FROM users WHERE id = ?', [keyRecord.user_id]);
      if (user) {
        req.user = {
          userId: user.id,
          username: user.username,
          role: user.role,
          exp: Math.floor(Date.now() / 1000) + 3600,
        };
        execute(db, 'UPDATE api_keys SET last_used_at = ? WHERE id = ?', [new Date().toISOString(), keyRecord.id]);
        return next();
      }
    }
  }

  if (!token) {
    res.status(401).json({ error: 'Authentication token required' });
    return;
  }

  const payload = verifyToken(token);
  if (!payload) {
    res.status(401).json({ error: 'Invalid or expired session token' });
    return;
  }

  req.user = payload;
  next();
}

export function requireAdmin(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): void {
  if (!req.user || req.user.role !== 'admin') {
    res.status(403).json({ error: 'Administrator access required' });
    return;
  }
  next();
}

export async function logActivity(
  userId: string,
  username: string,
  action: string,
  details: string,
  status: 'SUCCESS' | 'FAILED' | 'INFO' = 'SUCCESS',
  ip: string = '127.0.0.1'
): Promise<void> {
  try {
    const db = await getDb();
    execute(
      db,
      `INSERT INTO activity_logs (id, user_id, username, action, details, status, ip, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [crypto.randomUUID(), userId, username, action, details, status, ip, new Date().toISOString()]
    );
  } catch (err) {
    console.error('Failed to log activity:', err);
  }
}
