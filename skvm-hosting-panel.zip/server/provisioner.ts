import os from 'os';
import crypto from 'crypto';
import { getDb, queryOne, execute } from './db.js';
import { VM, VMStatus } from './types.js';
import { getProvider } from './providers/index.js';
import { getDiskStats } from './node.js';
import { logActivity } from './auth.js';
import { releasePort } from './portAllocator.js';

interface ProvisionTask {
  vmId: string;
}

const provisionQueue: ProvisionTask[] = [];
let isProcessing = false;

export function enqueueProvision(vmId: string): void {
  provisionQueue.push({ vmId });
  processQueue();
}

async function updateVmStatus(
  vmId: string,
  status: VMStatus,
  options: {
    containerId?: string | null;
    ipAddress?: string | null;
    sshPort?: number | null;
    errorMessage?: string | null;
    failureStage?: string | null;
  } = {}
): Promise<void> {
  const db = await getDb();
  const now = new Date().toISOString();

  let query = 'UPDATE vms SET status = ?, updated_at = ?';
  const params: any[] = [status, now];

  if (options.containerId !== undefined) {
    query += ', container_id = ?';
    params.push(options.containerId);
  }
  if (options.ipAddress !== undefined) {
    query += ', ip_address = ?';
    params.push(options.ipAddress);
  }
  if (options.sshPort !== undefined) {
    query += ', ssh_port = ?';
    params.push(options.sshPort);
  }
  if (options.errorMessage !== undefined) {
    query += ', error_message = ?';
    params.push(options.errorMessage);
  }
  if (options.errorMessage) {
    query += ', failure_message = ?, failure_timestamp = ?';
    params.push(options.errorMessage, now);
  }
  if (options.failureStage) {
    query += ', failure_stage = ?';
    params.push(options.failureStage);
  }

  query += ' WHERE id = ?';
  params.push(vmId);

  execute(db, query, params);

  // Update provisioning_jobs record
  const progressMap: Record<VMStatus, number> = {
    PENDING: 5,
    VALIDATING: 15,
    CREATING: 30,
    INSTALLING_OS: 50,
    CONFIGURING: 70,
    STARTING: 85,
    INSTALLING_SSH: 90,
    INSTALLING_TMATE: 95,
    READY: 100,
    STOPPED: 100,
    FAILED: 0,
    DELETING: 0,
  };

  const progress = progressMap[status] ?? 0;
  const jobStatus = status === 'READY' ? 'completed' : status === 'FAILED' ? 'failed' : 'in_progress';

  try {
    const existingJob = queryOne(db, 'SELECT id FROM provisioning_jobs WHERE vm_id = ?', [vmId]);
    if (existingJob) {
      execute(
        db,
        'UPDATE provisioning_jobs SET stage = ?, status = ?, progress_percent = ?, message = ?, error = ?, updated_at = ? WHERE vm_id = ?',
        [status, jobStatus, progress, `Stage: ${status}`, options.errorMessage || null, now, vmId]
      );
    } else {
      execute(
        db,
        'INSERT INTO provisioning_jobs (id, vm_id, stage, status, progress_percent, message, error, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [crypto.randomUUID(), vmId, status, jobStatus, progress, `Stage: ${status}`, options.errorMessage || null, now, now]
      );
    }
  } catch {
    // ignore
  }
}

async function processQueue(): Promise<void> {
  if (isProcessing || provisionQueue.length === 0) return;
  isProcessing = true;

  const task = provisionQueue.shift();
  if (!task) {
    isProcessing = false;
    return;
  }

  try {
    await runProvisionTask(task.vmId);
  } catch (err) {
    console.error(`Unexpected error processing VM ${task.vmId}:`, err);
  } finally {
    isProcessing = false;
    if (provisionQueue.length > 0) {
      setTimeout(processQueue, 50);
    }
  }
}

async function runProvisionTask(vmId: string): Promise<void> {
  const db = await getDb();
  const vm = queryOne<VM>(db, 'SELECT * FROM vms WHERE id = ?', [vmId]);
  if (!vm) return;

  let currentStage: VMStatus = 'VALIDATING';

  try {
    // 1. VALIDATING state
    currentStage = 'VALIDATING';
    await updateVmStatus(vmId, 'VALIDATING');

    const provider = getProvider(vm.engine);
    const avail = await provider.checkAvailability();
    if (!avail.available) {
      throw new Error(avail.error || `Infrastructure engine ${vm.engine} is not available on this host.`);
    }

    // Host resource validation
    const totalCpus = os.cpus().length;
    if (vm.cpu_cores > totalCpus) {
      throw new Error(`Insufficient host CPU cores. Requested: ${vm.cpu_cores}, Available: ${totalCpus}`);
    }

    const freeRamMb = Math.round(os.freemem() / (1024 * 1024));
    if (vm.ram_mb > freeRamMb) {
      throw new Error(`Insufficient host memory. Requested: ${vm.ram_mb} MB, Available: ${freeRamMb} MB`);
    }

    const diskStats = getDiskStats();
    if (vm.disk_gb > diskStats.freeGb) {
      throw new Error(`Insufficient host disk space. Requested: ${vm.disk_gb} GB, Available: ${diskStats.freeGb} GB`);
    }

    // 2. Perform Creation & Provisioning via real Provider
    currentStage = 'CREATING';
    await updateVmStatus(vmId, 'CREATING');

    const result = await provider.create(
      {
        id: vmId,
        name: vm.name,
        os: vm.os,
        ramMb: vm.ram_mb,
        cpuCores: vm.cpu_cores,
        diskGb: vm.disk_gb,
        username: vm.username,
        hostname: vm.hostname,
      },
      async (step: VMStatus, msg: string) => {
        currentStage = step;
        await updateVmStatus(vmId, step);
      }
    );

    // 3. Mark READY
    await updateVmStatus(vmId, 'READY', {
      containerId: result.containerId,
      ipAddress: result.ipAddress || null,
      sshPort: result.sshPort || null,
      errorMessage: null,
    });

    await logActivity(
      vm.user_id,
      vm.username,
      'VM_PROVISIONED',
      `Virtual Machine ${vm.name} provisioned successfully using engine ${vm.engine}.`,
      'SUCCESS'
    );
  } catch (err: any) {
    const errorMsg = err.message || 'Unknown error occurred during provisioning';
    console.error(`Provisioning failed for VM ${vm.name} (${vmId}) at stage ${currentStage}:`, errorMsg);

    await updateVmStatus(vmId, 'FAILED', {
      errorMessage: errorMsg,
      failureStage: currentStage,
    });

    await logActivity(
      vm.user_id,
      vm.username,
      'VM_PROVISION_FAILED',
      `Failed to provision ${vm.name} at stage ${currentStage}: ${errorMsg}`,
      'FAILED'
    );
  }
}

export async function deleteVM(vmId: string, userId: string, username: string): Promise<void> {
  const db = await getDb();
  const vm = queryOne<VM>(db, 'SELECT * FROM vms WHERE id = ?', [vmId]);
  if (!vm) throw new Error('VM not found');

  await updateVmStatus(vmId, 'DELETING');

  // If there's an actual workload, delete it on the engine
  if (vm.container_id) {
    try {
      const provider = getProvider(vm.engine);
      await provider.delete(vm.container_id);
    } catch (err: any) {
      console.warn(`Warning while deleting workload ${vm.container_id} on engine ${vm.engine}:`, err.message);
    }
  }

  // Release any allocated ports
  await releasePort(vmId);

  // Remove jobs and records
  execute(db, 'DELETE FROM provisioning_jobs WHERE vm_id = ?', [vmId]);
  execute(db, 'DELETE FROM vms WHERE id = ?', [vmId]);

  await logActivity(
    userId,
    username,
    'VM_DELETED',
    `Virtual machine ${vm.name} (${vm.engine}) was deleted.`,
    'SUCCESS'
  );
}

// Reconciles database state with real infrastructure at startup
export async function reconcileVMs(): Promise<void> {
  try {
    const db = await getDb();
    const vms = queryOne<{ count: number }>(db, 'SELECT COUNT(*) as count FROM vms');
    if (!vms || vms.count === 0) return;

    const allVms = (await getDb()).exec('SELECT * FROM vms');
    if (!allVms.length || !allVms[0].values.length) return;

    const columns = allVms[0].columns;
    const rows = allVms[0].values.map((v) => {
      const obj: any = {};
      columns.forEach((col, idx) => (obj[col] = v[idx]));
      return obj as VM;
    });

    for (const vm of rows) {
      if (
        vm.status === 'PENDING' ||
        vm.status === 'VALIDATING' ||
        vm.status === 'CREATING' ||
        vm.status === 'INSTALLING_OS' ||
        vm.status === 'CONFIGURING' ||
        vm.status === 'STARTING'
      ) {
        // Interrupted during previous run
        await updateVmStatus(vm.id, 'FAILED', {
          errorMessage: 'Provisioning was interrupted during server reboot/restart.',
          failureStage: vm.status,
        });
        continue;
      }

      if (vm.container_id) {
        try {
          const provider = getProvider(vm.engine);
          const st = await provider.status(vm.container_id);
          if (st.state === 'running') {
            await updateVmStatus(vm.id, 'READY', {
              ipAddress: st.ip || vm.ip_address,
              sshPort: st.sshPort || vm.ssh_port,
            });
          } else if (st.state === 'stopped') {
            await updateVmStatus(vm.id, 'STOPPED');
          } else if (st.state === 'not_found') {
            await updateVmStatus(vm.id, 'FAILED', {
              errorMessage: `Real workload ${vm.container_id} was not found on engine ${vm.engine}.`,
              failureStage: 'RECONCILIATION',
            });
          }
        } catch {
          // Keep current state
        }
      }
    }
  } catch (err) {
    console.error('Reconciliation error:', err);
  }
}
