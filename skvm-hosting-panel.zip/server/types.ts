export type UserRole = 'admin' | 'user';

export interface User {
  id: string;
  username: string;
  email: string;
  password_hash: string;
  role: UserRole;
  must_change_password: boolean;
  created_at: string;
  updated_at: string;
}

export type ContainerEngine = 'docker' | 'lxc' | 'qemu';

export type VMStatus =
  | 'PENDING'
  | 'VALIDATING'
  | 'CREATING'
  | 'INSTALLING_OS'
  | 'CONFIGURING'
  | 'STARTING'
  | 'INSTALLING_SSH'
  | 'INSTALLING_TMATE'
  | 'READY'
  | 'STOPPED'
  | 'FAILED'
  | 'DELETING';

export type SupportedOS =
  | 'Ubuntu 20.04'
  | 'Ubuntu 22.04'
  | 'Debian 11'
  | 'Debian 12';

export interface VM {
  id: string;
  name: string;
  engine: ContainerEngine;
  os: SupportedOS;
  ram_mb: number;
  cpu_cores: number;
  disk_gb: number;
  username: string;
  password_hash?: string;
  hostname: string;
  status: VMStatus;
  container_id: string | null;
  ip_address: string | null;
  ssh_port?: number | null;
  failure_message?: string | null;
  failure_stage?: string | null;
  failure_timestamp?: string | null;
  tmate_ssh?: string | null;
  tmate_web?: string | null;
  error_message?: string | null;
  user_id: string;
  created_at: string;
  updated_at: string;
}

export interface LocalNodeInfo {
  id: string;
  name: string;
  hostname: string;
  os_info: string;
  kernel_version: string;
  total_cpu_cores: number;
  total_ram_mb: number;
  total_disk_gb: number;
  used_cpu_percent: number;
  used_ram_mb: number;
  used_disk_gb: number;
  uptime_seconds: number;
  status: 'ONLINE' | 'DEGRADED' | 'OFFLINE';
  updated_at: string;
}

export interface ActivityLog {
  id: string;
  user_id: string;
  username: string;
  action: string;
  details: string;
  status: 'SUCCESS' | 'FAILED' | 'INFO';
  ip: string;
  created_at: string;
}

export interface ApiKey {
  id: string;
  user_id: string;
  name: string;
  key_hash: string;
  key_prefix: string;
  created_at: string;
  expires_at: string | null;
  last_used_at: string | null;
}

export interface SystemSettings {
  panel_name: string;
  container_engine: ContainerEngine;
  theme: 'dark' | 'light' | 'system';
  discord_url: string;
  logo_url: string;
}

export interface PortAllocation {
  port: number;
  vm_id: string;
  protocol: string;
  allocated_at: string;
}

export interface ProvisioningJob {
  id: string;
  vm_id: string;
  stage: VMStatus;
  status: 'in_progress' | 'completed' | 'failed';
  progress_percent: number;
  message?: string;
  error?: string;
  created_at: string;
  updated_at: string;
}
