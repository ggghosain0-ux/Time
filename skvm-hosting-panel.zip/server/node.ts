import os from 'os';
import fs from 'fs';
import { getDb, queryOne, execute } from './db.js';
import { LocalNodeInfo } from './types.js';

let lastCpuInfo: { idle: number; total: number } | null = null;

function getCpuTimes(): { idle: number; total: number } {
  const cpus = os.cpus();
  let idle = 0;
  let total = 0;
  for (const cpu of cpus) {
    for (const type in cpu.times) {
      total += (cpu.times as any)[type];
    }
    idle += cpu.times.idle;
  }
  return { idle, total };
}

export function getCpuUsagePercent(): number {
  const current = getCpuTimes();
  if (!lastCpuInfo) {
    lastCpuInfo = current;
    return 0;
  }
  const idleDiff = current.idle - lastCpuInfo.idle;
  const totalDiff = current.total - lastCpuInfo.total;
  lastCpuInfo = current;

  if (totalDiff <= 0) return 0;
  const usage = 100 - Math.round((idleDiff / totalDiff) * 100);
  return Math.max(0, Math.min(100, usage));
}

export function getDiskStats(): { totalGb: number; usedGb: number; freeGb: number } {
  try {
    if (typeof fs.statfsSync === 'function') {
      const stats = fs.statfsSync('/');
      const totalBytes = stats.bsize * stats.blocks;
      const freeBytes = stats.bsize * stats.bfree;
      const usedBytes = totalBytes - freeBytes;
      return {
        totalGb: Math.round(totalBytes / (1024 * 1024 * 1024)),
        usedGb: Math.round(usedBytes / (1024 * 1024 * 1024)),
        freeGb: Math.round(freeBytes / (1024 * 1024 * 1024)),
      };
    }
  } catch (err) {
    // fallback
  }

  // Fallback estimate based on available memory/default safe estimate
  return {
    totalGb: 50,
    usedGb: 5,
    freeGb: 45,
  };
}

export async function getLocalNodeStats(): Promise<LocalNodeInfo> {
  const cpus = os.cpus();
  const totalRamBytes = os.totalmem();
  const freeRamBytes = os.freemem();
  const usedRamBytes = totalRamBytes - freeRamBytes;

  const totalRamMb = Math.round(totalRamBytes / (1024 * 1024));
  const usedRamMb = Math.round(usedRamBytes / (1024 * 1024));
  const disk = getDiskStats();

  const nodeStats: LocalNodeInfo = {
    id: 'local-node-01',
    name: 'Local Node (Primary)',
    hostname: os.hostname(),
    os_info: `${os.type()} ${os.release()} (${os.arch()})`,
    kernel_version: os.release(),
    total_cpu_cores: cpus.length,
    total_ram_mb: totalRamMb,
    total_disk_gb: disk.totalGb,
    used_cpu_percent: getCpuUsagePercent(),
    used_ram_mb: usedRamMb,
    used_disk_gb: disk.usedGb,
    uptime_seconds: Math.round(os.uptime()),
    status: 'ONLINE',
    updated_at: new Date().toISOString(),
  };

  try {
    const db = await getDb();
    const existing = queryOne(db, 'SELECT id FROM local_node WHERE id = ?', [nodeStats.id]);
    if (existing) {
      execute(
        db,
        `UPDATE local_node SET
          name = ?, hostname = ?, os_info = ?, kernel_version = ?,
          total_cpu_cores = ?, total_ram_mb = ?, total_disk_gb = ?,
          status = ?, updated_at = ?
         WHERE id = ?`,
        [
          nodeStats.name,
          nodeStats.hostname,
          nodeStats.os_info,
          nodeStats.kernel_version,
          nodeStats.total_cpu_cores,
          nodeStats.total_ram_mb,
          nodeStats.total_disk_gb,
          nodeStats.status,
          nodeStats.updated_at,
          nodeStats.id,
        ]
      );
    } else {
      execute(
        db,
        `INSERT INTO local_node (
          id, name, hostname, os_info, kernel_version,
          total_cpu_cores, total_ram_mb, total_disk_gb, status, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          nodeStats.id,
          nodeStats.name,
          nodeStats.hostname,
          nodeStats.os_info,
          nodeStats.kernel_version,
          nodeStats.total_cpu_cores,
          nodeStats.total_ram_mb,
          nodeStats.total_disk_gb,
          nodeStats.status,
          nodeStats.updated_at,
        ]
      );
    }
  } catch (e) {
    console.error('Failed to sync local node to database:', e);
  }

  return nodeStats;
}
