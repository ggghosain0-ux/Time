import fs from 'fs';
import path from 'path';
import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import crypto from 'crypto';

let db: Database | null = null;
let SQL: SqlJsStatic | null = null;
const DB_PATH = process.env.DB_PATH || path.resolve(process.cwd(), 'skvm.sqlite');

export async function getDb(): Promise<Database> {
  if (db) return db;

  SQL = await initSqlJs();

  const dbDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dbDir)) {
    fs.mkdirSync(dbDir, { recursive: true });
  }

  if (fs.existsSync(DB_PATH)) {
    try {
      const fileBuffer = fs.readFileSync(DB_PATH);
      db = new SQL.Database(fileBuffer);
    } catch (e) {
      console.error('Failed to read existing database, initializing new:', e);
      db = new SQL.Database();
    }
  } else {
    db = new SQL.Database();
  }

  initTables(db);
  saveDb();
  return db;
}

export function saveDb(): void {
  if (!db) return;
  try {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  } catch (err) {
    console.error('Error saving SQLite database to disk:', err);
  }
}

function initTables(database: Database): void {
  database.run(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      username TEXT UNIQUE NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'user',
      must_change_password INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS vms (
      id TEXT PRIMARY KEY,
      name TEXT UNIQUE NOT NULL,
      engine TEXT NOT NULL,
      os TEXT NOT NULL,
      ram_mb INTEGER NOT NULL,
      cpu_cores INTEGER NOT NULL,
      disk_gb INTEGER NOT NULL,
      username TEXT NOT NULL,
      password_hash TEXT,
      hostname TEXT NOT NULL,
      status TEXT NOT NULL,
      container_id TEXT,
      ip_address TEXT,
      ssh_port INTEGER,
      failure_message TEXT,
      failure_stage TEXT,
      failure_timestamp TEXT,
      tmate_ssh TEXT,
      tmate_web TEXT,
      error_message TEXT,
      user_id TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS port_allocations (
      port INTEGER PRIMARY KEY,
      vm_id TEXT NOT NULL,
      protocol TEXT NOT NULL DEFAULT 'tcp',
      allocated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS provisioning_jobs (
      id TEXT PRIMARY KEY,
      vm_id TEXT NOT NULL,
      stage TEXT NOT NULL,
      status TEXT NOT NULL,
      progress_percent INTEGER NOT NULL DEFAULT 0,
      message TEXT,
      error TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS local_node (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      hostname TEXT NOT NULL,
      os_info TEXT NOT NULL,
      kernel_version TEXT NOT NULL,
      total_cpu_cores INTEGER NOT NULL,
      total_ram_mb INTEGER NOT NULL,
      total_disk_gb INTEGER NOT NULL,
      status TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS activity_logs (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      username TEXT NOT NULL,
      action TEXT NOT NULL,
      details TEXT NOT NULL,
      status TEXT NOT NULL,
      ip TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS api_keys (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      name TEXT NOT NULL,
      key_hash TEXT NOT NULL,
      key_prefix TEXT NOT NULL,
      created_at TEXT NOT NULL,
      expires_at TEXT,
      last_used_at TEXT
    );
  `);

  // Safe migrations for newly added columns
  const vmColumns = [
    'ssh_port INTEGER',
    'failure_message TEXT',
    'failure_stage TEXT',
    'failure_timestamp TEXT',
    'tmate_ssh TEXT',
    'tmate_web TEXT',
  ];
  for (const colDef of vmColumns) {
    try {
      database.run(`ALTER TABLE vms ADD COLUMN ${colDef}`);
    } catch {
      // column already exists
    }
  }

  // Default settings
  const settingsCount = queryOne(database, `SELECT COUNT(*) as count FROM settings`);
  if (!settingsCount || settingsCount.count === 0) {
    const defaultSettings: Record<string, string> = {
      panel_name: 'SKVM Hosting Panel',
      container_engine: 'docker',
      theme: 'dark',
      discord_url: '',
      logo_url: '',
    };
    for (const [key, value] of Object.entries(defaultSettings)) {
      database.run(`INSERT INTO settings (key, value) VALUES (?, ?)`, [key, value]);
    }
  }

  // Create or update default administrator
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync('admin123', salt, 100000, 64, 'sha512').toString('hex');
  const passwordHash = `${salt}:${hash}`;
  const now = new Date().toISOString();

  const existingAdmin = queryOne(database, `SELECT id FROM users WHERE role = 'admin' OR email = 'admin@gmail.com' OR username = 'admin'`);
  if (!existingAdmin) {
    database.run(
      `INSERT INTO users (id, username, email, password_hash, role, must_change_password, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      ['admin-root', 'admin', 'admin@gmail.com', passwordHash, 'admin', 0, now, now]
    );

    database.run(
      `INSERT INTO activity_logs (id, user_id, username, action, details, status, ip, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        crypto.randomUUID(),
        'system',
        'system',
        'SYSTEM_INITIALIZED',
        'Default administrator user created (admin@gmail.com).',
        'SUCCESS',
        '127.0.0.1',
        now,
      ]
    );
  } else {
    // Ensure credentials match admin@gmail.com / admin123
    database.run(
      `UPDATE users SET email = 'admin@gmail.com', username = 'admin', password_hash = ?, must_change_password = 0, updated_at = ? WHERE id = ?`,
      [passwordHash, now, existingAdmin.id]
    );
  }
}

// Database helper utilities for sql.js
export function queryAll<T = any>(database: Database, sql: string, params: any[] = []): T[] {
  const stmt = database.prepare(sql);
  stmt.bind(params);
  const rows: T[] = [];
  while (stmt.step()) {
    rows.push(stmt.getAsObject() as unknown as T);
  }
  stmt.free();
  return rows;
}

export function queryOne<T = any>(database: Database, sql: string, params: any[] = []): T | null {
  const rows = queryAll<T>(database, sql, params);
  return rows.length > 0 ? rows[0] : null;
}

export function execute(database: Database, sql: string, params: any[] = []): void {
  database.run(sql, params);
  saveDb();
}
