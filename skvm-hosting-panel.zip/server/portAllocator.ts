import net from 'net';
import { getDb, queryOne, queryAll, execute } from './db.js';
import { PortAllocation } from './types.js';

const START_PORT = 2222;
const END_PORT = 2999;

/**
 * Checks if a TCP port is genuinely available on the local host.
 */
export async function isPortAvailable(port: number): Promise<boolean> {
  return new Promise((resolve) => {
    const server = net.createServer();
    server.once('error', (err: any) => {
      if (err.code === 'EADDRINUSE' || err.code === 'EACCES') {
        resolve(false);
      } else {
        resolve(false);
      }
    });

    server.once('listening', () => {
      server.close(() => resolve(true));
    });

    try {
      server.listen(port, '0.0.0.0');
    } catch {
      resolve(false);
    }
  });
}

/**
 * Allocates a unique, host-verified port for a VM.
 */
export async function allocatePort(vmId: string, preferredPort?: number): Promise<number> {
  const db = await getDb();

  // Check if VM already has an assigned port
  const existing = queryOne<PortAllocation>(db, 'SELECT * FROM port_allocations WHERE vm_id = ?', [vmId]);
  if (existing) {
    const stillFree = await isPortAvailable(existing.port);
    if (stillFree) {
      return existing.port;
    }
  }

  // If preferred port is specified and available, use it
  if (preferredPort && preferredPort >= 1024 && preferredPort <= 65535) {
    const inDb = queryOne(db, 'SELECT port FROM port_allocations WHERE port = ?', [preferredPort]);
    if (!inDb) {
      const freeOnHost = await isPortAvailable(preferredPort);
      if (freeOnHost) {
        execute(
          db,
          'INSERT INTO port_allocations (port, vm_id, protocol, allocated_at) VALUES (?, ?, ?, ?)',
          [preferredPort, vmId, 'tcp', new Date().toISOString()]
        );
        return preferredPort;
      }
    }
  }

  // Iterate through standard port range
  const allocatedRows = queryAll<{ port: number }>(db, 'SELECT port FROM port_allocations');
  const usedPorts = new Set(allocatedRows.map((r) => r.port));

  for (let port = START_PORT; port <= END_PORT; port++) {
    if (usedPorts.has(port)) continue;

    const available = await isPortAvailable(port);
    if (available) {
      execute(
        db,
        'INSERT INTO port_allocations (port, vm_id, protocol, allocated_at) VALUES (?, ?, ?, ?)',
        [port, vmId, 'tcp', new Date().toISOString()]
      );
      return port;
    }
  }

  throw new Error(`No available host ports in range ${START_PORT}-${END_PORT}. All ports are either bound or allocated.`);
}

/**
 * Releases any allocated ports for a VM upon deletion.
 */
export async function releasePort(vmId: string): Promise<void> {
  const db = await getDb();
  execute(db, 'DELETE FROM port_allocations WHERE vm_id = ?', [vmId]);
}

/**
 * Gets the current allocated SSH port for a VM.
 */
export async function getAllocatedPort(vmId: string): Promise<number | null> {
  const db = await getDb();
  const row = queryOne<PortAllocation>(db, 'SELECT port FROM port_allocations WHERE vm_id = ?', [vmId]);
  return row ? row.port : null;
}
