import { Server as HttpServer } from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import url from 'url';
import { verifyToken, logActivity } from './auth.js';
import { getDb, queryOne } from './db.js';
import { VM } from './types.js';
import { getProvider } from './providers/index.js';
import { TerminalSession } from './providers/types.js';

export function setupTerminalWebSocket(server: HttpServer): WebSocketServer {
  const wss = new WebSocketServer({ noServer: true });

  server.on('upgrade', async (request, socket, head) => {
    const pathname = url.parse(request.url || '').pathname;

    // Pattern: /api/vms/:id/terminal
    const match = pathname?.match(/^\/api\/vms\/([a-zA-Z0-9_-]+)\/terminal$/);
    if (!match) {
      socket.destroy();
      return;
    }

    const vmId = match[1];
    const parsedUrl = url.parse(request.url || '', true);
    const token = parsedUrl.query.token as string;

    if (!token) {
      socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
      socket.destroy();
      return;
    }

    const auth = verifyToken(token);
    if (!auth) {
      socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
      socket.destroy();
      return;
    }

    try {
      const db = await getDb();
      const vm = queryOne<VM>(db, 'SELECT * FROM vms WHERE id = ?', [vmId]);
      if (!vm) {
        socket.write('HTTP/1.1 404 Not Found\r\n\r\n');
        socket.destroy();
        return;
      }

      // Check ownership or admin
      if (auth.role !== 'admin' && vm.user_id !== auth.userId) {
        socket.write('HTTP/1.1 403 Forbidden\r\n\r\n');
        socket.destroy();
        return;
      }

      if (vm.status !== 'READY' || !vm.container_id) {
        socket.write('HTTP/1.1 400 Bad Request\r\n\r\n');
        socket.destroy();
        return;
      }

      wss.handleUpgrade(request, socket, head, (ws) => {
        wss.emit('connection', ws, request, { vm, auth });
      });
    } catch (err) {
      console.error('Terminal upgrade error:', err);
      socket.destroy();
    }
  });

  wss.on('connection', async (ws: WebSocket, req: any, { vm, auth }: { vm: VM; auth: any }) => {
    let session: TerminalSession | null = null;
    const ip = req.socket.remoteAddress || '127.0.0.1';

    try {
      await logActivity(
        auth.userId,
        auth.username,
        'TERMINAL_SESSION_OPENED',
        `Terminal session opened for VM ${vm.name} (${vm.engine})`,
        'SUCCESS',
        ip
      );

      const provider = getProvider(vm.engine);
      session = await provider.createTerminalSession(vm.container_id!, ws, 80, 24);

      ws.on('message', (message: string) => {
        try {
          const parsed = JSON.parse(message.toString());
          if (parsed.type === 'input' && typeof parsed.data === 'string' && session) {
            session.sendInput(parsed.data);
          } else if (parsed.type === 'resize' && session) {
            const cols = Number(parsed.cols) || 80;
            const rows = Number(parsed.rows) || 24;
            session.resize(cols, rows);
          }
        } catch {
          // treat as raw stdin input if not valid JSON
          if (session) {
            session.sendInput(message.toString());
          }
        }
      });

      ws.on('close', async () => {
        if (session) {
          session.close();
          session = null;
        }
        await logActivity(
          auth.userId,
          auth.username,
          'TERMINAL_SESSION_CLOSED',
          `Terminal session closed for VM ${vm.name}`,
          'INFO',
          ip
        );
      });

      ws.on('error', (err) => {
        console.error('Terminal WebSocket error:', err);
        if (session) {
          session.close();
          session = null;
        }
      });
    } catch (err: any) {
      console.error('Failed to attach terminal session:', err);
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(
          JSON.stringify({
            type: 'error',
            message: `Terminal error: ${err.message || 'Failed to connect to container shell'}`,
          })
        );
        ws.close(1011, err.message);
      }
    }
  });

  return wss;
}
