import express from 'express';
import { authenticateToken } from '../auth.js';
import { getLocalNodeStats } from '../node.js';
import { getDb, queryOne } from '../db.js';

const router = express.Router();

// GET /api/node/stats
router.get('/stats', authenticateToken, async (req, res) => {
  const stats = await getLocalNodeStats();

  const db = await getDb();
  const totalUsers = queryOne<{ count: number }>(db, 'SELECT COUNT(*) as count FROM users')?.count || 0;
  const totalVms = queryOne<{ count: number }>(db, 'SELECT COUNT(*) as count FROM vms')?.count || 0;
  const runningVms = queryOne<{ count: number }>(db, "SELECT COUNT(*) as count FROM vms WHERE status = 'READY'")?.count || 0;
  const stoppedVms = queryOne<{ count: number }>(db, "SELECT COUNT(*) as count FROM vms WHERE status = 'STOPPED'")?.count || 0;
  const failedVms = queryOne<{ count: number }>(db, "SELECT COUNT(*) as count FROM vms WHERE status = 'FAILED'")?.count || 0;

  res.json({
    node: stats,
    overview: {
      totalUsers,
      totalVms,
      runningVms,
      stoppedVms,
      failedVms,
    },
  });
});

export default router;
