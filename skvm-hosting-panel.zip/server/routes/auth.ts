import express from 'express';
import crypto from 'crypto';
import { getDb, queryOne, queryAll, execute } from '../db.js';
import { hashPassword, verifyPassword, createToken, authenticateToken, requireAdmin, logActivity, AuthenticatedRequest } from '../auth.js';
import { User } from '../types.js';

const router = express.Router();

// POST /api/auth/login
router.post('/login', async (req, res) => {
  const username = req.body.username || req.body.login;
  const { password } = req.body;
  if (!username || !password) {
    res.status(400).json({ error: 'Username and password are required' });
    return;
  }

  const db = await getDb();
  const user = queryOne<User>(
    db,
    'SELECT * FROM users WHERE username = ? OR email = ?',
    [username, username]
  );

  if (!user || !verifyPassword(password, user.password_hash)) {
    await logActivity(
      'unauthenticated',
      username,
      'LOGIN_FAILED',
      'Failed login attempt with invalid credentials',
      'FAILED',
      req.ip || '127.0.0.1'
    );
    res.status(401).json({ error: 'Invalid username or password' });
    return;
  }

  const token = createToken(user);
  await logActivity(
    user.id,
    user.username,
    'LOGIN_SUCCESS',
    `User ${user.username} logged in successfully`,
    'SUCCESS',
    req.ip || '127.0.0.1'
  );

  res.json({
    token,
    user: {
      id: user.id,
      username: user.username,
      email: user.email,
      role: user.role,
      must_change_password: Boolean(user.must_change_password),
    },
  });
});

// POST /api/auth/register (Admin or first setup)
router.post('/register', async (req, res) => {
  const { username, email, password, role } = req.body;
  if (!username || !email || !password) {
    res.status(400).json({ error: 'Username, email, and password are required' });
    return;
  }

  if (password.length < 8) {
    res.status(400).json({ error: 'Password must be at least 8 characters' });
    return;
  }

  const db = await getDb();
  const existing = queryOne(
    db,
    'SELECT id FROM users WHERE username = ? OR email = ?',
    [username, email]
  );

  if (existing) {
    res.status(409).json({ error: 'Username or email already exists' });
    return;
  }

  const id = crypto.randomUUID();
  const passwordHash = hashPassword(password);
  const userRole = role === 'admin' ? 'admin' : 'user';
  const now = new Date().toISOString();

  execute(
    db,
    `INSERT INTO users (id, username, email, password_hash, role, must_change_password, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [id, username, email, passwordHash, userRole, 0, now, now]
  );

  await logActivity(
    id,
    username,
    'USER_REGISTERED',
    `User ${username} registered with role ${userRole}`,
    'SUCCESS',
    req.ip || '127.0.0.1'
  );

  const newUser = { id, username, email, role: userRole as any, must_change_password: false };
  const token = createToken(newUser);

  res.status(201).json({
    token,
    user: newUser,
  });
});

// GET /api/auth/me
router.get('/me', authenticateToken, async (req: AuthenticatedRequest, res) => {
  const db = await getDb();
  const user = queryOne<User>(db, 'SELECT * FROM users WHERE id = ?', [req.user!.userId]);
  if (!user) {
    res.status(404).json({ error: 'User not found' });
    return;
  }

  res.json({
    id: user.id,
    username: user.username,
    email: user.email,
    role: user.role,
    must_change_password: Boolean(user.must_change_password),
  });
});

// POST /api/auth/change-password
router.post('/change-password', authenticateToken, async (req: AuthenticatedRequest, res) => {
  const { currentPassword, newPassword } = req.body;
  if (!newPassword || newPassword.length < 8) {
    res.status(400).json({ error: 'New password must be at least 8 characters long' });
    return;
  }

  const db = await getDb();
  const user = queryOne<User>(db, 'SELECT * FROM users WHERE id = ?', [req.user!.userId]);
  if (!user) {
    res.status(404).json({ error: 'User not found' });
    return;
  }

  if (currentPassword && !verifyPassword(currentPassword, user.password_hash)) {
    res.status(401).json({ error: 'Current password is incorrect' });
    return;
  }

  const newHash = hashPassword(newPassword);
  const now = new Date().toISOString();

  execute(
    db,
    'UPDATE users SET password_hash = ?, must_change_password = 0, updated_at = ? WHERE id = ?',
    [newHash, now, user.id]
  );

  await logActivity(
    user.id,
    user.username,
    'PASSWORD_CHANGED',
    'User password was updated',
    'SUCCESS',
    req.ip || '127.0.0.1'
  );

  res.json({ message: 'Password updated successfully' });
});

// GET /api/auth/users (Admin only)
router.get('/users', authenticateToken, requireAdmin, async (req: AuthenticatedRequest, res) => {
  const db = await getDb();
  const users = queryAll<User>(db, 'SELECT id, username, email, role, created_at FROM users ORDER BY created_at DESC');
  res.json({ users });
});

// POST /api/auth/users (Admin create user)
router.post('/users', authenticateToken, requireAdmin, async (req: AuthenticatedRequest, res) => {
  const { username, email, password, role } = req.body;
  if (!username || !email || !password) {
    res.status(400).json({ error: 'Username, email, and password are required' });
    return;
  }

  if (password.length < 8) {
    res.status(400).json({ error: 'Password must be at least 8 characters long' });
    return;
  }

  const db = await getDb();
  const existing = queryOne(
    db,
    'SELECT id FROM users WHERE username = ? OR email = ?',
    [username.trim(), email.trim()]
  );

  if (existing) {
    res.status(409).json({ error: 'A user with that username or email already exists' });
    return;
  }

  const id = crypto.randomUUID();
  const passwordHash = hashPassword(password);
  const userRole = role === 'admin' ? 'admin' : 'user';
  const now = new Date().toISOString();

  execute(
    db,
    `INSERT INTO users (id, username, email, password_hash, role, must_change_password, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [id, username.trim(), email.trim(), passwordHash, userRole, 0, now, now]
  );

  await logActivity(
    req.user!.userId,
    req.user!.username,
    'USER_CREATED_BY_ADMIN',
    `User ${username.trim()} (${userRole}) created by admin ${req.user!.username}`,
    'SUCCESS',
    req.ip || '127.0.0.1'
  );

  res.status(201).json({
    user: {
      id,
      username: username.trim(),
      email: email.trim(),
      role: userRole,
      created_at: now,
    },
  });
});

// DELETE /api/auth/users/:id (Admin delete user)
router.delete('/users/:id', authenticateToken, requireAdmin, async (req: AuthenticatedRequest, res) => {
  const { id } = req.params;
  if (id === req.user!.userId) {
    res.status(400).json({ error: 'You cannot delete your own administrator account' });
    return;
  }

  const db = await getDb();
  const targetUser = queryOne<User>(db, 'SELECT * FROM users WHERE id = ?', [id]);
  if (!targetUser) {
    res.status(404).json({ error: 'User not found' });
    return;
  }

  // Also remove or reassign VMs
  execute(db, 'DELETE FROM users WHERE id = ?', [id]);

  await logActivity(
    req.user!.userId,
    req.user!.username,
    'USER_DELETED',
    `User ${targetUser.username} (${targetUser.email}) was deleted by admin ${req.user!.username}`,
    'SUCCESS',
    req.ip || '127.0.0.1'
  );

  res.json({ message: `User ${targetUser.username} successfully deleted` });
});

export default router;
