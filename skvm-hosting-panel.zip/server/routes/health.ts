import express from 'express';
import os from 'os';
import fs from 'fs';
import { getDb, queryOne } from '../db.js';
import { checkAllEngines } from '../providers/index.js';
import { getLocalNodeStats } from '../node.js';

const router = express.Router();

// GET /api/health
router.get('/', async (req, res) => {
  let dbHealthy = false;
  let dbDetails = '';
  try {
    const db = await getDb();
    const test = queryOne(db, 'SELECT 1 as alive');
    dbHealthy = test && test.alive === 1;
    dbDetails = 'SQLite connection active and readable';
  } catch (err: any) {
    dbDetails = err.message;
  }

  // Check engines
  const engines = await checkAllEngines();

  // Check node & permissions
  let isRoot = false;
  try {
    isRoot = process.getuid ? process.getuid() === 0 : false;
  } catch {
    // Windows / non-posix fallback
  }

  // Check cgroups support
  const cgroupsV1 = fs.existsSync('/sys/fs/cgroup/cpu') || fs.existsSync('/sys/fs/cgroup/memory');
  const cgroupsV2 = fs.existsSync('/sys/fs/cgroup/cgroup.controllers');
  const cgroupsAvailable = cgroupsV1 || cgroupsV2;

  // Node stats
  const nodeStats = await getLocalNodeStats();

  const isAnyEngineAvailable = engines.docker.available || engines.lxc.available || engines.qemu.available;
  const overallHealthy = dbHealthy && isAnyEngineAvailable;

  const limitedEnvironmentReasons: string[] = [];
  if (!engines.docker.available) {
    limitedEnvironmentReasons.push(`Docker: ${engines.docker.error}`);
  }
  if (!engines.lxc.available) {
    limitedEnvironmentReasons.push(`LXC: ${engines.lxc.error}`);
  }
  if (!engines.qemu.available) {
    limitedEnvironmentReasons.push(`QEMU: ${engines.qemu.error}`);
  }
  if (!cgroupsAvailable) {
    limitedEnvironmentReasons.push('cgroups filesystem not mounted or restricted');
  }

  res.status(overallHealthy ? 200 : 503).json({
    status: overallHealthy ? 'healthy' : 'degraded',
    infrastructure_ready: isAnyEngineAvailable,
    timestamp: new Date().toISOString(),
    components: {
      database: {
        healthy: dbHealthy,
        driver: 'sqlite',
        details: dbDetails,
      },
      engines: {
        docker: engines.docker,
        lxc: engines.lxc,
        qemu: engines.qemu,
      },
      capabilities: {
        is_root: isRoot,
        cgroups_support: cgroupsAvailable,
        cgroups_v2: cgroupsV2,
        architecture: os.arch(),
        platform: os.platform(),
      },
      node: {
        hostname: nodeStats.hostname,
        total_cpu_cores: nodeStats.total_cpu_cores,
        total_ram_mb: nodeStats.total_ram_mb,
        total_disk_gb: nodeStats.total_disk_gb,
        uptime_seconds: nodeStats.uptime_seconds,
      },
    },
    limited_environment: !isAnyEngineAvailable,
    limited_environment_reasons: limitedEnvironmentReasons,
  });
});

export default router;
