import express from 'express';
import crypto from 'crypto';
import { getDb, queryOne, queryAll, execute } from '../db.js';
import { authenticateToken, requireAdmin, logActivity, hashPassword, AuthenticatedRequest } from '../auth.js';
import { VM, SupportedOS, ContainerEngine } from '../types.js';
import { getProvider } from '../providers/index.js';
import { enqueueProvision, deleteVM } from '../provisioner.js';

const router = express.Router();

const VALID_OS_LIST: string[] = [
  'Ubuntu 20.04',
  'Ubuntu 22.04',
  'Debian 11',
  'Debian 12',
  'ubuntu:20.04',
  'ubuntu:22.04',
  'debian:11',
  'debian:12',
];

// GET /api/vms
router.get('/', authenticateToken, async (req: AuthenticatedRequest, res) => {
  const db = await getDb();
  let vms: VM[] = [];

  if (req.user!.role === 'admin') {
    vms = queryAll<VM>(db, 'SELECT * FROM vms ORDER BY created_at DESC');
  } else {
    vms = queryAll<VM>(db, 'SELECT * FROM vms WHERE user_id = ? ORDER BY created_at DESC', [req.user!.userId]);
  }

  // Sanitize: never return password_hash
  const sanitized = vms.map((vm) => {
    const { password_hash, ...rest } = vm;
    return rest;
  });

  res.json({ vms: sanitized });
});

// POST /api/vms (Admin only)
router.post('/', authenticateToken, requireAdmin, async (req: AuthenticatedRequest, res) => {
  const {
    name,
    os,
    ram_mb,
    cpu_cores,
    disk_gb,
    username = 'root',
    password,
    hostname,
    target_user_id,
  } = req.body;

  // Validation
  if (!name || typeof name !== 'string' || name.trim().length < 2) {
    res.status(400).json({ error: 'Valid VM Name is required (minimum 2 characters)' });
    return;
  }

  const cleanName = name.trim();
  if (!/^[a-zA-Z0-9_-]+$/.test(cleanName)) {
    res.status(400).json({ error: 'VM Name may only contain alphanumeric characters, underscores, and dashes' });
    return;
  }

  if (!VALID_OS_LIST.includes(os)) {
    res.status(400).json({
      error: `Invalid Operating System. Supported: ${VALID_OS_LIST.join(', ')}`,
    });
    return;
  }

  const ram = parseInt(ram_mb, 10);
  const cpu = parseInt(cpu_cores, 10);
  const disk = parseInt(disk_gb, 10);

  if (isNaN(ram) || ram < 256 || ram > 65536) {
    res.status(400).json({ error: 'RAM must be between 256 MB and 65,536 MB' });
    return;
  }

  if (isNaN(cpu) || cpu < 1 || cpu > 64) {
    res.status(400).json({ error: 'CPU cores must be between 1 and 64' });
    return;
  }

  if (isNaN(disk) || disk < 1 || disk > 1000) {
    res.status(400).json({ error: 'Disk must be between 1 GB and 1,000 GB' });
    return;
  }

  const db = await getDb();

  // Check unique name
  const existingName = queryOne(db, 'SELECT id FROM vms WHERE name = ?', [cleanName]);
  if (existingName) {
    res.status(409).json({ error: `A virtual machine named "${cleanName}" already exists` });
    return;
  }

  // Determine container engine from settings
  const engineSetting = queryOne<{ value: string }>(
    db,
    'SELECT value FROM settings WHERE key = ?',
    ['container_engine']
  );
  const engine: ContainerEngine = (engineSetting?.value as ContainerEngine) || 'docker';

  const vmId = crypto.randomUUID();
  const assignedUserId = target_user_id || req.user!.userId;
  const now = new Date().toISOString();
  const passwordHash = password ? hashPassword(password) : undefined;
  const cleanHostname = hostname ? hostname.trim() : cleanName.toLowerCase();

  execute(
    db,
    `INSERT INTO vms (
      id, name, engine, os, ram_mb, cpu_cores, disk_gb,
      username, password_hash, hostname, status, container_id,
      ip_address, error_message, user_id, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      vmId,
      cleanName,
      engine,
      os,
      ram,
      cpu,
      disk,
      username.trim(),
      passwordHash || null,
      cleanHostname,
      'PENDING',
      null,
      null,
      null,
      assignedUserId,
      now,
      now,
    ]
  );

  await logActivity(
    req.user!.userId,
    req.user!.username,
    'VM_CREATE_REQUESTED',
    `VM ${cleanName} creation queued with ${ram}MB RAM, ${cpu} cores, OS ${os} using engine ${engine}.`,
    'INFO',
    req.ip || '127.0.0.1'
  );

  // Trigger asynchronous provisioning
  enqueueProvision(vmId);

  res.status(202).json({
    message: 'VM creation queued and provisioning initiated',
    vmId,
  });
});

// GET /api/vms/:id
router.get('/:id', authenticateToken, async (req: AuthenticatedRequest, res) => {
  const db = await getDb();
  const vm = queryOne<VM>(db, 'SELECT * FROM vms WHERE id = ?', [req.params.id]);

  if (!vm) {
    res.status(404).json({ error: 'Virtual Machine not found' });
    return;
  }

  if (req.user!.role !== 'admin' && vm.user_id !== req.user!.userId) {
    res.status(403).json({ error: 'Forbidden: You do not have access to this virtual machine' });
    return;
  }

  // Live status probe if container exists
  if (vm.container_id && vm.status === 'READY') {
    try {
      const provider = getProvider(vm.engine);
      const st = await provider.status(vm.container_id);
      if (st.state === 'running' && st.ip && st.ip !== vm.ip_address) {
        execute(db, 'UPDATE vms SET ip_address = ? WHERE id = ?', [st.ip, vm.id]);
        vm.ip_address = st.ip;
      }
    } catch {
      // ignore
    }
  }

  const { password_hash, ...rest } = vm;
  res.json({ vm: rest });
});

// POST /api/vms/:id/start
router.post('/:id/start', authenticateToken, async (req: AuthenticatedRequest, res) => {
  const db = await getDb();
  const vm = queryOne<VM>(db, 'SELECT * FROM vms WHERE id = ?', [req.params.id]);

  if (!vm) {
    res.status(404).json({ error: 'Virtual Machine not found' });
    return;
  }

  if (req.user!.role !== 'admin' && vm.user_id !== req.user!.userId) {
    res.status(403).json({ error: 'Forbidden' });
    return;
  }

  if (!vm.container_id) {
    res.status(400).json({ error: 'Cannot start VM: No underlying container allocated' });
    return;
  }

  try {
    const provider = getProvider(vm.engine);
    await provider.start(vm.container_id);
    const ip = await provider.getIp(vm.container_id);

    execute(
      db,
      'UPDATE vms SET status = ?, ip_address = ?, updated_at = ? WHERE id = ?',
      ['READY', ip || vm.ip_address, new Date().toISOString(), vm.id]
    );

    await logActivity(
      req.user!.userId,
      req.user!.username,
      'VM_STARTED',
      `Virtual Machine ${vm.name} started successfully`,
      'SUCCESS',
      req.ip || '127.0.0.1'
    );

    res.json({ message: 'VM started successfully', status: 'READY', ip_address: ip || vm.ip_address });
  } catch (err: any) {
    res.status(500).json({ error: `Failed to start VM: ${err.message}` });
  }
});

// POST /api/vms/:id/stop
router.post('/:id/stop', authenticateToken, async (req: AuthenticatedRequest, res) => {
  const db = await getDb();
  const vm = queryOne<VM>(db, 'SELECT * FROM vms WHERE id = ?', [req.params.id]);

  if (!vm) {
    res.status(404).json({ error: 'Virtual Machine not found' });
    return;
  }

  if (req.user!.role !== 'admin' && vm.user_id !== req.user!.userId) {
    res.status(403).json({ error: 'Forbidden' });
    return;
  }

  if (!vm.container_id) {
    res.status(400).json({ error: 'Cannot stop VM: No underlying container allocated' });
    return;
  }

  try {
    const provider = getProvider(vm.engine);
    await provider.stop(vm.container_id);

    execute(
      db,
      'UPDATE vms SET status = ?, updated_at = ? WHERE id = ?',
      ['STOPPED', new Date().toISOString(), vm.id]
    );

    await logActivity(
      req.user!.userId,
      req.user!.username,
      'VM_STOPPED',
      `Virtual Machine ${vm.name} stopped`,
      'SUCCESS',
      req.ip || '127.0.0.1'
    );

    res.json({ message: 'VM stopped successfully', status: 'STOPPED' });
  } catch (err: any) {
    res.status(500).json({ error: `Failed to stop VM: ${err.message}` });
  }
});

// POST /api/vms/:id/restart
router.post('/:id/restart', authenticateToken, async (req: AuthenticatedRequest, res) => {
  const db = await getDb();
  const vm = queryOne<VM>(db, 'SELECT * FROM vms WHERE id = ?', [req.params.id]);

  if (!vm) {
    res.status(404).json({ error: 'Virtual Machine not found' });
    return;
  }

  if (req.user!.role !== 'admin' && vm.user_id !== req.user!.userId) {
    res.status(403).json({ error: 'Forbidden' });
    return;
  }

  if (!vm.container_id) {
    res.status(400).json({ error: 'Cannot restart VM: No underlying container allocated' });
    return;
  }

  try {
    const provider = getProvider(vm.engine);
    await provider.restart(vm.container_id);
    const ip = await provider.getIp(vm.container_id);

    execute(
      db,
      'UPDATE vms SET status = ?, ip_address = ?, updated_at = ? WHERE id = ?',
      ['READY', ip || vm.ip_address, new Date().toISOString(), vm.id]
    );

    await logActivity(
      req.user!.userId,
      req.user!.username,
      'VM_RESTARTED',
      `Virtual Machine ${vm.name} restarted`,
      'SUCCESS',
      req.ip || '127.0.0.1'
    );

    res.json({ message: 'VM restarted successfully', status: 'READY', ip_address: ip || vm.ip_address });
  } catch (err: any) {
    res.status(500).json({ error: `Failed to restart VM: ${err.message}` });
  }
});

// DELETE /api/vms/:id
router.delete('/:id', authenticateToken, async (req: AuthenticatedRequest, res) => {
  const db = await getDb();
  const vm = queryOne<VM>(db, 'SELECT * FROM vms WHERE id = ?', [req.params.id]);

  if (!vm) {
    res.status(404).json({ error: 'Virtual Machine not found' });
    return;
  }

  if (req.user!.role !== 'admin' && vm.user_id !== req.user!.userId) {
    res.status(403).json({ error: 'Forbidden: Only administrators or the VM owner may delete this machine' });
    return;
  }

  try {
    await deleteVM(vm.id, req.user!.userId, req.user!.username);
    res.json({ message: 'VM successfully deleted' });
  } catch (err: any) {
    res.status(500).json({ error: `Failed to delete VM: ${err.message}` });
  }
});

// GET /api/vms/:id/status
router.get('/:id/status', authenticateToken, async (req: AuthenticatedRequest, res) => {
  const db = await getDb();
  const vm = queryOne<VM>(db, 'SELECT * FROM vms WHERE id = ?', [req.params.id]);

  if (!vm) {
    res.status(404).json({ error: 'Virtual Machine not found' });
    return;
  }

  if (req.user!.role !== 'admin' && vm.user_id !== req.user!.userId) {
    res.status(403).json({ error: 'Forbidden' });
    return;
  }

  if (!vm.container_id) {
    res.json({
      db_status: vm.status,
      engine_status: 'none',
      ip: null,
      error_message: vm.error_message,
    });
    return;
  }

  try {
    const provider = getProvider(vm.engine);
    const st = await provider.status(vm.container_id);
    res.json({
      db_status: vm.status,
      engine_status: st.state,
      ip: st.ip || vm.ip_address,
      uptime: st.uptime,
      error_message: vm.error_message || st.errorMessage,
    });
  } catch (err: any) {
    res.json({
      db_status: vm.status,
      engine_status: 'error',
      error_message: err.message,
    });
  }
});

// GET /api/vms/:id/logs
router.get('/:id/logs', authenticateToken, async (req: AuthenticatedRequest, res) => {
  const db = await getDb();
  const vm = queryOne<VM>(db, 'SELECT * FROM vms WHERE id = ?', [req.params.id]);

  if (!vm) {
    res.status(404).json({ error: 'Virtual Machine not found' });
    return;
  }

  if (req.user!.role !== 'admin' && vm.user_id !== req.user!.userId) {
    res.status(403).json({ error: 'Forbidden' });
    return;
  }

  if (!vm.container_id) {
    res.json({ logs: 'No underlying container allocated.' });
    return;
  }

  try {
    const provider = getProvider(vm.engine);
    const logs = await provider.getLogs(vm.container_id);
    res.json({ logs });
  } catch (err: any) {
    res.status(500).json({ error: `Failed to fetch logs: ${err.message}` });
  }
});

// GET /api/vms/:id/files
router.get('/:id/files', authenticateToken, async (req: AuthenticatedRequest, res) => {
  const db = await getDb();
  const vm = queryOne<VM>(db, 'SELECT * FROM vms WHERE id = ?', [req.params.id]);

  if (!vm) {
    res.status(404).json({ error: 'Virtual Machine not found' });
    return;
  }

  if (req.user!.role !== 'admin' && vm.user_id !== req.user!.userId) {
    res.status(403).json({ error: 'Forbidden' });
    return;
  }

  if (!vm.container_id || vm.status !== 'READY') {
    res.json({
      files: [],
      path: req.query.path || '/',
      message: 'Container is not currently running.',
    });
    return;
  }

  const requestedPath = typeof req.query.path === 'string' && req.query.path ? req.query.path : '/root';

  try {
    const provider = getProvider(vm.engine);
    // Execute ls -la in container
    const result = await provider.execute(vm.container_id, ['ls', '-la', requestedPath]);
    const lines = result.output.split('\n').filter((l) => l.trim().length > 0);
    const items = lines.slice(1).map((line) => {
      const parts = line.trim().split(/\s+/);
      const permissions = parts[0] || '';
      const isDir = permissions.startsWith('d');
      const size = parts[4] || '0';
      const name = parts.slice(8).join(' ') || parts[parts.length - 1];
      return {
        name,
        isDir,
        size,
        permissions,
        updated: `${parts[5] || ''} ${parts[6] || ''} ${parts[7] || ''}`,
      };
    }).filter((i) => i.name && i.name !== '.' && i.name !== '..');

    res.json({
      path: requestedPath,
      files: items,
      raw: result.output,
    });
  } catch (err: any) {
    res.status(500).json({ error: `Failed to list files: ${err.message}` });
  }
});

// POST /api/vms/:id/command
router.post('/:id/command', authenticateToken, async (req: AuthenticatedRequest, res) => {
  const { command } = req.body;
  if (!command || typeof command !== 'string') {
    res.status(400).json({ error: 'Command string is required' });
    return;
  }

  const db = await getDb();
  const vm = queryOne<VM>(db, 'SELECT * FROM vms WHERE id = ?', [req.params.id]);

  if (!vm) {
    res.status(404).json({ error: 'Virtual Machine not found' });
    return;
  }

  if (req.user!.role !== 'admin' && vm.user_id !== req.user!.userId) {
    res.status(403).json({ error: 'Forbidden' });
    return;
  }

  if (!vm.container_id || vm.status !== 'READY') {
    res.status(400).json({ error: 'Cannot execute command: Container is not running' });
    return;
  }

  try {
    const provider = getProvider(vm.engine);
    const result = await provider.execute(vm.container_id, ['/bin/sh', '-c', command]);
    res.json({
      exitCode: result.exitCode,
      output: result.output,
    });
  } catch (err: any) {
    res.status(500).json({ error: `Command execution failed: ${err.message}` });
  }
});

// GET /api/vms/:id/metrics
router.get('/:id/metrics', authenticateToken, async (req: AuthenticatedRequest, res) => {
  const db = await getDb();
  const vm = queryOne<VM>(db, 'SELECT * FROM vms WHERE id = ?', [req.params.id]);

  if (!vm) {
    res.status(404).json({ error: 'Virtual Machine not found' });
    return;
  }

  if (req.user!.role !== 'admin' && vm.user_id !== req.user!.userId) {
    res.status(403).json({ error: 'Forbidden' });
    return;
  }

  if (!vm.container_id || vm.status !== 'READY') {
    res.json({
      status: vm.status,
      cpu_percent: 0,
      memory_usage_mb: 0,
      total_ram_mb: vm.ram_mb,
      disk_gb: vm.disk_gb,
      uptime_seconds: 0,
    });
    return;
  }

  try {
    const provider = getProvider(vm.engine);
    const st = await provider.status(vm.container_id);
    res.json({
      status: vm.status,
      cpu_percent: st.cpuPercent || 0,
      memory_usage_mb: st.memoryUsageMb || 0,
      total_ram_mb: vm.ram_mb,
      disk_gb: vm.disk_gb,
      uptime_seconds: st.uptime || 0,
    });
  } catch (err: any) {
    res.status(500).json({ error: `Failed to retrieve metrics: ${err.message}` });
  }
});

// GET /api/vms/:id/network
router.get('/:id/network', authenticateToken, async (req: AuthenticatedRequest, res) => {
  const db = await getDb();
  const vm = queryOne<VM>(db, 'SELECT * FROM vms WHERE id = ?', [req.params.id]);

  if (!vm) {
    res.status(404).json({ error: 'Virtual Machine not found' });
    return;
  }

  if (req.user!.role !== 'admin' && vm.user_id !== req.user!.userId) {
    res.status(403).json({ error: 'Forbidden' });
    return;
  }

  const sshPort = vm.ssh_port || 22;
  const ip = vm.ip_address || '127.0.0.1';
  const sshCommand = `ssh -p ${sshPort} ${vm.username}@${ip}`;

  res.json({
    ip: vm.ip_address,
    ssh_port: sshPort,
    ssh_command: sshCommand,
    gateway: '172.17.0.1',
    subnet: '255.255.0.0',
    dns: ['1.1.1.1', '8.8.8.8'],
  });
});

// POST /api/vms/:id/tmate
router.post('/:id/tmate', authenticateToken, async (req: AuthenticatedRequest, res) => {
  const db = await getDb();
  const vm = queryOne<VM>(db, 'SELECT * FROM vms WHERE id = ?', [req.params.id]);

  if (!vm) {
    res.status(404).json({ error: 'Virtual Machine not found' });
    return;
  }

  if (req.user!.role !== 'admin' && vm.user_id !== req.user!.userId) {
    res.status(403).json({ error: 'Forbidden' });
    return;
  }

  if (!vm.container_id || vm.status !== 'READY') {
    res.status(400).json({ error: 'Cannot initiate tmate: workload is not running' });
    return;
  }

  try {
    const provider = getProvider(vm.engine);
    const setupScript = [
      'if ! command -v tmate >/dev/null 2>&1; then',
      '  apt-get update -y && apt-get install -y tmate || yum install -y tmate || true',
      'fi',
      'tmate -S /tmp/tmate.sock new-session -d || true',
      'tmate -S /tmp/tmate.sock wait for-server-connection || true',
      'echo "TMATE_SSH=$(tmate -S /tmp/tmate.sock display -p \'#{tmate_ssh}\')"',
      'echo "TMATE_WEB=$(tmate -S /tmp/tmate.sock display -p \'#{tmate_web}\')"',
    ].join('\n');

    const result = await provider.execute(vm.container_id, ['/bin/sh', '-c', setupScript]);
    
    let tmateSsh: string | null = null;
    let tmateWeb: string | null = null;

    for (const line of result.output.split('\n')) {
      if (line.startsWith('TMATE_SSH=')) {
        tmateSsh = line.replace('TMATE_SSH=', '').trim() || null;
      }
      if (line.startsWith('TMATE_WEB=')) {
        tmateWeb = line.replace('TMATE_WEB=', '').trim() || null;
      }
    }

    if (!tmateSsh && !tmateWeb) {
      throw new Error(`Failed to establish tmate session: ${result.output.trim()}`);
    }

    execute(db, 'UPDATE vms SET tmate_ssh = ?, tmate_web = ? WHERE id = ?', [tmateSsh, tmateWeb, vm.id]);

    await logActivity(
      req.user!.userId,
      req.user!.username,
      'TMATE_SESSION_STARTED',
      `Tmate session established for VM ${vm.name}`,
      'SUCCESS'
    );

    res.json({
      success: true,
      tmate_ssh: tmateSsh,
      tmate_web: tmateWeb,
    });
  } catch (err: any) {
    res.status(500).json({ error: `Tmate session creation failed: ${err.message}` });
  }
});

export default router;
