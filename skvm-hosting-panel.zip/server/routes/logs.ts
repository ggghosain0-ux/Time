import express from 'express';
import { getDb, queryAll } from '../db.js';
import { authenticateToken, requireAdmin, AuthenticatedRequest } from '../auth.js';
import { ActivityLog } from '../types.js';

const router = express.Router();

// GET /api/logs (Admin only)
router.get('/', authenticateToken, requireAdmin, async (req: AuthenticatedRequest, res) => {
  const db = await getDb();
  const limit = Math.min(100, Math.max(10, parseInt(req.query.limit as string, 10) || 50));
  const logs = queryAll<ActivityLog>(
    db,
    'SELECT * FROM activity_logs ORDER BY created_at DESC LIMIT ?',
    [limit]
  );

  res.json({ logs });
});

export default router;
