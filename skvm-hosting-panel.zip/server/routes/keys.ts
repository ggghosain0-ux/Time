import express from 'express';
import crypto from 'crypto';
import { getDb, queryAll, queryOne, execute } from '../db.js';
import { authenticateToken, requireAdmin, logActivity, hashApiKey, AuthenticatedRequest } from '../auth.js';
import { ApiKey } from '../types.js';

const router = express.Router();

// GET /api/keys
router.get('/', authenticateToken, requireAdmin, async (req: AuthenticatedRequest, res) => {
  const db = await getDb();
  const keys = queryAll<ApiKey>(
    db,
    'SELECT id, user_id, name, key_prefix, created_at, expires_at, last_used_at FROM api_keys ORDER BY created_at DESC'
  );
  res.json({ keys });
});

// POST /api/keys
router.post('/', authenticateToken, requireAdmin, async (req: AuthenticatedRequest, res) => {
  const { name } = req.body;
  if (!name || typeof name !== 'string' || name.trim().length === 0) {
    res.status(400).json({ error: 'Key name is required' });
    return;
  }

  // Generate cryptographically secure random API key
  const randomBytes = crypto.randomBytes(24).toString('hex');
  const fullKey = `skvm_${randomBytes}`;
  const keyPrefix = fullKey.substring(0, 9); // e.g. "skvm_a1b2"
  const keyHash = hashApiKey(fullKey);

  const id = crypto.randomUUID();
  const now = new Date().toISOString();
  const db = await getDb();

  execute(
    db,
    `INSERT INTO api_keys (id, user_id, name, key_hash, key_prefix, created_at, expires_at, last_used_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [id, req.user!.userId, name.trim(), keyHash, keyPrefix, now, null, null]
  );

  await logActivity(
    req.user!.userId,
    req.user!.username,
    'API_KEY_CREATED',
    `Created API key "${name.trim()}" (prefix: ${keyPrefix}...)`,
    'SUCCESS',
    req.ip || '127.0.0.1'
  );

  // Return fullKey ONCE
  res.status(201).json({
    key: {
      id,
      name: name.trim(),
      key_prefix: keyPrefix,
      created_at: now,
      secret_token: fullKey,
    },
    warning: 'Save this API key now. It will not be shown again.',
  });
});

// DELETE /api/keys/:id
router.delete('/:id', authenticateToken, requireAdmin, async (req: AuthenticatedRequest, res) => {
  const db = await getDb();
  const key = queryOne<ApiKey>(db, 'SELECT * FROM api_keys WHERE id = ?', [req.params.id]);
  if (!key) {
    res.status(404).json({ error: 'API key not found' });
    return;
  }

  execute(db, 'DELETE FROM api_keys WHERE id = ?', [req.params.id]);

  await logActivity(
    req.user!.userId,
    req.user!.username,
    'API_KEY_REVOKED',
    `Revoked API key "${key.name}" (prefix: ${key.key_prefix}...)`,
    'SUCCESS',
    req.ip || '127.0.0.1'
  );

  res.json({ message: 'API key revoked successfully' });
});

export default router;
