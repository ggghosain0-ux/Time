import express from 'express';
import { getDb, queryAll, execute } from '../db.js';
import { authenticateToken, requireAdmin, logActivity, AuthenticatedRequest } from '../auth.js';
import { SystemSettings, ContainerEngine } from '../types.js';

const router = express.Router();

// GET /api/settings
router.get('/', authenticateToken, async (req, res) => {
  const db = await getDb();
  const rows = queryAll<{ key: string; value: string }>(db, 'SELECT key, value FROM settings');
  const settings: Record<string, string> = {};
  for (const r of rows) {
    settings[r.key] = r.value;
  }

  res.json({
    settings: {
      panel_name: settings.panel_name || 'SKVM Hosting Panel',
      container_engine: (settings.container_engine as ContainerEngine) || 'docker',
      theme: (settings.theme as 'dark' | 'light' | 'system') || 'dark',
      discord_url: settings.discord_url || '',
      logo_url: settings.logo_url || '',
    },
  });
});

// PUT /api/settings (Admin only)
router.put('/', authenticateToken, requireAdmin, async (req: AuthenticatedRequest, res) => {
  const { panel_name, container_engine, theme, discord_url, logo_url } = req.body;

  if (container_engine && !['docker', 'lxc', 'qemu'].includes(container_engine)) {
    res.status(400).json({ error: 'Invalid engine. Allowed: docker, lxc, qemu' });
    return;
  }

  if (theme && !['dark', 'light', 'system'].includes(theme)) {
    res.status(400).json({ error: 'Invalid theme. Allowed: dark, light, system' });
    return;
  }

  const db = await getDb();

  const updates: Record<string, string> = {};
  if (panel_name !== undefined) updates['panel_name'] = String(panel_name).trim();
  if (container_engine !== undefined) updates['container_engine'] = container_engine;
  if (theme !== undefined) updates['theme'] = theme;
  if (discord_url !== undefined) updates['discord_url'] = String(discord_url).trim();
  if (logo_url !== undefined) updates['logo_url'] = String(logo_url).trim();

  for (const [key, value] of Object.entries(updates)) {
    execute(
      db,
      `INSERT INTO settings (key, value) VALUES (?, ?)
       ON CONFLICT(key) DO UPDATE SET value = excluded.value`,
      [key, value]
    );
  }

  await logActivity(
    req.user!.userId,
    req.user!.username,
    'SETTINGS_UPDATED',
    `System settings updated. Engine: ${updates['container_engine'] || 'unchanged'}`,
    'SUCCESS',
    req.ip || '127.0.0.1'
  );

  res.json({ message: 'Settings saved successfully', settings: updates });
});

export default router;
