import { WebSocket } from 'ws';
import { SupportedOS, VMStatus, ContainerEngine } from '../types.js';

export interface CreateVMConfig {
  id?: string;
  name: string;
  os: SupportedOS;
  ramMb: number;
  cpuCores: number;
  diskGb: number;
  username: string;
  password?: string;
  hostname: string;
}

export interface ContainerStatusResult {
  state: 'running' | 'stopped' | 'failed' | 'not_found';
  ip?: string;
  sshPort?: number;
  uptime?: number;
  memoryUsageMb?: number;
  cpuPercent?: number;
  errorMessage?: string;
}

export interface TerminalSession {
  sendInput: (data: string) => void;
  resize: (cols: number, rows: number) => void;
  close: () => void;
}

export interface ContainerProvider {
  name: ContainerEngine;
  checkAvailability(): Promise<{ available: boolean; version?: string; error?: string }>;
  create(
    config: CreateVMConfig,
    onProgress?: (step: VMStatus, msg: string) => Promise<void>
  ): Promise<{ containerId: string; ipAddress?: string; sshPort?: number }>;
  start(containerId: string): Promise<void>;
  stop(containerId: string): Promise<void>;
  restart(containerId: string): Promise<void>;
  delete(containerId: string): Promise<void>;
  status(containerId: string): Promise<ContainerStatusResult>;
  getIp(containerId: string): Promise<string | null>;
  execute(containerId: string, command: string[]): Promise<{ exitCode: number; output: string }>;
  getLogs(containerId: string): Promise<string>;
  createTerminalSession(
    containerId: string,
    ws: WebSocket,
    initialCols?: number,
    initialRows?: number
  ): Promise<TerminalSession>;
}
