import { ContainerEngine } from '../types.js';
import { ContainerProvider } from './types.js';
import { DockerProvider } from './docker.js';
import { LXCProvider } from './lxc.js';
import { QEMUProvider } from './qemu.js';

const dockerProvider = new DockerProvider();
const lxcProvider = new LXCProvider();
const qemuProvider = new QEMUProvider();

export function getProvider(engine: ContainerEngine): ContainerProvider {
  if (engine === 'docker') {
    return dockerProvider;
  }
  if (engine === 'lxc') {
    return lxcProvider;
  }
  if (engine === 'qemu') {
    return qemuProvider;
  }
  throw new Error(`Unsupported engine: ${engine}`);
}

export async function checkAllEngines(): Promise<Record<ContainerEngine, { available: boolean; version?: string; error?: string }>> {
  const [dockerStatus, lxcStatus, qemuStatus] = await Promise.all([
    dockerProvider.checkAvailability(),
    lxcProvider.checkAvailability(),
    qemuProvider.checkAvailability(),
  ]);

  return {
    docker: dockerStatus,
    lxc: lxcStatus,
    qemu: qemuStatus,
  };
}
