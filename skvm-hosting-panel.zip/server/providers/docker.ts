import fs from 'fs';
import Docker from 'dockerode';
import { WebSocket } from 'ws';
import { ContainerProvider, CreateVMConfig, ContainerStatusResult, TerminalSession } from './types.js';
import { VMStatus } from '../types.js';

export class DockerProvider implements ContainerProvider {
  name: 'docker' = 'docker';
  private docker: Docker;
  private socketPath: string;

  constructor() {
    this.socketPath = process.env.DOCKER_SOCKET || '/var/run/docker.sock';
    this.docker = new Docker({ socketPath: this.socketPath });
  }

  async checkAvailability(): Promise<{ available: boolean; version?: string; error?: string }> {
    if (!fs.existsSync(this.socketPath)) {
      return {
        available: false,
        error: `Infrastructure unavailable: Docker daemon is not accessible at ${this.socketPath} (socket file not found).`,
      };
    }
    try {
      const ping = await this.docker.ping();
      if (!ping) {
        return {
          available: false,
          error: 'Infrastructure unavailable: Docker daemon is not responding.',
        };
      }
      const versionInfo = await this.docker.version();
      return {
        available: true,
        version: versionInfo.Version,
      };
    } catch (err: any) {
      return {
        available: false,
        error: `Infrastructure unavailable: Docker daemon is not accessible at ${this.socketPath} (${err.message || 'connection failed'}).`,
      };
    }
  }

  async create(
    config: CreateVMConfig,
    onProgress?: (step: VMStatus, msg: string) => Promise<void>
  ): Promise<{ containerId: string; ipAddress?: string }> {
    // 1. Verify availability
    const avail = await this.checkAvailability();
    if (!avail.available) {
      throw new Error(avail.error);
    }

    if (onProgress) await onProgress('VALIDATING', 'Validating container specifications and Docker engine');

    const osImageMap: Record<string, string> = {
      'Ubuntu 20.04': 'ubuntu:20.04',
      'Ubuntu 22.04': 'ubuntu:22.04',
      'Debian 11': 'debian:11',
      'Debian 12': 'debian:12',
      'ubuntu:20.04': 'ubuntu:20.04',
      'ubuntu:22.04': 'ubuntu:22.04',
      'debian:11': 'debian:11',
      'debian:12': 'debian:12',
    };
    const targetImage = osImageMap[config.os] || config.os;

    // 2. Ensure image exists locally or pull it
    if (onProgress) await onProgress('INSTALLING_OS', `Fetching OS image ${targetImage}`);
    const images = await this.docker.listImages();
    const hasImage = images.some((img) =>
      img.RepoTags ? img.RepoTags.includes(targetImage) : false
    );

    if (!hasImage) {
      await new Promise<void>((resolve, reject) => {
        this.docker.pull(targetImage, (err: any, stream: any) => {
          if (err) return reject(new Error(`Failed to pull image ${targetImage}: ${err.message}`));
          this.docker.modem.followProgress(stream, (followErr: any) => {
            if (followErr) return reject(new Error(`Error downloading image: ${followErr.message}`));
            resolve();
          });
        });
      });
    }

    // 3. Create container
    if (onProgress) await onProgress('CREATING', `Creating container for ${config.name}`);
    const safeContainerName = `skvm-${config.name.toLowerCase().replace(/[^a-z0-9_-]/g, '-')}-${Date.now().toString(36)}`;
    
    // Resource limits enforcement
    const nanoCpus = Math.round(config.cpuCores * 1e9);
    const memoryBytes = Math.round(config.ramMb * 1024 * 1024);

    const container = (await this.docker.createContainer({
      Image: targetImage,
      name: safeContainerName,
      Hostname: config.hostname || config.name,
      Tty: true,
      OpenStdin: true,
      Cmd: ['/bin/sh', '-c', 'while true; do sleep 3600; done'],
      HostConfig: {
        NanoCpus: nanoCpus,
        Memory: memoryBytes,
        MemorySwap: memoryBytes * 2,
        RestartPolicy: { Name: 'unless-stopped' },
      },
    })) as Docker.Container;

    const containerId = container.id;

    // 4. Start container
    if (onProgress) await onProgress('STARTING', 'Starting container instance');
    await container.start();

    // 5. Configure user inside container if username provided
    if (config.username && config.username !== 'root') {
      if (onProgress) await onProgress('CONFIGURING', `Configuring initial user ${config.username}`);
      try {
        await this.execute(containerId, [
          '/bin/sh',
          '-c',
          `id -u ${config.username} >/dev/null 2>&1 || (useradd -m -s /bin/bash ${config.username} 2>/dev/null || useradd -m -s /bin/sh ${config.username})`,
        ]);
      } catch (userErr) {
        console.warn('User setup notice:', userErr);
      }
    }

    // 6. Get real IP address
    const ipAddress = (await this.getIp(containerId)) || undefined;

    return {
      containerId,
      ipAddress,
    };
  }

  async start(containerId: string): Promise<void> {
    const avail = await this.checkAvailability();
    if (!avail.available) throw new Error(avail.error);
    const container = this.docker.getContainer(containerId);
    await container.start();
  }

  async stop(containerId: string): Promise<void> {
    const avail = await this.checkAvailability();
    if (!avail.available) throw new Error(avail.error);
    const container = this.docker.getContainer(containerId);
    await container.stop({ t: 10 });
  }

  async restart(containerId: string): Promise<void> {
    const avail = await this.checkAvailability();
    if (!avail.available) throw new Error(avail.error);
    const container = this.docker.getContainer(containerId);
    await container.restart({ t: 10 });
  }

  async delete(containerId: string): Promise<void> {
    const avail = await this.checkAvailability();
    if (!avail.available) throw new Error(avail.error);
    const container = this.docker.getContainer(containerId);
    try {
      await container.stop({ t: 2 });
    } catch {
      // might already be stopped
    }
    await container.remove({ force: true, v: true });
  }

  async status(containerId: string): Promise<ContainerStatusResult> {
    try {
      const container = this.docker.getContainer(containerId);
      const data = await container.inspect();
      const isRunning = data.State.Running;
      const net = data.NetworkSettings as any;
      const ip =
        net?.IPAddress ||
        net?.Networks?.bridge?.IPAddress ||
        (Object.values(net?.Networks || {})[0] as any)?.IPAddress;

      return {
        state: isRunning ? 'running' : 'stopped',
        ip: ip || undefined,
        uptime: isRunning && data.State.StartedAt ? Math.round((Date.now() - new Date(data.State.StartedAt).getTime()) / 1000) : 0,
      };
    } catch (err: any) {
      if (err.statusCode === 404) {
        return { state: 'not_found', errorMessage: 'Container does not exist on Docker engine' };
      }
      return { state: 'failed', errorMessage: err.message };
    }
  }

  async getIp(containerId: string): Promise<string | null> {
    try {
      const st = await this.status(containerId);
      return st.ip || null;
    } catch {
      return null;
    }
  }

  async execute(containerId: string, command: string[]): Promise<{ exitCode: number; output: string }> {
    const container = this.docker.getContainer(containerId);
    const exec = await container.exec({
      Cmd: command,
      AttachStdout: true,
      AttachStderr: true,
    });

    const stream = await exec.start({ hijack: true, stdin: false });
    return new Promise((resolve, reject) => {
      let output = '';
      stream.on('data', (chunk: Buffer) => {
        output += chunk.toString('utf-8');
      });
      stream.on('end', async () => {
        try {
          const inspect = await exec.inspect();
          resolve({ exitCode: inspect.ExitCode ?? 0, output });
        } catch (e) {
          resolve({ exitCode: 0, output });
        }
      });
      stream.on('error', (err) => reject(err));
    });
  }

  async getLogs(containerId: string): Promise<string> {
    const avail = await this.checkAvailability();
    if (!avail.available) throw new Error(avail.error);
    const container = this.docker.getContainer(containerId);
    const logsBuffer = (await container.logs({
      stdout: true,
      stderr: true,
      tail: 200,
      timestamps: true,
    })) as Buffer | string;
    return logsBuffer.toString('utf-8');
  }

  async createTerminalSession(
    containerId: string,
    ws: WebSocket,
    initialCols: number = 80,
    initialRows: number = 24
  ): Promise<TerminalSession> {
    const avail = await this.checkAvailability();
    if (!avail.available) {
      throw new Error(avail.error);
    }

    const container = this.docker.getContainer(containerId);
    const inspect = await container.inspect();
    if (!inspect.State.Running) {
      throw new Error('Cannot open terminal: Container is not running');
    }

    // Detect whether /bin/bash or /bin/sh is available
    let shell = '/bin/bash';
    try {
      const testBash = await this.execute(containerId, ['test', '-x', '/bin/bash']);
      if (testBash.exitCode !== 0) {
        shell = '/bin/sh';
      }
    } catch {
      shell = '/bin/sh';
    }

    const exec = await container.exec({
      AttachStdin: true,
      AttachStdout: true,
      AttachStderr: true,
      Tty: true,
      Cmd: [shell],
      Env: ['TERM=xterm-256color', 'HOME=/root'],
    });

    const stream = await exec.start({
      hijack: true,
      stdin: true,
      Tty: true,
    });

    // Resize initially
    try {
      await exec.resize({ w: initialCols, h: initialRows });
    } catch (e) {
      // ignore initial resize failure
    }

    // Pipe stdout/stderr to WebSocket
    stream.on('data', (chunk: Buffer) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(
          JSON.stringify({
            type: 'stdout',
            data: chunk.toString('utf-8'),
          })
        );
      }
    });

    stream.on('end', () => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'status', message: 'Process exited' }));
        ws.close();
      }
    });

    stream.on('error', (err: any) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'error', message: err.message }));
      }
    });

    return {
      sendInput: (data: string) => {
        if (stream && !stream.destroyed) {
          stream.write(data);
        }
      },
      resize: (cols: number, rows: number) => {
        try {
          exec.resize({ w: cols, h: rows });
        } catch {
          // ignore resize errors
        }
      },
      close: () => {
        try {
          stream.end();
        } catch {
          // ignore
        }
      },
    };
  }
}
