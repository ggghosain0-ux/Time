import { spawn, execFile } from 'child_process';
import { promisify } from 'util';
import { WebSocket } from 'ws';
import { ContainerProvider, CreateVMConfig, ContainerStatusResult, TerminalSession } from './types.js';
import { VMStatus } from '../types.js';

const execFileAsync = promisify(execFile);

export class LXCProvider implements ContainerProvider {
  name: 'lxc' = 'lxc';

  async checkAvailability(): Promise<{ available: boolean; version?: string; error?: string }> {
    try {
      const { stdout } = await execFileAsync('lxc', ['--version']);
      return {
        available: true,
        version: stdout.trim(),
      };
    } catch (err: any) {
      return {
        available: false,
        error: 'Infrastructure unavailable: LXC/LXD CLI is not installed or accessible on this host.',
      };
    }
  }

  private mapImage(os: string): string {
    switch (os) {
      case 'Ubuntu 20.04':
      case 'ubuntu:20.04':
        return 'images:ubuntu/20.04';
      case 'Ubuntu 22.04':
      case 'ubuntu:22.04':
        return 'images:ubuntu/22.04';
      case 'Debian 11':
      case 'debian:11':
        return 'images:debian/11';
      case 'Debian 12':
      case 'debian:12':
        return 'images:debian/12';
      default:
        throw new Error(`Unsupported OS for LXC: ${os}`);
    }
  }

  async create(
    config: CreateVMConfig,
    onProgress?: (step: VMStatus, msg: string) => Promise<void>
  ): Promise<{ containerId: string; ipAddress?: string }> {
    const avail = await this.checkAvailability();
    if (!avail.available) {
      throw new Error(avail.error);
    }

    if (onProgress) await onProgress('VALIDATING', 'Validating LXC engine and environment');

    const lxcImage = this.mapImage(config.os);
    const containerName = `skvm-${config.name.toLowerCase().replace(/[^a-z0-9_-]/g, '-')}-${Date.now().toString(36)}`;

    // 1. Launch/Create container
    if (onProgress) await onProgress('INSTALLING_OS', `Fetching LXC image template ${lxcImage}`);
    try {
      await execFileAsync('lxc', ['init', lxcImage, containerName]);
    } catch (err: any) {
      throw new Error(`Failed to initialize LXC container: ${err.message}`);
    }

    // 2. Resource limits enforcement
    if (onProgress) await onProgress('CONFIGURING', 'Enforcing CPU and Memory resource limits');
    try {
      await execFileAsync('lxc', ['config', 'set', containerName, 'limits.cpu', String(config.cpuCores)]);
      await execFileAsync('lxc', ['config', 'set', containerName, 'limits.memory', `${config.ramMb}MB`]);
    } catch (err: any) {
      console.warn('LXC resource limit config warning:', err.message);
    }

    // 3. Start container
    if (onProgress) await onProgress('STARTING', 'Starting LXC container instance');
    await execFileAsync('lxc', ['start', containerName]);

    // 4. Configure user if provided
    if (config.username && config.username !== 'root') {
      try {
        await execFileAsync('lxc', [
          'exec',
          containerName,
          '--',
          'useradd',
          '-m',
          '-s',
          '/bin/bash',
          config.username,
        ]);
      } catch (e) {
        // ignore non-critical user creation
      }
    }

    const ipAddress = (await this.getIp(containerName)) || undefined;

    return {
      containerId: containerName,
      ipAddress,
    };
  }

  async start(containerId: string): Promise<void> {
    const avail = await this.checkAvailability();
    if (!avail.available) throw new Error(avail.error);
    await execFileAsync('lxc', ['start', containerId]);
  }

  async stop(containerId: string): Promise<void> {
    const avail = await this.checkAvailability();
    if (!avail.available) throw new Error(avail.error);
    await execFileAsync('lxc', ['stop', containerId]);
  }

  async restart(containerId: string): Promise<void> {
    const avail = await this.checkAvailability();
    if (!avail.available) throw new Error(avail.error);
    await execFileAsync('lxc', ['restart', containerId]);
  }

  async delete(containerId: string): Promise<void> {
    const avail = await this.checkAvailability();
    if (!avail.available) throw new Error(avail.error);
    try {
      await execFileAsync('lxc', ['stop', containerId, '--force']);
    } catch {
      // might already be stopped
    }
    await execFileAsync('lxc', ['delete', containerId]);
  }

  async status(containerId: string): Promise<ContainerStatusResult> {
    const avail = await this.checkAvailability();
    if (!avail.available) {
      return { state: 'failed', errorMessage: avail.error };
    }

    try {
      const { stdout } = await execFileAsync('lxc', ['info', containerId]);
      const isRunning = stdout.includes('Status: RUNNING') || stdout.includes('Status: Running');
      const isStopped = stdout.includes('Status: STOPPED') || stdout.includes('Status: Stopped');

      // Parse IP
      const ipMatch = stdout.match(/inet\s+(\d+\.\d+\.\d+\.\d+)/);
      const ip = ipMatch ? ipMatch[1] : undefined;

      return {
        state: isRunning ? 'running' : isStopped ? 'stopped' : 'failed',
        ip,
      };
    } catch (err: any) {
      return { state: 'not_found', errorMessage: err.message };
    }
  }

  async getIp(containerId: string): Promise<string | null> {
    try {
      const st = await this.status(containerId);
      return st.ip || null;
    } catch {
      return null;
    }
  }

  async execute(containerId: string, command: string[]): Promise<{ exitCode: number; output: string }> {
    try {
      const { stdout, stderr } = await execFileAsync('lxc', ['exec', containerId, '--', ...command]);
      return { exitCode: 0, output: stdout || stderr };
    } catch (err: any) {
      return { exitCode: err.code || 1, output: err.message };
    }
  }

  async getLogs(containerId: string): Promise<string> {
    const avail = await this.checkAvailability();
    if (!avail.available) throw new Error(avail.error);
    try {
      const { stdout, stderr } = await execFileAsync('lxc', ['info', '--show-log', containerId]);
      return stdout || stderr || 'No log messages recorded for this container.';
    } catch (err: any) {
      return `LXC log retrieval: ${err.message || 'Log not available'}`;
    }
  }

  async createTerminalSession(
    containerId: string,
    ws: WebSocket,
    initialCols: number = 80,
    initialRows: number = 24
  ): Promise<TerminalSession> {
    const avail = await this.checkAvailability();
    if (!avail.available) throw new Error(avail.error);

    const st = await this.status(containerId);
    if (st.state !== 'running') {
      throw new Error('Cannot open terminal: LXC container is not running');
    }

    // Determine shell
    let shell = '/bin/bash';
    try {
      const test = await this.execute(containerId, ['test', '-x', '/bin/bash']);
      if (test.exitCode !== 0) shell = '/bin/sh';
    } catch {
      shell = '/bin/sh';
    }

    const proc = spawn('lxc', ['exec', containerId, '--', shell], {
      env: { ...process.env, TERM: 'xterm-256color', COLUMNS: String(initialCols), LINES: String(initialRows) },
    });

    proc.stdout.on('data', (data) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'stdout', data: data.toString('utf-8') }));
      }
    });

    proc.stderr.on('data', (data) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'stdout', data: data.toString('utf-8') }));
      }
    });

    proc.on('close', () => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'status', message: 'Process exited' }));
        ws.close();
      }
    });

    proc.on('error', (err) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'error', message: err.message }));
      }
    });

    return {
      sendInput: (data: string) => {
        if (proc.stdin && !proc.stdin.destroyed) {
          proc.stdin.write(data);
        }
      },
      resize: (cols: number, rows: number) => {
        // Best effort for LXC terminal resize
        try {
          proc.kill('SIGWINCH');
        } catch {
          // ignore
        }
      },
      close: () => {
        try {
          proc.kill();
        } catch {
          // ignore
        }
      },
    };
  }
}
