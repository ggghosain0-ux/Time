import { hashPassword, verifyPassword, createToken, verifyToken, hashApiKey } from '../server/auth.js';
import { getDb, queryOne, queryAll } from '../server/db.js';
import { getProvider, checkAllEngines } from '../server/providers/index.js';
import { getLocalNodeStats } from '../server/node.js';
import { allocatePort, releasePort, isPortAvailable } from '../server/portAllocator.js';

async function runTests() {
  console.log('--- STARTING SKVM AUTOMATED TEST SUITE ---');
  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, msg: string) {
    if (condition) {
      console.log(`[PASS] ${msg}`);
      passed++;
    } else {
      console.error(`[FAIL] ${msg}`);
      failed++;
    }
  }

  // 1. Password Hashing & Verification
  try {
    const pwd = 'TestSecretPassword_2026!';
    const hash = hashPassword(pwd);
    assert(hash.includes(':'), 'Password hash contains salt and digest');
    assert(verifyPassword(pwd, hash), 'Password verification succeeds with correct password');
    assert(!verifyPassword('WrongPassword', hash), 'Password verification rejects wrong password');
  } catch (err: any) {
    assert(false, `Password test error: ${err.message}`);
  }

  // 2. Token Creation & Verification & RBAC Roles
  try {
    const userPayload = { id: 'usr-1', username: 'alice', role: 'user' as const };
    const userToken = createToken(userPayload, 1);
    const userVerified = verifyToken(userToken);
    assert(userVerified !== null && userVerified.userId === 'usr-1', 'JWT user token verifies correctly');
    assert(userVerified?.role === 'user', 'Normal user role is preserved in token');

    const adminPayload = { id: 'admin-root', username: 'admin', role: 'admin' as const };
    const adminToken = createToken(adminPayload, 1);
    const adminVerified = verifyToken(adminToken);
    assert(adminVerified?.role === 'admin', 'Admin role is preserved in token');

    assert(verifyToken(userToken + 'tampered') === null, 'Tampered token is rejected');
  } catch (err: any) {
    assert(false, `Token test error: ${err.message}`);
  }

  // 3. API Key Generation & Hashing
  try {
    const rawKey = 'skvm_1234567890abcdef12345678';
    const hashed = hashApiKey(rawKey);
    assert(hashed.length === 64, 'API Key hash is valid SHA-256');
    assert(hashApiKey(rawKey) === hashed, 'API Key hashing is deterministic');
  } catch (err: any) {
    assert(false, `API Key test error: ${err.message}`);
  }

  // 4. Database Initialization & Admin Setup
  try {
    const db = await getDb();
    const admin = queryOne(db, 'SELECT * FROM users WHERE role = ?', ['admin']);
    assert(admin !== null && admin.email === 'admin@gmail.com', 'Default admin created with email admin@gmail.com');
    assert(verifyPassword('admin123', admin.password_hash), 'Default admin password verifies with admin123');
  } catch (err: any) {
    assert(false, `Database test error: ${err.message}`);
  }

  // 5. Node Resource Metrics
  try {
    const stats = await getLocalNodeStats();
    assert(stats.total_cpu_cores > 0, `Node detects real CPU cores: ${stats.total_cpu_cores}`);
    assert(stats.total_ram_mb > 0, `Node detects real RAM: ${stats.total_ram_mb} MB`);
    assert(stats.hostname.length > 0, `Node detects real hostname: ${stats.hostname}`);
  } catch (err: any) {
    assert(false, `Node stats test error: ${err.message}`);
  }

  // 6. Real Port Allocator Tests
  try {
    const testVmId = 'test-vm-port-alloc';
    const port = await allocatePort(testVmId);
    assert(port >= 2222 && port <= 2999, `Allocated valid port: ${port}`);

    // Verify port availability
    const isFree = await isPortAvailable(port);
    assert(isFree, `Port ${port} was verified available on host`);

    // Release port
    await releasePort(testVmId);
    const db = await getDb();
    const alloc = queryOne(db, 'SELECT * FROM port_allocations WHERE vm_id = ?', [testVmId]);
    assert(alloc === null, 'Port allocation is cleaned up on release');
  } catch (err: any) {
    assert(false, `Port allocator test error: ${err.message}`);
  }

  // 7. Provider Detection & Honesty (Docker, LXC, QEMU)
  try {
    const engines = await checkAllEngines();
    console.log('Real Engines Detected:', JSON.stringify(engines, null, 2));

    const docker = getProvider('docker');
    const dockerCheck = await docker.checkAvailability();
    if (!dockerCheck.available) {
      assert(
        dockerCheck.error !== undefined && dockerCheck.error.includes('Docker daemon is not accessible'),
        'Docker provider honestly reports unavailable when daemon socket is absent'
      );
    } else {
      assert(dockerCheck.available, 'Docker engine is running and detected');
    }

    const lxc = getProvider('lxc');
    const lxcCheck = await lxc.checkAvailability();
    if (!lxcCheck.available) {
      assert(
        lxcCheck.error !== undefined && lxcCheck.error.includes('LXC/LXD CLI is not installed'),
        'LXC provider honestly reports unavailable when CLI is absent'
      );
    } else {
      assert(lxcCheck.available, 'LXC engine is detected');
    }

    const qemu = getProvider('qemu');
    const qemuCheck = await qemu.checkAvailability();
    if (!qemuCheck.available) {
      assert(
        qemuCheck.error !== undefined && qemuCheck.error.includes('QEMU binary'),
        'QEMU provider honestly reports unavailable when binary is absent'
      );
    } else {
      assert(qemuCheck.available, 'QEMU engine is detected');
    }
  } catch (err: any) {
    assert(false, `Provider test error: ${err.message}`);
  }

  console.log(`\nTEST RESULTS: ${passed} PASSED, ${failed} FAILED`);
  if (failed > 0) {
    process.exit(1);
  }
}

runTests().catch((e) => {
  console.error('Fatal test error:', e);
  process.exit(1);
});
