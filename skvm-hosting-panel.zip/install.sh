#!/usr/bin/env bash
# ==============================================================================
# SKVM - Linux VM & Container Hosting Control Panel Installer
# Safe, idempotent installer (Strictly NO systemd / NO systemctl)
# ==============================================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKVM_DIR="${SKVM_DIR:-$SCRIPT_DIR}"
DATA_DIR="${DATA_DIR:-$SCRIPT_DIR/data}"
LOG_DIR="${LOG_DIR:-$SCRIPT_DIR/logs}"
PORT="${PORT:-3000}"

echo "=================================================================="
echo "          SKVM - Production Hosting Panel Installer               "
echo "=================================================================="

# 1. Check User Privileges
if [ "$EUID" -ne 0 ]; then
  echo "[!] Notice: Running installer as user $(whoami)."
  echo "    Root privileges may be needed for Docker/LXC/QEMU package installation."
else
  echo "[+] Running as root."
fi

# 2. Detect Architecture and OS
ARCH="$(uname -m)"
echo "[*] Detected Host Architecture: $ARCH"

if [ -f /etc/os-release ]; then
  . /etc/os-release
  DISTRO=$ID
  VERSION=$VERSION_ID
  echo "[*] Detected Linux OS: $NAME ($VERSION)"
else
  echo "[*] Generic Linux environment detected."
  DISTRO="unknown"
fi

# 3. Create Required Storage Directories (Non-destructive)
echo "[*] Verifying infrastructure storage directories..."
mkdir -p "$SKVM_DIR"
mkdir -p "$DATA_DIR"
mkdir -p "$DATA_DIR/vms"
mkdir -p "$LOG_DIR"

# 4. Check / Install Node.js runtime
echo "[*] Checking Node.js runtime..."
if ! command -v node >/dev/null 2>&1; then
  echo "[*] Node.js not found. Installing Node.js 20.x..."
  if [ "$DISTRO" = "ubuntu" ] || [ "$DISTRO" = "debian" ]; then
    apt-get update -y && apt-get install -y curl ca-certificates gnupg
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
  elif [ "$DISTRO" = "centos" ] || [ "$DISTRO" = "rhel" ] || [ "$DISTRO" = "rocky" ]; then
    curl -fsSL https://rpm.nodesource.com/setup_20.x | bash -
    yum install -y nodejs
  else
    echo "[!] Please install Node.js (v18+) for your distribution manually."
  fi
else
  NODE_VER=$(node -v)
  echo "[+] Found Node.js $NODE_VER"
fi

# 5. Check & Report Infrastructure Engines (Docker, LXC, QEMU)
echo "[*] Probing Infrastructure Virtualization Engines..."

# Docker
if command -v docker >/dev/null 2>&1; then
  echo "[+] Docker Engine: Available ($(docker --version))"
else
  echo "[-] Docker Engine: Not installed or not in PATH."
  echo "    To install on Debian/Ubuntu: apt-get update && apt-get install -y docker.io"
fi

# LXC
if command -v lxc >/dev/null 2>&1; then
  echo "[+] LXC Engine: Available ($(lxc --version))"
else
  echo "[-] LXC Engine: Not installed."
  echo "    To install on Debian/Ubuntu: apt-get update && apt-get install -y lxc lxc-templates"
fi

# QEMU
if command -v qemu-system-x86_64 >/dev/null 2>&1 || command -v qemu-system-aarch64 >/dev/null 2>&1; then
  echo "[+] QEMU Engine: Available ($(qemu-img --version 2>/dev/null | head -n 1 || echo 'Installed'))"
else
  echo "[-] QEMU Engine: Not installed."
  echo "    To install on Debian/Ubuntu: apt-get update && apt-get install -y qemu-system-x86 qemu-utils cloud-image-utils"
fi

# 6. Setup Configuration (.env) - Preserves existing secrets
ENV_FILE="$SKVM_DIR/.env"
if [ ! -f "$ENV_FILE" ]; then
  echo "[*] Generating initial configuration in $ENV_FILE..."
  JWT_SECRET=$(head -c 32 /dev/urandom | base64 | tr -dc 'a-zA-Z0-9' | head -c 32)
  cat <<EOF > "$ENV_FILE"
PORT=$PORT
NODE_ENV=production
DB_PATH=$DATA_DIR/skvm.sqlite
VM_STORAGE_DIR=$DATA_DIR/vms
JWT_SECRET=$JWT_SECRET
DOCKER_SOCKET=/var/run/docker.sock
EOF
  chmod 600 "$ENV_FILE"
  echo "[+] Secure configuration created."
else
  echo "[+] Existing configuration found at $ENV_FILE, preserving."
fi

# 7. Install Application Dependencies
echo "[*] Installing app dependencies..."
if [ -f "$SKVM_DIR/package.json" ]; then
  if [ -d "$SKVM_DIR/node_modules" ]; then
    echo "[+] Dependencies already installed in $SKVM_DIR/node_modules."
  else
    (cd "$SKVM_DIR" && npm install --omit=dev --legacy-peer-deps)
  fi
fi

# 8. Database Non-destructive Verification
echo "[*] Checking database status..."
if [ -f "$DATA_DIR/skvm.sqlite" ]; then
  echo "[+] Existing database found at $DATA_DIR/skvm.sqlite; preserving all users, VMs, and records."
else
  echo "[+] Fresh database will be safely seeded on first startup."
fi

# 9. Setup Process Management CLI
if [ -f "$SKVM_DIR/skvm" ]; then
  chmod +x "$SKVM_DIR/skvm"
  echo "[+] Standalone process manager configured: $SKVM_DIR/skvm"
fi

# 10. Summary and Completion
IP_ADDR=$(hostname -I 2>/dev/null | awk '{print $1}' || echo "localhost")

echo "=================================================================="
echo "          SKVM Installation & Verification Complete!              "
echo "=================================================================="
echo ""
echo "Panel Root:       $SKVM_DIR"
echo "Database:         $DATA_DIR/skvm.sqlite"
echo "VM Storage:       $DATA_DIR/vms"
echo "Web Port:         $PORT"
echo ""
echo "Default Administrator Credentials:"
echo "  Email:    admin@gmail.com"
echo "  Username: admin"
echo "  Password: admin123"
echo ""
echo "Process Management (No systemctl / No systemd):"
echo "  Start:    $SKVM_DIR/skvm start"
echo "  Stop:     $SKVM_DIR/skvm stop"
echo "  Restart:  $SKVM_DIR/skvm restart"
echo "  Status:   $SKVM_DIR/skvm status"
echo "  Logs:     $SKVM_DIR/skvm logs"
echo ""
echo "Access the hosting panel in your browser:"
echo "  http://$IP_ADDR:$PORT"
echo "=================================================================="
