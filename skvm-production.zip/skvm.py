import os
import re
import secrets
import threading
from datetime import datetime
from functools import wraps

from flask import Flask, render_template, request, redirect, url_for, flash, abort
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash

try:
    import docker
    from docker.errors import DockerException
except Exception:
    docker = None
    DockerException = Exception

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get(
    "SKVM_SECRET_KEY", "skvm-development-secret-change-me"
)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///" + os.path.join(BASE_DIR, "skvm.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"

_docker_client = None
_docker_error = None


def docker_client():
    """Return a connected Docker client, or None when Docker is unavailable."""
    global _docker_client, _docker_error

    if _docker_client is not None:
        try:
            _docker_client.ping()
            return _docker_client
        except Exception:
            _docker_client = None

    if docker is None:
        _docker_error = "Python Docker SDK is not installed."
        return None

    try:
        _docker_client = docker.from_env()
        _docker_client.ping()
        _docker_error = None
        return _docker_client
    except Exception as exc:
        _docker_error = str(exc)
        return None


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default="user")
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    vps = db.relationship("VPS", backref="owner", cascade="all, delete-orphan", lazy=True)


class VPS(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    node = db.Column(db.String(100), nullable=False, default="Local-Node-1")
    ram = db.Column(db.String(30), nullable=False)
    disk = db.Column(db.String(30), nullable=False)
    cpu = db.Column(db.String(30), nullable=False)
    os = db.Column(db.String(50), nullable=False)
    container_id = db.Column(db.String(128))
    tmate_token = db.Column(db.Text)
    status = db.Column(db.String(40), nullable=False, default="Provisioning")
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)


class Settings(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    panel_name = db.Column(db.String(120), nullable=False, default="SKVM Panel")
    logo_url = db.Column(db.String(500), default="")
    banner_url = db.Column(db.String(500), default="")
    background_url = db.Column(db.String(500), default="")


@login_manager.user_loader
def load_user(user_id):
    try:
        return db.session.get(User, int(user_id))
    except Exception:
        return None


@app.context_processor
def global_context():
    settings = Settings.query.first()
    return {
        "site": settings or Settings(panel_name="SKVM Panel"),
        "docker_online": docker_client() is not None,
        "docker_error": _docker_error,
    }


def admin_required(fn):
    @wraps(fn)
    @login_required
    def wrapper(*args, **kwargs):
        if current_user.role != "admin":
            abort(403)
        return fn(*args, **kwargs)
    return wrapper


def amount(value, fallback=1):
    match = re.search(r"\d+", str(value or ""))
    return int(match.group()) if match else fallback


def docker_resources(vps):
    ram_gb = max(1, amount(vps.ram))
    cpu_cores = max(1, amount(vps.cpu))
    return {
        "mem_limit": f"{ram_gb}g",
        "nano_cpus": cpu_cores * 1_000_000_000,
    }


def extract_tmate_ssh(text):
    """Extract tmate's SSH connection string from command output."""
    if not text:
        return None

    text = text.replace("\r", " ").replace("\n", " ")
    patterns = [
        r"(ssh\s+tmate-[A-Za-z0-9._:+/@-]+)",
        r"(ssh\s+[^ ]+@[^ ]+)",
    ]
    for pattern in patterns:
        match = re.search(pattern, text)
        if match:
            return match.group(1).strip().rstrip("'\"")
    return None


def provision_vps(vps_id):
    """
    Background provisioning:
    1. Pull selected Ubuntu image.
    2. Start a long-running container with RAM/CPU limits.
    3. Install tmate inside it.
    4. Create a tmate session and obtain its SSH connection string.
    5. Save the connection string and mark VPS Active.
    """
    with app.app_context():
        vps = db.session.get(VPS, vps_id)
        if not vps:
            return

        client = docker_client()
        if not client:
            vps.status = "Docker Unavailable"
            vps.tmate_token = (
                "Docker is not reachable from the panel. "
                "Start Docker and redeploy this VPS."
            )
            db.session.commit()
            return

        image = "ubuntu:22.04" if "22.04" in vps.os else "ubuntu:20.04"
        container = None

        try:
            vps.status = "Pulling Image"
            db.session.commit()

            try:
                client.images.get(image)
            except Exception:
                client.images.pull(image)

            resources = docker_resources(vps)
            container_name = f"skvm-{vps.id}-{secrets.token_hex(4)}"

            container = client.containers.run(
                image=image,
                command=["bash", "-lc", "sleep infinity"],
                name=container_name,
                detach=True,
                tty=True,
                stdin_open=True,
                mem_limit=resources["mem_limit"],
                nano_cpus=resources["nano_cpus"],
                labels={
                    "com.skvm.managed": "true",
                    "com.skvm.vps_id": str(vps.id),
                },
            )

            vps.container_id = container.id
            vps.status = "Installing tmate"
            db.session.commit()

            install_and_start = r"""
set -e
export DEBIAN_FRONTEND=noninteractive
apt-get update -y >/dev/null 2>&1
apt-get install -y tmate openssh-client ca-certificates >/dev/null 2>&1
rm -f /tmp/skvm-tmate.sock
tmate -S /tmp/skvm-tmate.sock new-session -d
tmate -S /tmp/skvm-tmate.sock wait-for-server
for i in $(seq 1 20); do
    URL="$(tmate -S /tmp/skvm-tmate.sock display -p '#{tmate_ssh}' 2>/dev/null || true)"
    if [ -n "$URL" ]; then
        echo "SKVM_TMate: $URL"
        exit 0
    fi
    sleep 1
done
exit 1
"""
            result = container.exec_run(
                ["bash", "-lc", install_and_start],
                stdout=True,
                stderr=True,
            )
            raw = result.output or b""
            output = raw.decode("utf-8", "replace")

            ssh_string = extract_tmate_ssh(output)

            # A second read gives tmate a little more time on slow nodes.
            if not ssh_string:
                result2 = container.exec_run(
                    ["bash", "-lc",
                     "tmate -S /tmp/skvm-tmate.sock display -p '#{tmate_ssh}' 2>/dev/null || true"],
                    stdout=True,
                    stderr=True,
                )
                output += (result2.output or b"").decode("utf-8", "replace")
                ssh_string = extract_tmate_ssh(output)

            if not ssh_string:
                raise RuntimeError(
                    "tmate did not return an SSH session. Output: "
                    + output[-1200:]
                )

            vps.tmate_token = ssh_string
            vps.status = "Active"
            db.session.commit()

        except Exception as exc:
            vps.status = "Error"
            vps.tmate_token = f"Provisioning failed: {exc}"
            db.session.commit()
            if container is not None:
                try:
                    container.remove(force=True)
                except Exception:
                    pass


def seed_database():
    db.create_all()

    admin = User.query.filter_by(username="admin").first()
    if admin is None:
        admin = User(
            username="admin",
            password_hash=generate_password_hash("admin123"),
            role="admin",
        )
        db.session.add(admin)
    else:
        admin.role = "admin"

    if Settings.query.first() is None:
        db.session.add(Settings(panel_name="SKVM Panel"))

    db.session.commit()


@app.route("/")
def starter():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))
    return render_template("starter.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        user = User.query.filter_by(username=username).first()

        if user and check_password_hash(user.password_hash, password):
            login_user(user)
            next_url = request.args.get("next")
            return redirect(next_url if next_url and next_url.startswith("/") else url_for("dashboard"))

        flash("Invalid username or password.", "error")

    return render_template("login.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        if len(username) < 3:
            flash("Username must contain at least 3 characters.", "error")
        elif len(password) < 6:
            flash("Password must contain at least 6 characters.", "error")
        elif User.query.filter_by(username=username).first():
            flash("That username is already registered.", "error")
        else:
            db.session.add(
                User(
                    username=username,
                    password_hash=generate_password_hash(password),
                    role="user",
                )
            )
            db.session.commit()
            flash("Account created successfully.", "success")
            return redirect(url_for("login"))

    return render_template("register.html")


@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("starter"))


@app.route("/dashboard")
@login_required
def dashboard():
    vps_list = VPS.query.filter_by(user_id=current_user.id).order_by(VPS.created_at.desc()).all()
    return render_template("dashboard.html", vps_list=vps_list)


@app.route("/myvps")
@login_required
def myvps():
    vps_list = VPS.query.filter_by(user_id=current_user.id).order_by(VPS.created_at.desc()).all()
    return render_template("myvps.html", vps_list=vps_list)


@app.route("/vps/<int:vps_id>")
@login_required
def vps_details(vps_id):
    vps = db.session.get(VPS, vps_id)
    if not vps or (vps.user_id != current_user.id and current_user.role != "admin"):
        abort(404)
    return render_template("vps_details.html", vps=vps)


@app.route("/vps/<int:vps_id>/action/<action>", methods=["POST"])
@login_required
def vps_action(vps_id, action):
    vps = db.session.get(VPS, vps_id)
    if not vps or (vps.user_id != current_user.id and current_user.role != "admin"):
        abort(404)

    client = docker_client()
    if not client or not vps.container_id:
        flash("Docker is unavailable or this VPS has no container yet.", "error")
        return redirect(url_for("vps_details", vps_id=vps_id))

    try:
        container = client.containers.get(vps.container_id)

        if action == "start":
            container.start()
            vps.status = "Active"
        elif action == "stop":
            container.stop()
            vps.status = "Stopped"
        elif action == "restart":
            container.restart()
            vps.status = "Active"
        else:
            abort(400)

        db.session.commit()
        flash(f"{action.capitalize()} completed.", "success")
    except Exception as exc:
        flash(f"Docker action failed: {exc}", "error")

    return redirect(url_for("vps_details", vps_id=vps_id))


@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    if request.method == "POST":
        password = request.form.get("password", "")
        confirm = request.form.get("confirm_password", "")

        if len(password) < 6:
            flash("Password must contain at least 6 characters.", "error")
        elif password != confirm:
            flash("Passwords do not match.", "error")
        else:
            current_user.password_hash = generate_password_hash(password)
            db.session.commit()
            flash("Password updated.", "success")
            return redirect(url_for("profile"))

    return render_template("profile.html")


@app.route("/create-vps", methods=["GET", "POST"])
@admin_required
def create_vps():
    users = User.query.order_by(User.username.asc()).all()

    if request.method == "POST":
        name = request.form.get("name", "").strip()
        user_id = request.form.get("user_id", type=int)
        node = request.form.get("node", "Local-Node-1")
        ram = request.form.get("ram", "1GB")
        disk = request.form.get("disk", "10GB")
        cpu = request.form.get("cpu", "1 Core")
        os_name = request.form.get("os", "Ubuntu 22.04")

        if not name:
            flash("VPS name is required.", "error")
            return render_template("create_vps.html", users=users)

        owner = db.session.get(User, user_id) if user_id else None
        if owner is None:
            flash("Select a valid target user.", "error")
            return render_template("create_vps.html", users=users)

        if os_name not in ("Ubuntu 22.04", "Ubuntu 20.04"):
            flash("Unsupported operating system.", "error")
            return render_template("create_vps.html", users=users)

        vps = VPS(
            name=name,
            user_id=owner.id,
            node=node,
            ram=ram,
            disk=disk,
            cpu=cpu,
            os=os_name,
            status="Provisioning",
        )
        db.session.add(vps)
        db.session.commit()

        threading.Thread(
            target=provision_vps,
            args=(vps.id,),
            daemon=True,
        ).start()

        flash(f"{name} deployment started.", "success")
        return redirect(url_for("vps_details", vps_id=vps.id))

    return render_template("create_vps.html", users=users)


@app.route("/admin")
@admin_required
def admin_dashboard():
    client = docker_client()
    containers = []
    running = 0

    if client:
        try:
            containers = client.containers.list(
                all=True,
                filters={"label": "com.skvm.managed=true"},
            )
            running = sum(1 for c in containers if c.status == "running")
        except Exception:
            pass

    return render_template(
        "admin_dashboard.html",
        users_count=User.query.count(),
        vps_count=VPS.query.count(),
        containers_count=len(containers),
        running_count=running,
        recent_vps=VPS.query.order_by(VPS.created_at.desc()).limit(8).all(),
    )


@app.route("/user-management")
@admin_required
def user_management():
    users = User.query.order_by(User.created_at.desc()).all()
    return render_template("user_management.html", users=users)


@app.route("/user-management/<int:user_id>/role", methods=["POST"])
@admin_required
def change_role(user_id):
    user = db.session.get(User, user_id)

    if not user or user.id == current_user.id:
        flash("That account cannot be changed here.", "error")
        return redirect(url_for("user_management"))

    user.role = "admin" if user.role == "user" else "user"
    db.session.commit()
    flash(f"{user.username} role changed to {user.role}.", "success")
    return redirect(url_for("user_management"))


@app.route("/user-management/<int:user_id>/delete", methods=["POST"])
@admin_required
def delete_user(user_id):
    user = db.session.get(User, user_id)

    if not user or user.id == current_user.id:
        flash("That account cannot be deleted.", "error")
        return redirect(url_for("user_management"))

    client = docker_client()
    for vps in list(user.vps):
        if client and vps.container_id:
            try:
                client.containers.get(vps.container_id).remove(force=True)
            except Exception:
                pass

    db.session.delete(user)
    db.session.commit()
    flash("User and assigned VPS records were deleted.", "success")
    return redirect(url_for("user_management"))


@app.route("/settings", methods=["GET", "POST"])
@admin_required
def settings():
    site = Settings.query.first()

    if request.method == "POST":
        site.panel_name = request.form.get("panel_name", "").strip() or "SKVM Panel"
        site.logo_url = request.form.get("logo_url", "").strip()
        site.banner_url = request.form.get("banner_url", "").strip()
        site.background_url = request.form.get("background_url", "").strip()
        db.session.commit()
        flash("Settings saved.", "success")
        return redirect(url_for("settings"))

    return render_template("settings.html", settings=site)


@app.errorhandler(403)
def forbidden(_error):
    return render_template("login.html", error_title="Access denied"), 403


@app.errorhandler(404)
def not_found(_error):
    return render_template("login.html", error_title="Page not found"), 404


with app.app_context():
    seed_database()


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5555, debug=False)
