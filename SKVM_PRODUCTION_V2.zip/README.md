# SKVM

Production-focused Docker VPS management panel using Flask, SQLAlchemy, Flask-Login and docker-py.

## Install

From the extracted project directory:

```bash
sudo bash install.sh
```

The installer installs Docker/Python, creates the virtual environment, initializes SQLite, installs a systemd service and starts SKVM on port 5555.

## Default administrator

Username: `admin`
Password: `admin123`

Change the password after first login if the panel will be exposed publicly.

## tmate provisioning

SKVM starts tmate inside each VPS and polls `tmate display -p '#{tmate_ssh}'` until the relay returns a real SSH command. It does **not** use the unsupported `wait-for-server` command and does not treat `https://tmate.io` HTTP status as the relay health check.

The Docker container must have outbound DNS and TCP/HTTPS connectivity to the tmate infrastructure. If Docker DNS is broken, set `SKVM_DOCKER_DNS` in `.env`, then restart the service.

## Disk limits

Docker storage quotas are driver/host dependent. SKVM does not issue unsupported btrfs `storage_opt` quota requests. Requested disk is recorded as metadata in compatibility mode; CPU and RAM use Docker resource limits.
