#!/usr/bin/env bash
set -Eeuo pipefail
trap 'echo "[SKVM] Installation failed on line $LINENO. Check the error above." >&2' ERR

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

if [[ $EUID -ne 0 ]]; then
  echo "Run: sudo bash install.sh"
  exit 1
fi

export DEBIAN_FRONTEND=noninteractive

echo "[1/7] Installing system packages..."
apt-get update -y
apt-get install -y --no-install-recommends \
  ca-certificates curl python3 python3-pip python3-venv python3-dev \
  build-essential docker.io unzip

systemctl enable --now docker

if ! docker info >/dev/null 2>&1; then
  echo "[SKVM] Docker is installed but not accessible to root."
  exit 1
fi

# Determine the real login user. Prefer SUDO_USER; otherwise keep root.
RUN_USER="${SUDO_USER:-root}"
if [[ "$RUN_USER" == "root" ]]; then
  RUN_HOME="/root"
else
  RUN_HOME="$(getent passwd "$RUN_USER" | cut -d: -f6)"
fi

# Make Docker usable by the login user on normal VPS hosts.
if [[ "$RUN_USER" != "root" ]]; then
  usermod -aG docker "$RUN_USER" || true
fi

echo "[2/7] Preparing Python environment..."
rm -rf venv
python3 -m venv venv
venv/bin/python -m pip install --upgrade pip setuptools wheel
venv/bin/pip install --no-cache-dir -r requirements.txt

echo "[3/7] Creating production .env..."
if [[ ! -f .env ]]; then
  cp .env.example .env
fi

SECRET="$(python3 - <<'PY'
import secrets
print(secrets.token_hex(32))
PY
)"
python3 - "$SECRET" <<'PY'
from pathlib import Path
import sys
p=Path('.env')
s=p.read_text()
lines=[]
seen=False
for line in s.splitlines():
    if line.startswith('SKVM_SECRET_KEY='):
        lines.append('SKVM_SECRET_KEY=' + sys.argv[1]); seen=True
    else:
        lines.append(line)
if not seen:
    lines.insert(0, 'SKVM_SECRET_KEY=' + sys.argv[1])
p.write_text('\n'.join(lines)+'\n')
PY

# The requested fixed default administrator. Never print the password to the UI/log.
python3 - <<'PY'
from pathlib import Path
p=Path('.env')
s=p.read_text()
import re
s=re.sub(r'^SKVM_ADMIN_USERNAME=.*$', 'SKVM_ADMIN_USERNAME=admin', s, flags=re.M)
s=re.sub(r'^SKVM_ADMIN_PASSWORD=.*$', 'SKVM_ADMIN_PASSWORD=admin123', s, flags=re.M)
if 'SKVM_ADMIN_USERNAME=' not in s: s += 'SKVM_ADMIN_USERNAME=admin\n'
if 'SKVM_ADMIN_PASSWORD=' not in s: s += 'SKVM_ADMIN_PASSWORD=admin123\n'
p.write_text(s)
PY
chmod 600 .env

# Optional Docker DNS can be set by the operator; do not guess DNS servers here.
# SKVM_DOCKER_DNS=1.1.1.1,8.8.8.8

echo "[4/7] Initializing database and enforcing default admin..."
venv/bin/python - <<'PY'
from skvm import app, db, User
from werkzeug.security import generate_password_hash
with app.app_context():
    db.create_all()
    u = User.query.filter_by(username='admin').first()
    if not u:
        u = User(username='admin', role='admin', password_hash=generate_password_hash('admin123'))
        db.session.add(u)
    else:
        u.role='admin'
        u.password_hash=generate_password_hash('admin123')
    db.session.commit()
PY

echo "[5/7] Installing systemd service..."
cat > /etc/systemd/system/skvm.service <<EOF
[Unit]
Description=SKVM VPS Management Panel
Documentation=https://localhost:5555
After=docker.service network-online.target
Wants=network-online.target
Requires=docker.service

[Service]
Type=simple
User=$RUN_USER
WorkingDirectory=$SCRIPT_DIR
EnvironmentFile=$SCRIPT_DIR/.env
ExecStart=$SCRIPT_DIR/venv/bin/gunicorn --bind 0.0.0.0:5555 --workers 1 --threads 8 --timeout 900 skvm:app
Restart=always
RestartSec=5
KillSignal=SIGTERM
TimeoutStopSec=30
NoNewPrivileges=false
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF

chown -R "$RUN_USER":"$RUN_USER" "$SCRIPT_DIR"
chmod 600 "$SCRIPT_DIR/.env"

systemctl daemon-reload
systemctl enable skvm
systemctl restart skvm

# Give a non-root login user Docker access. The current shell may need re-login/newgrp.
if [[ "$RUN_USER" != "root" ]]; then
  usermod -aG docker "$RUN_USER" || true
fi

echo "[6/7] Opening firewall port when UFW is present..."
if command -v ufw >/dev/null 2>&1; then
  ufw allow 5555/tcp || true
fi

echo "[7/7] Verifying service..."
sleep 2
if ! systemctl is-active --quiet skvm; then
  systemctl --no-pager --full status skvm || true
  journalctl -u skvm -n 80 --no-pager || true
  exit 1
fi

IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
echo
echo "=============================================="
echo " SKVM installation completed successfully"
echo "=============================================="
echo " Panel: http://${IP:-YOUR_SERVER_IP}:5555"
echo " Service: systemctl status skvm"
echo " Logs:    journalctl -u skvm -f"
echo " Docker:  $(docker version --format '{{.Server.Version}}')"
echo "=============================================="
