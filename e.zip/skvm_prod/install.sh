#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ $EUID -ne 0 ]]; then echo "Run: sudo bash install.sh"; exit 1; fi
apt-get update
apt-get install -y python3 python3-pip python3-venv python3-dev build-essential ca-certificates curl unzip docker.io
systemctl enable --now docker
U="${SUDO_USER:-root}"
python3 -m venv venv
venv/bin/pip install --upgrade pip wheel
venv/bin/pip install -r requirements.txt
if [[ ! -f .env ]]; then cp .env.example .env; python3 - <<'PY'
from pathlib import Path
import secrets
p=Path('.env'); s=p.read_text(); s=s.replace('change-this-to-a-long-random-secret', secrets.token_hex(32)); s=s.replace('change-this-admin-password', secrets.token_urlsafe(18)); p.write_text(s)
PY
fi
chown -R "$U":"$U" .
sed "s|SKVM_USER|$U|g; s|SKVM_DIR|$PWD|g" skvm.service.example > /etc/systemd/system/skvm.service
systemctl daemon-reload
systemctl enable --now skvm
if command -v ufw >/dev/null 2>&1; then ufw allow 5555/tcp || true; fi
echo "SKVM is installed and running on port 5555."
systemctl --no-pager --full status skvm || true
