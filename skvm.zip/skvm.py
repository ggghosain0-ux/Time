import os
import re
import time
import threading
import secrets
from datetime import datetime
from functools import wraps

from flask import Flask, render_template, request, redirect, url_for, flash, abort, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash

try:
    import docker
    from docker.errors import DockerException
except ImportError:
    docker = None
    DockerException = Exception

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SKVM_SECRET_KEY", "change-this-secret-in-production")
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///" + os.path.join(BASE_DIR, "skvm.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"

docker_client = None
docker_error = None

def get_docker_client():
    global docker_client, docker_error
    if docker_client is not None:
        return docker_client
    if docker is None:
        docker_error = "docker SDK is not installed."
        return None
    try:
        client = docker.from_env()
        client.ping()
        docker_client = client
        docker_error = None
        return client
    except Exception as exc:
        docker_error = str(exc)
        return None

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), default="user", nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    vps = db.relationship("VPS", backref="owner", lazy=True, cascade="all, delete-orphan")

class VPS(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    node = db.Column(db.String(100), default="Local-Node-1", nullable=False)
    ram = db.Column(db.String(30), nullable=False)
    disk = db.Column(db.String(30), nullable=False)
    cpu = db.Column(db.String(30), nullable=False)
    os = db.Column(db.String(50), nullable=False)
    container_id = db.Column(db.String(128))
    tmate_token = db.Column(db.Text)
    status = db.Column(db.String(30), default="Provisioning", nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

class Settings(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    panel_name = db.Column(db.String(120), default="SKVM Panel")
    logo_url = db.Column(db.String(500), default="")
    banner_url = db.Column(db.String(500), default="")
    background_url = db.Column(db.String(500), default="")

@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))

@app.context_processor
def inject_globals():
    settings = Settings.query.first()
    return {
        "site": settings or Settings(panel_name="SKVM Panel"),
        "docker_online": get_docker_client() is not None,
        "docker_error": docker_error,
    }

def admin_required(view):
    @wraps(view)
    @login_required
    def wrapped(*args, **kwargs):
        if current_user.role != "admin":
            abort(403)
        return view(*args, **kwargs)
    return wrapped

def parse_amount(value, default=1):
    try:
        return max(1, int(re.search(r"\d+", str(value)).group()))
    except Exception:
        return default

def docker_limits(vps):
    # Docker memory is a hard limit; CPU is represented as CPU quota.
    ram_gb = parse_amount(vps.ram)
    cpu_cores = parse_amount(vps.cpu)
    return {
        "mem_limit": f"{ram_gb}g",
        "nano_cpus": cpu_cores * 1_000_000_000,
    }

def create_container_and_tmate(vps_id):
    with app.app_context():
        vps = db.session.get(VPS, vps_id)
        if not vps:
            return

        client = get_docker_client()
        if not client:
            vps.status = "Docker Unavailable"
            vps.tmate_token = "Docker socket unavailable. Start Docker and redeploy this VPS."
            db.session.commit()
            return

        image = "ubuntu:22.04" if "22.04" in vps.os else "ubuntu:20.04"
        name = f"skvm-vps-{vps.id}-{secrets.token_hex(3)}"

        try:
            try:
                client.images.get(image)
            except Exception:
                client.images.pull(image)

            limits = docker_limits(vps)
            container = client.containers.run(
                image,
                command=["bash", "-lc", "sleep infinity"],
                name=name,
                detach=True,
                tty=True,
                stdin_open=True,
                mem_limit=limits["mem_limit"],
                nano_cpus=limits["nano_cpus"],
                labels={"com.skvm.vps_id": str(vps.id), "com.skvm.managed": "true"},
            )
            vps.container_id = container.id
            vps.status = "Installing tmate"
            db.session.commit()

            # Install tmate inside the selected Ubuntu image.
            install_cmd = (
                "export DEBIAN_FRONTEND=noninteractive; "
                "apt-get update -y >/dev/null 2>&1 && "
                "apt-get install -y tmate openssh-client >/dev/null 2>&1 && "
                "tmate -S /tmp/tmate.sock new-session -d && "
                "tmate -S /tmp/tmate.sock wait-for-server && "
                "tmate -S /tmp/tmate.sock display -p '#{tmate_ssh}'"
            )
            result = container.exec_run(["bash", "-lc", install_cmd], demux=False)
            output = (result.output or b"").decode("utf-8", "replace").strip()

            # tmate output can vary. Extract an SSH URI when available.
            match = re.search(r"(ssh\s+tmate-[^\s]+@[^\s]+)", output)
            if not match:
                match = re.search(r"(ssh\s+[-\w@.:]+)", output)

            token = match.group(1) if match else output[-500:]
            if not token:
                token = "tmate installed, but no SSH session string was returned."

            vps.tmate_token = token
            vps.status = "Active"
            db.session.commit()

        except Exception as exc:
            vps.status = "Error"
            vps.tmate_token = f"Provisioning error: {exc}"
            db.session.commit()
            try:
                if vps.container_id:
                    client.containers.get(vps.container_id).remove(force=True)
            except Exception:
                pass

def seed_database():
    db.create_all()
    admin = User.query.filter_by(username="admin").first()
    if not admin:
        admin = User(
            username="admin",
            password_hash=generate_password_hash("admin123"),
            role="admin",
        )
        db.session.add(admin)
    elif admin.role != "admin":
        admin.role = "admin"

    if not Settings.query.first():
        db.session.add(Settings(panel_name="SKVM Panel"))
    db.session.commit()

@app.route("/")
def starter():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))
    return render_template("starter.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password_hash, password):
            login_user(user)
            return redirect(request.args.get("next") or url_for("dashboard"))
        flash("Invalid username or password.", "error")
    return render_template("login.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if len(username) < 3 or len(password) < 6:
            flash("Username must be 3+ characters and password 6+ characters.", "error")
        elif User.query.filter_by(username=username).first():
            flash("That username is already registered.", "error")
        else:
            user = User(username=username, password_hash=generate_password_hash(password), role="user")
            db.session.add(user)
            db.session.commit()
            flash("Account created. You can now sign in.", "success")
            return redirect(url_for("login"))
    return render_template("register.html")

@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("starter"))

@app.route("/dashboard")
@login_required
def dashboard():
    vps_list = VPS.query.filter_by(user_id=current_user.id).order_by(VPS.created_at.desc()).all()
    return render_template("dashboard.html", vps_list=vps_list)

@app.route("/myvps")
@login_required
def myvps():
    vps_list = VPS.query.filter_by(user_id=current_user.id).order_by(VPS.created_at.desc()).all()
    return render_template("myvps.html", vps_list=vps_list)

@app.route("/vps/<int:vps_id>")
@login_required
def vps_details(vps_id):
    vps = db.session.get(VPS, vps_id)
    if not vps or (vps.user_id != current_user.id and current_user.role != "admin"):
        abort(404)
    return render_template("vps_details.html", vps=vps)

@app.route("/vps/<int:vps_id>/action/<action>", methods=["POST"])
@login_required
def vps_action(vps_id, action):
    vps = db.session.get(VPS, vps_id)
    if not vps or (vps.user_id != current_user.id and current_user.role != "admin"):
        abort(404)

    client = get_docker_client()
    if not client or not vps.container_id:
        flash("Docker is unavailable or this VPS has no container.", "error")
        return redirect(url_for("vps_details", vps_id=vps.id))

    try:
        container = client.containers.get(vps.container_id)
        if action == "start":
            container.start()
            vps.status = "Active"
        elif action == "stop":
            container.stop()
            vps.status = "Stopped"
        elif action == "restart":
            container.restart()
            vps.status = "Active"
        else:
            abort(400)
        db.session.commit()
        flash(f"VPS {action} command completed.", "success")
    except Exception as exc:
        flash(f"Docker action failed: {exc}", "error")
    return redirect(url_for("vps_details", vps_id=vps.id))

@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    if request.method == "POST":
        password = request.form.get("password", "")
        confirm = request.form.get("confirm_password", "")
        if len(password) < 6:
            flash("New password must be at least 6 characters.", "error")
        elif password != confirm:
            flash("Passwords do not match.", "error")
        else:
            current_user.password_hash = generate_password_hash(password)
            db.session.commit()
            flash("Password updated.", "success")
            return redirect(url_for("profile"))
    return render_template("profile.html")

@app.route("/create-vps", methods=["GET", "POST"])
@admin_required
def create_vps():
    users = User.query.order_by(User.username.asc()).all()
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        user_id = request.form.get("user_id", type=int)
        node = request.form.get("node", "Local-Node-1")
        ram = request.form.get("ram", "1GB")
        disk = request.form.get("disk", "10GB")
        cpu = request.form.get("cpu", "1 Core")
        os_name = request.form.get("os", "Ubuntu 22.04")

        if not name or not user_id or not db.session.get(User, user_id):
            flash("Provide a VPS name and valid target user.", "error")
            return render_template("create_vps.html", users=users)

        vps = VPS(
            name=name, user_id=user_id, node=node, ram=ram,
            disk=disk, cpu=cpu, os=os_name, status="Provisioning"
        )
        db.session.add(vps)
        db.session.commit()
        threading.Thread(target=create_container_and_tmate, args=(vps.id,), daemon=True).start()
        flash(f"{name} deployment started in the background.", "success")
        return redirect(url_for("vps_details", vps_id=vps.id))
    return render_template("create_vps.html", users=users)

@app.route("/admin")
@admin_required
def admin_dashboard():
    client = get_docker_client()
    containers = []
    running = 0
    if client:
        try:
            containers = client.containers.list(all=True, filters={"label": "com.skvm.managed=true"})
            running = sum(1 for c in containers if c.status == "running")
        except Exception:
            pass
    return render_template(
        "admin_dashboard.html",
        users_count=User.query.count(),
        vps_count=VPS.query.count(),
        running_count=running,
        containers_count=len(containers),
        docker_online=client is not None,
        recent_vps=VPS.query.order_by(VPS.created_at.desc()).limit(8).all(),
    )

@app.route("/user-management")
@admin_required
def user_management():
    users = User.query.order_by(User.created_at.desc()).all()
    return render_template("user_management.html", users=users)

@app.route("/user-management/<int:user_id>/role", methods=["POST"])
@admin_required
def change_role(user_id):
    user = db.session.get(User, user_id)
    if not user or user.id == current_user.id:
        flash("That account cannot be changed here.", "error")
        return redirect(url_for("user_management"))
    user.role = "admin" if user.role == "user" else "user"
    db.session.commit()
    flash(f"{user.username} is now {user.role}.", "success")
    return redirect(url_for("user_management"))

@app.route("/user-management/<int:user_id>/delete", methods=["POST"])
@admin_required
def delete_user(user_id):
    user = db.session.get(User, user_id)
    if not user or user.id == current_user.id:
        flash("That account cannot be deleted.", "error")
        return redirect(url_for("user_management"))
    client = get_docker_client()
    for vps in list(user.vps):
        if client and vps.container_id:
            try:
                client.containers.get(vps.container_id).remove(force=True)
            except Exception:
                pass
    db.session.delete(user)
    db.session.commit()
    flash("User deleted.", "success")
    return redirect(url_for("user_management"))

@app.route("/settings", methods=["GET", "POST"])
@admin_required
def settings():
    site = Settings.query.first()
    if request.method == "POST":
        site.panel_name = request.form.get("panel_name", "SKVM Panel").strip() or "SKVM Panel"
        site.logo_url = request.form.get("logo_url", "").strip()
        site.banner_url = request.form.get("banner_url", "").strip()
        site.background_url = request.form.get("background_url", "").strip()
        db.session.commit()
        flash("Panel settings saved.", "success")
        return redirect(url_for("settings"))
    return render_template("settings.html", settings=site)

@app.errorhandler(403)
def forbidden(_):
    return render_template("login.html", error_title="Access denied"), 403

with app.app_context():
    seed_database()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5555, debug=False)
